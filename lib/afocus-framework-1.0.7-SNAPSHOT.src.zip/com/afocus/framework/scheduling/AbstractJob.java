/*  1:   */ package com.afocus.framework.scheduling;
/*  2:   */ 
/*  3:   */ import org.quartz.Job;
/*  4:   */ import org.quartz.JobDetail;
/*  5:   */ import org.quartz.JobExecutionContext;
/*  6:   */ import org.quartz.JobExecutionException;
/*  7:   */ import org.quartz.JobKey;
/*  8:   */ import org.slf4j.Logger;
/*  9:   */ import org.slf4j.LoggerFactory;
/* 10:   */ 
/* 11:   */ public abstract class AbstractJob
/* 12:   */   implements Job
/* 13:   */ {
/* 14:14 */   protected static final Logger log = LoggerFactory.getLogger(AbstractJob.class);
/* 15:   */   
/* 16:   */   public final void execute(JobExecutionContext context)
/* 17:   */     throws JobExecutionException
/* 18:   */   {
/* 19:18 */     String identity = context.getJobDetail().getKey().getName();
/* 20:   */     
/* 21:20 */     log.debug("===========系统提示：将开始进入执行《" + identity + "》的定时业务=============");
/* 22:   */     
/* 23:   */ 
/* 24:23 */     boolean isReady = preExecute(identity);
/* 25:25 */     if (isReady)
/* 26:   */     {
/* 27:26 */       Exception exception = null;
/* 28:   */       try
/* 29:   */       {
/* 30:28 */         execute0(identity);
/* 31:   */       }
/* 32:   */       catch (Exception e)
/* 33:   */       {
/* 34:30 */         exception = e;
/* 35:31 */         log.error("定时任务执行发生异常,任务标识 {}", identity, e);
/* 36:   */       }
/* 37:34 */       postExecute(identity, exception);
/* 38:   */     }
/* 39:37 */     log.debug("===========系统提示：《" + identity + "》的定时业务执行完成了!=============");
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected abstract void execute0(String paramString);
/* 43:   */   
/* 44:   */   protected boolean preExecute(String identity)
/* 45:   */   {
/* 46:49 */     return true;
/* 47:   */   }
/* 48:   */   
/* 49:   */   protected void postExecute(String identity, Exception exception) {}
/* 50:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.AbstractJob
 * JD-Core Version:    0.7.0.1
 */