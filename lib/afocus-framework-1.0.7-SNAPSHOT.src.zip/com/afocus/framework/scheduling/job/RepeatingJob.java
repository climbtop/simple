/*  1:   */ package com.afocus.framework.scheduling.job;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ 
/*  5:   */ public class RepeatingJob
/*  6:   */   extends BaseJob
/*  7:   */ {
/*  8:   */   private final Date startTime;
/*  9:   */   private final int interval;
/* 10:15 */   private int repeatCount = -1;
/* 11:   */   
/* 12:   */   public RepeatingJob(String identity, String className, Date startTime, int interval)
/* 13:   */   {
/* 14:27 */     super(identity, className);
/* 15:28 */     this.startTime = startTime;
/* 16:29 */     this.interval = interval;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public RepeatingJob(String identity, String className, Date startTime, int interval, int repeatCount)
/* 20:   */   {
/* 21:33 */     super(identity, className);
/* 22:34 */     this.startTime = startTime;
/* 23:35 */     this.interval = interval;
/* 24:36 */     this.repeatCount = repeatCount;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String toString()
/* 28:   */   {
/* 29:42 */     return String.format("Identity: %s, StartTime:%s, Interval:%s,RepeatCount:%d,ClassName:%s", new Object[] {
/* 30:43 */       getIdentity(), 
/* 31:44 */       getStartTime(), 
/* 32:45 */       Integer.valueOf(getInterval()), 
/* 33:46 */       Integer.valueOf(getRepeatCount()), 
/* 34:47 */       getClassName() });
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Date getStartTime()
/* 38:   */   {
/* 39:57 */     return this.startTime;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int getInterval()
/* 43:   */   {
/* 44:66 */     return this.interval;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public int getRepeatCount()
/* 48:   */   {
/* 49:75 */     return this.repeatCount;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.job.RepeatingJob
 * JD-Core Version:    0.7.0.1
 */