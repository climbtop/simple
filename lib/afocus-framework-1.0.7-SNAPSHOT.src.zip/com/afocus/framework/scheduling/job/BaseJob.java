/*  1:   */ package com.afocus.framework.scheduling.job;
/*  2:   */ 
/*  3:   */ public abstract class BaseJob
/*  4:   */ {
/*  5:   */   private final String identity;
/*  6:   */   private final String className;
/*  7:   */   
/*  8:   */   public BaseJob(String identity, String className)
/*  9:   */   {
/* 10:13 */     this.identity = identity;
/* 11:14 */     this.className = className;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getIdentity()
/* 15:   */   {
/* 16:18 */     return this.identity;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getClassName()
/* 20:   */   {
/* 21:22 */     return this.className;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.job.BaseJob
 * JD-Core Version:    0.7.0.1
 */