/*  1:   */ package com.afocus.framework.scheduling.job;
/*  2:   */ 
/*  3:   */ public class OneTimeJob
/*  4:   */   extends BaseJob
/*  5:   */ {
/*  6:   */   public OneTimeJob(String identity, String className)
/*  7:   */   {
/*  8: 9 */     super(identity, className);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public String toString()
/* 12:   */   {
/* 13:15 */     return String.format("Identity: %s, ClassName:%s", new Object[] { getIdentity(), getClassName() });
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.job.OneTimeJob
 * JD-Core Version:    0.7.0.1
 */