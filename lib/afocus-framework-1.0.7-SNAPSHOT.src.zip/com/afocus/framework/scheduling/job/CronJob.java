/*  1:   */ package com.afocus.framework.scheduling.job;
/*  2:   */ 
/*  3:   */ public class CronJob
/*  4:   */   extends BaseJob
/*  5:   */ {
/*  6:   */   private final String cron;
/*  7:   */   
/*  8:   */   public CronJob(String identity, String className, String cron)
/*  9:   */   {
/* 10:16 */     super(identity, className);
/* 11:17 */     this.cron = cron;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getCron()
/* 15:   */   {
/* 16:26 */     return this.cron;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String toString()
/* 20:   */   {
/* 21:31 */     return String.format("Identity: %s, Cron:%s, ClassName:%s", new Object[] { getIdentity(), getCron(), getClassName() });
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.job.CronJob
 * JD-Core Version:    0.7.0.1
 */