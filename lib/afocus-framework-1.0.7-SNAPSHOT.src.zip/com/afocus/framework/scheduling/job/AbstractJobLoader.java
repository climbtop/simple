/*  1:   */ package com.afocus.framework.scheduling.job;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.scheduling.JobLoader;
/*  4:   */ import com.afocus.framework.scheduling.JobScheduler;
/*  5:   */ import java.util.Date;
/*  6:   */ import java.util.List;
/*  7:   */ import org.slf4j.Logger;
/*  8:   */ import org.slf4j.LoggerFactory;
/*  9:   */ 
/* 10:   */ public abstract class AbstractJobLoader
/* 11:   */   implements JobLoader
/* 12:   */ {
/* 13:16 */   private static final Logger log = LoggerFactory.getLogger(AbstractJobLoader.class);
/* 14:   */   
/* 15:   */   public void loadJobs(JobScheduler scheduler)
/* 16:   */   {
/* 17:   */     try
/* 18:   */     {
/* 19:21 */       log.info("JobLoader 加载任务启动 {}", new Date());
/* 20:22 */       List<BaseJob> entities = getAllJobEntities();
/* 21:23 */       if (entities == null) {
/* 22:23 */         return;
/* 23:   */       }
/* 24:25 */       log.info("JobLoader 共 {}个有效任务", Integer.valueOf(entities.size()));
/* 25:27 */       for (BaseJob job : entities) {
/* 26:28 */         if (scheduler.scheduleJob(job)) {
/* 27:29 */           log.info("JobLoader 添加定时任务 {}", job.toString());
/* 28:   */         }
/* 29:   */       }
/* 30:32 */       log.info("JobLoader 加载任务结束 {}", new Date());
/* 31:   */     }
/* 32:   */     catch (Exception e)
/* 33:   */     {
/* 34:34 */       e.printStackTrace();
/* 35:35 */       log.error("AbstractJobLoader加载任务异常", e);
/* 36:   */     }
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected abstract List<BaseJob> getAllJobEntities();
/* 40:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.job.AbstractJobLoader
 * JD-Core Version:    0.7.0.1
 */