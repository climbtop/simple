/*   1:    */ package com.afocus.framework.scheduling;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.scheduling.job.BaseJob;
/*   4:    */ import com.afocus.framework.scheduling.job.CronJob;
/*   5:    */ import com.afocus.framework.scheduling.job.RepeatingJob;
/*   6:    */ import java.util.Date;
/*   7:    */ import java.util.Timer;
/*   8:    */ import java.util.TimerTask;
/*   9:    */ import org.quartz.CronScheduleBuilder;
/*  10:    */ import org.quartz.CronTrigger;
/*  11:    */ import org.quartz.Job;
/*  12:    */ import org.quartz.JobBuilder;
/*  13:    */ import org.quartz.JobDetail;
/*  14:    */ import org.quartz.JobKey;
/*  15:    */ import org.quartz.Scheduler;
/*  16:    */ import org.quartz.SchedulerException;
/*  17:    */ import org.quartz.SimpleScheduleBuilder;
/*  18:    */ import org.quartz.SimpleTrigger;
/*  19:    */ import org.quartz.TriggerBuilder;
/*  20:    */ import org.quartz.impl.StdSchedulerFactory;
/*  21:    */ import org.quartz.impl.triggers.SimpleTriggerImpl;
/*  22:    */ import org.slf4j.Logger;
/*  23:    */ import org.slf4j.LoggerFactory;
/*  24:    */ 
/*  25:    */ public class JobScheduler
/*  26:    */ {
/*  27: 26 */   private static final Logger log = LoggerFactory.getLogger(JobScheduler.class);
/*  28:    */   private Scheduler scheduler;
/*  29:    */   private Timer timer;
/*  30:    */   private JobLoader loader;
/*  31: 34 */   volatile boolean inited = false;
/*  32:    */   
/*  33:    */   public JobScheduler() {}
/*  34:    */   
/*  35:    */   public JobScheduler(JobLoader loader)
/*  36:    */   {
/*  37: 50 */     this.loader = loader;
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected static JobDetail createJobDetail(String identity, String className)
/*  41:    */     throws ClassNotFoundException
/*  42:    */   {
/*  43: 63 */     Class<?> clazz = Class.forName(className);
/*  44: 64 */     return JobBuilder.newJob(clazz.asSubclass(Job.class)).withIdentity(identity, "DEFAULT").build();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public synchronized void init()
/*  48:    */   {
/*  49:    */     try
/*  50:    */     {
/*  51: 73 */       if (this.inited) {
/*  52: 73 */         return;
/*  53:    */       }
/*  54: 74 */       this.inited = true;
/*  55: 75 */       this.scheduler = StdSchedulerFactory.getDefaultScheduler();
/*  56: 76 */       if (this.loader != null)
/*  57:    */       {
/*  58: 78 */         final JobScheduler scheduler = this;
/*  59: 79 */         if (this.timer == null) {
/*  60: 79 */           this.timer = new Timer("jobLoader_timer", true);
/*  61:    */         }
/*  62: 81 */         this.timer.scheduleAtFixedRate(new TimerTask()
/*  63:    */         {
/*  64:    */           public void run()
/*  65:    */           {
/*  66: 84 */             JobScheduler.this.loader.loadJobs(scheduler);
/*  67:    */           }
/*  68: 84 */         }, 5000L, 600000L);
/*  69:    */       }
/*  70: 88 */       if (!this.scheduler.isStarted()) {
/*  71: 89 */         this.scheduler.start();
/*  72:    */       }
/*  73: 91 */       log.debug("调度触发器启动成功。");
/*  74:    */     }
/*  75:    */     catch (Exception e)
/*  76:    */     {
/*  77: 93 */       log.error("调度触发器启动异常。", e);
/*  78: 94 */       destroy();
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void destroy()
/*  83:    */   {
/*  84:    */     try
/*  85:    */     {
/*  86:103 */       this.inited = false;
/*  87:104 */       if (this.scheduler != null) {
/*  88:105 */         this.scheduler.shutdown(true);
/*  89:    */       }
/*  90:107 */       if (this.timer != null)
/*  91:    */       {
/*  92:108 */         this.timer.cancel();
/*  93:109 */         this.timer = null;
/*  94:    */       }
/*  95:    */     }
/*  96:    */     catch (Exception e)
/*  97:    */     {
/*  98:112 */       log.error("销毁调度异常。", e);
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean scheduleJob(BaseJob job)
/* 103:    */   {
/* 104:122 */     if (existsJob(job.getIdentity())) {
/* 105:123 */       return false;
/* 106:    */     }
/* 107:124 */     if ((job instanceof CronJob))
/* 108:    */     {
/* 109:125 */       CronJob cronJob = (CronJob)job;
/* 110:126 */       return scheduleJob(cronJob.getIdentity(), cronJob.getClassName(), cronJob.getCron());
/* 111:    */     }
/* 112:127 */     if ((job instanceof RepeatingJob))
/* 113:    */     {
/* 114:128 */       RepeatingJob repeat = (RepeatingJob)job;
/* 115:129 */       return scheduleJob(repeat.getIdentity(), repeat.getClassName(), repeat
/* 116:130 */         .getStartTime(), repeat.getInterval(), repeat.getRepeatCount());
/* 117:    */     }
/* 118:132 */     return scheduleJob(job.getIdentity(), job.getClassName());
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean scheduleJob(String identity, String className)
/* 122:    */   {
/* 123:    */     try
/* 124:    */     {
/* 125:147 */       SimpleTriggerImpl trigger = new SimpleTriggerImpl();
/* 126:148 */       trigger.setName(identity + "_trigger");
/* 127:149 */       trigger.setJobName(identity);
/* 128:150 */       trigger.setGroup("DEFAULT");
/* 129:    */       
/* 130:152 */       JobDetail jobDetail = createJobDetail(identity, className);
/* 131:    */       
/* 132:154 */       this.scheduler.scheduleJob(jobDetail, trigger);
/* 133:155 */       log.debug("加入调度对象成功：identity=" + identity);
/* 134:156 */       return true;
/* 135:    */     }
/* 136:    */     catch (SchedulerException|ClassNotFoundException e)
/* 137:    */     {
/* 138:158 */       String errorMsg = "执行调度对象异常：identity=" + identity;
/* 139:159 */       log.error(errorMsg, e);
/* 140:160 */       throw new RuntimeException(errorMsg + e.getMessage());
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   public boolean scheduleJob(String identity, String className, Date startTime, int repeatInterval, int repeatCount)
/* 145:    */   {
/* 146:    */     try
/* 147:    */     {
/* 148:190 */       SimpleTrigger trigger = (SimpleTrigger)TriggerBuilder.newTrigger().withIdentity(identity + "_trigger", "DEFAULT").startAt(startTime).withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(repeatInterval).withRepeatCount(repeatCount)).build();
/* 149:    */       
/* 150:192 */       JobDetail jobDetail = createJobDetail(identity, className);
/* 151:193 */       this.scheduler.scheduleJob(jobDetail, trigger);
/* 152:    */       
/* 153:195 */       log.debug("加入调度对象成功：identity=" + identity + ", 启动时间" + startTime + "，每隔" + repeatInterval + "秒后进行循环！");
/* 154:196 */       return true;
/* 155:    */     }
/* 156:    */     catch (SchedulerException|ClassNotFoundException e)
/* 157:    */     {
/* 158:199 */       String errorMsg = "执行调度对象异常：identity=" + identity;
/* 159:200 */       log.error(errorMsg, e);
/* 160:201 */       throw new RuntimeException(errorMsg, e);
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean scheduleJob(String identity, String cron, String className)
/* 165:    */   {
/* 166:    */     try
/* 167:    */     {
/* 168:215 */       JobDetail jobDetail = createJobDetail(identity, className);
/* 169:    */       
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:228 */       CronTrigger trigger = (CronTrigger)TriggerBuilder.newTrigger().withIdentity(identity + "_trigger", "DEFAULT").withSchedule(CronScheduleBuilder.cronSchedule(cron)).build();
/* 182:    */       
/* 183:    */ 
/* 184:231 */       this.scheduler.scheduleJob(jobDetail, trigger);
/* 185:    */       
/* 186:233 */       log.debug("加入调度对象成功：identity=" + identity + ",cron=" + cron);
/* 187:    */       
/* 188:235 */       return true;
/* 189:    */     }
/* 190:    */     catch (ClassNotFoundException e)
/* 191:    */     {
/* 192:241 */       e.printStackTrace();
/* 193:242 */       log.error("添加调度任务失败", e);
/* 194:243 */       throw new RuntimeException("找不到类" + className, e);
/* 195:    */     }
/* 196:    */     catch (SchedulerException e)
/* 197:    */     {
/* 198:245 */       e.printStackTrace();
/* 199:246 */       log.error("添加调度任务失败", e);
/* 200:247 */       throw new RuntimeException("添加调度任务失败", e);
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean deleteJob(String identity)
/* 205:    */   {
/* 206:    */     try
/* 207:    */     {
/* 208:259 */       boolean flag = this.scheduler.deleteJob(JobKey.jobKey(identity, "DEFAULT"));
/* 209:260 */       log.debug("删除调度对象成功：identity=" + identity);
/* 210:261 */       return flag;
/* 211:    */     }
/* 212:    */     catch (SchedulerException e)
/* 213:    */     {
/* 214:263 */       String errorMsg = "删除调度对象异常：identity=" + identity;
/* 215:264 */       log.error(errorMsg, e);
/* 216:265 */       throw new RuntimeException(errorMsg + e.getMessage());
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean existsJob(String identity)
/* 221:    */   {
/* 222:    */     try
/* 223:    */     {
/* 224:276 */       JobDetail job = this.scheduler.getJobDetail(JobKey.jobKey(identity, "DEFAULT"));
/* 225:277 */       return null != job;
/* 226:    */     }
/* 227:    */     catch (SchedulerException e)
/* 228:    */     {
/* 229:279 */       String errorMsg = "判断调度对象是否存在异常：identity=" + identity;
/* 230:280 */       log.error(errorMsg, e);
/* 231:281 */       throw new RuntimeException(errorMsg + e.getMessage());
/* 232:    */     }
/* 233:    */   }
/* 234:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.JobScheduler
 * JD-Core Version:    0.7.0.1
 */