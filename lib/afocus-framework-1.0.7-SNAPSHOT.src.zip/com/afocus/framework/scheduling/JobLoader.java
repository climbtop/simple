package com.afocus.framework.scheduling;

public abstract interface JobLoader
{
  public abstract void loadJobs(JobScheduler paramJobScheduler);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.scheduling.JobLoader
 * JD-Core Version:    0.7.0.1
 */