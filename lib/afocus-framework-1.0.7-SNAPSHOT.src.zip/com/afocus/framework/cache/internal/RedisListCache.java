/*   1:    */ package com.afocus.framework.cache.internal;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.cache.Cache;
/*   4:    */ import com.afocus.framework.cache.CacheSpec;
/*   5:    */ import com.afocus.framework.cache.RedisCache;
/*   6:    */ import com.afocus.framework.cache.loader.CacheLoader;
/*   7:    */ import com.alibaba.fastjson.JSON;
/*   8:    */ import com.alibaba.fastjson.JSONObject;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Set;
/*  13:    */ import org.apache.commons.lang3.StringUtils;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public class RedisListCache<V>
/*  18:    */   implements Cache<String, V>
/*  19:    */ {
/*  20: 25 */   private static final Logger log = LoggerFactory.getLogger(RedisListCache.class);
/*  21:    */   private final RedisCache redis;
/*  22:    */   private final CacheSpec<V> cacheSpec;
/*  23:    */   
/*  24:    */   public RedisListCache(RedisCache redis, CacheSpec<V> cacheSpec)
/*  25:    */   {
/*  26: 31 */     this.redis = redis;
/*  27: 32 */     this.cacheSpec = cacheSpec;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public V get(String key, CacheLoader<V> loader)
/*  31:    */   {
/*  32: 38 */     String _key = getInnerKey(key);
/*  33: 39 */     log.info("Key:{}", _key);
/*  34: 40 */     if (this.redis.exists(_key).booleanValue())
/*  35:    */     {
/*  36: 41 */       String data = this.redis.lpop(_key);
/*  37:    */       try
/*  38:    */       {
/*  39: 43 */         log.info("命中缓存，Key:{} Content:{}", _key, data);
/*  40: 44 */         return JSONObject.parseObject(data, this.cacheSpec.getClazz());
/*  41:    */       }
/*  42:    */       catch (Exception e)
/*  43:    */       {
/*  44: 46 */         log.error("获取缓存内容，并转成对象失败 Key:{}  Content:{}", _key, data);
/*  45:    */       }
/*  46:    */     }
/*  47: 50 */     V obj = loader.load();
/*  48: 51 */     log.info("装载数据，Key:{} Content:{}", _key, JSON.toJSONString(obj));
/*  49: 52 */     if (obj == null) {
/*  50: 52 */       return null;
/*  51:    */     }
/*  52: 53 */     set0(_key, obj);
/*  53: 54 */     return obj;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void set(String key, V value)
/*  57:    */   {
/*  58: 59 */     set0(getInnerKey(key), value);
/*  59:    */   }
/*  60:    */   
/*  61:    */   private void set0(String innerKey, V value)
/*  62:    */   {
/*  63: 64 */     this.redis.lpush(innerKey, new String[] { JSON.toJSONString(value) });
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void clear(String key)
/*  67:    */   {
/*  68: 69 */     this.redis.remove(getInnerKey(key));
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void clear(String key, V value) {}
/*  72:    */   
/*  73:    */   public boolean exists(String key)
/*  74:    */   {
/*  75: 79 */     return this.redis.exists(getInnerKey(key)).booleanValue();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Long incrBy(String key, Long value)
/*  79:    */   {
/*  80: 84 */     return this.redis.incrBy(getInnerKey(key), value);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Map<String, String> getAllMap(String key)
/*  84:    */   {
/*  85: 89 */     return Collections.emptyMap();
/*  86:    */   }
/*  87:    */   
/*  88:    */   private String getInnerKey(String key)
/*  89:    */   {
/*  90: 93 */     return StringUtils.join(new String[] { this.cacheSpec.getCollection(), ":", this.cacheSpec.getPrefix(), ":", key });
/*  91:    */   }
/*  92:    */   
/*  93:    */   public List<String> getAllList(String key)
/*  94:    */   {
/*  95: 98 */     String _key = getInnerKey(key);
/*  96: 99 */     log.info("Key:{}", _key);
/*  97:100 */     if (this.redis.exists(_key).booleanValue())
/*  98:    */     {
/*  99:101 */       List<String> list = this.redis.lrangeString(_key);
/* 100:    */       try
/* 101:    */       {
/* 102:103 */         log.info("命中缓存，Key:{} Content:{}", _key, JSONObject.toJSONString(list));
/* 103:104 */         return list;
/* 104:    */       }
/* 105:    */       catch (Exception localException) {}
/* 106:    */     }
/* 107:109 */     return Collections.emptyList();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Set<String> getAllSet(String key)
/* 111:    */   {
/* 112:114 */     return Collections.emptySet();
/* 113:    */   }
/* 114:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.internal.RedisListCache
 * JD-Core Version:    0.7.0.1
 */