/*   1:    */ package com.afocus.framework.cache.internal;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.cache.Cache;
/*   4:    */ import com.afocus.framework.cache.CacheSpec;
/*   5:    */ import com.afocus.framework.cache.RedisCache;
/*   6:    */ import com.afocus.framework.cache.loader.CacheLoader;
/*   7:    */ import com.alibaba.fastjson.JSON;
/*   8:    */ import com.alibaba.fastjson.JSONObject;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Set;
/*  13:    */ import org.apache.commons.lang3.StringUtils;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public class RedisSetCache<V>
/*  18:    */   implements Cache<String, V>
/*  19:    */ {
/*  20: 25 */   private static final Logger log = LoggerFactory.getLogger(RedisSetCache.class);
/*  21:    */   private final RedisCache redis;
/*  22:    */   private final CacheSpec<V> cacheSpec;
/*  23:    */   
/*  24:    */   public RedisSetCache(RedisCache redis, CacheSpec<V> cacheSpec)
/*  25:    */   {
/*  26: 31 */     this.redis = redis;
/*  27: 32 */     this.cacheSpec = cacheSpec;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public V get(String key, CacheLoader<V> loader)
/*  31:    */   {
/*  32: 38 */     String _key = getInnerKey(key);
/*  33: 39 */     log.info("Key:{}", _key);
/*  34: 40 */     if (this.redis.exists(_key).booleanValue())
/*  35:    */     {
/*  36: 41 */       String data = this.redis.spop(_key);
/*  37:    */       try
/*  38:    */       {
/*  39: 43 */         log.info("命中缓存，Key:{} Content:{}", _key, data);
/*  40: 44 */         return JSONObject.parseObject(data, this.cacheSpec.getClazz());
/*  41:    */       }
/*  42:    */       catch (Exception e)
/*  43:    */       {
/*  44: 46 */         log.error("获取缓存内容，并转成对象失败 Key:{}  Content:{}", _key, data);
/*  45:    */       }
/*  46:    */     }
/*  47: 50 */     V obj = loader.load();
/*  48: 51 */     log.info("装载数据，Key:{} Content:{}", _key, JSON.toJSONString(obj));
/*  49: 52 */     if (obj == null) {
/*  50: 52 */       return null;
/*  51:    */     }
/*  52: 53 */     set0(_key, obj);
/*  53: 54 */     return obj;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void set(String key, V value)
/*  57:    */   {
/*  58: 59 */     set0(getInnerKey(key), value);
/*  59:    */   }
/*  60:    */   
/*  61:    */   private void set0(String innerKey, V value)
/*  62:    */   {
/*  63: 63 */     this.redis.sadd(innerKey, JSON.toJSONString(value));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void clear(String key)
/*  67:    */   {
/*  68: 68 */     this.redis.remove(getInnerKey(key));
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void clear(String key, V value)
/*  72:    */   {
/*  73: 73 */     this.redis.srem(getInnerKey(key), new String[] { JSON.toJSONString(value) });
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean exists(String key)
/*  77:    */   {
/*  78: 78 */     return this.redis.exists(getInnerKey(key)).booleanValue();
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Long incrBy(String key, Long value)
/*  82:    */   {
/*  83: 83 */     return this.redis.incrBy(getInnerKey(key), value);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Map<String, String> getAllMap(String key)
/*  87:    */   {
/*  88: 88 */     return null;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private String getInnerKey(String key)
/*  92:    */   {
/*  93: 92 */     return StringUtils.join(new String[] { this.cacheSpec.getCollection(), ":", this.cacheSpec.getPrefix(), ":", key });
/*  94:    */   }
/*  95:    */   
/*  96:    */   public List<String> getAllList(String key)
/*  97:    */   {
/*  98: 97 */     return Collections.emptyList();
/*  99:    */   }
/* 100:    */   
/* 101:    */   public Set<String> getAllSet(String key)
/* 102:    */   {
/* 103:102 */     String _key = getInnerKey(key);
/* 104:103 */     log.info("Key:{}", _key);
/* 105:104 */     if (this.redis.exists(_key).booleanValue())
/* 106:    */     {
/* 107:105 */       Set<String> list = this.redis.smembers(_key);
/* 108:    */       try
/* 109:    */       {
/* 110:107 */         log.info("命中缓存，Key:{} Content:{}", _key, JSONObject.toJSONString(list));
/* 111:108 */         return list;
/* 112:    */       }
/* 113:    */       catch (Exception localException) {}
/* 114:    */     }
/* 115:113 */     return Collections.emptySet();
/* 116:    */   }
/* 117:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.internal.RedisSetCache
 * JD-Core Version:    0.7.0.1
 */