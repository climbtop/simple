/*   1:    */ package com.afocus.framework.cache.internal;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.cache.Cache;
/*   4:    */ import com.afocus.framework.cache.CacheSpec;
/*   5:    */ import com.afocus.framework.cache.RedisCache;
/*   6:    */ import com.afocus.framework.cache.loader.CacheLoader;
/*   7:    */ import com.alibaba.fastjson.JSON;
/*   8:    */ import com.alibaba.fastjson.JSONObject;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Set;
/*  13:    */ import org.apache.commons.lang3.StringUtils;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public class RedisHashCache<V>
/*  18:    */   implements Cache<String, V>
/*  19:    */ {
/*  20: 25 */   private static final Logger log = LoggerFactory.getLogger(RedisHashCache.class);
/*  21:    */   private final RedisCache redis;
/*  22:    */   private final CacheSpec<V> cacheSpec;
/*  23:    */   
/*  24:    */   public RedisHashCache(RedisCache redis, CacheSpec<V> cacheSpec)
/*  25:    */   {
/*  26: 31 */     this.redis = redis;
/*  27: 32 */     this.cacheSpec = cacheSpec;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public V get(String key, CacheLoader<V> loader)
/*  31:    */   {
/*  32: 37 */     String _field = getInnerKey(key);
/*  33: 39 */     if (this.redis.hexists(this.cacheSpec.getCollection(), _field).booleanValue())
/*  34:    */     {
/*  35: 40 */       String data = this.redis.hget(this.cacheSpec.getCollection(), _field);
/*  36:    */       try
/*  37:    */       {
/*  38: 42 */         log.info("命中缓存，Key:{} Content:{}", _field, data);
/*  39: 43 */         return JSONObject.parseObject(data, this.cacheSpec.getClazz());
/*  40:    */       }
/*  41:    */       catch (Exception e)
/*  42:    */       {
/*  43: 45 */         log.error("获取缓存内容，并转成对象失败 Key:{} Content:{}", _field, data);
/*  44:    */       }
/*  45:    */     }
/*  46: 49 */     V obj = loader.load();
/*  47: 50 */     log.info("装载数据，Key:{} Content:{}", _field, JSON.toJSONString(obj));
/*  48: 51 */     if (obj == null) {
/*  49: 51 */       return null;
/*  50:    */     }
/*  51: 52 */     set0(_field, obj);
/*  52: 53 */     return obj;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void set(String key, V value)
/*  56:    */   {
/*  57: 58 */     set0(getInnerKey(key), value);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private void set0(String innerKey, V value)
/*  61:    */   {
/*  62: 62 */     this.redis.hset(this.cacheSpec.getCollection(), innerKey, JSON.toJSONString(value));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void clear(String key)
/*  66:    */   {
/*  67: 67 */     this.redis.hdel(this.cacheSpec.getCollection(), new String[] { getInnerKey(key) });
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void clear(String key, V value) {}
/*  71:    */   
/*  72:    */   public boolean exists(String key)
/*  73:    */   {
/*  74: 77 */     return this.redis.hexists(this.cacheSpec.getCollection(), getInnerKey(key)).booleanValue();
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Long incrBy(String key, Long value)
/*  78:    */   {
/*  79: 82 */     return this.redis.hincrBy(this.cacheSpec.getCollection(), getInnerKey(key), value);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private String getInnerKey(String key)
/*  83:    */   {
/*  84: 86 */     return StringUtils.join(new String[] { this.cacheSpec.getPrefix(), ":", key });
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Map<String, String> getAllMap(String key)
/*  88:    */   {
/*  89: 91 */     String _field = getInnerKey(key);
/*  90: 93 */     if (this.redis.exists(this.cacheSpec.getCollection()).booleanValue())
/*  91:    */     {
/*  92: 94 */       Map<String, String> data = this.redis.getAllMap(this.cacheSpec.getCollection());
/*  93:    */       try
/*  94:    */       {
/*  95: 96 */         log.info("命中缓存，Key:{} Content:{}", JSON.toJSONString(data));
/*  96: 97 */         return data;
/*  97:    */       }
/*  98:    */       catch (Exception localException) {}
/*  99:    */     }
/* 100:102 */     return Collections.emptyMap();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public List<String> getAllList(String key)
/* 104:    */   {
/* 105:107 */     return Collections.emptyList();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Set<String> getAllSet(String key)
/* 109:    */   {
/* 110:112 */     return Collections.emptySet();
/* 111:    */   }
/* 112:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.internal.RedisHashCache
 * JD-Core Version:    0.7.0.1
 */