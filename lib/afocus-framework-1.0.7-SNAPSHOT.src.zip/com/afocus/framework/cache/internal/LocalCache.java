/*   1:    */ package com.afocus.framework.cache.internal;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.cache.Cache;
/*   4:    */ import com.afocus.framework.cache.CacheSpec;
/*   5:    */ import com.afocus.framework.cache.RedisCache;
/*   6:    */ import com.afocus.framework.cache.loader.CacheLoader;
/*   7:    */ import com.alibaba.fastjson.JSONObject;
/*   8:    */ import java.util.Collections;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Set;
/*  12:    */ import java.util.concurrent.ConcurrentHashMap;
/*  13:    */ import org.apache.commons.lang3.StringUtils;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public class LocalCache<V>
/*  18:    */   implements Cache<String, V>
/*  19:    */ {
/*  20: 23 */   private static final Logger log = LoggerFactory.getLogger(LocalCache.class);
/*  21: 26 */   private static Map<String, LocalCacheItem> innerCache = new ConcurrentHashMap();
/*  22:    */   private final RedisCache redis;
/*  23:    */   private final CacheSpec<V> cacheSpec;
/*  24:    */   
/*  25:    */   public LocalCache(RedisCache redis, CacheSpec<V> cacheSpec)
/*  26:    */   {
/*  27: 33 */     this.redis = redis;
/*  28: 34 */     this.cacheSpec = cacheSpec;
/*  29:    */   }
/*  30:    */   
/*  31:    */   private LocalCacheItem<V> set0(String innerKey, V v, boolean refreshVersion)
/*  32:    */   {
/*  33: 45 */     log.debug("查询数据, holder:" + JSONObject.toJSONString(this.cacheSpec));
/*  34:    */     
/*  35: 47 */     long version = -1L;
/*  36: 49 */     if (refreshVersion)
/*  37:    */     {
/*  38: 51 */       version = this.redis.hincrBy(this.cacheSpec.getCollection(), innerKey, Long.valueOf(1L)).longValue();
/*  39:    */       
/*  40: 53 */       log.info("更新Redis, id:{}, version:{}, object:{}", new Object[] { innerKey, 
/*  41:    */       
/*  42: 55 */         Long.valueOf(version), 
/*  43: 56 */         JSONObject.toJSONString(v) });
/*  44:    */     }
/*  45:    */     else
/*  46:    */     {
/*  47: 58 */       version = getRemoteVersion(this.redis, innerKey);
/*  48:    */     }
/*  49: 60 */     LocalCacheItem<V> local = new LocalCacheItem(v, version);
/*  50:    */     
/*  51: 62 */     log.debug("更新本地");
/*  52: 63 */     innerCache.put(innerKey, local);
/*  53:    */     
/*  54: 65 */     return local;
/*  55:    */   }
/*  56:    */   
/*  57:    */   private long getRemoteVersion(RedisCache redis, String versionKey)
/*  58:    */   {
/*  59:    */     try
/*  60:    */     {
/*  61: 77 */       String result = redis.hget(this.cacheSpec.getCollection(), versionKey);
/*  62: 78 */       if (StringUtils.isEmpty(result)) {
/*  63: 79 */         return 0L;
/*  64:    */       }
/*  65: 81 */       return Long.parseLong(result);
/*  66:    */     }
/*  67:    */     catch (Exception e)
/*  68:    */     {
/*  69: 83 */       log.error(e.getMessage());
/*  70:    */     }
/*  71: 84 */     return 0L;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public V get(String key, CacheLoader<V> loader)
/*  75:    */   {
/*  76: 92 */     String _key = getInnerKey(key);
/*  77:    */     
/*  78:    */ 
/*  79: 95 */     long remoteVersion = getRemoteVersion(this.redis, _key);
/*  80: 97 */     if (innerCache.containsKey(_key))
/*  81:    */     {
/*  82: 98 */       LocalCacheItem<V> item = (LocalCacheItem)innerCache.get(_key);
/*  83:100 */       if (remoteVersion == 0L)
/*  84:    */       {
/*  85:101 */         log.info("redis 无版本记录，Reload，并刷新Redis版本");
/*  86:102 */         item = set0(_key, loader.load(), true);
/*  87:    */       }
/*  88:105 */       else if (item.getVersion() < remoteVersion)
/*  89:    */       {
/*  90:106 */         log.info("本地缓存失效, Reload, 不刷新Redis版本");
/*  91:107 */         item = set0(_key, loader.load(), false);
/*  92:    */       }
/*  93:    */       else
/*  94:    */       {
/*  95:109 */         log.info("本地缓存命中");
/*  96:    */       }
/*  97:112 */       return item.data;
/*  98:    */     }
/*  99:114 */     log.info("本地无缓存，Reload");
/* 100:    */     
/* 101:    */ 
/* 102:117 */     LocalCacheItem<V> item = set0(_key, loader.load(), remoteVersion < 1L);
/* 103:118 */     return item.data;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void set(String key, V value)
/* 107:    */   {
/* 108:124 */     set0(getInnerKey(key), value, true);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void clear(String key)
/* 112:    */   {
/* 113:129 */     innerCache.remove(getInnerKey(key));
/* 114:    */     
/* 115:131 */     this.redis.hincrBy(this.cacheSpec.getCollection(), getInnerKey(key), Long.valueOf(1L));
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void clear(String key, V value) {}
/* 119:    */   
/* 120:    */   public boolean exists(String key)
/* 121:    */   {
/* 122:141 */     return this.redis.hexists(this.cacheSpec.getCollection(), getInnerKey(key)).booleanValue();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Long incrBy(String key, Long value)
/* 126:    */   {
/* 127:146 */     throw new UnsupportedOperationException("本地缓存不支持自增操作");
/* 128:    */   }
/* 129:    */   
/* 130:    */   public Map<String, String> getAllMap(String key)
/* 131:    */   {
/* 132:151 */     return Collections.emptyMap();
/* 133:    */   }
/* 134:    */   
/* 135:    */   public List<String> getAllList(String key)
/* 136:    */   {
/* 137:156 */     return Collections.emptyList();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public Set<String> getAllSet(String key)
/* 141:    */   {
/* 142:161 */     return Collections.emptySet();
/* 143:    */   }
/* 144:    */   
/* 145:    */   private String getInnerKey(String key)
/* 146:    */   {
/* 147:165 */     return StringUtils.join(new String[] { this.cacheSpec.getCollection(), ":", this.cacheSpec.getPrefix(), ":", key });
/* 148:    */   }
/* 149:    */   
/* 150:    */   private static class LocalCacheItem<T>
/* 151:    */   {
/* 152:    */     private final T data;
/* 153:    */     private final long version;
/* 154:    */     
/* 155:    */     LocalCacheItem(T data, long version)
/* 156:    */     {
/* 157:178 */       this.data = data;
/* 158:179 */       this.version = version;
/* 159:    */     }
/* 160:    */     
/* 161:    */     public T getData()
/* 162:    */     {
/* 163:183 */       return this.data;
/* 164:    */     }
/* 165:    */     
/* 166:    */     public long getVersion()
/* 167:    */     {
/* 168:187 */       return this.version;
/* 169:    */     }
/* 170:    */   }
/* 171:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.internal.LocalCache
 * JD-Core Version:    0.7.0.1
 */