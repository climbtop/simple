package com.afocus.framework.cache;

public abstract interface Identifiable
{
  public abstract String identity();
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.Identifiable
 * JD-Core Version:    0.7.0.1
 */