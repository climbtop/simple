package com.afocus.framework.cache;

public enum CacheMode
{
  STRING,  LIST,  SET,  HASH,  LOCAL;
  
  private CacheMode() {}
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.CacheMode
 * JD-Core Version:    0.7.0.1
 */