/*   1:    */ package com.afocus.framework.cache;
/*   2:    */ 
/*   3:    */ public final class CacheSpec<T>
/*   4:    */ {
/*   5:    */   private final String collectionName;
/*   6:    */   private final String prefix;
/*   7:    */   private final Class<T> clazz;
/*   8:    */   private final int expire;
/*   9:    */   private final CacheMode cacheMode;
/*  10:    */   
/*  11:    */   protected CacheSpec(Class<T> clazz, String collectionName, String prefix, int expire, CacheMode cacheMode)
/*  12:    */   {
/*  13: 19 */     this.clazz = clazz;
/*  14: 20 */     this.collectionName = collectionName;
/*  15: 21 */     this.prefix = prefix;
/*  16: 22 */     this.expire = Math.max(expire, 0);
/*  17: 23 */     this.cacheMode = cacheMode;
/*  18:    */   }
/*  19:    */   
/*  20:    */   private static <T> CacheSpec<T> redis(Class<T> clazz, String collectionName, String prefix, CacheMode cacheMode)
/*  21:    */   {
/*  22: 36 */     return new CacheSpec(clazz, collectionName, prefix, 0, cacheMode);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static <T> CacheSpec<T> redisList(Class<T> clazz, String collectionName, String prefix)
/*  26:    */   {
/*  27: 48 */     return redis(clazz, collectionName, prefix, CacheMode.LIST);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <T> CacheSpec<T> redisHash(Class<T> clazz, String collectionName, String prefix)
/*  31:    */   {
/*  32: 60 */     return redis(clazz, collectionName, prefix, CacheMode.HASH);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <T> CacheSpec<T> redisSet(Class<T> clazz, String collectionName, String prefix)
/*  36:    */   {
/*  37: 72 */     return redis(clazz, collectionName, prefix, CacheMode.SET);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <T> CacheSpec<T> redisString(Class<T> clazz, String collectionName, String prefix, int expire)
/*  41:    */   {
/*  42: 99 */     return new CacheSpec(clazz, collectionName, prefix, expire, CacheMode.STRING);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <T> CacheSpec<T> local(Class<T> clazz, String collectionName, String prefix)
/*  46:    */   {
/*  47:111 */     return new CacheSpec(clazz, collectionName, prefix, 0, CacheMode.LOCAL);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getCollection()
/*  51:    */   {
/*  52:121 */     return this.collectionName;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Class<T> getClazz()
/*  56:    */   {
/*  57:130 */     return this.clazz;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getPrefix()
/*  61:    */   {
/*  62:140 */     return this.prefix;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int getExpire()
/*  66:    */   {
/*  67:149 */     return this.expire;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public CacheMode getCacheMode()
/*  71:    */   {
/*  72:153 */     return this.cacheMode;
/*  73:    */   }
/*  74:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.CacheSpec
 * JD-Core Version:    0.7.0.1
 */