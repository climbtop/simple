package com.afocus.framework.cache.wrapper;

public abstract interface CacheWrapper5<P1, P2, P3, P4, P5, V>
{
  public abstract V get(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4, P5 paramP5);
  
  public abstract void set(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4, P5 paramP5, V paramV);
  
  public abstract void clear(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4, P5 paramP5);
  
  public abstract boolean exists(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4, P5 paramP5);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.wrapper.CacheWrapper5
 * JD-Core Version:    0.7.0.1
 */