package com.afocus.framework.cache.wrapper;

public abstract interface CacheWrapper4<P1, P2, P3, P4, V>
{
  public abstract V get(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4);
  
  public abstract void set(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4, V paramV);
  
  public abstract void clear(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4);
  
  public abstract boolean exists(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.wrapper.CacheWrapper4
 * JD-Core Version:    0.7.0.1
 */