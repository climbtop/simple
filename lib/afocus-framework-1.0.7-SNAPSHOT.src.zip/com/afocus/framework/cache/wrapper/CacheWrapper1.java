package com.afocus.framework.cache.wrapper;

import com.afocus.framework.cache.entity.Identifiable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface CacheWrapper1<P extends Identifiable, V>
{
  public abstract V get(P paramP);
  
  public abstract void set(P paramP, V paramV);
  
  public abstract void clear(P paramP);
  
  public abstract boolean exists(P paramP);
  
  public abstract List<String> getAllList(P paramP);
  
  public abstract Map<String, String> getAllMap(P paramP);
  
  public abstract Set<String> getAllSet(P paramP);
  
  public abstract void clear(P paramP, V paramV);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.wrapper.CacheWrapper1
 * JD-Core Version:    0.7.0.1
 */