package com.afocus.framework.cache.loader;

public abstract interface CacheLoader4<P1, P2, P3, P4, V>
{
  public abstract V load(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.loader.CacheLoader4
 * JD-Core Version:    0.7.0.1
 */