package com.afocus.framework.cache.loader;

public abstract interface CacheLoader2<P1, P2, V>
{
  public abstract V load(P1 paramP1, P2 paramP2);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.loader.CacheLoader2
 * JD-Core Version:    0.7.0.1
 */