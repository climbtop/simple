package com.afocus.framework.cache.loader;

public abstract interface CacheLoader5<P1, P2, P3, P4, P5, V>
{
  public abstract V load(P1 paramP1, P2 paramP2, P3 paramP3, P4 paramP4, P5 paramP5);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.loader.CacheLoader5
 * JD-Core Version:    0.7.0.1
 */