package com.afocus.framework.cache.loader;

public abstract interface CacheLoader<V>
{
  public abstract V load();
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.loader.CacheLoader
 * JD-Core Version:    0.7.0.1
 */