package com.afocus.framework.cache.loader;

import com.afocus.framework.cache.entity.Identifiable;

public abstract interface CacheLoader1<P extends Identifiable, V>
{
  public abstract V load(P paramP);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.loader.CacheLoader1
 * JD-Core Version:    0.7.0.1
 */