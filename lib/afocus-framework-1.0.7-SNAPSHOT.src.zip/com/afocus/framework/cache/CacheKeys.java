/*  1:   */ package com.afocus.framework.cache;
/*  2:   */ 
/*  3:   */ import org.apache.commons.lang3.StringUtils;
/*  4:   */ 
/*  5:   */ public final class CacheKeys
/*  6:   */ {
/*  7:   */   public static String key(String appCode, MajorModule majorModule, String minorModule, String uniqueness)
/*  8:   */   {
/*  9:23 */     return StringUtils.join(new String[] { appCode, majorModule.getName(), minorModule, uniqueness }, '.');
/* 10:   */   }
/* 11:   */   
/* 12:   */   public static String key(String appCode, MajorModule majorModule, String minorModule)
/* 13:   */   {
/* 14:35 */     return StringUtils.join(new String[] { appCode, majorModule.getName(), minorModule }, '.');
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static String key(MajorModule majorModule, MinorModule minorModule, String uniqueness)
/* 18:   */   {
/* 19:47 */     return StringUtils.join(new String[] { majorModule.getName(), minorModule.getName(), uniqueness }, '.');
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static enum MajorModule
/* 23:   */   {
/* 24:51 */     AF("af"),  WLJLJ("wljlj"),  THC("thc"),  SYSTEM("sys"),  ACTIVITY("activity"),  CARD("card"),  CUSTOMER(""),  FAN("fan"),  MEDIA("media"),  MESSAGE("message"),  QRCODE("qrcode"),  MENU("menu"),  PERMISSION("permission"),  SMS("sms"),  WXACCOUNT("wxaccount"),  MALL("mall"),  SCRMMALL("scrmmall"),  TAG("tag"),  STATS("stats"),  ANALYSIS("analysis"),  SHOP("shop");
/* 25:   */     
/* 26:   */     private String name;
/* 27:   */     
/* 28:   */     private MajorModule(String name)
/* 29:   */     {
/* 30:77 */       this.name = name;
/* 31:   */     }
/* 32:   */     
/* 33:   */     public String getName()
/* 34:   */     {
/* 35:81 */       return this.name;
/* 36:   */     }
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static enum MinorModule
/* 40:   */   {
/* 41:86 */     WEBINFO("webinfo"),  ACTIVITYINFO("activityInfo"),  PRIZE("prize"),  ACTIVITY_PRIZE("activity_prize"),  ACTIVITY_WHITELIST("activity_whitelist");
/* 42:   */     
/* 43:   */     private String name;
/* 44:   */     
/* 45:   */     private MinorModule(String name)
/* 46:   */     {
/* 47:95 */       this.name = name;
/* 48:   */     }
/* 49:   */     
/* 50:   */     public String getName()
/* 51:   */     {
/* 52:99 */       return this.name;
/* 53:   */     }
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.CacheKeys
 * JD-Core Version:    0.7.0.1
 */