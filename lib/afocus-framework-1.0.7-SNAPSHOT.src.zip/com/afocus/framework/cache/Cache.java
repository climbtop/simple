package com.afocus.framework.cache;

import com.afocus.framework.cache.loader.CacheLoader;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface Cache<K, V>
{
  public abstract V get(K paramK, CacheLoader<V> paramCacheLoader);
  
  public abstract void set(K paramK, V paramV);
  
  public abstract void clear(K paramK);
  
  public abstract void clear(K paramK, V paramV);
  
  public abstract boolean exists(K paramK);
  
  public abstract Long incrBy(String paramString, Long paramLong);
  
  public abstract Map<String, String> getAllMap(K paramK);
  
  public abstract List<String> getAllList(K paramK);
  
  public abstract Set<String> getAllSet(K paramK);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.Cache
 * JD-Core Version:    0.7.0.1
 */