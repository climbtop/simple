/*  1:   */ package com.afocus.framework.cache.entity;
/*  2:   */ 
/*  3:   */ public class IdentityGenerator
/*  4:   */ {
/*  5:   */   public static final String separator = ":";
/*  6:   */   
/*  7:   */   public static String generate(Object... params)
/*  8:   */   {
/*  9:12 */     if ((params == null) || (params.length == 0)) {
/* 10:13 */       return "";
/* 11:   */     }
/* 12:14 */     if (params.length == 1) {
/* 13:15 */       return objectToString(params[0]);
/* 14:   */     }
/* 15:16 */     StringBuilder sb = new StringBuilder();
/* 16:17 */     for (Object obj : params)
/* 17:   */     {
/* 18:18 */       sb.append(objectToString(obj));
/* 19:19 */       sb.append(":");
/* 20:   */     }
/* 21:21 */     return sb.substring(0, sb.length() - 1);
/* 22:   */   }
/* 23:   */   
/* 24:   */   private static String objectToString(Object param)
/* 25:   */   {
/* 26:27 */     if ((param instanceof Integer)) {
/* 27:28 */       return Integer.toString(((Integer)param).intValue());
/* 28:   */     }
/* 29:29 */     if ((param instanceof Double)) {
/* 30:30 */       return Double.toString(((Double)param).doubleValue());
/* 31:   */     }
/* 32:31 */     if ((param instanceof Float)) {
/* 33:32 */       return Float.toString(((Float)param).floatValue());
/* 34:   */     }
/* 35:33 */     if ((param instanceof CharSequence)) {
/* 36:34 */       return param.toString();
/* 37:   */     }
/* 38:35 */     if ((param instanceof Boolean)) {
/* 39:36 */       return ((Boolean)param).booleanValue() ? "1" : "0";
/* 40:   */     }
/* 41:37 */     if ((param instanceof Identifiable)) {
/* 42:38 */       return ((Identifiable)param).identity();
/* 43:   */     }
/* 44:40 */     return param.toString();
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.entity.IdentityGenerator
 * JD-Core Version:    0.7.0.1
 */