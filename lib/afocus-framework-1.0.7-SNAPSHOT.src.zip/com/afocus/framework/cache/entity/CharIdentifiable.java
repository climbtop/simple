/*  1:   */ package com.afocus.framework.cache.entity;
/*  2:   */ 
/*  3:   */ public class CharIdentifiable
/*  4:   */   implements Identifiable
/*  5:   */ {
/*  6:   */   private final CharSequence charSequence;
/*  7:   */   
/*  8:   */   public static CharIdentifiable create(boolean value)
/*  9:   */   {
/* 10:12 */     return new CharIdentifiable(value ? "1" : "0");
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static CharIdentifiable create(String value)
/* 14:   */   {
/* 15:16 */     return new CharIdentifiable(value);
/* 16:   */   }
/* 17:   */   
/* 18:   */   private CharIdentifiable(CharSequence value)
/* 19:   */   {
/* 20:19 */     this.charSequence = value;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String identity()
/* 24:   */   {
/* 25:24 */     return this.charSequence.toString();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public CharSequence getCharSequence()
/* 29:   */   {
/* 30:28 */     return this.charSequence;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.entity.CharIdentifiable
 * JD-Core Version:    0.7.0.1
 */