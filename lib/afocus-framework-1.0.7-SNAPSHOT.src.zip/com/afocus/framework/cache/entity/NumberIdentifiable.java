/*  1:   */ package com.afocus.framework.cache.entity;
/*  2:   */ 
/*  3:   */ public class NumberIdentifiable
/*  4:   */   implements Identifiable
/*  5:   */ {
/*  6:   */   private final Number number;
/*  7:   */   
/*  8:   */   public static NumberIdentifiable create(int value)
/*  9:   */   {
/* 10:12 */     return new NumberIdentifiable(Integer.valueOf(value));
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static NumberIdentifiable create(float value)
/* 14:   */   {
/* 15:16 */     return new NumberIdentifiable(Float.valueOf(value));
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static NumberIdentifiable create(long value)
/* 19:   */   {
/* 20:20 */     return new NumberIdentifiable(Long.valueOf(value));
/* 21:   */   }
/* 22:   */   
/* 23:   */   private NumberIdentifiable(Number value)
/* 24:   */   {
/* 25:24 */     this.number = value;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String identity()
/* 29:   */   {
/* 30:29 */     return String.valueOf(this.number);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public Number getNumber()
/* 34:   */   {
/* 35:33 */     return this.number;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.entity.NumberIdentifiable
 * JD-Core Version:    0.7.0.1
 */