/*   1:    */ package com.afocus.framework.cache;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.cache.entity.Identifiable;
/*   4:    */ import com.afocus.framework.cache.entity.IdentityGenerator;
/*   5:    */ import com.afocus.framework.cache.internal.LocalCache;
/*   6:    */ import com.afocus.framework.cache.internal.RedisHashCache;
/*   7:    */ import com.afocus.framework.cache.internal.RedisListCache;
/*   8:    */ import com.afocus.framework.cache.internal.RedisMapCache;
/*   9:    */ import com.afocus.framework.cache.internal.RedisSetCache;
/*  10:    */ import com.afocus.framework.cache.loader.CacheLoader;
/*  11:    */ import com.afocus.framework.cache.loader.CacheLoader1;
/*  12:    */ import com.afocus.framework.cache.loader.CacheLoader2;
/*  13:    */ import com.afocus.framework.cache.wrapper.CacheWrapper1;
/*  14:    */ import com.afocus.framework.cache.wrapper.CacheWrapper2;
/*  15:    */ import com.afocus.framework.util.SpringUtil;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.Map;
/*  18:    */ import java.util.Set;
/*  19:    */ 
/*  20:    */ public class CacheWrappers
/*  21:    */ {
/*  22:    */   public static <K extends Identifiable, V> CacheWrapper1<K, V> create(CacheSpec<V> cacheSpec, CacheLoader1<K, V> loader)
/*  23:    */   {
/*  24: 33 */     return create((RedisCache)SpringUtil.getBean(RedisCache.class), cacheSpec, loader);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <K extends Identifiable, V> CacheWrapper1<K, V> create(RedisCache redis, CacheSpec<V> cacheSpec, CacheLoader1<K, V> loader)
/*  28:    */   {
/*  29: 37 */     return new CacheWrapper1Impl(redis, cacheSpec, loader);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <K extends Identifiable> NumberCacheWrapper1<K> createNumberCache(RedisCache redis, CacheSpec<Long> cacheSpec, CacheLoader1<K, Long> loader)
/*  33:    */   {
/*  34: 41 */     return new NumberCacheWrapper1(redis, cacheSpec, loader);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K extends Identifiable> NumberCacheWrapper1<K> createNumberCache(CacheSpec<Long> cacheSpec, CacheLoader1<K, Long> loader)
/*  38:    */   {
/*  39: 45 */     return createNumberCache((RedisCache)SpringUtil.getBean(RedisCache.class), cacheSpec, loader);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static <K1, K2, V> CacheWrapper2<K1, K2, V> create(CacheSpec<V> cacheSpec, CacheLoader2<K1, K2, V> loader)
/*  43:    */   {
/*  44: 48 */     return create((RedisCache)SpringUtil.getBean(RedisCache.class), cacheSpec, loader);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static <K1, K2, V> CacheWrapper2<K1, K2, V> create(RedisCache redis, CacheSpec<V> cacheSpec, CacheLoader2<K1, K2, V> loader)
/*  48:    */   {
/*  49: 52 */     return new CacheWrapper2Impl(redis, cacheSpec, loader);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <V> Cache<String, V> createInnerCache(RedisCache redis, CacheSpec<V> cacheSpec)
/*  53:    */   {
/*  54: 64 */     if (cacheSpec == null) {
/*  55: 64 */       return new LocalCache(redis, cacheSpec);
/*  56:    */     }
/*  57: 65 */     if (cacheSpec.getCacheMode() == null) {
/*  58: 65 */       return new LocalCache(redis, cacheSpec);
/*  59:    */     }
/*  60: 66 */     switch (1.$SwitchMap$com$afocus$framework$cache$CacheMode[cacheSpec.getCacheMode().ordinal()])
/*  61:    */     {
/*  62:    */     case 1: 
/*  63: 68 */       return new RedisListCache(redis, cacheSpec);
/*  64:    */     case 2: 
/*  65: 70 */       return new RedisHashCache(redis, cacheSpec);
/*  66:    */     case 3: 
/*  67: 72 */       return new RedisMapCache(redis, cacheSpec);
/*  68:    */     case 4: 
/*  69: 74 */       return new RedisSetCache(redis, cacheSpec);
/*  70:    */     }
/*  71: 77 */     return new LocalCache(redis, cacheSpec);
/*  72:    */   }
/*  73:    */   
/*  74:    */   static class CacheWrapper1Impl<K extends Identifiable, V>
/*  75:    */     implements CacheWrapper1<K, V>
/*  76:    */   {
/*  77:    */     private final Cache<String, V> innerCache;
/*  78:    */     private final CacheLoader1<K, V> loader;
/*  79:    */     
/*  80:    */     public CacheWrapper1Impl(RedisCache redis, CacheSpec<V> cacheSpec, CacheLoader1<K, V> loader)
/*  81:    */     {
/*  82: 94 */       this.innerCache = CacheWrappers.createInnerCache(redis, cacheSpec);
/*  83: 95 */       this.loader = loader;
/*  84:    */     }
/*  85:    */     
/*  86:    */     public V get(final K key)
/*  87:    */     {
/*  88:100 */       this.innerCache.get(getIdentity(key), new CacheLoader()
/*  89:    */       {
/*  90:    */         public V load()
/*  91:    */         {
/*  92:103 */           return CacheWrappers.CacheWrapper1Impl.this.loader.load(key);
/*  93:    */         }
/*  94:    */       });
/*  95:    */     }
/*  96:    */     
/*  97:    */     public void set(K key, V value)
/*  98:    */     {
/*  99:110 */       this.innerCache.set(getIdentity(key), value);
/* 100:    */     }
/* 101:    */     
/* 102:    */     public void clear(K key)
/* 103:    */     {
/* 104:115 */       this.innerCache.clear(getIdentity(key));
/* 105:    */     }
/* 106:    */     
/* 107:    */     public boolean exists(K key)
/* 108:    */     {
/* 109:120 */       return this.innerCache.exists(getIdentity(key));
/* 110:    */     }
/* 111:    */     
/* 112:    */     public List<String> getAllList(K key)
/* 113:    */     {
/* 114:125 */       return this.innerCache.getAllList(getIdentity(key));
/* 115:    */     }
/* 116:    */     
/* 117:    */     public Map<String, String> getAllMap(K key)
/* 118:    */     {
/* 119:130 */       return this.innerCache.getAllMap(getIdentity(key));
/* 120:    */     }
/* 121:    */     
/* 122:    */     public Set<String> getAllSet(K key)
/* 123:    */     {
/* 124:135 */       return this.innerCache.getAllSet(getIdentity(key));
/* 125:    */     }
/* 126:    */     
/* 127:    */     public void clear(K key, V value)
/* 128:    */     {
/* 129:140 */       this.innerCache.clear(getIdentity(key), value);
/* 130:    */     }
/* 131:    */     
/* 132:    */     protected String getIdentity(K key)
/* 133:    */     {
/* 134:144 */       return key.identity();
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   static class CacheWrapper2Impl<K1, K2, V>
/* 139:    */     implements CacheWrapper2<K1, K2, V>
/* 140:    */   {
/* 141:    */     private final Cache<String, V> innerCache;
/* 142:    */     private final CacheLoader2<K1, K2, V> loader;
/* 143:    */     
/* 144:    */     public CacheWrapper2Impl(RedisCache redis, CacheSpec<V> cacheSpec, CacheLoader2<K1, K2, V> loader)
/* 145:    */     {
/* 146:158 */       this.innerCache = CacheWrappers.createInnerCache(redis, cacheSpec);
/* 147:159 */       this.loader = loader;
/* 148:    */     }
/* 149:    */     
/* 150:    */     public V get(final K1 k1, final K2 k2)
/* 151:    */     {
/* 152:164 */       this.innerCache.get(getIdentity(k1, k2), new CacheLoader()
/* 153:    */       {
/* 154:    */         public V load()
/* 155:    */         {
/* 156:167 */           return CacheWrappers.CacheWrapper2Impl.this.loader.load(k1, k2);
/* 157:    */         }
/* 158:    */       });
/* 159:    */     }
/* 160:    */     
/* 161:    */     public void set(K1 k1, K2 k2, V value)
/* 162:    */     {
/* 163:174 */       this.innerCache.set(getIdentity(k1, k2), value);
/* 164:    */     }
/* 165:    */     
/* 166:    */     public void clear(K1 k1, K2 k2)
/* 167:    */     {
/* 168:179 */       this.innerCache.clear(getIdentity(k1, k2));
/* 169:    */     }
/* 170:    */     
/* 171:    */     public boolean exists(K1 k1, K2 k2)
/* 172:    */     {
/* 173:184 */       return this.innerCache.exists(getIdentity(k1, k2));
/* 174:    */     }
/* 175:    */     
/* 176:    */     protected String getIdentity(K1 k1, K2 k2)
/* 177:    */     {
/* 178:188 */       return IdentityGenerator.generate(new Object[] { k1, k2 });
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   public static final class NumberCacheWrapper1<K extends Identifiable>
/* 183:    */     extends CacheWrappers.CacheWrapper1Impl<K, Long>
/* 184:    */   {
/* 185:    */     public NumberCacheWrapper1(RedisCache redis, CacheSpec<Long> cacheSpec, CacheLoader1<K, Long> loader)
/* 186:    */     {
/* 187:202 */       super(cacheSpec, loader);
/* 188:    */     }
/* 189:    */     
/* 190:    */     public Long incrBy(K key, Long value)
/* 191:    */     {
/* 192:209 */       return CacheWrappers.CacheWrapper1Impl.access$200(this).incrBy(getIdentity(key), value);
/* 193:    */     }
/* 194:    */     
/* 195:    */     protected String getIdentity(K key)
/* 196:    */     {
/* 197:213 */       return key.identity();
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static final class NumberCacheWrapper2<K1, K2>
/* 202:    */     extends CacheWrappers.CacheWrapper2Impl<K1, K2, Long>
/* 203:    */   {
/* 204:    */     public NumberCacheWrapper2(RedisCache redis, CacheSpec<Long> cacheSpec, CacheLoader2<K1, K2, Long> loader)
/* 205:    */     {
/* 206:224 */       super(cacheSpec, loader);
/* 207:    */     }
/* 208:    */     
/* 209:    */     public Long incrBy(K1 key1, K2 key2, Long value)
/* 210:    */     {
/* 211:229 */       if (super.exists(key1, key2)) {
/* 212:230 */         return (Long)get(key1, key2);
/* 213:    */       }
/* 214:231 */       return CacheWrappers.CacheWrapper2Impl.access$300(this).incrBy(getIdentity(key1, key2), value);
/* 215:    */     }
/* 216:    */   }
/* 217:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.CacheWrappers
 * JD-Core Version:    0.7.0.1
 */