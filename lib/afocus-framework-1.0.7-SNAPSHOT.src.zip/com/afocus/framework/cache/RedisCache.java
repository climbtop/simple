/*    1:     */ package com.afocus.framework.cache;
/*    2:     */ 
/*    3:     */ import com.afocus.framework.util.SerializeUtil;
/*    4:     */ import com.google.common.base.Function;
/*    5:     */ import java.util.List;
/*    6:     */ import java.util.Map;
/*    7:     */ import java.util.Map.Entry;
/*    8:     */ import java.util.Set;
/*    9:     */ import org.apache.log4j.Logger;
/*   10:     */ import redis.clients.jedis.Jedis;
/*   11:     */ import redis.clients.jedis.JedisPool;
/*   12:     */ import redis.clients.util.SafeEncoder;
/*   13:     */ 
/*   14:     */ public final class RedisCache
/*   15:     */ {
/*   16:  18 */   protected static final Logger log = Logger.getLogger(RedisCache.class);
/*   17:     */   private final JedisPool jedisPool;
/*   18:     */   
/*   19:     */   public RedisCache(JedisPool jedisPool)
/*   20:     */   {
/*   21:  28 */     this.jedisPool = jedisPool;
/*   22:     */   }
/*   23:     */   
/*   24:     */   public Boolean exists(final String key)
/*   25:     */   {
/*   26:  38 */     (Boolean)exec(new Function()
/*   27:     */     {
/*   28:     */       public Boolean apply(Jedis arg0)
/*   29:     */       {
/*   30:  41 */         return arg0.exists(key);
/*   31:     */       }
/*   32:     */     });
/*   33:     */   }
/*   34:     */   
/*   35:     */   public Long hlen(final String key)
/*   36:     */   {
/*   37:  52 */     (Long)exec(new Function()
/*   38:     */     {
/*   39:     */       public Long apply(Jedis arg0)
/*   40:     */       {
/*   41:  55 */         return arg0.hlen(key);
/*   42:     */       }
/*   43:     */     });
/*   44:     */   }
/*   45:     */   
/*   46:     */   public Set<String> getKeys(final String key)
/*   47:     */   {
/*   48:  66 */     (Set)exec(new Function()
/*   49:     */     {
/*   50:     */       public Set<String> apply(Jedis arg0)
/*   51:     */       {
/*   52:  69 */         return arg0.keys(key);
/*   53:     */       }
/*   54:     */     });
/*   55:     */   }
/*   56:     */   
/*   57:     */   public Long del(final String key)
/*   58:     */   {
/*   59:  80 */     (Long)exec(new Function()
/*   60:     */     {
/*   61:     */       public Long apply(Jedis arg0)
/*   62:     */       {
/*   63:  83 */         return arg0.del(key);
/*   64:     */       }
/*   65:     */     });
/*   66:     */   }
/*   67:     */   
/*   68:     */   public Long incrBy(final String key, final Long value)
/*   69:     */   {
/*   70:  95 */     (Long)exec(new Function()
/*   71:     */     {
/*   72:     */       public Long apply(Jedis arg0)
/*   73:     */       {
/*   74:  98 */         return arg0.incrBy(key, value.longValue());
/*   75:     */       }
/*   76:     */     });
/*   77:     */   }
/*   78:     */   
/*   79:     */   public Long hsetObject(final String key, final String field, final Object value)
/*   80:     */   {
/*   81: 112 */     (Long)exec(new Function()
/*   82:     */     {
/*   83:     */       public Long apply(Jedis jedis)
/*   84:     */       {
/*   85: 115 */         return jedis.hset(SafeEncoder.encode(key), SafeEncoder.encode(field), SerializeUtil.serialize(value));
/*   86:     */       }
/*   87:     */     });
/*   88:     */   }
/*   89:     */   
/*   90:     */   public Map<String, String> getAllMap(final String key)
/*   91:     */   {
/*   92: 129 */     (Map)exec(new Function()
/*   93:     */     {
/*   94:     */       public Map<String, String> apply(Jedis input)
/*   95:     */       {
/*   96: 132 */         return input.hgetAll(key);
/*   97:     */       }
/*   98:     */     });
/*   99:     */   }
/*  100:     */   
/*  101:     */   public Object hgetObject(final String key, final String field)
/*  102:     */   {
/*  103: 146 */     exec(new Function()
/*  104:     */     {
/*  105:     */       public Object apply(Jedis jedis)
/*  106:     */       {
/*  107: 149 */         byte[] result = jedis.hget(SafeEncoder.encode(key), SafeEncoder.encode(field));
/*  108: 150 */         if (result == null) {
/*  109: 151 */           return null;
/*  110:     */         }
/*  111: 153 */         return SerializeUtil.unserialize(result);
/*  112:     */       }
/*  113:     */     });
/*  114:     */   }
/*  115:     */   
/*  116:     */   public String hget(final String key, final String field)
/*  117:     */   {
/*  118: 166 */     (String)exec(new Function()
/*  119:     */     {
/*  120:     */       public String apply(Jedis jedis)
/*  121:     */       {
/*  122: 169 */         return jedis.hget(key, field);
/*  123:     */       }
/*  124:     */     });
/*  125:     */   }
/*  126:     */   
/*  127:     */   public Long lpushObject(final String key, final Object member)
/*  128:     */   {
/*  129: 182 */     (Long)exec(new Function()
/*  130:     */     {
/*  131:     */       public Long apply(Jedis jedis)
/*  132:     */       {
/*  133: 185 */         return jedis.lpush(SafeEncoder.encode(key), new byte[][] { SerializeUtil.serialize(member) });
/*  134:     */       }
/*  135:     */     });
/*  136:     */   }
/*  137:     */   
/*  138:     */   public Long lpush(final String key, final String... strings)
/*  139:     */   {
/*  140: 197 */     (Long)exec(new Function()
/*  141:     */     {
/*  142:     */       public Long apply(Jedis jedis)
/*  143:     */       {
/*  144: 200 */         return jedis.lpush(key, strings);
/*  145:     */       }
/*  146:     */     });
/*  147:     */   }
/*  148:     */   
/*  149:     */   public Long rpushObject(final String key, final Object member)
/*  150:     */   {
/*  151: 212 */     (Long)exec(new Function()
/*  152:     */     {
/*  153:     */       public Long apply(Jedis jedis)
/*  154:     */       {
/*  155: 215 */         return jedis.rpush(SafeEncoder.encode(key), new byte[][] { SerializeUtil.serialize(member) });
/*  156:     */       }
/*  157:     */     });
/*  158:     */   }
/*  159:     */   
/*  160:     */   public Long rpush(final String key, final String... strings)
/*  161:     */   {
/*  162: 227 */     (Long)exec(new Function()
/*  163:     */     {
/*  164:     */       public Long apply(Jedis jedis)
/*  165:     */       {
/*  166: 230 */         return jedis.rpush(key, strings);
/*  167:     */       }
/*  168:     */     });
/*  169:     */   }
/*  170:     */   
/*  171:     */   public Object rpopObject(final String key)
/*  172:     */   {
/*  173: 241 */     exec(new Function()
/*  174:     */     {
/*  175:     */       public Object apply(Jedis jedis)
/*  176:     */       {
/*  177: 244 */         byte[] result = jedis.rpop(SafeEncoder.encode(key));
/*  178: 245 */         if (result == null) {
/*  179: 246 */           return null;
/*  180:     */         }
/*  181: 248 */         return SerializeUtil.unserialize(result);
/*  182:     */       }
/*  183:     */     });
/*  184:     */   }
/*  185:     */   
/*  186:     */   public String rpop(final String key)
/*  187:     */   {
/*  188: 259 */     (String)exec(new Function()
/*  189:     */     {
/*  190:     */       public String apply(Jedis jedis)
/*  191:     */       {
/*  192: 262 */         return jedis.rpop(key);
/*  193:     */       }
/*  194:     */     });
/*  195:     */   }
/*  196:     */   
/*  197:     */   public Object lpopObject(final String key)
/*  198:     */   {
/*  199: 273 */     exec(new Function()
/*  200:     */     {
/*  201:     */       public Object apply(Jedis jedis)
/*  202:     */       {
/*  203: 276 */         byte[] result = jedis.lpop(SafeEncoder.encode(key));
/*  204: 277 */         if (result == null) {
/*  205: 278 */           return null;
/*  206:     */         }
/*  207: 280 */         return SerializeUtil.unserialize(result);
/*  208:     */       }
/*  209:     */     });
/*  210:     */   }
/*  211:     */   
/*  212:     */   public String lpop(final String key)
/*  213:     */   {
/*  214: 291 */     (String)exec(new Function()
/*  215:     */     {
/*  216:     */       public String apply(Jedis jedis)
/*  217:     */       {
/*  218: 294 */         return jedis.lpop(key);
/*  219:     */       }
/*  220:     */     });
/*  221:     */   }
/*  222:     */   
/*  223:     */   public Long saddObject(final String key, final Object member)
/*  224:     */   {
/*  225: 306 */     (Long)exec(new Function()
/*  226:     */     {
/*  227:     */       public Long apply(Jedis jedis)
/*  228:     */       {
/*  229: 309 */         return jedis.sadd(SafeEncoder.encode(key), new byte[][] { SerializeUtil.serialize(member) });
/*  230:     */       }
/*  231:     */     });
/*  232:     */   }
/*  233:     */   
/*  234:     */   public Long sadd(final String key, final String member)
/*  235:     */   {
/*  236: 321 */     (Long)exec(new Function()
/*  237:     */     {
/*  238:     */       public Long apply(Jedis jedis)
/*  239:     */       {
/*  240: 324 */         return jedis.sadd(key, new String[] { member });
/*  241:     */       }
/*  242:     */     });
/*  243:     */   }
/*  244:     */   
/*  245:     */   public Object spopOject(final String key)
/*  246:     */   {
/*  247: 335 */     exec(new Function()
/*  248:     */     {
/*  249:     */       public Object apply(Jedis jedis)
/*  250:     */       {
/*  251: 338 */         byte[] result = jedis.spop(SafeEncoder.encode(key));
/*  252: 339 */         if (result == null) {
/*  253: 340 */           return null;
/*  254:     */         }
/*  255: 342 */         return SerializeUtil.unserialize(result);
/*  256:     */       }
/*  257:     */     });
/*  258:     */   }
/*  259:     */   
/*  260:     */   public String spop(final String key)
/*  261:     */   {
/*  262: 353 */     (String)exec(new Function()
/*  263:     */     {
/*  264:     */       public String apply(Jedis jedis)
/*  265:     */       {
/*  266: 356 */         return jedis.spop(key);
/*  267:     */       }
/*  268:     */     });
/*  269:     */   }
/*  270:     */   
/*  271:     */   public Boolean hexists(final String key, final String field)
/*  272:     */   {
/*  273: 369 */     (Boolean)exec(new Function()
/*  274:     */     {
/*  275:     */       public Boolean apply(Jedis input)
/*  276:     */       {
/*  277: 372 */         return input.hexists(SafeEncoder.encode(key), SafeEncoder.encode(field));
/*  278:     */       }
/*  279:     */     });
/*  280:     */   }
/*  281:     */   
/*  282:     */   public List<String> lrangeString(final String key)
/*  283:     */   {
/*  284: 385 */     (List)exec(new Function()
/*  285:     */     {
/*  286:     */       public List<String> apply(Jedis input)
/*  287:     */       {
/*  288: 389 */         return input.lrange(key, 0L, -1L);
/*  289:     */       }
/*  290:     */     });
/*  291:     */   }
/*  292:     */   
/*  293:     */   public List<byte[]> lrange(final String key)
/*  294:     */   {
/*  295: 401 */     (List)exec(new Function()
/*  296:     */     {
/*  297:     */       public List<byte[]> apply(Jedis input)
/*  298:     */       {
/*  299: 405 */         return input.lrange(SafeEncoder.encode(key), 0L, -1L);
/*  300:     */       }
/*  301:     */     });
/*  302:     */   }
/*  303:     */   
/*  304:     */   public long llen(final String key)
/*  305:     */   {
/*  306: 416 */     ((Long)exec(new Function()
/*  307:     */     {
/*  308:     */       public Long apply(Jedis input)
/*  309:     */       {
/*  310: 419 */         return input.llen(key);
/*  311:     */       }
/*  312:     */     })).longValue();
/*  313:     */   }
/*  314:     */   
/*  315:     */   public String lindex(final String key, final long index)
/*  316:     */   {
/*  317: 430 */     (String)exec(new Function()
/*  318:     */     {
/*  319:     */       public String apply(Jedis input)
/*  320:     */       {
/*  321: 433 */         return input.lindex(key, index);
/*  322:     */       }
/*  323:     */     });
/*  324:     */   }
/*  325:     */   
/*  326:     */   public Long lremObject(final String key, final Object obj, final Integer count)
/*  327:     */   {
/*  328: 450 */     (Long)exec(new Function()
/*  329:     */     {
/*  330:     */       public Long apply(Jedis input)
/*  331:     */       {
/*  332: 453 */         return input.lrem(SafeEncoder.encode(key), count.intValue(), SerializeUtil.serialize(obj));
/*  333:     */       }
/*  334:     */     });
/*  335:     */   }
/*  336:     */   
/*  337:     */   public Long lrem(final String key, final String value, final Integer count)
/*  338:     */   {
/*  339: 469 */     (Long)exec(new Function()
/*  340:     */     {
/*  341:     */       public Long apply(Jedis input)
/*  342:     */       {
/*  343: 472 */         return input.lrem(key, count.intValue(), value);
/*  344:     */       }
/*  345:     */     });
/*  346:     */   }
/*  347:     */   
/*  348:     */   public Long lrem(String key, Integer count, long index)
/*  349:     */   {
/*  350: 488 */     String value = lindex(key, index);
/*  351: 489 */     if ((value != null) && (!"".equals(value))) {
/*  352: 490 */       return lrem(key, value, count);
/*  353:     */     }
/*  354: 492 */     return Long.valueOf(0L);
/*  355:     */   }
/*  356:     */   
/*  357:     */   public Object getObject(final String key)
/*  358:     */   {
/*  359: 501 */     exec(new Function()
/*  360:     */     {
/*  361:     */       public Object apply(Jedis jedis)
/*  362:     */       {
/*  363: 504 */         byte[] result = jedis.get(SafeEncoder.encode(key));
/*  364: 505 */         if (result == null) {
/*  365: 506 */           return null;
/*  366:     */         }
/*  367: 508 */         return SerializeUtil.unserialize(result);
/*  368:     */       }
/*  369:     */     });
/*  370:     */   }
/*  371:     */   
/*  372:     */   public String get(final String key)
/*  373:     */   {
/*  374: 520 */     (String)exec(new Function()
/*  375:     */     {
/*  376:     */       public String apply(Jedis jedis)
/*  377:     */       {
/*  378: 523 */         return jedis.get(key);
/*  379:     */       }
/*  380:     */     });
/*  381:     */   }
/*  382:     */   
/*  383:     */   @Deprecated
/*  384:     */   public void putObject(String key, Object value, int expireSeconds)
/*  385:     */   {
/*  386: 530 */     setexObject(key, value, expireSeconds);
/*  387:     */   }
/*  388:     */   
/*  389:     */   public void set(final String key, final String value)
/*  390:     */   {
/*  391: 541 */     exec(new Function()
/*  392:     */     {
/*  393:     */       public Void apply(Jedis jedis)
/*  394:     */       {
/*  395: 544 */         jedis.set(key, value);
/*  396: 545 */         return null;
/*  397:     */       }
/*  398:     */     });
/*  399:     */   }
/*  400:     */   
/*  401:     */   public void setObject(final String key, final Object value)
/*  402:     */   {
/*  403: 557 */     exec(new Function()
/*  404:     */     {
/*  405:     */       public Void apply(Jedis jedis)
/*  406:     */       {
/*  407: 560 */         jedis.set(SafeEncoder.encode(key), SerializeUtil.serialize(value));
/*  408: 561 */         return null;
/*  409:     */       }
/*  410:     */     });
/*  411:     */   }
/*  412:     */   
/*  413:     */   public void setex(final String key, final String value, final int expireSeconds)
/*  414:     */   {
/*  415: 574 */     exec(new Function()
/*  416:     */     {
/*  417:     */       public Void apply(Jedis jedis)
/*  418:     */       {
/*  419: 577 */         jedis.setex(key, expireSeconds, value);
/*  420: 578 */         return null;
/*  421:     */       }
/*  422:     */     });
/*  423:     */   }
/*  424:     */   
/*  425:     */   public void setexObject(final String key, final Object value, final int expireSeconds)
/*  426:     */   {
/*  427: 591 */     exec(new Function()
/*  428:     */     {
/*  429:     */       public Void apply(Jedis jedis)
/*  430:     */       {
/*  431: 594 */         jedis.setex(SafeEncoder.encode(key), expireSeconds, SerializeUtil.serialize(value));
/*  432: 595 */         return null;
/*  433:     */       }
/*  434:     */     });
/*  435:     */   }
/*  436:     */   
/*  437:     */   @Deprecated
/*  438:     */   public void put(String key, String value, int expireSeconds)
/*  439:     */   {
/*  440: 602 */     setex(key, value, expireSeconds);
/*  441:     */   }
/*  442:     */   
/*  443:     */   public void remove(final String key)
/*  444:     */   {
/*  445: 611 */     exec(new Function()
/*  446:     */     {
/*  447:     */       public Void apply(Jedis jedis)
/*  448:     */       {
/*  449: 614 */         jedis.del(key);
/*  450: 615 */         return null;
/*  451:     */       }
/*  452:     */     });
/*  453:     */   }
/*  454:     */   
/*  455:     */   public synchronized RedisCache init()
/*  456:     */   {
/*  457: 621 */     return this;
/*  458:     */   }
/*  459:     */   
/*  460:     */   public void destroy()
/*  461:     */   {
/*  462: 625 */     if (this.jedisPool != null) {
/*  463: 626 */       this.jedisPool.destroy();
/*  464:     */     }
/*  465:     */   }
/*  466:     */   
/*  467:     */   public Long hset(final String key, final String field, final String value)
/*  468:     */   {
/*  469: 639 */     (Long)exec(new Function()
/*  470:     */     {
/*  471:     */       public Long apply(Jedis jedis)
/*  472:     */       {
/*  473: 642 */         return jedis.hset(key, field, value);
/*  474:     */       }
/*  475:     */     });
/*  476:     */   }
/*  477:     */   
/*  478:     */   public Long hset(final String key, final String field, final String value, final int expireSeconds)
/*  479:     */   {
/*  480: 656 */     (Long)exec(new Function()
/*  481:     */     {
/*  482:     */       public Long apply(Jedis jedis)
/*  483:     */       {
/*  484: 659 */         Long result = jedis.hset(key, field, value);
/*  485: 660 */         jedis.expire(key, expireSeconds);
/*  486: 661 */         return result;
/*  487:     */       }
/*  488:     */     });
/*  489:     */   }
/*  490:     */   
/*  491:     */   public Long hsetObject(final String key, final String field, final Object value, final int expireSeconds)
/*  492:     */   {
/*  493: 676 */     (Long)exec(new Function()
/*  494:     */     {
/*  495:     */       public Long apply(Jedis jedis)
/*  496:     */       {
/*  497: 679 */         Long result = jedis.hset(SafeEncoder.encode(key), SafeEncoder.encode(field), SerializeUtil.serialize(value));
/*  498: 680 */         jedis.expire(SafeEncoder.encode(key), expireSeconds);
/*  499: 681 */         return result;
/*  500:     */       }
/*  501:     */     });
/*  502:     */   }
/*  503:     */   
/*  504:     */   public void hset(final String key, final Map<String, String> map)
/*  505:     */   {
/*  506: 693 */     exec(new Function()
/*  507:     */     {
/*  508:     */       public Void apply(Jedis jedis)
/*  509:     */       {
/*  510: 696 */         for (Map.Entry<String, String> pair : map.entrySet()) {
/*  511: 697 */           jedis.hset(key, (String)pair.getKey(), (String)pair.getValue());
/*  512:     */         }
/*  513: 699 */         return null;
/*  514:     */       }
/*  515:     */     });
/*  516:     */   }
/*  517:     */   
/*  518:     */   public Map<String, String> hget(final String key)
/*  519:     */   {
/*  520: 711 */     (Map)exec(new Function()
/*  521:     */     {
/*  522:     */       public Map<String, String> apply(Jedis jedis)
/*  523:     */       {
/*  524: 715 */         return jedis.hgetAll(key);
/*  525:     */       }
/*  526:     */     });
/*  527:     */   }
/*  528:     */   
/*  529:     */   public Long hdel(final String key, final String... fields)
/*  530:     */   {
/*  531: 728 */     (Long)exec(new Function()
/*  532:     */     {
/*  533:     */       public Long apply(Jedis jedis)
/*  534:     */       {
/*  535: 731 */         return jedis.hdel(key, fields);
/*  536:     */       }
/*  537:     */     });
/*  538:     */   }
/*  539:     */   
/*  540:     */   public Long sadd(final String key, final int expireSeconds, final String... members)
/*  541:     */   {
/*  542: 745 */     (Long)exec(new Function()
/*  543:     */     {
/*  544:     */       public Long apply(Jedis jedis)
/*  545:     */       {
/*  546: 748 */         Long result = jedis.srem(key, members);
/*  547: 749 */         jedis.expire(key, expireSeconds);
/*  548: 750 */         return result;
/*  549:     */       }
/*  550:     */     });
/*  551:     */   }
/*  552:     */   
/*  553:     */   public Long sadd(final String key, final String... members)
/*  554:     */   {
/*  555: 763 */     (Long)exec(new Function()
/*  556:     */     {
/*  557:     */       public Long apply(Jedis jedis)
/*  558:     */       {
/*  559: 766 */         return jedis.sadd(key, members);
/*  560:     */       }
/*  561:     */     });
/*  562:     */   }
/*  563:     */   
/*  564:     */   public Set<String> smembers(final String key)
/*  565:     */   {
/*  566: 778 */     (Set)exec(new Function()
/*  567:     */     {
/*  568:     */       public Set<String> apply(Jedis jedis)
/*  569:     */       {
/*  570: 781 */         return jedis.smembers(key);
/*  571:     */       }
/*  572:     */     });
/*  573:     */   }
/*  574:     */   
/*  575:     */   public Long srem(final String key, final String... members)
/*  576:     */   {
/*  577: 794 */     (Long)exec(new Function()
/*  578:     */     {
/*  579:     */       public Long apply(Jedis jedis)
/*  580:     */       {
/*  581: 797 */         return jedis.srem(key, members);
/*  582:     */       }
/*  583:     */     });
/*  584:     */   }
/*  585:     */   
/*  586:     */   public Boolean sismember(final String key, final String member)
/*  587:     */   {
/*  588: 810 */     (Boolean)exec(new Function()
/*  589:     */     {
/*  590:     */       public Boolean apply(Jedis jedis)
/*  591:     */       {
/*  592: 813 */         return jedis.sismember(key, member);
/*  593:     */       }
/*  594:     */     });
/*  595:     */   }
/*  596:     */   
/*  597:     */   public Long hincrBy(final String key, final String field, final Long value)
/*  598:     */   {
/*  599: 827 */     (Long)exec(new Function()
/*  600:     */     {
/*  601:     */       public Long apply(Jedis jedis)
/*  602:     */       {
/*  603: 831 */         return jedis.hincrBy(key, field, value.longValue());
/*  604:     */       }
/*  605:     */     });
/*  606:     */   }
/*  607:     */   
/*  608:     */   public <F, T> T getObject(final String key, final F args, final Function<F, T> generator, final int expireSeconds)
/*  609:     */   {
/*  610: 840 */     exec(new Function()
/*  611:     */     {
/*  612:     */       public T apply(Jedis jedis)
/*  613:     */       {
/*  614: 843 */         byte[] _key = SafeEncoder.encode(key);
/*  615: 844 */         if (jedis.exists(_key).booleanValue())
/*  616:     */         {
/*  617: 845 */           byte[] result = jedis.get(_key);
/*  618: 846 */           if (result == null) {
/*  619: 847 */             return null;
/*  620:     */           }
/*  621: 849 */           Object obj = SerializeUtil.unserialize(result);
/*  622: 850 */           if (obj == null) {
/*  623: 850 */             return null;
/*  624:     */           }
/*  625: 851 */           return obj;
/*  626:     */         }
/*  627: 853 */         T result = generator.apply(args);
/*  628: 854 */         jedis.setex(_key, expireSeconds, SerializeUtil.serialize(result));
/*  629: 855 */         return result;
/*  630:     */       }
/*  631:     */     });
/*  632:     */   }
/*  633:     */   
/*  634:     */   public Long zadd(final String key, final double score, String member)
/*  635:     */   {
/*  636: 870 */     (Long)exec(new Function()
/*  637:     */     {
/*  638:     */       public Long apply(Jedis jedis)
/*  639:     */       {
/*  640: 873 */         return jedis.zadd(key, score, this.val$member);
/*  641:     */       }
/*  642:     */     });
/*  643:     */   }
/*  644:     */   
/*  645:     */   public Long zadd(final String key, final Map<String, Double> scoreMembers)
/*  646:     */   {
/*  647: 886 */     (Long)exec(new Function()
/*  648:     */     {
/*  649:     */       public Long apply(Jedis jedis)
/*  650:     */       {
/*  651: 889 */         return jedis.zadd(key, scoreMembers);
/*  652:     */       }
/*  653:     */     });
/*  654:     */   }
/*  655:     */   
/*  656:     */   public Long zcard(final String key)
/*  657:     */   {
/*  658: 901 */     (Long)exec(new Function()
/*  659:     */     {
/*  660:     */       public Long apply(Jedis jedis)
/*  661:     */       {
/*  662: 904 */         return jedis.zcard(key);
/*  663:     */       }
/*  664:     */     });
/*  665:     */   }
/*  666:     */   
/*  667:     */   public Long zcount(final String key, final double min, double max)
/*  668:     */   {
/*  669: 917 */     (Long)exec(new Function()
/*  670:     */     {
/*  671:     */       public Long apply(Jedis jedis)
/*  672:     */       {
/*  673: 920 */         return jedis.zcount(key, min, this.val$max);
/*  674:     */       }
/*  675:     */     });
/*  676:     */   }
/*  677:     */   
/*  678:     */   public Double zincrby(final String key, final double score, String member)
/*  679:     */   {
/*  680: 934 */     (Double)exec(new Function()
/*  681:     */     {
/*  682:     */       public Double apply(Jedis jedis)
/*  683:     */       {
/*  684: 937 */         return jedis.zincrby(key, score, this.val$member);
/*  685:     */       }
/*  686:     */     });
/*  687:     */   }
/*  688:     */   
/*  689:     */   public Double zscore(final String key, final String member)
/*  690:     */   {
/*  691: 950 */     (Double)exec(new Function()
/*  692:     */     {
/*  693:     */       public Double apply(Jedis jedis)
/*  694:     */       {
/*  695: 953 */         Double score = jedis.zscore(key, member);
/*  696: 954 */         return Double.valueOf(score == null ? 0.0D : score.doubleValue());
/*  697:     */       }
/*  698:     */     });
/*  699:     */   }
/*  700:     */   
/*  701:     */   public Long zrank(final String key, final String member)
/*  702:     */   {
/*  703: 968 */     (Long)exec(new Function()
/*  704:     */     {
/*  705:     */       public Long apply(Jedis jedis)
/*  706:     */       {
/*  707: 971 */         return jedis.zrank(key, member);
/*  708:     */       }
/*  709:     */     });
/*  710:     */   }
/*  711:     */   
/*  712:     */   public Long zremrangeByRank(final String key, final long start, long end)
/*  713:     */   {
/*  714: 990 */     (Long)exec(new Function()
/*  715:     */     {
/*  716:     */       public Long apply(Jedis jedis)
/*  717:     */       {
/*  718: 993 */         return jedis.zremrangeByRank(key, start, this.val$end);
/*  719:     */       }
/*  720:     */     });
/*  721:     */   }
/*  722:     */   
/*  723:     */   public Long zrevrank(final String key, final String member)
/*  724:     */   {
/*  725:1008 */     (Long)exec(new Function()
/*  726:     */     {
/*  727:     */       public Long apply(Jedis jedis)
/*  728:     */       {
/*  729:1011 */         return jedis.zrevrank(key, member);
/*  730:     */       }
/*  731:     */     });
/*  732:     */   }
/*  733:     */   
/*  734:     */   public Set<String> zrange(final String key, final long start, long end)
/*  735:     */   {
/*  736:1033 */     (Set)exec(new Function()
/*  737:     */     {
/*  738:     */       public Set<String> apply(Jedis jedis)
/*  739:     */       {
/*  740:1036 */         return jedis.zrange(key, start, this.val$end);
/*  741:     */       }
/*  742:     */     });
/*  743:     */   }
/*  744:     */   
/*  745:     */   public Set<String> zrevrange(final String key, final long start, long end)
/*  746:     */   {
/*  747:1053 */     (Set)exec(new Function()
/*  748:     */     {
/*  749:     */       public Set<String> apply(Jedis jedis)
/*  750:     */       {
/*  751:1056 */         return jedis.zrevrange(key, start, this.val$end);
/*  752:     */       }
/*  753:     */     });
/*  754:     */   }
/*  755:     */   
/*  756:     */   public <T> T exec(Function<Jedis, T> function)
/*  757:     */   {
/*  758:1069 */     Jedis jedis = this.jedisPool.getResource();Throwable localThrowable3 = null;
/*  759:     */     try
/*  760:     */     {
/*  761:1070 */       return function.apply(jedis);
/*  762:     */     }
/*  763:     */     catch (Throwable localThrowable4)
/*  764:     */     {
/*  765:1069 */       localThrowable3 = localThrowable4;throw localThrowable4;
/*  766:     */     }
/*  767:     */     finally
/*  768:     */     {
/*  769:1071 */       if (jedis != null) {
/*  770:1071 */         if (localThrowable3 != null) {
/*  771:     */           try
/*  772:     */           {
/*  773:1071 */             jedis.close();
/*  774:     */           }
/*  775:     */           catch (Throwable localThrowable2)
/*  776:     */           {
/*  777:1071 */             localThrowable3.addSuppressed(localThrowable2);
/*  778:     */           }
/*  779:     */         } else {
/*  780:1071 */           jedis.close();
/*  781:     */         }
/*  782:     */       }
/*  783:     */     }
/*  784:     */   }
/*  785:     */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.cache.RedisCache
 * JD-Core Version:    0.7.0.1
 */