/*  1:   */ package com.afocus.framework.exception;
/*  2:   */ 
/*  3:   */ public class ServiceOperationException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 4618415364025173907L;
/*  7:   */   
/*  8:   */   public ServiceOperationException() {}
/*  9:   */   
/* 10:   */   public ServiceOperationException(String message)
/* 11:   */   {
/* 12:23 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public ServiceOperationException(String message, Throwable cause)
/* 16:   */   {
/* 17:32 */     super(message, cause);
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.ServiceOperationException
 * JD-Core Version:    0.7.0.1
 */