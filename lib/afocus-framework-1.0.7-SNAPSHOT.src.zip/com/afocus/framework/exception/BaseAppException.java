/*   1:    */ package com.afocus.framework.exception;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.StringUtil;
/*   4:    */ import java.io.PrintWriter;
/*   5:    */ import java.io.StringWriter;
/*   6:    */ 
/*   7:    */ public class BaseAppException
/*   8:    */   extends Exception
/*   9:    */ {
/*  10:    */   private static final long serialVersionUID = 8343048459443313229L;
/*  11: 15 */   private String errorCode = null;
/*  12: 16 */   private Object[] args = null;
/*  13:    */   
/*  14:    */   public String getErrorCode()
/*  15:    */   {
/*  16: 22 */     return this.errorCode;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void setErrorCode(String errorCode)
/*  20:    */   {
/*  21: 29 */     this.errorCode = errorCode;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public BaseAppException() {}
/*  25:    */   
/*  26:    */   public BaseAppException(String errorCode)
/*  27:    */   {
/*  28: 38 */     setErrorCode(errorCode);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public BaseAppException(Throwable cause)
/*  32:    */   {
/*  33: 42 */     super(cause);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public BaseAppException(String errorCode, Throwable cause)
/*  37:    */   {
/*  38: 46 */     super(cause);
/*  39: 47 */     setErrorCode(errorCode);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public BaseAppException(String errorCode, String message, Throwable cause)
/*  43:    */   {
/*  44: 51 */     this(message, cause);
/*  45: 52 */     setErrorCode(errorCode);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public BaseAppException(String errorCode, String message)
/*  49:    */   {
/*  50: 56 */     super(message);
/*  51: 57 */     setErrorCode(errorCode);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public BaseAppException(String errorCode, String message, Object[] args)
/*  55:    */   {
/*  56: 61 */     super(message);
/*  57: 62 */     setErrorCode(errorCode);
/*  58: 63 */     setArgs(args);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public BaseAppException(String errorCode, Object[] args)
/*  62:    */   {
/*  63: 67 */     setErrorCode(errorCode);
/*  64: 68 */     setArgs(args);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public BaseAppException(String errorCode, Throwable cause, Object[] args)
/*  68:    */   {
/*  69: 71 */     super(cause);
/*  70: 72 */     setErrorCode(errorCode);
/*  71: 73 */     setArgs(args);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public BaseAppException(String errorCode, String message, Throwable cause, Object[] args)
/*  75:    */   {
/*  76: 77 */     super(message, cause);
/*  77: 78 */     setErrorCode(errorCode);
/*  78: 79 */     setArgs(args);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static void printMethodCallStack(String message)
/*  82:    */   {
/*  83:    */     try
/*  84:    */     {
/*  85: 84 */       throw new BaseAppException(message);
/*  86:    */     }
/*  87:    */     catch (Exception e)
/*  88:    */     {
/*  89: 87 */       e.printStackTrace();
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static String getStackTraceString(Exception e)
/*  94:    */   {
/*  95: 92 */     StringWriter sw = new StringWriter();
/*  96: 93 */     e.printStackTrace(new PrintWriter(sw));
/*  97: 94 */     return sw.toString();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public String getStackTraceString()
/* 101:    */   {
/* 102: 98 */     return getStackTraceString(this);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String toString()
/* 106:    */   {
/* 107:103 */     StringBuffer ret = new StringBuffer(getClass().getName());
/* 108:104 */     if (!StringUtil.isEmpty(getErrorCode())) {
/* 109:105 */       ret.append(":").append(getErrorCode());
/* 110:    */     }
/* 111:107 */     String message = getLocalizedMessage();
/* 112:108 */     if (!StringUtil.isEmpty(message)) {
/* 113:109 */       ret.append(",").append(message);
/* 114:    */     }
/* 115:111 */     if (this.args != null)
/* 116:    */     {
/* 117:112 */       ret.append(",args:");
/* 118:113 */       for (int i = 0; i < this.args.length; i++) {
/* 119:114 */         ret.append(this.args[i]).append(",");
/* 120:    */       }
/* 121:    */     }
/* 122:116 */     return ret.toString();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Object[] getArgs()
/* 126:    */   {
/* 127:123 */     return this.args;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void setArgs(Object[] args)
/* 131:    */   {
/* 132:130 */     this.args = args;
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.BaseAppException
 * JD-Core Version:    0.7.0.1
 */