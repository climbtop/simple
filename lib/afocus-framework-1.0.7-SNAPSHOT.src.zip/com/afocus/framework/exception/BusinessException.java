/*  1:   */ package com.afocus.framework.exception;
/*  2:   */ 
/*  3:   */ public class BusinessException
/*  4:   */   extends BaseAppException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -2403009184390388310L;
/*  7:   */   
/*  8:   */   public BusinessException() {}
/*  9:   */   
/* 10:   */   public BusinessException(String errorCode, Object[] args)
/* 11:   */   {
/* 12:19 */     super(errorCode, args);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public BusinessException(String errorCode, String message, Object[] args)
/* 16:   */   {
/* 17:24 */     super(errorCode, message, args);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public BusinessException(String errorCode, String message, Throwable cause, Object[] args)
/* 21:   */   {
/* 22:29 */     super(errorCode, message, cause, args);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public BusinessException(String errorCode, String message, Throwable cause)
/* 26:   */   {
/* 27:34 */     super(errorCode, message, cause);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public BusinessException(String errorCode, String message)
/* 31:   */   {
/* 32:39 */     super(errorCode, message);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public BusinessException(String errorCode, Throwable cause, Object[] args)
/* 36:   */   {
/* 37:44 */     super(errorCode, cause, args);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public BusinessException(String errorCode, Throwable cause)
/* 41:   */   {
/* 42:49 */     super(errorCode, cause);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public BusinessException(String errorCode)
/* 46:   */   {
/* 47:54 */     super(errorCode);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public BusinessException(Throwable cause)
/* 51:   */   {
/* 52:59 */     super(cause);
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.BusinessException
 * JD-Core Version:    0.7.0.1
 */