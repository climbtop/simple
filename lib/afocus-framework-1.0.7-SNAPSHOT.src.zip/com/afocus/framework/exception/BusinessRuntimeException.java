/*  1:   */ package com.afocus.framework.exception;
/*  2:   */ 
/*  3:   */ public class BusinessRuntimeException
/*  4:   */   extends BaseAppRuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1325601692472497460L;
/*  7:   */   
/*  8:   */   public BusinessRuntimeException(Exception e)
/*  9:   */   {
/* 10:13 */     super(e);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public BusinessRuntimeException() {}
/* 14:   */   
/* 15:   */   public BusinessRuntimeException(String errorCode, Object[] args)
/* 16:   */   {
/* 17:22 */     super(errorCode, args);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public BusinessRuntimeException(String errorCode, String message, Object[] args)
/* 21:   */   {
/* 22:27 */     super(errorCode, message, args);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public BusinessRuntimeException(String errorCode, String message, Throwable cause, Object[] args)
/* 26:   */   {
/* 27:32 */     super(errorCode, message, cause, args);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public BusinessRuntimeException(String errorCode, String message, Throwable cause)
/* 31:   */   {
/* 32:37 */     super(errorCode, message, cause);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public BusinessRuntimeException(String errorCode, String message)
/* 36:   */   {
/* 37:42 */     super(errorCode, message);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public BusinessRuntimeException(String errorCode, Throwable cause, Object[] args)
/* 41:   */   {
/* 42:47 */     super(errorCode, cause, args);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public BusinessRuntimeException(String errorCode, Throwable cause)
/* 46:   */   {
/* 47:52 */     super(errorCode, cause);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public BusinessRuntimeException(String errorCode)
/* 51:   */   {
/* 52:57 */     super(errorCode);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public BusinessRuntimeException(Throwable cause)
/* 56:   */   {
/* 57:62 */     super(cause);
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.BusinessRuntimeException
 * JD-Core Version:    0.7.0.1
 */