/*   1:    */ package com.afocus.framework.exception;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.StringUtil;
/*   4:    */ import java.io.PrintWriter;
/*   5:    */ import java.io.StringWriter;
/*   6:    */ 
/*   7:    */ public class BaseAppRuntimeException
/*   8:    */   extends RuntimeException
/*   9:    */ {
/*  10:    */   private static final long serialVersionUID = -6021077900819863433L;
/*  11: 15 */   private String errorCode = null;
/*  12: 16 */   private Object[] args = null;
/*  13:    */   
/*  14:    */   public String getErrorCode()
/*  15:    */   {
/*  16: 22 */     return this.errorCode;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void setErrorCode(String errorCode)
/*  20:    */   {
/*  21: 29 */     this.errorCode = errorCode;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public BaseAppRuntimeException() {}
/*  25:    */   
/*  26:    */   public BaseAppRuntimeException(String errorCode)
/*  27:    */   {
/*  28: 38 */     setErrorCode(errorCode);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public BaseAppRuntimeException(Throwable cause)
/*  32:    */   {
/*  33: 42 */     super(cause);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public BaseAppRuntimeException(String errorCode, Throwable cause)
/*  37:    */   {
/*  38: 46 */     super(cause);
/*  39: 47 */     setErrorCode(errorCode);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public BaseAppRuntimeException(String errorCode, String message, Throwable cause)
/*  43:    */   {
/*  44: 51 */     this(message, cause);
/*  45: 52 */     setErrorCode(errorCode);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public BaseAppRuntimeException(String errorCode, String message)
/*  49:    */   {
/*  50: 56 */     super(message);
/*  51: 57 */     setErrorCode(errorCode);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public BaseAppRuntimeException(String errorCode, String message, Object[] args)
/*  55:    */   {
/*  56: 61 */     super(message);
/*  57: 62 */     setErrorCode(errorCode);
/*  58: 63 */     setArgs(args);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public BaseAppRuntimeException(String errorCode, Object[] args)
/*  62:    */   {
/*  63: 67 */     setErrorCode(errorCode);
/*  64: 68 */     setArgs(args);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public BaseAppRuntimeException(String errorCode, Throwable cause, Object[] args)
/*  68:    */   {
/*  69: 71 */     super(cause);
/*  70: 72 */     setErrorCode(errorCode);
/*  71: 73 */     setArgs(args);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public BaseAppRuntimeException(String errorCode, String message, Throwable cause, Object[] args)
/*  75:    */   {
/*  76: 77 */     super(message, cause);
/*  77: 78 */     setErrorCode(errorCode);
/*  78: 79 */     setArgs(args);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String getStackTraceString()
/*  82:    */   {
/*  83: 86 */     StringWriter sw = new StringWriter();
/*  84: 87 */     printStackTrace(new PrintWriter(sw));
/*  85: 88 */     return sw.toString();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public String toString()
/*  89:    */   {
/*  90: 93 */     StringBuffer ret = new StringBuffer(getClass().getName());
/*  91: 94 */     if (!StringUtil.isEmpty(getErrorCode())) {
/*  92: 95 */       ret.append(":").append(getErrorCode());
/*  93:    */     }
/*  94: 97 */     String message = getLocalizedMessage();
/*  95: 98 */     if (!StringUtil.isEmpty(message)) {
/*  96: 99 */       ret.append(",").append(message);
/*  97:    */     }
/*  98:101 */     if (this.args != null)
/*  99:    */     {
/* 100:102 */       ret.append(",args:");
/* 101:103 */       for (int i = 0; i < this.args.length; i++) {
/* 102:104 */         ret.append(this.args[i]).append(",");
/* 103:    */       }
/* 104:    */     }
/* 105:106 */     return ret.toString();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Object[] getArgs()
/* 109:    */   {
/* 110:113 */     return this.args;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setArgs(Object[] args)
/* 114:    */   {
/* 115:120 */     this.args = args;
/* 116:    */   }
/* 117:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.BaseAppRuntimeException
 * JD-Core Version:    0.7.0.1
 */