/*  1:   */ package com.afocus.framework.exception;
/*  2:   */ 
/*  3:   */ public class RequestIllegalException
/*  4:   */   extends IllegalArgumentException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 508756173313949529L;
/*  7:   */   
/*  8:   */   public RequestIllegalException() {}
/*  9:   */   
/* 10:   */   public RequestIllegalException(String message)
/* 11:   */   {
/* 12:23 */     super(message);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.RequestIllegalException
 * JD-Core Version:    0.7.0.1
 */