/*  1:   */ package com.afocus.framework.exception.handler;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.exception.BaseAppException;
/*  4:   */ import com.afocus.framework.exception.BaseAppRuntimeException;
/*  5:   */ import com.afocus.framework.util.StringUtil;
/*  6:   */ import javax.servlet.http.HttpServletRequest;
/*  7:   */ import javax.servlet.http.HttpServletResponse;
/*  8:   */ import org.apache.log4j.Logger;
/*  9:   */ import org.springframework.context.ApplicationContext;
/* 10:   */ import org.springframework.context.NoSuchMessageException;
/* 11:   */ import org.springframework.core.Ordered;
/* 12:   */ import org.springframework.web.servlet.DispatcherServlet;
/* 13:   */ import org.springframework.web.servlet.HandlerExceptionResolver;
/* 14:   */ import org.springframework.web.servlet.ModelAndView;
/* 15:   */ 
/* 16:   */ public class BaseAppExceptionHandler
/* 17:   */   implements HandlerExceptionResolver, Ordered
/* 18:   */ {
/* 19:   */   private int order;
/* 20:24 */   private String exceptionView = null;
/* 21:25 */   private Logger log = Logger.getLogger(getClass());
/* 22:   */   
/* 23:   */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception e)
/* 24:   */   {
/* 25:31 */     if (StringUtil.isEmpty(this.exceptionView)) {
/* 26:32 */       return null;
/* 27:   */     }
/* 28:34 */     ApplicationContext acx = (ApplicationContext)request.getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 29:   */     
/* 30:36 */     String message = null;
/* 31:37 */     ModelAndView mv = new ModelAndView(this.exceptionView, "exception", e);
/* 32:38 */     if ((e instanceof BaseAppException))
/* 33:   */     {
/* 34:39 */       BaseAppException ex = (BaseAppException)e;
/* 35:   */       try
/* 36:   */       {
/* 37:41 */         message = acx.getMessage(ex.getErrorCode(), ex.getArgs(), request.getLocale());
/* 38:   */       }
/* 39:   */       catch (NoSuchMessageException e1)
/* 40:   */       {
/* 41:43 */         this.log.warn("in message file no key: " + ex.getErrorCode());
/* 42:   */       }
/* 43:   */     }
/* 44:46 */     else if ((e instanceof BaseAppRuntimeException))
/* 45:   */     {
/* 46:47 */       BaseAppRuntimeException ex = (BaseAppRuntimeException)e;
/* 47:   */       try
/* 48:   */       {
/* 49:49 */         message = acx.getMessage(ex.getErrorCode(), ex.getArgs(), request.getLocale());
/* 50:   */       }
/* 51:   */       catch (NoSuchMessageException e1)
/* 52:   */       {
/* 53:51 */         this.log.warn("in message file no key: " + ex.getErrorCode());
/* 54:   */       }
/* 55:   */     }
/* 56:55 */     if (StringUtil.isEmpty(message))
/* 57:   */     {
/* 58:56 */       message = e.getLocalizedMessage();
/* 59:57 */       if (StringUtil.isEmpty(message)) {
/* 60:58 */         message = e.toString();
/* 61:   */       }
/* 62:   */     }
/* 63:62 */     mv.addObject("errorMessage", message);
/* 64:63 */     return mv;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int getOrder()
/* 68:   */   {
/* 69:67 */     return this.order;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public void setOrder(int order)
/* 73:   */   {
/* 74:71 */     this.order = order;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public String getExceptionView()
/* 78:   */   {
/* 79:78 */     return this.exceptionView;
/* 80:   */   }
/* 81:   */   
/* 82:   */   public void setExceptionView(String exceptionView)
/* 83:   */   {
/* 84:85 */     this.exceptionView = exceptionView;
/* 85:   */   }
/* 86:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.exception.handler.BaseAppExceptionHandler
 * JD-Core Version:    0.7.0.1
 */