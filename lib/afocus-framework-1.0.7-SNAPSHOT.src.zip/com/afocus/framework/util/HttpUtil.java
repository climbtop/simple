/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.http.LocalHttpClient;
/*   4:    */ import com.alibaba.fastjson.JSONObject;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import org.apache.commons.codec.Charsets;
/*  10:    */ import org.apache.http.HttpEntity;
/*  11:    */ import org.apache.http.HttpResponse;
/*  12:    */ import org.apache.http.StatusLine;
/*  13:    */ import org.apache.http.client.ClientProtocolException;
/*  14:    */ import org.apache.http.client.ResponseHandler;
/*  15:    */ import org.apache.http.client.methods.RequestBuilder;
/*  16:    */ import org.apache.http.entity.StringEntity;
/*  17:    */ import org.apache.http.util.EntityUtils;
/*  18:    */ import org.slf4j.Logger;
/*  19:    */ import org.slf4j.LoggerFactory;
/*  20:    */ 
/*  21:    */ @Deprecated
/*  22:    */ public class HttpUtil
/*  23:    */ {
/*  24: 31 */   private static final Logger log = LoggerFactory.getLogger(HttpUtil.class);
/*  25: 34 */   private static ResponseHandler<String> stringResponseHandler = new ResponseHandler()
/*  26:    */   {
/*  27:    */     public String handleResponse(HttpResponse response)
/*  28:    */       throws ClientProtocolException, IOException
/*  29:    */     {
/*  30: 37 */       int status = response.getStatusLine().getStatusCode();
/*  31: 38 */       if ((status >= 200) && (status < 300))
/*  32:    */       {
/*  33: 39 */         HttpEntity entity = response.getEntity();
/*  34: 40 */         return EntityUtils.toString(entity);
/*  35:    */       }
/*  36: 42 */       throw new ClientProtocolException("Unexpected response status: " + status);
/*  37:    */     }
/*  38:    */   };
/*  39:    */   
/*  40:    */   public static String post(String url, Map<String, Object> params)
/*  41:    */   {
/*  42: 57 */     return post(url, params, Collections.emptyMap());
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static String post(String url, Map<String, Object> params, Map<String, String> headers)
/*  46:    */   {
/*  47: 70 */     return execute(RequestBuilder.post(), url, params, headers);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static String post(String url, Map<String, Object> params, Map<String, String> headers, String data)
/*  51:    */   {
/*  52: 82 */     RequestBuilder builder = RequestBuilder.post().setUri(url);
/*  53: 83 */     addHeaders(builder, headers);
/*  54: 84 */     addParameters(builder, params);
/*  55: 85 */     builder.setEntity(new StringEntity(data, Charsets.UTF_8));
/*  56:    */     
/*  57: 87 */     return (String)LocalHttpClient.execute(builder.build(), stringResponseHandler);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static String get(String url, Map<String, Object> params)
/*  61:    */   {
/*  62: 98 */     return get(url, params, Collections.emptyMap());
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static String get(String url, Map<String, Object> params, Map<String, String> headers)
/*  66:    */   {
/*  67:110 */     return execute(RequestBuilder.get(), url, params, headers);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static JSONObject getJson(String url, Map<String, Object> params)
/*  71:    */   {
/*  72:114 */     return JSONObject.parseObject(get(url, params));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static JSONObject getJson(String url, Map<String, Object> params, Map<String, String> headers)
/*  76:    */   {
/*  77:118 */     return JSONObject.parseObject(get(url, params, headers));
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static String put(String url, Map<String, Object> params)
/*  81:    */   {
/*  82:130 */     return put(url, params, Collections.emptyMap());
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static String put(String url, Map<String, Object> params, Map<String, String> headers)
/*  86:    */   {
/*  87:143 */     return execute(RequestBuilder.put(), url, params, headers);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static String delete(String url, Map<String, Object> params)
/*  91:    */   {
/*  92:154 */     return delete(url, params, Collections.emptyMap());
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static String delete(String url, Map<String, Object> params, Map<String, String> headers)
/*  96:    */   {
/*  97:166 */     return execute(RequestBuilder.delete(), url, params, headers);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static String head(String url, Map<String, Object> params)
/* 101:    */   {
/* 102:179 */     return head(url, params, Collections.emptyMap());
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static String head(String url, Map<String, Object> params, Map<String, String> headers)
/* 106:    */   {
/* 107:192 */     return execute(RequestBuilder.head(), url, params, headers);
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static String execute(RequestBuilder builder, String url, Map<String, Object> params, Map<String, String> headers)
/* 111:    */   {
/* 112:197 */     builder.setUri(url);
/* 113:198 */     addHeaders(builder, headers);
/* 114:199 */     addParameters(builder, params);
/* 115:200 */     return (String)LocalHttpClient.execute(builder.build(), stringResponseHandler);
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static RequestBuilder addHeaders(RequestBuilder builder, Map<String, String> headers)
/* 119:    */   {
/* 120:204 */     if ((headers != null) && (headers.size() > 0)) {
/* 121:205 */       for (Map.Entry<String, String> head : headers.entrySet()) {
/* 122:206 */         builder.addHeader((String)head.getKey(), (String)head.getValue());
/* 123:    */       }
/* 124:    */     }
/* 125:209 */     return builder;
/* 126:    */   }
/* 127:    */   
/* 128:    */   private static RequestBuilder addParameters(RequestBuilder builder, Map<String, Object> params)
/* 129:    */   {
/* 130:213 */     if ((params != null) && (params.size() > 0)) {
/* 131:214 */       for (Map.Entry<String, Object> head : params.entrySet()) {
/* 132:215 */         builder.addParameter((String)head.getKey(), head.getValue().toString());
/* 133:    */       }
/* 134:    */     }
/* 135:218 */     return builder;
/* 136:    */   }
/* 137:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.HttpUtil
 * JD-Core Version:    0.7.0.1
 */