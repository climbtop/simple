/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.text.MessageFormat;
/*   4:    */ import java.util.regex.Matcher;
/*   5:    */ import java.util.regex.Pattern;
/*   6:    */ 
/*   7:    */ public class HtmlUtil
/*   8:    */ {
/*   9:    */   private static final String XMP = "<xmp>{0}</xmp>";
/*  10:    */   private static final String PRE = "<pre>{0}</pre>";
/*  11:    */   
/*  12:    */   public static String encodeHtml(String str)
/*  13:    */   {
/*  14: 18 */     if ((str == null) || (str.equals(""))) {
/*  15: 19 */       return "";
/*  16:    */     }
/*  17: 22 */     char[] content = new char[str.length()];
/*  18: 23 */     str.getChars(0, str.length(), content, 0);
/*  19:    */     
/*  20: 25 */     StringBuffer result = new StringBuffer(content.length + 50);
/*  21: 26 */     char preChar = ' ';
/*  22: 27 */     for (int i = 0; i < content.length; i++)
/*  23:    */     {
/*  24: 28 */       switch (content[i])
/*  25:    */       {
/*  26:    */       case '<': 
/*  27: 30 */         result.append("&lt;");
/*  28: 31 */         break;
/*  29:    */       case '>': 
/*  30: 33 */         result.append("&gt;");
/*  31: 34 */         break;
/*  32:    */       case '&': 
/*  33: 36 */         result.append("&amp;");
/*  34: 37 */         break;
/*  35:    */       case '"': 
/*  36: 39 */         result.append("&quot;");
/*  37: 40 */         break;
/*  38:    */       case ' ': 
/*  39: 42 */         result.append("&nbsp;");
/*  40: 43 */         break;
/*  41:    */       case '\r': 
/*  42: 45 */         result.append("<br>");
/*  43: 46 */         break;
/*  44:    */       case '\n': 
/*  45: 49 */         if (preChar != '\r') {
/*  46: 50 */           result.append("<br>");
/*  47:    */         }
/*  48:    */         break;
/*  49:    */       default: 
/*  50: 54 */         result.append(content[i]);
/*  51:    */       }
/*  52: 56 */       preChar = content[i];
/*  53:    */     }
/*  54: 58 */     return result.toString();
/*  55:    */   }
/*  56:    */   
/*  57:    */   @Deprecated
/*  58:    */   public static String encodeHtmlTag(String str)
/*  59:    */   {
/*  60: 69 */     if ((str == null) || (str.equals(""))) {
/*  61: 70 */       return "";
/*  62:    */     }
/*  63: 72 */     str = formatContent(str);
/*  64: 73 */     return encodeHtml(str);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static String filterFontTag(String str)
/*  68:    */   {
/*  69: 83 */     if ((str == null) || (str.length() == 0)) {
/*  70: 84 */       return str;
/*  71:    */     }
/*  72: 86 */     return str.replaceAll("<font.*?</font>", "");
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static String filterHrefTag(String str)
/*  76:    */   {
/*  77: 94 */     if ((str == null) || (str.length() == 0)) {
/*  78: 95 */       return str;
/*  79:    */     }
/*  80: 97 */     return str.replaceAll("<a.*?</a>", "");
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static String filterJavaScriptTag(String str)
/*  84:    */   {
/*  85:108 */     if ((str == null) || (str.length() == 0) || ((str.toLowerCase().indexOf("script") < 0) && (str.toLowerCase().indexOf("javascript") < 0))) {
/*  86:109 */       return str;
/*  87:    */     }
/*  88:111 */     return Pattern.compile("\\<(\\s*)(script)(\\s.*?)?\\>((\\s|.)*?)\\<\\/(\\s*)(script)(\\s.*?)?\\>", 2).matcher(str).replaceAll("");
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static String filterRowTag(String str)
/*  92:    */   {
/*  93:119 */     if ((str == null) || (str.length() == 0)) {
/*  94:120 */       return str;
/*  95:    */     }
/*  96:122 */     return str.replaceAll("\r\n", "<br>").replaceAll("\n", "<br>").replaceAll("\r", "<br>");
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static String formatContent(String str)
/* 100:    */   {
/* 101:131 */     String[] contents = str.split("\r");
/* 102:132 */     if (contents == null) {
/* 103:133 */       return "　　" + str.trim().replace("　　", "");
/* 104:    */     }
/* 105:135 */     StringBuffer content = new StringBuffer("");
/* 106:136 */     for (int i = 0; i < contents.length; i++) {
/* 107:137 */       if (i == 0) {
/* 108:139 */         content.append("　　" + contents[i].trim().replace("　　", ""));
/* 109:    */       } else {
/* 110:141 */         content.append("\r　　" + contents[i].trim().replace("　　", ""));
/* 111:    */       }
/* 112:    */     }
/* 113:144 */     return content.toString();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static boolean isBmp(String fileName)
/* 117:    */   {
/* 118:153 */     if (fileName.toLowerCase().endsWith(".bmp")) {
/* 119:154 */       return true;
/* 120:    */     }
/* 121:156 */     return false;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static boolean isGif(String fileName)
/* 125:    */   {
/* 126:165 */     if (fileName.toLowerCase().endsWith(".gif")) {
/* 127:166 */       return true;
/* 128:    */     }
/* 129:168 */     return false;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static boolean isJpg(String fileName)
/* 133:    */   {
/* 134:176 */     if (fileName.toLowerCase().endsWith(".jpg")) {
/* 135:177 */       return true;
/* 136:    */     }
/* 137:179 */     return false;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static boolean isPng(String fileName)
/* 141:    */   {
/* 142:187 */     if (fileName.toLowerCase().endsWith(".png")) {
/* 143:188 */       return true;
/* 144:    */     }
/* 145:190 */     return false;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public static boolean isJpeg(String fileName)
/* 149:    */   {
/* 150:199 */     if (fileName.toLowerCase().endsWith(".jpeg")) {
/* 151:200 */       return true;
/* 152:    */     }
/* 153:202 */     return false;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public static boolean isPicUrl(String url)
/* 157:    */   {
/* 158:211 */     if (StringUtil.isNullOrBlank(url)) {
/* 159:212 */       return false;
/* 160:    */     }
/* 161:215 */     return (isPng(url)) || (isBmp(url)) || (isGif(url)) || (isJpg(url)) || (isJpeg(url));
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static String decodeHtml(String str)
/* 165:    */   {
/* 166:224 */     if ((str == null) || (str.equals(""))) {
/* 167:225 */       return str;
/* 168:    */     }
/* 169:229 */     str = str.replaceAll("<br>", "\r");
/* 170:230 */     str = str.replaceAll("&nbsp;", " ");
/* 171:231 */     str = str.replaceAll("&quot;", "\"");
/* 172:232 */     str = str.replaceAll("&lt;", "<");
/* 173:233 */     str = str.replaceAll("&gt;", ">");
/* 174:234 */     str = str.replaceAll("&amp;", "&");
/* 175:235 */     return str;
/* 176:    */   }
/* 177:    */   
/* 178:    */   @Deprecated
/* 179:    */   public static String unEncodeHtmlTag(String str)
/* 180:    */   {
/* 181:248 */     return decodeHtml(str);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static boolean isSpecUrl(String url)
/* 185:    */   {
/* 186:257 */     if (url.indexOf("login.tianya.cn") > 0) {
/* 187:258 */       return true;
/* 188:    */     }
/* 189:260 */     if (url.indexOf("loginsubmit.asp") > 0) {
/* 190:261 */       return true;
/* 191:    */     }
/* 192:263 */     if (url.indexOf("loginout.asp") > 0) {
/* 193:264 */       return true;
/* 194:    */     }
/* 195:266 */     return false;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public static String includeToXmp(String value)
/* 199:    */   {
/* 200:281 */     if ((value == null) || ("".equals(value))) {
/* 201:281 */       return "";
/* 202:    */     }
/* 203:282 */     return MessageFormat.format("<xmp>{0}</xmp>", new Object[] { value });
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static String includeToPre(String value)
/* 207:    */   {
/* 208:294 */     if ((value == null) || ("".equals(value))) {
/* 209:294 */       return "";
/* 210:    */     }
/* 211:295 */     return MessageFormat.format("<pre>{0}</pre>", new Object[] { value });
/* 212:    */   }
/* 213:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.HtmlUtil
 * JD-Core Version:    0.7.0.1
 */