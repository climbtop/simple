/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ 
/*   5:    */ public class PageTurn
/*   6:    */   implements Serializable
/*   7:    */ {
/*   8:    */   private static final long serialVersionUID = -3078109584161867959L;
/*   9: 16 */   private int pageCount = 0;
/*  10: 18 */   private int page = 0;
/*  11: 24 */   private int start = 0;
/*  12: 26 */   private int end = 0;
/*  13: 28 */   private int pageSize = 0;
/*  14: 30 */   private int rowCount = 0;
/*  15:    */   public static final int DEFAULT_PAGE_SIZE = 1000;
/*  16:    */   
/*  17:    */   public PageTurn()
/*  18:    */   {
/*  19: 40 */     this.page = 1;
/*  20: 41 */     this.pageSize = 1000;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public PageTurn(int page, int pagesize)
/*  24:    */   {
/*  25: 53 */     initWithPage(page, pagesize, (page > 0 ? page : 1) * pagesize);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public PageTurn(int page, int pagesize, int rowscount)
/*  29:    */   {
/*  30: 67 */     initWithPage(page, pagesize, rowscount);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void initWithPage(int page, int pagesize, int rowscount)
/*  34:    */   {
/*  35: 81 */     initWithStart((page - 1) * pagesize, pagesize, rowscount);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void initWithStart(int startRow, int pagesize, int rowscount)
/*  39:    */   {
/*  40: 97 */     if ((rowscount <= 0) || (pagesize <= 0)) {
/*  41: 98 */       return;
/*  42:    */     }
/*  43:101 */     this.rowCount = rowscount;
/*  44:    */     
/*  45:    */ 
/*  46:104 */     this.pageSize = pagesize;
/*  47:    */     
/*  48:106 */     int startResult = startRow < 0 ? 0 : startRow;
/*  49:107 */     if (startResult > rowscount) {
/*  50:109 */       startResult = rowscount - rowscount % pagesize;
/*  51:    */     }
/*  52:111 */     if (startResult < 0) {
/*  53:112 */       startResult = 0;
/*  54:    */     }
/*  55:114 */     this.start = startResult;
/*  56:    */     
/*  57:116 */     this.pageCount = ((int)Math.ceil(rowscount / pagesize));
/*  58:    */     
/*  59:118 */     int pageResult = startResult / pagesize + 1;
/*  60:119 */     if (pageResult > this.pageCount) {
/*  61:120 */       pageResult = this.pageCount;
/*  62:    */     }
/*  63:121 */     this.page = pageResult;
/*  64:    */     
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:127 */     int endResult = startResult + pagesize;
/*  70:128 */     endResult = endResult > rowscount ? rowscount : endResult;
/*  71:129 */     this.end = endResult;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public Integer getEnd()
/*  75:    */   {
/*  76:145 */     return Integer.valueOf(this.end);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Integer getPage()
/*  80:    */   {
/*  81:152 */     return Integer.valueOf(this.page);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Integer getCurrentPage()
/*  85:    */   {
/*  86:159 */     return Integer.valueOf(this.page);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Integer getPageCount()
/*  90:    */   {
/*  91:173 */     return Integer.valueOf(this.pageCount);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public Integer getPageSize()
/*  95:    */   {
/*  96:180 */     return Integer.valueOf(this.pageSize);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Integer getRowCount()
/* 100:    */   {
/* 101:194 */     return Integer.valueOf(this.rowCount);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Integer getStart()
/* 105:    */   {
/* 106:201 */     return Integer.valueOf(this.start);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setPageCount(Integer pageCount)
/* 110:    */   {
/* 111:293 */     this.pageCount = pageCount.intValue();
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setPage(Integer page)
/* 115:    */   {
/* 116:297 */     this.page = page.intValue();
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setStart(Integer start)
/* 120:    */   {
/* 121:309 */     this.start = start.intValue();
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setEnd(Integer end)
/* 125:    */   {
/* 126:313 */     this.end = end.intValue();
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void setPageSize(Integer pageSize)
/* 130:    */   {
/* 131:317 */     this.pageSize = pageSize.intValue();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setRowCount(Integer rowCount)
/* 135:    */   {
/* 136:321 */     this.rowCount = rowCount.intValue();
/* 137:    */   }
/* 138:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.PageTurn
 * JD-Core Version:    0.7.0.1
 */