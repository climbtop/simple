/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.alibaba.fastjson.JSONObject;
/*   4:    */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*   5:    */ import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.apache.commons.lang3.StringUtils;
/*  10:    */ import org.slf4j.Logger;
/*  11:    */ import org.slf4j.LoggerFactory;
/*  12:    */ 
/*  13:    */ public class JsonUtils
/*  14:    */ {
/*  15: 19 */   private static final Logger log = LoggerFactory.getLogger(JsonUtils.class);
/*  16:    */   
/*  17:    */   public static <T> T parseObject(String text, Class<T> clazz)
/*  18:    */   {
/*  19: 29 */     if (StringUtils.isEmpty(text)) {
/*  20: 30 */       return null;
/*  21:    */     }
/*  22:    */     try
/*  23:    */     {
/*  24: 32 */       return JSONObject.parseObject(text, clazz);
/*  25:    */     }
/*  26:    */     catch (Exception e)
/*  27:    */     {
/*  28: 34 */       LogUtil.error(log, e);
/*  29: 35 */       e.printStackTrace();
/*  30:    */     }
/*  31: 36 */     return null;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <T> List<T> parseArray(String text, Class<T> clazz)
/*  35:    */   {
/*  36: 48 */     if (StringUtils.isEmpty(text)) {
/*  37: 49 */       return Collections.emptyList();
/*  38:    */     }
/*  39:    */     try
/*  40:    */     {
/*  41: 51 */       return JSONObject.parseArray(text, clazz);
/*  42:    */     }
/*  43:    */     catch (Exception e)
/*  44:    */     {
/*  45: 53 */       LogUtil.error(log, e);
/*  46: 54 */       e.printStackTrace();
/*  47:    */     }
/*  48: 55 */     return Collections.emptyList();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static String toJSONString(Object object, String... properties)
/*  52:    */   {
/*  53: 76 */     if ((properties != null) && (properties.length > 0))
/*  54:    */     {
/*  55: 77 */       SimplePropertyPreFilter filter = new SimplePropertyPreFilter(properties);
/*  56: 78 */       return JSONObject.toJSONString(object, filter, new SerializerFeature[0]);
/*  57:    */     }
/*  58: 80 */     return JSONObject.toJSONString(object);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static String toJSONStringByIgnore(Object object, String... ignoreField)
/*  62:    */   {
/*  63:100 */     if ((ignoreField != null) && (ignoreField.length > 0))
/*  64:    */     {
/*  65:101 */       SimplePropertyPreFilter filter = new SimplePropertyPreFilter(new String[0]);
/*  66:102 */       for (String ignore : ignoreField) {
/*  67:103 */         filter.getExcludes().add(ignore);
/*  68:    */       }
/*  69:105 */       return JSONObject.toJSONString(object, filter, new SerializerFeature[0]);
/*  70:    */     }
/*  71:107 */     return JSONObject.toJSONString(object);
/*  72:    */   }
/*  73:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.JsonUtils
 * JD-Core Version:    0.7.0.1
 */