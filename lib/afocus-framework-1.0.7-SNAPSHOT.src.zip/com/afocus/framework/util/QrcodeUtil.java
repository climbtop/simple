/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.google.zxing.BarcodeFormat;
/*   4:    */ import com.google.zxing.EncodeHintType;
/*   5:    */ import com.google.zxing.MultiFormatWriter;
/*   6:    */ import com.google.zxing.client.j2se.MatrixToImageWriter;
/*   7:    */ import com.google.zxing.common.BitMatrix;
/*   8:    */ import java.awt.image.BufferedImage;
/*   9:    */ import java.io.ByteArrayOutputStream;
/*  10:    */ import java.io.PrintStream;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.Map;
/*  13:    */ import javax.imageio.ImageIO;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public final class QrcodeUtil
/*  18:    */ {
/*  19:    */   private static final String SERVER_URL = "http://imageserver.afocus.com/upload";
/*  20: 24 */   private static final Logger log = LoggerFactory.getLogger(QrcodeUtil.class);
/*  21:    */   
/*  22:    */   public static ByteArrayOutputStream generate(String content, int width, int height, String format)
/*  23:    */     throws Exception
/*  24:    */   {
/*  25: 31 */     Map<EncodeHintType, Object> hints = new HashMap();
/*  26: 32 */     hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
/*  27:    */     
/*  28:    */ 
/*  29: 35 */     BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, width, height, hints);
/*  30:    */     
/*  31: 37 */     BufferedImage buffer = MatrixToImageWriter.toBufferedImage(bitMatrix);
/*  32: 38 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  33: 39 */     ImageIO.write(buffer, format, out);
/*  34: 40 */     return out;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static String generateQrcode(Integer appCode, String content, int width, int height)
/*  38:    */   {
/*  39: 52 */     String fileName = StringUtil.randNum(6) + ".png";
/*  40: 53 */     if (width <= 0) {
/*  41: 54 */       width = 480;
/*  42:    */     }
/*  43: 56 */     if (height <= 0) {
/*  44: 57 */       height = 480;
/*  45:    */     }
/*  46: 59 */     String format = "png";
/*  47:    */     try
/*  48:    */     {
/*  49: 61 */       byte[] data = generate(content, width, height, format).toByteArray();
/*  50: 62 */       log.info("----------二维码字节长度：" + data.length + "-----------");
/*  51: 63 */       return UploadFileUtil.uploadFile("http://imageserver.afocus.com/upload", String.valueOf(appCode), fileName, data);
/*  52:    */     }
/*  53:    */     catch (Exception ex)
/*  54:    */     {
/*  55: 65 */       LogUtil.error(log, ex);
/*  56:    */     }
/*  57: 67 */     return "";
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static String generateQrcode(String content, Integer appCode, Integer userId, Integer type)
/*  61:    */   {
/*  62: 77 */     String fileName = appCode + "_" + userId + "_" + StringUtil.randNum(6) + ".jpg";
/*  63: 78 */     Integer size = Integer.valueOf(QRSizeEnum.getSize(type.intValue()));
/*  64:    */     
/*  65:    */ 
/*  66: 81 */     String format = "jpg";
/*  67:    */     try
/*  68:    */     {
/*  69: 84 */       byte[] data = generate(content, size.intValue(), size.intValue(), "jpg").toByteArray();
/*  70: 85 */       log.info("----------二维码字节长度：" + data.length + "-----------");
/*  71: 86 */       return UploadFileUtil.uploadFile("http://imageserver.afocus.com/upload", String.valueOf(appCode), fileName, data);
/*  72:    */     }
/*  73:    */     catch (Exception ex)
/*  74:    */     {
/*  75: 88 */       LogUtil.error(log, ex);
/*  76:    */     }
/*  77: 91 */     return "";
/*  78:    */   }
/*  79:    */   
/*  80:    */   private static enum QRSizeEnum
/*  81:    */   {
/*  82: 99 */     SMALLEST(1, 390, "8CM"),  NORMAL(2, 730, "15CM"),  BIG(3, 1455, "30CM"),  BIGGEST(4, 2410, "50CM");
/*  83:    */     
/*  84:    */     int id;
/*  85:    */     int size;
/*  86:    */     String text;
/*  87:    */     
/*  88:    */     private QRSizeEnum(int id, int size, String text)
/*  89:    */     {
/*  90:110 */       this.id = id;
/*  91:111 */       this.size = size;
/*  92:112 */       this.text = text;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public static int getSize(int type)
/*  96:    */     {
/*  97:122 */       System.out.println("type=" + type);
/*  98:123 */       if (type == SMALLEST.getId()) {
/*  99:124 */         return SMALLEST.getSize();
/* 100:    */       }
/* 101:125 */       if (type == NORMAL.getId()) {
/* 102:126 */         return NORMAL.getSize();
/* 103:    */       }
/* 104:127 */       if (type == BIG.getId()) {
/* 105:128 */         return BIG.getSize();
/* 106:    */       }
/* 107:129 */       if (type == BIGGEST.getId()) {
/* 108:130 */         return BIGGEST.getSize();
/* 109:    */       }
/* 110:132 */       return 480;
/* 111:    */     }
/* 112:    */     
/* 113:    */     public int getId()
/* 114:    */     {
/* 115:136 */       return this.id;
/* 116:    */     }
/* 117:    */     
/* 118:    */     public void setId(int id)
/* 119:    */     {
/* 120:140 */       this.id = id;
/* 121:    */     }
/* 122:    */     
/* 123:    */     public int getSize()
/* 124:    */     {
/* 125:144 */       return this.size;
/* 126:    */     }
/* 127:    */     
/* 128:    */     public void setSize(int size)
/* 129:    */     {
/* 130:148 */       this.size = size;
/* 131:    */     }
/* 132:    */     
/* 133:    */     public String getText()
/* 134:    */     {
/* 135:152 */       return this.text;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public void setText(String text)
/* 139:    */     {
/* 140:156 */       this.text = text;
/* 141:    */     }
/* 142:    */   }
/* 143:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.QrcodeUtil
 * JD-Core Version:    0.7.0.1
 */