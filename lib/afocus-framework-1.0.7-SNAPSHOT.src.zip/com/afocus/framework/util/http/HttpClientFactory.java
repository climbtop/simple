/*  1:   */ package com.afocus.framework.util.http;
/*  2:   */ 
/*  3:   */ import org.apache.http.client.HttpClient;
/*  4:   */ import org.apache.http.impl.client.HttpClients;
/*  5:   */ import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
/*  6:   */ 
/*  7:   */ public class HttpClientFactory
/*  8:   */ {
/*  9:   */   public static HttpClient createHttpClient()
/* 10:   */   {
/* 11:12 */     return HttpClients.createMinimal();
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static HttpClient createHttpClient(int maxTotal, int maxPerRoute)
/* 15:   */   {
/* 16:16 */     PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
/* 17:17 */     connManager.setMaxTotal(maxTotal);
/* 18:18 */     connManager.setDefaultMaxPerRoute(maxPerRoute);
/* 19:   */     
/* 20:20 */     return HttpClients.createMinimal(connManager);
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.http.HttpClientFactory
 * JD-Core Version:    0.7.0.1
 */