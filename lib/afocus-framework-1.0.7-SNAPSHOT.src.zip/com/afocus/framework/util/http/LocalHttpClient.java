/*  1:   */ package com.afocus.framework.util.http;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.apache.http.HttpResponse;
/*  5:   */ import org.apache.http.client.ClientProtocolException;
/*  6:   */ import org.apache.http.client.HttpClient;
/*  7:   */ import org.apache.http.client.ResponseHandler;
/*  8:   */ import org.apache.http.client.methods.HttpUriRequest;
/*  9:   */ 
/* 10:   */ public class LocalHttpClient
/* 11:   */ {
/* 12:18 */   protected static HttpClient httpClient = HttpClientFactory.createHttpClient(100, 10);
/* 13:   */   
/* 14:   */   public static void init(int maxTotal, int maxPerRoute)
/* 15:   */   {
/* 16:27 */     httpClient = HttpClientFactory.createHttpClient(maxTotal, maxPerRoute);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static HttpResponse execute(HttpUriRequest request)
/* 20:   */   {
/* 21:   */     try
/* 22:   */     {
/* 23:38 */       return httpClient.execute(request);
/* 24:   */     }
/* 25:   */     catch (ClientProtocolException e)
/* 26:   */     {
/* 27:40 */       e.printStackTrace();
/* 28:   */     }
/* 29:   */     catch (IOException e)
/* 30:   */     {
/* 31:42 */       e.printStackTrace();
/* 32:   */     }
/* 33:44 */     return null;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static <T> T execute(HttpUriRequest request, ResponseHandler<T> responseHandler)
/* 37:   */   {
/* 38:   */     try
/* 39:   */     {
/* 40:57 */       return httpClient.execute(request, responseHandler);
/* 41:   */     }
/* 42:   */     catch (ClientProtocolException e)
/* 43:   */     {
/* 44:59 */       e.printStackTrace();
/* 45:   */     }
/* 46:   */     catch (IOException e)
/* 47:   */     {
/* 48:61 */       e.printStackTrace();
/* 49:   */     }
/* 50:63 */     return null;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public static <T> T executeJsonResult(HttpUriRequest request, Class<T> clazz)
/* 54:   */   {
/* 55:74 */     return execute(request, JsonResponseHandler.createResponseHandler(clazz));
/* 56:   */   }
/* 57:   */   
/* 58:   */   public static <T> T executeXmlResult(HttpUriRequest request, Class<T> clazz)
/* 59:   */   {
/* 60:85 */     return execute(request, XmlResponseHandler.createResponseHandler(clazz));
/* 61:   */   }
/* 62:   */   
/* 63:   */   public static String executeTextResult(HttpUriRequest request)
/* 64:   */   {
/* 65:95 */     return (String)execute(request, StringResponseHandler.createResponseHandler());
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.http.LocalHttpClient
 * JD-Core Version:    0.7.0.1
 */