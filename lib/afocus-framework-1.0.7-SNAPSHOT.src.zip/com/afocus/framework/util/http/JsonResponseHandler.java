/*  1:   */ package com.afocus.framework.util.http;
/*  2:   */ 
/*  3:   */ import com.alibaba.fastjson.JSON;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.HashMap;
/*  6:   */ import java.util.Map;
/*  7:   */ import org.apache.http.HttpEntity;
/*  8:   */ import org.apache.http.HttpResponse;
/*  9:   */ import org.apache.http.StatusLine;
/* 10:   */ import org.apache.http.client.ClientProtocolException;
/* 11:   */ import org.apache.http.client.ResponseHandler;
/* 12:   */ import org.apache.http.util.EntityUtils;
/* 13:   */ 
/* 14:   */ public class JsonResponseHandler
/* 15:   */ {
/* 16:18 */   private static Map<String, ResponseHandler<?>> map = new HashMap();
/* 17:   */   
/* 18:   */   public static <T> ResponseHandler<T> createResponseHandler(Class<T> clazz)
/* 19:   */   {
/* 20:23 */     if (map.containsKey(clazz.getName())) {
/* 21:24 */       return (ResponseHandler)map.get(clazz.getName());
/* 22:   */     }
/* 23:26 */     ResponseHandler<T> responseHandler = new ResponseHandler()
/* 24:   */     {
/* 25:   */       public T handleResponse(HttpResponse response)
/* 26:   */         throws ClientProtocolException, IOException
/* 27:   */       {
/* 28:30 */         int status = response.getStatusLine().getStatusCode();
/* 29:31 */         if ((status >= 200) && (status < 300))
/* 30:   */         {
/* 31:32 */           HttpEntity entity = response.getEntity();
/* 32:33 */           String str = EntityUtils.toString(entity);
/* 33:34 */           return JSON.parseObject(new String(str.getBytes("iso-8859-1"), "utf-8"), this.val$clazz);
/* 34:   */         }
/* 35:36 */         throw new ClientProtocolException("Unexpected response status: " + status);
/* 36:   */       }
/* 37:39 */     };
/* 38:40 */     map.put(clazz.getName(), responseHandler);
/* 39:41 */     return responseHandler;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.http.JsonResponseHandler
 * JD-Core Version:    0.7.0.1
 */