/*  1:   */ package com.afocus.framework.util.http;
/*  2:   */ 
/*  3:   */ import com.thoughtworks.xstream.XStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.HashMap;
/*  6:   */ import java.util.Map;
/*  7:   */ import org.apache.http.HttpResponse;
/*  8:   */ import org.apache.http.StatusLine;
/*  9:   */ import org.apache.http.client.ClientProtocolException;
/* 10:   */ import org.apache.http.client.ResponseHandler;
/* 11:   */ import org.apache.http.util.EntityUtils;
/* 12:   */ 
/* 13:   */ public class XmlResponseHandler
/* 14:   */ {
/* 15:17 */   private static Map<String, ResponseHandler<?>> map = new HashMap();
/* 16:   */   
/* 17:   */   public static <T> ResponseHandler<T> createResponseHandler(Class<T> clazz)
/* 18:   */   {
/* 19:21 */     if (map.containsKey(clazz.getName())) {
/* 20:22 */       return (ResponseHandler)map.get(clazz.getName());
/* 21:   */     }
/* 22:24 */     ResponseHandler<T> responseHandler = new ResponseHandler()
/* 23:   */     {
/* 24:   */       public T handleResponse(HttpResponse response)
/* 25:   */         throws ClientProtocolException, IOException
/* 26:   */       {
/* 27:28 */         int status = response.getStatusLine().getStatusCode();
/* 28:29 */         if ((status >= 200) && (status < 300))
/* 29:   */         {
/* 30:30 */           String xml = EntityUtils.toString(response.getEntity());
/* 31:31 */           XStream xStream = new XStream();
/* 32:32 */           return xStream.fromXML(xml);
/* 33:   */         }
/* 34:35 */         throw new ClientProtocolException("Unexpected response status: " + status);
/* 35:   */       }
/* 36:39 */     };
/* 37:40 */     map.put(clazz.getName(), responseHandler);
/* 38:41 */     return responseHandler;
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.http.XmlResponseHandler
 * JD-Core Version:    0.7.0.1
 */