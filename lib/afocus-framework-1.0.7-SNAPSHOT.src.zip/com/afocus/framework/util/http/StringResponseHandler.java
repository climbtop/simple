/*  1:   */ package com.afocus.framework.util.http;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.apache.http.HttpEntity;
/*  5:   */ import org.apache.http.HttpResponse;
/*  6:   */ import org.apache.http.ParseException;
/*  7:   */ import org.apache.http.StatusLine;
/*  8:   */ import org.apache.http.client.ClientProtocolException;
/*  9:   */ import org.apache.http.client.ResponseHandler;
/* 10:   */ import org.apache.http.util.EntityUtils;
/* 11:   */ 
/* 12:   */ public class StringResponseHandler
/* 13:   */ {
/* 14:   */   public static ResponseHandler<String> createResponseHandler()
/* 15:   */   {
/* 16:21 */     new ResponseHandler()
/* 17:   */     {
/* 18:   */       public String handleResponse(HttpResponse response)
/* 19:   */         throws ClientProtocolException, IOException, ParseException
/* 20:   */       {
/* 21:25 */         int status = response.getStatusLine().getStatusCode();
/* 22:26 */         if ((status >= 200) && (status < 300))
/* 23:   */         {
/* 24:27 */           HttpEntity entity = response.getEntity();
/* 25:28 */           return EntityUtils.toString(entity);
/* 26:   */         }
/* 27:30 */         throw new ClientProtocolException("Unexpected response status: " + status);
/* 28:   */       }
/* 29:   */     };
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.http.StringResponseHandler
 * JD-Core Version:    0.7.0.1
 */