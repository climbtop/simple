/*    1:     */ package com.afocus.framework.util.file;
/*    2:     */ 
/*    3:     */ import com.afocus.framework.util.emulehash.IMD4;
/*    4:     */ import com.afocus.framework.util.emulehash.MD4Factory;
/*    5:     */ import java.io.BufferedInputStream;
/*    6:     */ import java.io.BufferedReader;
/*    7:     */ import java.io.File;
/*    8:     */ import java.io.FileFilter;
/*    9:     */ import java.io.FileInputStream;
/*   10:     */ import java.io.FileNotFoundException;
/*   11:     */ import java.io.FileOutputStream;
/*   12:     */ import java.io.FileReader;
/*   13:     */ import java.io.IOException;
/*   14:     */ import java.io.InputStream;
/*   15:     */ import java.io.InputStreamReader;
/*   16:     */ import java.io.LineNumberReader;
/*   17:     */ import java.io.OutputStream;
/*   18:     */ import java.io.OutputStreamWriter;
/*   19:     */ import java.io.Reader;
/*   20:     */ import java.io.UnsupportedEncodingException;
/*   21:     */ import java.io.Writer;
/*   22:     */ import java.net.URI;
/*   23:     */ import java.net.URISyntaxException;
/*   24:     */ import java.net.URL;
/*   25:     */ import java.util.ArrayList;
/*   26:     */ import java.util.HashMap;
/*   27:     */ import java.util.Iterator;
/*   28:     */ import java.util.List;
/*   29:     */ import java.util.Map;
/*   30:     */ import javax.servlet.ServletContext;
/*   31:     */ import javax.servlet.http.HttpServletRequest;
/*   32:     */ import javax.servlet.http.HttpSession;
/*   33:     */ import org.apache.log4j.Logger;
/*   34:     */ import sun.misc.BASE64Decoder;
/*   35:     */ 
/*   36:     */ public final class FileUtil
/*   37:     */ {
/*   38:  40 */   private static Logger log = Logger.getLogger(FileUtil.class);
/*   39:     */   private static final String IMAGE_TYPE = "bmp,dib,gif,jfif, jpe,jpeg,jpg, png,tif,tiff,ico";
/*   40:     */   private static final String VOICE_TYPE = "amr,mp3,wav,wma,ogg,ape,acc";
/*   41:     */   private static final String VIDEO_TYPE = "mov,avi,wma,rmvb,rm,flash,mp4,mid,3gp";
/*   42:     */   
/*   43:     */   public static class FileInfo
/*   44:     */   {
/*   45:     */     private File obj;
/*   46:  54 */     private String fileName = "";
/*   47:  55 */     private String name = "";
/*   48:  56 */     private String ext = "";
/*   49:  57 */     private String path = "";
/*   50:  58 */     private String hashCode = null;
/*   51:     */     
/*   52:     */     public FileInfo(File f)
/*   53:     */     {
/*   54:  61 */       this.obj = f;
/*   55:  62 */       this.fileName = f.getName();
/*   56:  63 */       this.path = f.getPath();
/*   57:  64 */       int endIndex = this.fileName.lastIndexOf(".");
/*   58:  65 */       if (endIndex > 0)
/*   59:     */       {
/*   60:  66 */         this.name = this.fileName.substring(0, endIndex);
/*   61:  67 */         this.ext = this.fileName.substring(endIndex + 1).toLowerCase();
/*   62:     */       }
/*   63:     */     }
/*   64:     */     
/*   65:     */     public FileInfo(String filePath)
/*   66:     */     {
/*   67:  72 */       this(new File(filePath));
/*   68:     */     }
/*   69:     */     
/*   70:     */     public String getExt()
/*   71:     */     {
/*   72:  79 */       return this.ext;
/*   73:     */     }
/*   74:     */     
/*   75:     */     public synchronized String getHashCode()
/*   76:     */     {
/*   77:  86 */       if ((this.hashCode == null) && (this.obj != null) && (this.obj.isFile())) {
/*   78:  87 */         this.hashCode = FileUtil.md4HashCode(this.obj);
/*   79:     */       }
/*   80:  89 */       return this.hashCode;
/*   81:     */     }
/*   82:     */     
/*   83:     */     public String getName()
/*   84:     */     {
/*   85:  96 */       return this.name;
/*   86:     */     }
/*   87:     */     
/*   88:     */     public File getObj()
/*   89:     */     {
/*   90: 103 */       return this.obj;
/*   91:     */     }
/*   92:     */     
/*   93:     */     public String getPath()
/*   94:     */     {
/*   95: 110 */       return this.path;
/*   96:     */     }
/*   97:     */     
/*   98:     */     public String getFileName()
/*   99:     */     {
/*  100: 117 */       return this.fileName;
/*  101:     */     }
/*  102:     */   }
/*  103:     */   
/*  104:     */   public static class Folder
/*  105:     */   {
/*  106:     */     private String name;
/*  107:     */     private File obj;
/*  108:     */     private List<File> children;
/*  109:     */     private List<File> files;
/*  110:     */     
/*  111:     */     public Folder(File obj, FileFilter filter)
/*  112:     */     {
/*  113: 133 */       this.obj = obj;
/*  114: 134 */       this.name = obj.getName();
/*  115: 135 */       this.children = FileUtil.listDirectorys(obj, false);
/*  116: 136 */       this.files = FileUtil.listAll(obj, filter, false);
/*  117:     */     }
/*  118:     */     
/*  119:     */     public List<File> getChildren()
/*  120:     */     {
/*  121: 143 */       return this.children;
/*  122:     */     }
/*  123:     */     
/*  124:     */     public void setChildren(List<File> children)
/*  125:     */     {
/*  126: 151 */       this.children = children;
/*  127:     */     }
/*  128:     */     
/*  129:     */     public List<File> getFiles()
/*  130:     */     {
/*  131: 158 */       return this.files;
/*  132:     */     }
/*  133:     */     
/*  134:     */     public void setFiles(List<File> files)
/*  135:     */     {
/*  136: 166 */       this.files = files;
/*  137:     */     }
/*  138:     */     
/*  139:     */     public String getName()
/*  140:     */     {
/*  141: 173 */       return this.name;
/*  142:     */     }
/*  143:     */     
/*  144:     */     public void setName(String name)
/*  145:     */     {
/*  146: 181 */       this.name = name;
/*  147:     */     }
/*  148:     */     
/*  149:     */     public File getObj()
/*  150:     */     {
/*  151: 188 */       return this.obj;
/*  152:     */     }
/*  153:     */     
/*  154:     */     public void setObj(File obj)
/*  155:     */     {
/*  156: 196 */       this.obj = obj;
/*  157:     */     }
/*  158:     */   }
/*  159:     */   
/*  160:     */   public static String getFileType(String fileName)
/*  161:     */   {
/*  162: 209 */     String ext = "";
/*  163: 210 */     if ((fileName != null) && (fileName.trim().length() > 0))
/*  164:     */     {
/*  165: 211 */       int endIndex = fileName.lastIndexOf(".");
/*  166: 212 */       if (endIndex > 0) {
/*  167: 213 */         ext = fileName.substring(endIndex + 1).toLowerCase();
/*  168:     */       }
/*  169:     */     }
/*  170: 216 */     return ext;
/*  171:     */   }
/*  172:     */   
/*  173:     */   public static String execCommand(String command)
/*  174:     */     throws RuntimeException
/*  175:     */   {
/*  176: 228 */     Process process = null;
/*  177: 229 */     InputStreamReader ir = null;
/*  178: 230 */     InputStream in = null;
/*  179: 231 */     LineNumberReader lnr = null;
/*  180:     */     try
/*  181:     */     {
/*  182: 233 */       StringBuffer msg = new StringBuffer();
/*  183: 234 */       process = Runtime.getRuntime().exec(command);
/*  184:     */       
/*  185: 236 */       in = process.getInputStream();
/*  186: 237 */       ir = new InputStreamReader(in);
/*  187: 238 */       lnr = new LineNumberReader(ir);
/*  188: 239 */       String line = null;
/*  189: 240 */       while ((line = lnr.readLine()) != null) {
/*  190: 242 */         msg.append(line).append("\n");
/*  191:     */       }
/*  192: 247 */       StringBuffer error = new StringBuffer();
/*  193: 248 */       in = process.getErrorStream();
/*  194: 249 */       ir = new InputStreamReader(in);
/*  195: 250 */       lnr = new LineNumberReader(ir);
/*  196: 251 */       while ((line = lnr.readLine()) != null) {
/*  197: 253 */         error.append(line).append("\n");
/*  198:     */       }
/*  199: 259 */       if (error.length() > 0) {
/*  200: 260 */         throw new RuntimeException(error.toString());
/*  201:     */       }
/*  202: 262 */       return msg.toString();
/*  203:     */     }
/*  204:     */     catch (IOException e)
/*  205:     */     {
/*  206: 265 */       e.printStackTrace();
/*  207: 266 */       throw new RuntimeException(e);
/*  208:     */     }
/*  209:     */     finally
/*  210:     */     {
/*  211:     */       try
/*  212:     */       {
/*  213: 269 */         process.getInputStream().close();
/*  214: 270 */         process.getErrorStream().close();
/*  215: 271 */         process.getOutputStream().close();
/*  216:     */       }
/*  217:     */       catch (IOException e1)
/*  218:     */       {
/*  219: 275 */         e1.printStackTrace();
/*  220:     */       }
/*  221:     */     }
/*  222:     */   }
/*  223:     */   
/*  224:     */   public static String md4HashCode(String filename)
/*  225:     */   {
/*  226:     */     try
/*  227:     */     {
/*  228: 290 */       IMD4 md4 = MD4Factory.getInstance();
/*  229: 291 */       return md4.addFile(filename);
/*  230:     */     }
/*  231:     */     catch (Exception e)
/*  232:     */     {
/*  233: 293 */       e.printStackTrace();
/*  234: 294 */       log.error("md4HashCode error: " + filename + "," + e);
/*  235:     */     }
/*  236: 295 */     return null;
/*  237:     */   }
/*  238:     */   
/*  239:     */   public static String md4HashCode(File file)
/*  240:     */   {
/*  241:     */     try
/*  242:     */     {
/*  243: 308 */       IMD4 md4 = MD4Factory.getInstance();
/*  244: 309 */       return md4.addFile(file);
/*  245:     */     }
/*  246:     */     catch (Exception e)
/*  247:     */     {
/*  248: 311 */       e.printStackTrace();
/*  249: 312 */       log.error("md4HashCode error: " + file.getName() + "," + e);
/*  250:     */     }
/*  251: 313 */     return null;
/*  252:     */   }
/*  253:     */   
/*  254:     */   public static boolean touch(File file)
/*  255:     */   {
/*  256: 326 */     if (!file.exists()) {
/*  257:     */       try
/*  258:     */       {
/*  259: 328 */         return file.createNewFile();
/*  260:     */       }
/*  261:     */       catch (IOException e)
/*  262:     */       {
/*  263: 330 */         e.printStackTrace();
/*  264:     */       }
/*  265:     */     }
/*  266: 333 */     return file.setLastModified(System.currentTimeMillis());
/*  267:     */   }
/*  268:     */   
/*  269:     */   public static boolean touch(String fileName)
/*  270:     */   {
/*  271: 345 */     File file = new File(fileName);
/*  272: 346 */     return touch(file);
/*  273:     */   }
/*  274:     */   
/*  275:     */   public static void touch(File[] files)
/*  276:     */   {
/*  277: 358 */     for (int i = 0; i < files.length; i++) {
/*  278: 359 */       touch(files[i]);
/*  279:     */     }
/*  280:     */   }
/*  281:     */   
/*  282:     */   public static void touch(String[] fileNames)
/*  283:     */   {
/*  284: 372 */     File[] files = new File[fileNames.length];
/*  285: 373 */     for (int i = 0; i < fileNames.length; i++) {
/*  286: 374 */       files[i] = new File(fileNames[i]);
/*  287:     */     }
/*  288: 376 */     touch(files);
/*  289:     */   }
/*  290:     */   
/*  291:     */   public static String unixRegFileName(String fileName)
/*  292:     */   {
/*  293: 386 */     return fileName.replaceAll("[\\x20\\x21\\x23\\x24\\x25\\x26\\x27\\x28\\x29\\x2B\\x3B\\x3d\\x40\\x5b\\x5c\\x5d\\x5e\\x60\\x7b\\x7d\\x7e]", "_");
/*  294:     */   }
/*  295:     */   
/*  296:     */   public static boolean isExist(String fileName)
/*  297:     */   {
/*  298: 398 */     return new File(fileName).exists();
/*  299:     */   }
/*  300:     */   
/*  301:     */   public static boolean isDirectory(String fileName)
/*  302:     */   {
/*  303: 409 */     boolean flag = true;
/*  304: 410 */     if ((!isExist(fileName)) || (!new File(fileName).isDirectory())) {
/*  305: 411 */       flag = false;
/*  306:     */     }
/*  307: 413 */     return flag;
/*  308:     */   }
/*  309:     */   
/*  310:     */   public static boolean makeParentFolder(File file)
/*  311:     */   {
/*  312: 425 */     File parent = file.getParentFile();
/*  313: 426 */     if ((parent != null) && (!parent.exists())) {
/*  314: 427 */       return parent.mkdirs();
/*  315:     */     }
/*  316: 429 */     return false;
/*  317:     */   }
/*  318:     */   
/*  319:     */   public static boolean makeFolder(String path)
/*  320:     */   {
/*  321: 439 */     if (!isDirectory(path))
/*  322:     */     {
/*  323: 440 */       File file = new File(path);
/*  324: 441 */       file.mkdirs();
/*  325: 442 */       return true;
/*  326:     */     }
/*  327: 444 */     return false;
/*  328:     */   }
/*  329:     */   
/*  330:     */   public static boolean makeParentFolder(String fileName)
/*  331:     */   {
/*  332: 456 */     return makeParentFolder(new File(fileName));
/*  333:     */   }
/*  334:     */   
/*  335:     */   public static boolean emptyFolder(File directory)
/*  336:     */   {
/*  337: 469 */     boolean result = false;
/*  338: 470 */     File[] entries = directory.listFiles();
/*  339: 471 */     for (int i = 0; i < entries.length; i++) {
/*  340: 472 */       if (!entries[i].delete()) {
/*  341: 473 */         result = false;
/*  342:     */       }
/*  343:     */     }
/*  344: 476 */     return result;
/*  345:     */   }
/*  346:     */   
/*  347:     */   public boolean isEmptyFolder(String dir)
/*  348:     */   {
/*  349: 485 */     File file = new File(dir);
/*  350: 486 */     String[] files = file.list();
/*  351: 487 */     return files.length == 0;
/*  352:     */   }
/*  353:     */   
/*  354:     */   public static boolean emptyFolder(String directoryName)
/*  355:     */   {
/*  356: 500 */     File dir = new File(directoryName);
/*  357: 501 */     return emptyFolder(dir);
/*  358:     */   }
/*  359:     */   
/*  360:     */   public static boolean deleteDirectory(String dirName, boolean deleteAll)
/*  361:     */     throws IllegalArgumentException
/*  362:     */   {
/*  363: 516 */     return deleteDirectory(new File(dirName), deleteAll);
/*  364:     */   }
/*  365:     */   
/*  366:     */   public static boolean deleteDirectory(File dir, boolean deleteAll)
/*  367:     */   {
/*  368: 531 */     if ((dir == null) || (!dir.isDirectory()))
/*  369:     */     {
/*  370: 532 */       log.error(dir + " is not a directory. ");
/*  371: 533 */       return false;
/*  372:     */     }
/*  373: 536 */     File[] entries = dir.listFiles();
/*  374: 537 */     int sz = entries.length;
/*  375: 538 */     boolean result = true;
/*  376: 540 */     for (int i = 0; i < sz; i++)
/*  377:     */     {
/*  378: 541 */       if ((entries[i].isDirectory()) && (deleteAll) && 
/*  379: 542 */         (!deleteDirectory(entries[i], deleteAll))) {
/*  380: 543 */         result = false;
/*  381:     */       }
/*  382: 545 */       if (!entries[i].delete()) {
/*  383: 546 */         result = false;
/*  384:     */       }
/*  385:     */     }
/*  386: 550 */     if (!dir.delete()) {
/*  387: 551 */       result = false;
/*  388:     */     }
/*  389: 553 */     return result;
/*  390:     */   }
/*  391:     */   
/*  392:     */   public static List<File> listFiles(String dirName, boolean listAll)
/*  393:     */   {
/*  394: 566 */     return listFiles(new File(dirName), listAll);
/*  395:     */   }
/*  396:     */   
/*  397:     */   public static List<File> listFiles(File dir, boolean listAll)
/*  398:     */   {
/*  399: 579 */     listAll(dir, new FileFilter()
/*  400:     */     {
/*  401:     */       public boolean accept(File f)
/*  402:     */       {
/*  403: 581 */         return f.isFile();
/*  404:     */       }
/*  405: 581 */     }, listAll);
/*  406:     */   }
/*  407:     */   
/*  408:     */   public static List<File> listDirectorys(String dirName, boolean listAll)
/*  409:     */   {
/*  410: 596 */     return listDirectorys(new File(dirName), listAll);
/*  411:     */   }
/*  412:     */   
/*  413:     */   public static List<File> listDirectorys(File dir, boolean listAll)
/*  414:     */   {
/*  415: 609 */     listAll(dir, new FileFilter()
/*  416:     */     {
/*  417:     */       public boolean accept(File f)
/*  418:     */       {
/*  419: 611 */         return f.isDirectory();
/*  420:     */       }
/*  421: 611 */     }, listAll);
/*  422:     */   }
/*  423:     */   
/*  424:     */   public static Map<String, Folder> getFolderMap(String dirName, FileFilter filter)
/*  425:     */   {
/*  426: 626 */     return getFolderMap(new File(dirName), filter);
/*  427:     */   }
/*  428:     */   
/*  429:     */   public static Map<String, Folder> getFolderMap(File dir, FileFilter filter)
/*  430:     */   {
/*  431: 640 */     HashMap<String, Folder> map = new HashMap();
/*  432: 641 */     if (!dir.exists()) {
/*  433: 642 */       return map;
/*  434:     */     }
/*  435: 644 */     getFolderMap(map, dir, filter);
/*  436: 645 */     return map;
/*  437:     */   }
/*  438:     */   
/*  439:     */   private static void getFolderMap(Map<String, Folder> map, File dir, FileFilter filter)
/*  440:     */   {
/*  441: 649 */     Folder folder = new Folder(dir, filter);
/*  442: 650 */     log.debug("file:" + dir.getAbsolutePath());
/*  443: 651 */     map.put(dir.getAbsolutePath(), folder);
/*  444: 652 */     Iterator<File> iter = folder.children.iterator();
/*  445: 653 */     while (iter.hasNext())
/*  446:     */     {
/*  447: 654 */       File child = (File)iter.next();
/*  448: 655 */       log.debug("child:" + child.getAbsolutePath());
/*  449: 656 */       getFolderMap(map, child, filter);
/*  450:     */     }
/*  451:     */   }
/*  452:     */   
/*  453:     */   public static List<File> listAll(File file, FileFilter filter, boolean listAll)
/*  454:     */   {
/*  455: 673 */     ArrayList<File> list = new ArrayList();
/*  456: 674 */     if (!file.exists()) {
/*  457: 675 */       return list;
/*  458:     */     }
/*  459: 677 */     listAll(list, file, filter, listAll);
/*  460: 678 */     if (list.contains(file)) {
/*  461: 679 */       list.remove(file);
/*  462:     */     }
/*  463: 681 */     log.debug(list);
/*  464: 682 */     return list;
/*  465:     */   }
/*  466:     */   
/*  467:     */   private static void listAll(ArrayList<File> list, File file, FileFilter filter, boolean listAll)
/*  468:     */   {
/*  469: 698 */     if (file.isDirectory())
/*  470:     */     {
/*  471: 699 */       File[] files = file.listFiles();
/*  472: 700 */       for (int i = 0; i < files.length; i++)
/*  473:     */       {
/*  474: 701 */         if (filter.accept(files[i])) {
/*  475: 702 */           list.add(files[i]);
/*  476:     */         }
/*  477: 704 */         log.debug("files:" + files[i].getAbsolutePath());
/*  478: 705 */         if (listAll) {
/*  479: 706 */           listAll(list, files[i], filter, listAll);
/*  480:     */         }
/*  481:     */       }
/*  482:     */     }
/*  483:     */   }
/*  484:     */   
/*  485:     */   public static String toUNIXpath(String filePath)
/*  486:     */   {
/*  487: 724 */     return filePath.replace('\\', '/');
/*  488:     */   }
/*  489:     */   
/*  490:     */   public static boolean copy(String fromFileName, String toFileName)
/*  491:     */   {
/*  492: 738 */     return copy(fromFileName, toFileName, false);
/*  493:     */   }
/*  494:     */   
/*  495:     */   public static boolean move(String fromFileName, String toFileName)
/*  496:     */   {
/*  497: 752 */     File fromFile = new File(fromFileName);
/*  498: 753 */     File toFile = new File(toFileName);
/*  499: 754 */     return move(fromFile, toFile, false);
/*  500:     */   }
/*  501:     */   
/*  502:     */   public static boolean move(String fromFileName, String toFileName, boolean override)
/*  503:     */   {
/*  504: 770 */     File fromFile = new File(fromFileName);
/*  505: 771 */     File toFile = new File(toFileName);
/*  506: 772 */     return move(fromFile, toFile, override);
/*  507:     */   }
/*  508:     */   
/*  509:     */   public static boolean move(File fromFile, File toFile, boolean override)
/*  510:     */   {
/*  511: 788 */     boolean ret = copy(fromFile, toFile, override);
/*  512: 789 */     if (ret) {
/*  513: 790 */       ret = fromFile.delete();
/*  514:     */     }
/*  515: 791 */     return ret;
/*  516:     */   }
/*  517:     */   
/*  518:     */   public static boolean copy(String fromFileName, String toFileName, boolean override)
/*  519:     */   {
/*  520: 807 */     File fromFile = new File(fromFileName);
/*  521: 808 */     File toFile = new File(toFileName);
/*  522: 809 */     return copy(fromFile, toFile, override);
/*  523:     */   }
/*  524:     */   
/*  525:     */   public static boolean copy(File fromFile, File toFile, boolean override)
/*  526:     */   {
/*  527: 825 */     if ((!fromFile.exists()) || (!fromFile.isFile()) || (!fromFile.canRead())) {
/*  528: 826 */       return false;
/*  529:     */     }
/*  530: 829 */     if (toFile.isDirectory()) {
/*  531: 830 */       toFile = new File(toFile, fromFile.getName());
/*  532:     */     }
/*  533:     */     File dir;
/*  534: 833 */     if (toFile.exists())
/*  535:     */     {
/*  536: 834 */       if ((!toFile.canWrite()) || (!override)) {
/*  537: 835 */         return false;
/*  538:     */       }
/*  539:     */     }
/*  540:     */     else
/*  541:     */     {
/*  542: 838 */       String parent = toFile.getParent();
/*  543: 839 */       if (parent == null) {
/*  544: 840 */         parent = System.getProperty("user.dir");
/*  545:     */       }
/*  546: 842 */       dir = new File(parent);
/*  547: 843 */       if ((!dir.exists()) || (dir.isFile()) || (!dir.canWrite())) {
/*  548: 844 */         return false;
/*  549:     */       }
/*  550:     */     }
/*  551: 848 */     BufferedInputStream from = null;
/*  552:     */     try
/*  553:     */     {
/*  554: 850 */       from = new BufferedInputStream(new FileInputStream(fromFile));
/*  555: 851 */       writeToFile(from, toFile);
/*  556: 852 */       return 1;
/*  557:     */     }
/*  558:     */     catch (IOException e)
/*  559:     */     {
/*  560: 854 */       log.error("copy " + fromFile + " to " + toFile + " :" + e);
/*  561: 855 */       return false;
/*  562:     */     }
/*  563:     */     finally
/*  564:     */     {
/*  565: 857 */       close(from, null);
/*  566:     */     }
/*  567:     */   }
/*  568:     */   
/*  569:     */   public static boolean putFileToStream(File fromFile, OutputStream out)
/*  570:     */     throws IOException
/*  571:     */   {
/*  572: 872 */     if ((!fromFile.exists()) || (!fromFile.isFile()) || (!fromFile.canRead()))
/*  573:     */     {
/*  574: 873 */       log.debug(" fromFile is not valid");
/*  575: 874 */       return false;
/*  576:     */     }
/*  577: 877 */     BufferedInputStream from = null;
/*  578:     */     try
/*  579:     */     {
/*  580: 879 */       from = new BufferedInputStream(new FileInputStream(fromFile));
/*  581: 880 */       pipeTransform(from, out);
/*  582: 881 */       return true;
/*  583:     */     }
/*  584:     */     catch (IOException e)
/*  585:     */     {
/*  586: 883 */       throw e;
/*  587:     */     }
/*  588:     */     finally
/*  589:     */     {
/*  590: 885 */       close(from, null);
/*  591:     */     }
/*  592:     */   }
/*  593:     */   
/*  594:     */   public static String readTextFile(File srcFile, String encoding)
/*  595:     */     throws IOException
/*  596:     */   {
/*  597: 900 */     if ((!srcFile.exists()) || (!srcFile.isFile()) || (!srcFile.canRead())) {
/*  598: 901 */       log.debug(" fromFile is not valid");
/*  599:     */     }
/*  600: 904 */     InputStreamReader from = null;
/*  601:     */     try
/*  602:     */     {
/*  603: 906 */       char[] buffer = new char[4096];
/*  604: 907 */       int read = 0;
/*  605: 908 */       from = new InputStreamReader(new FileInputStream(srcFile), encoding);
/*  606: 909 */       StringBuffer result = new StringBuffer();
/*  607: 910 */       while ((read = from.read(buffer, 0, buffer.length)) != -1) {
/*  608: 911 */         result.append(buffer, 0, read);
/*  609:     */       }
/*  610: 913 */       return result.toString();
/*  611:     */     }
/*  612:     */     catch (IOException e)
/*  613:     */     {
/*  614: 915 */       throw e;
/*  615:     */     }
/*  616:     */     finally
/*  617:     */     {
/*  618: 917 */       if (from != null) {
/*  619: 918 */         from.close();
/*  620:     */       }
/*  621:     */     }
/*  622:     */   }
/*  623:     */   
/*  624:     */   public static void writeToFile(InputStream iStream, String fileName)
/*  625:     */     throws IOException
/*  626:     */   {
/*  627: 932 */     String me = "FileUtil.WriteToFile";
/*  628: 933 */     if (fileName == null) {
/*  629: 934 */       throw new IOException(me + ": filename is null");
/*  630:     */     }
/*  631: 936 */     File theFile = new File(fileName);
/*  632: 938 */     if (theFile.exists())
/*  633:     */     {
/*  634: 939 */       String msg = !theFile.canWrite() ? "not writable" : theFile.isDirectory() ? "directory" : null;
/*  635: 940 */       if (msg != null) {
/*  636: 941 */         throw new IOException(me + ": file '" + fileName + "' is " + msg);
/*  637:     */       }
/*  638:     */     }
/*  639: 944 */     writeToFile(iStream, theFile);
/*  640:     */   }
/*  641:     */   
/*  642:     */   public static void writeToFile(InputStream iStream, File theFile)
/*  643:     */     throws IOException
/*  644:     */   {
/*  645: 957 */     String me = "FileUtil.WriteToFile";
/*  646: 958 */     if (theFile == null) {
/*  647: 959 */       throw new IOException(me + ": theFile is null");
/*  648:     */     }
/*  649: 961 */     if (iStream == null) {
/*  650: 962 */       throw new IOException(me + ": InputStream is null");
/*  651:     */     }
/*  652: 965 */     FileOutputStream fOut = null;
/*  653:     */     try
/*  654:     */     {
/*  655: 967 */       fOut = new FileOutputStream(theFile);
/*  656: 968 */       pipeTransform(iStream, fOut);
/*  657:     */     }
/*  658:     */     catch (Exception e)
/*  659:     */     {
/*  660: 970 */       throw new IOException(me + " failed, got: " + e.toString());
/*  661:     */     }
/*  662:     */     finally
/*  663:     */     {
/*  664: 972 */       close(iStream, fOut);
/*  665:     */     }
/*  666:     */   }
/*  667:     */   
/*  668:     */   public static boolean writeToTextFile(String fileName, String content, String encoding)
/*  669:     */   {
/*  670: 977 */     OutputStreamWriter writer = null;
/*  671:     */     try
/*  672:     */     {
/*  673: 979 */       writer = new OutputStreamWriter(new FileOutputStream(fileName), encoding);
/*  674: 980 */       writer.write(content);
/*  675: 981 */       return true;
/*  676:     */     }
/*  677:     */     catch (Exception e)
/*  678:     */     {
/*  679: 983 */       e.printStackTrace();
/*  680:     */     }
/*  681:     */     finally
/*  682:     */     {
/*  683: 985 */       if (writer != null) {
/*  684:     */         try
/*  685:     */         {
/*  686: 987 */           writer.close();
/*  687:     */         }
/*  688:     */         catch (IOException e)
/*  689:     */         {
/*  690: 989 */           e.printStackTrace();
/*  691:     */         }
/*  692:     */       }
/*  693:     */     }
/*  694: 993 */     return false;
/*  695:     */   }
/*  696:     */   
/*  697:     */   public static void pipeTransform(InputStream iStream, OutputStream oStream)
/*  698:     */     throws IOException
/*  699:     */   {
/*  700:1004 */     byte[] buffer = new byte[4096];
/*  701:1005 */     int bytesRead = 0;
/*  702:1006 */     while ((bytesRead = iStream.read(buffer, 0, buffer.length)) != -1) {
/*  703:1007 */       oStream.write(buffer, 0, bytesRead);
/*  704:     */     }
/*  705:     */   }
/*  706:     */   
/*  707:     */   public static void pipeTransform(Reader reader, Writer writer)
/*  708:     */     throws IOException
/*  709:     */   {
/*  710:1012 */     char[] buffer = new char[4096];
/*  711:1013 */     int read = 0;
/*  712:1014 */     while ((read = reader.read(buffer, 0, buffer.length)) != -1) {
/*  713:1015 */       writer.write(buffer, 0, read);
/*  714:     */     }
/*  715:     */   }
/*  716:     */   
/*  717:     */   private static void close(InputStream iStream, OutputStream oStream)
/*  718:     */   {
/*  719:     */     try
/*  720:     */     {
/*  721:1025 */       if (iStream != null) {
/*  722:1026 */         iStream.close();
/*  723:     */       }
/*  724:     */     }
/*  725:     */     catch (IOException localIOException) {}
/*  726:     */     try
/*  727:     */     {
/*  728:1031 */       if (oStream != null) {
/*  729:1032 */         oStream.close();
/*  730:     */       }
/*  731:     */     }
/*  732:     */     catch (IOException localIOException1) {}
/*  733:     */   }
/*  734:     */   
/*  735:     */   private static void close(Reader reader, Writer writer)
/*  736:     */   {
/*  737:     */     try
/*  738:     */     {
/*  739:1039 */       if (reader != null) {
/*  740:1040 */         reader.close();
/*  741:     */       }
/*  742:     */     }
/*  743:     */     catch (IOException localIOException) {}
/*  744:     */     try
/*  745:     */     {
/*  746:1045 */       if (writer != null) {
/*  747:1046 */         writer.close();
/*  748:     */       }
/*  749:     */     }
/*  750:     */     catch (IOException localIOException1) {}
/*  751:     */   }
/*  752:     */   
/*  753:     */   public static void convertEncoding(String srcFileName, String dstFileName, String srcEncoding, String dstEncoding)
/*  754:     */     throws IOException
/*  755:     */   {
/*  756:1052 */     convertEncoding(new File(srcFileName), new File(dstFileName), srcEncoding, dstEncoding);
/*  757:     */   }
/*  758:     */   
/*  759:     */   public static void convertEncoding(File srcFile, File dstFile, String srcEncoding, String dstEncoding)
/*  760:     */     throws IOException
/*  761:     */   {
/*  762:1056 */     if ((!srcFile.exists()) || (!srcFile.isFile()) || (!srcFile.canRead())) {
/*  763:1057 */       log.debug(" fromFile is not valid");
/*  764:     */     }
/*  765:1059 */     makeParentFolder(dstFile);
/*  766:     */     
/*  767:1061 */     InputStreamReader from = null;
/*  768:1062 */     Writer out = null;
/*  769:     */     try
/*  770:     */     {
/*  771:1064 */       out = new OutputStreamWriter(new FileOutputStream(dstFile), dstEncoding);
/*  772:1065 */       from = new InputStreamReader(new FileInputStream(srcFile), srcEncoding);
/*  773:1066 */       pipeTransform(from, out);
/*  774:     */     }
/*  775:     */     finally
/*  776:     */     {
/*  777:1068 */       close(from, out);
/*  778:     */     }
/*  779:     */   }
/*  780:     */   
/*  781:     */   public static String getUrlPath(Class clazz, String fileName)
/*  782:     */     throws FileNotFoundException
/*  783:     */   {
/*  784:1082 */     if (fileName.startsWith("classpath:")) {
/*  785:1083 */       fileName = fileName.substring("classpath:".length());
/*  786:     */     }
/*  787:1085 */     URL url = clazz.getClassLoader().getResource(fileName);
/*  788:1087 */     if (url == null) {
/*  789:1088 */       throw new FileNotFoundException("file \"" + fileName + "\" not found in classpath!");
/*  790:     */     }
/*  791:1091 */     String urlPath = null;
/*  792:     */     try
/*  793:     */     {
/*  794:1093 */       urlPath = url.toURI().getPath();
/*  795:     */     }
/*  796:     */     catch (URISyntaxException localURISyntaxException) {}
/*  797:1097 */     if (urlPath == null) {
/*  798:1098 */       urlPath = url.getFile();
/*  799:     */     }
/*  800:1100 */     return urlPath;
/*  801:     */   }
/*  802:     */   
/*  803:     */   public static List<String> readEachLineStr(String filePath)
/*  804:     */   {
/*  805:1110 */     File file = new File(filePath);
/*  806:1111 */     BufferedReader br = null;
/*  807:     */     try
/*  808:     */     {
/*  809:1113 */       FileReader fileReader = new FileReader(file);
/*  810:1114 */       br = new BufferedReader(fileReader);
/*  811:1115 */       String line = null;
/*  812:1116 */       List<String> contentList = new ArrayList();
/*  813:1117 */       while ((line = br.readLine()) != null) {
/*  814:1118 */         contentList.add(line);
/*  815:     */       }
/*  816:1120 */       return contentList;
/*  817:     */     }
/*  818:     */     catch (Exception e)
/*  819:     */     {
/*  820:1122 */       e.printStackTrace();
/*  821:     */     }
/*  822:     */     finally
/*  823:     */     {
/*  824:1124 */       if (br != null) {
/*  825:     */         try
/*  826:     */         {
/*  827:1126 */           br.close();
/*  828:     */         }
/*  829:     */         catch (IOException e)
/*  830:     */         {
/*  831:1128 */           e.printStackTrace();
/*  832:     */         }
/*  833:     */       }
/*  834:     */     }
/*  835:1132 */     return null;
/*  836:     */   }
/*  837:     */   
/*  838:     */   public static List<String> readLines(String filePath)
/*  839:     */   {
/*  840:1136 */     File file = new File(filePath);
/*  841:1137 */     BufferedReader reader = null;
/*  842:     */     try
/*  843:     */     {
/*  844:1139 */       reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
/*  845:1140 */       String line = null;
/*  846:1141 */       List<String> lines = new ArrayList();
/*  847:1142 */       while ((line = reader.readLine()) != null) {
/*  848:1143 */         lines.add(line.trim());
/*  849:     */       }
/*  850:1145 */       return lines;
/*  851:     */     }
/*  852:     */     catch (UnsupportedEncodingException e)
/*  853:     */     {
/*  854:1147 */       e.printStackTrace();
/*  855:1148 */       log.error("读取文件出错：", e);
/*  856:     */     }
/*  857:     */     catch (FileNotFoundException e)
/*  858:     */     {
/*  859:1150 */       e.printStackTrace();
/*  860:1151 */       log.error("读取文件出错：", e);
/*  861:     */     }
/*  862:     */     catch (IOException e)
/*  863:     */     {
/*  864:1153 */       e.printStackTrace();
/*  865:     */     }
/*  866:     */     finally
/*  867:     */     {
/*  868:1155 */       if (reader != null) {
/*  869:     */         try
/*  870:     */         {
/*  871:1157 */           reader.close();
/*  872:     */         }
/*  873:     */         catch (IOException e)
/*  874:     */         {
/*  875:1159 */           e.printStackTrace();
/*  876:     */         }
/*  877:     */       }
/*  878:     */     }
/*  879:1163 */     return null;
/*  880:     */   }
/*  881:     */   
/*  882:     */   public static String dealName(String fileName)
/*  883:     */   {
/*  884:1175 */     String resultName = "";
/*  885:1176 */     String time = "";
/*  886:1177 */     String extName = "";
/*  887:     */     
/*  888:1179 */     extName = fileName.split("\\\\")[(fileName.split("\\\\").length - 1)];
/*  889:1180 */     extName = extName.split("\\.")[(extName.split("\\.").length - 1)];
/*  890:     */     
/*  891:1182 */     time = String.valueOf(System.currentTimeMillis());
/*  892:     */     
/*  893:1184 */     resultName = time + "." + extName;
/*  894:     */     
/*  895:1186 */     return resultName;
/*  896:     */   }
/*  897:     */   
/*  898:     */   public static boolean deleteFile(String filepath)
/*  899:     */   {
/*  900:     */     try
/*  901:     */     {
/*  902:1191 */       File file = new File(filepath);
/*  903:1192 */       if (file.exists()) {
/*  904:1193 */         file.delete();
/*  905:     */       }
/*  906:1195 */       return true;
/*  907:     */     }
/*  908:     */     catch (Exception e)
/*  909:     */     {
/*  910:1197 */       log.error("删除文件出错：", e);
/*  911:     */     }
/*  912:1200 */     return false;
/*  913:     */   }
/*  914:     */   
/*  915:     */   public static String getSaveFilePath(String realPath, String relateDir, String fileName)
/*  916:     */   {
/*  917:1213 */     StringBuffer rootDir = new StringBuffer(realPath).append("/").append(relateDir);
/*  918:     */     
/*  919:1215 */     File logoSaveFile = new File(rootDir.toString());
/*  920:1216 */     if (!logoSaveFile.exists()) {
/*  921:1217 */       logoSaveFile.mkdirs();
/*  922:     */     }
/*  923:1219 */     return fileName.replace("//", "/").replace("/./", "/");
/*  924:     */   }
/*  925:     */   
/*  926:     */   public static String getRealPath(HttpServletRequest request)
/*  927:     */   {
/*  928:1229 */     return request.getSession().getServletContext().getRealPath("");
/*  929:     */   }
/*  930:     */   
/*  931:     */   public static void writeBase64ToFile(String baseCode, String filePath)
/*  932:     */     throws Exception
/*  933:     */   {
/*  934:1238 */     FileOutputStream fos = null;
/*  935:     */     try
/*  936:     */     {
/*  937:1240 */       BASE64Decoder decoder = new BASE64Decoder();
/*  938:1241 */       byte[] b = decoder.decodeBuffer(baseCode);
/*  939:1242 */       File file = new File(filePath);
/*  940:1243 */       fos = new FileOutputStream(file);
/*  941:1244 */       fos.write(b);
/*  942:     */     }
/*  943:     */     catch (Exception e)
/*  944:     */     {
/*  945:1246 */       throw e;
/*  946:     */     }
/*  947:     */     finally
/*  948:     */     {
/*  949:1248 */       if (fos != null)
/*  950:     */       {
/*  951:1249 */         fos.close();
/*  952:1250 */         fos = null;
/*  953:     */       }
/*  954:     */     }
/*  955:     */   }
/*  956:     */   
/*  957:     */   public static void rename(String oldNamePath, String newNamePath)
/*  958:     */   {
/*  959:1256 */     File file = new File(oldNamePath);
/*  960:1257 */     file.renameTo(new File(newNamePath));
/*  961:     */   }
/*  962:     */   
/*  963:     */   public static String sortFileType(String fileName)
/*  964:     */   {
/*  965:1266 */     String filePreFix = getFileType(fileName);
/*  966:1267 */     if ("bmp,dib,gif,jfif, jpe,jpeg,jpg, png,tif,tiff,ico".indexOf(filePreFix.toLowerCase()) != -1) {
/*  967:1268 */       return MediaTypeEnum.MEDIA_IMAGE.getName();
/*  968:     */     }
/*  969:1269 */     if ("mov,avi,wma,rmvb,rm,flash,mp4,mid,3gp".indexOf(filePreFix.toLowerCase()) != -1) {
/*  970:1270 */       return MediaTypeEnum.MEDIA_VIDEO.getName();
/*  971:     */     }
/*  972:1271 */     if ("amr,mp3,wav,wma,ogg,ape,acc".indexOf(filePreFix.toLowerCase()) != -1) {
/*  973:1272 */       return MediaTypeEnum.MEDIA_VOICE.getName();
/*  974:     */     }
/*  975:1274 */     return MediaTypeEnum.MEDIA_FILE.getName();
/*  976:     */   }
/*  977:     */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.file.FileUtil
 * JD-Core Version:    0.7.0.1
 */