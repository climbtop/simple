/*  1:   */ package com.afocus.framework.util.file;
/*  2:   */ 
/*  3:   */ public enum MediaTypeEnum
/*  4:   */ {
/*  5:10 */   MEDIA_IMAGE(1, "image"),  MEDIA_VOICE(2, "voice"),  MEDIA_VIDEO(3, "video"),  MEDIA_FILE(4, "file");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private MediaTypeEnum(int id, String name)
/* 11:   */   {
/* 12:18 */     this.id = id;
/* 13:19 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:23 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:27 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:31 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:35 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:39 */     for (MediaTypeEnum goodsEnum : ) {
/* 39:40 */       if (id == goodsEnum.getId()) {
/* 40:41 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:44 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.file.MediaTypeEnum
 * JD-Core Version:    0.7.0.1
 */