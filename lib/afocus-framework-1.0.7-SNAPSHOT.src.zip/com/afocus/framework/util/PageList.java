/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ 
/*  6:   */ @Deprecated
/*  7:   */ public class PageList<E>
/*  8:   */   extends ArrayList<E>
/*  9:   */   implements Serializable
/* 10:   */ {
/* 11:   */   private static final long serialVersionUID = -7317702765506896103L;
/* 12:   */   private PageTurn pageTurn;
/* 13:   */   
/* 14:   */   public PageList() {}
/* 15:   */   
/* 16:   */   public PageList(int page, int pagesize, int rowscount)
/* 17:   */   {
/* 18:23 */     this.pageTurn = new PageTurn(page, pagesize, rowscount);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public PageTurn getPageTurn()
/* 22:   */   {
/* 23:30 */     return this.pageTurn;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setPageTurn(PageTurn pageTurn)
/* 27:   */   {
/* 28:38 */     this.pageTurn = pageTurn;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String toString()
/* 32:   */   {
/* 33:42 */     return "pageList:" + super.toString() + ",pageTurn:" + this.pageTurn;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.PageList
 * JD-Core Version:    0.7.0.1
 */