package com.afocus.framework.util.contants;

public class Constants
{
  public static final String BUNDLE_KEY = "ApplicationResources";
  public static final String ENC_ALGORITHM = "algorithm";
  public static final String ENCRYPT_PASSWORD = "encryptPassword";
  public static final String EXCEPTION_MESSAGE = "exceptionResources";
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.contants.Constants
 * JD-Core Version:    0.7.0.1
 */