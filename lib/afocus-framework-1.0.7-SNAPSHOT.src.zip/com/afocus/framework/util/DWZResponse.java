/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Set;
/*   7:    */ 
/*   8:    */ public class DWZResponse
/*   9:    */ {
/*  10:    */   private final int statusCode;
/*  11:    */   private final String message;
/*  12:    */   private final String navTabId;
/*  13:    */   private final String rel;
/*  14:    */   private final String callbackType;
/*  15:    */   private final String forwardUrl;
/*  16:    */   private final Map<String, Object> attributes;
/*  17:    */   
/*  18:    */   public static void main(String[] args)
/*  19:    */   {
/*  20: 44 */     Builder builder = getSucessBuilder("操作成功");
/*  21: 45 */     builder.callbackType("callbackType").forwardUrl("forwardUrl");
/*  22: 46 */     System.out.println(builder.build().toString());
/*  23:    */     
/*  24:    */ 
/*  25: 49 */     builder = getFailBuilder("操作失败");
/*  26: 50 */     builder.callbackType("callbackType").forwardUrl("forwardUrl");
/*  27: 51 */     System.out.println(builder.build().toString());
/*  28:    */     
/*  29:    */ 
/*  30: 54 */     builder = getTimeOutBuilder("操作超时");
/*  31: 55 */     builder.callbackType("callbackType").forwardUrl("forwardUrl");
/*  32: 56 */     System.out.println(builder.build().toString());
/*  33:    */     
/*  34:    */ 
/*  35: 59 */     builder = getBuilder(404, "操作定制");
/*  36: 60 */     builder.callbackType("callbackType").forwardUrl("forwardUrl");
/*  37: 61 */     builder.addAttribute("nullAttr", null).addAttribute("blankStr", "");
/*  38: 62 */     builder.addAttribute("integer1", Integer.valueOf(1));
/*  39: 63 */     System.out.println(builder.build().toString());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public DWZResponse(Builder builder)
/*  43:    */   {
/*  44: 71 */     this.statusCode = builder.statusCode;
/*  45: 72 */     this.message = builder.message;
/*  46: 73 */     this.navTabId = builder.navTabId;
/*  47: 74 */     this.rel = builder.rel;
/*  48: 75 */     this.callbackType = builder.callbackType;
/*  49: 76 */     this.forwardUrl = builder.forwardUrl;
/*  50: 77 */     this.attributes = new HashMap(builder.attributes);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String toString(boolean toAll)
/*  54:    */   {
/*  55: 90 */     StringBuilder builder = new StringBuilder();
/*  56: 91 */     builder.append("{");
/*  57: 92 */     builder.append("\"statusCode\":\"").append(this.statusCode).append("\",");
/*  58: 93 */     builder.append("\"message\":\"").append(this.message).append("\"");
/*  59: 94 */     if (toAll)
/*  60:    */     {
/*  61: 95 */       builder.append(",");
/*  62: 96 */       builder.append("\"navTabId\":\"").append(this.navTabId).append("\",");
/*  63: 97 */       builder.append("\"rel\":\"").append(this.rel).append("\",");
/*  64: 98 */       builder.append("\"callbackType\":\"").append(this.callbackType).append("\",");
/*  65: 99 */       builder.append("\"forwardUrl\":\"").append(this.forwardUrl).append("\"");
/*  66:100 */       if ((this.attributes != null) && (!this.attributes.isEmpty()))
/*  67:    */       {
/*  68:101 */         Set<String> keySet = this.attributes.keySet();
/*  69:102 */         for (String key : keySet)
/*  70:    */         {
/*  71:103 */           builder.append(",");
/*  72:104 */           Object value = this.attributes.get(key);
/*  73:105 */           if (value == null) {
/*  74:106 */             value = "";
/*  75:    */           }
/*  76:108 */           builder.append("\"").append(key).append("\":\"");
/*  77:109 */           builder.append(value).append("\"");
/*  78:    */         }
/*  79:    */       }
/*  80:    */     }
/*  81:113 */     builder.append("}");
/*  82:114 */     return builder.toString();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String toString()
/*  86:    */   {
/*  87:124 */     return toString(true);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static Builder getSucessBuilder(String message)
/*  91:    */   {
/*  92:141 */     Builder builder = new Builder(200, message, null);
/*  93:    */     
/*  94:143 */     return builder;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static Builder getSucessBuilder(String message, String forwardUrl)
/*  98:    */   {
/*  99:161 */     Builder builder = new Builder(200, message, null);
/* 100:162 */     builder.callbackType = "forward";
/* 101:163 */     builder.forwardUrl = forwardUrl;
/* 102:164 */     return builder;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static Builder getFailBuilder(String message)
/* 106:    */   {
/* 107:181 */     Builder builder = new Builder(300, message, null);
/* 108:182 */     builder.callbackType = "closeCurrent";
/* 109:183 */     return builder;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static Builder getTimeOutBuilder(String message)
/* 113:    */   {
/* 114:200 */     Builder builder = new Builder(301, message, null);
/* 115:201 */     builder.callbackType = "closeCurrent";
/* 116:202 */     return builder;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static Builder getBuilder(int statusCode, String message)
/* 120:    */   {
/* 121:215 */     return new Builder(statusCode, message, null);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static class Builder
/* 125:    */   {
/* 126:    */     private int statusCode;
/* 127:    */     private String message;
/* 128:232 */     private String navTabId = "";
/* 129:234 */     private String rel = "";
/* 130:236 */     private String callbackType = "";
/* 131:238 */     private String forwardUrl = "";
/* 132:241 */     private Map<String, Object> attributes = new HashMap();
/* 133:    */     
/* 134:    */     private Builder(int statusCode, String message)
/* 135:    */     {
/* 136:249 */       this.statusCode = statusCode;
/* 137:250 */       this.message = message;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public Builder navTabId(String navTabId)
/* 141:    */     {
/* 142:259 */       this.navTabId = navTabId;
/* 143:260 */       return this;
/* 144:    */     }
/* 145:    */     
/* 146:    */     public Builder rel(String rel)
/* 147:    */     {
/* 148:269 */       this.rel = rel;
/* 149:270 */       return this;
/* 150:    */     }
/* 151:    */     
/* 152:    */     public Builder forwardUrl(String forwardUrl)
/* 153:    */     {
/* 154:279 */       this.forwardUrl = forwardUrl;
/* 155:280 */       return this;
/* 156:    */     }
/* 157:    */     
/* 158:    */     public Builder callbackType(String callbackType)
/* 159:    */     {
/* 160:289 */       this.callbackType = callbackType;
/* 161:290 */       return this;
/* 162:    */     }
/* 163:    */     
/* 164:    */     public Builder addAttribute(String key, Object value)
/* 165:    */     {
/* 166:300 */       this.attributes.put(key, value);
/* 167:301 */       return this;
/* 168:    */     }
/* 169:    */     
/* 170:    */     public DWZResponse build()
/* 171:    */     {
/* 172:309 */       return new DWZResponse(this);
/* 173:    */     }
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.DWZResponse
 * JD-Core Version:    0.7.0.1
 */