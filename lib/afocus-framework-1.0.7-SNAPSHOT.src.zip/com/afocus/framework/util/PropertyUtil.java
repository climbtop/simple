/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.io.BufferedOutputStream;
/*   4:    */ import java.io.FileOutputStream;
/*   5:    */ import java.util.Properties;
/*   6:    */ import java.util.PropertyResourceBundle;
/*   7:    */ import java.util.ResourceBundle;
/*   8:    */ import org.apache.commons.lang3.StringUtils;
/*   9:    */ import org.apache.log4j.Logger;
/*  10:    */ 
/*  11:    */ public class PropertyUtil
/*  12:    */ {
/*  13: 18 */   private static Logger log = Logger.getLogger(PropertyUtil.class);
/*  14:    */   
/*  15:    */   public static int getIntProperty(Properties p, String key, int defaultValue)
/*  16:    */   {
/*  17: 29 */     if (p == null) {
/*  18: 29 */       return defaultValue;
/*  19:    */     }
/*  20: 30 */     String ret = p.getProperty(key);
/*  21: 31 */     if (StringUtil.isEmpty(ret)) {
/*  22: 31 */       return defaultValue;
/*  23:    */     }
/*  24: 32 */     return Integer.parseInt(ret);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static void saveProperties(Properties p, String fileName)
/*  28:    */   {
/*  29: 43 */     saveProperties(p, fileName, null, "UTF-8");
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static void saveProperties(Properties p, String fileName, String comment)
/*  33:    */   {
/*  34: 54 */     saveProperties(p, fileName, comment, "UTF-8");
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void savePropertiesXml(Properties p, String fileName, String encoding)
/*  38:    */   {
/*  39: 65 */     saveProperties(p, fileName, null, encoding);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static void saveProperties(Properties p, String fileName, String comment, String encoding)
/*  43:    */   {
/*  44:    */     try
/*  45:    */     {
/*  46: 77 */       BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(fileName));Throwable localThrowable3 = null;
/*  47:    */       try
/*  48:    */       {
/*  49: 78 */         if (fileName.toLowerCase().endsWith(".xml")) {
/*  50: 79 */           p.storeToXML(out, comment, encoding);
/*  51:    */         } else {
/*  52: 81 */           p.store(out, comment);
/*  53:    */         }
/*  54:    */       }
/*  55:    */       catch (Throwable localThrowable1)
/*  56:    */       {
/*  57: 77 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*  58:    */       }
/*  59:    */       finally
/*  60:    */       {
/*  61: 82 */         if (out != null) {
/*  62: 82 */           if (localThrowable3 != null) {
/*  63:    */             try
/*  64:    */             {
/*  65: 82 */               out.close();
/*  66:    */             }
/*  67:    */             catch (Throwable localThrowable2)
/*  68:    */             {
/*  69: 82 */               localThrowable3.addSuppressed(localThrowable2);
/*  70:    */             }
/*  71:    */           } else {
/*  72: 82 */             out.close();
/*  73:    */           }
/*  74:    */         }
/*  75:    */       }
/*  76:    */     }
/*  77:    */     catch (Exception e)
/*  78:    */     {
/*  79: 83 */       log.error("Save properties to " + fileName + ",Exception: " + e.getMessage());
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static String getProperty(String fileName, String key)
/*  84:    */   {
/*  85:    */     try
/*  86:    */     {
/*  87: 95 */       PropertyResourceBundle configBundle = (PropertyResourceBundle)ResourceBundle.getBundle(fileName);
/*  88: 96 */       if (configBundle.containsKey(key)) {
/*  89: 97 */         return configBundle.getString(key);
/*  90:    */       }
/*  91:    */     }
/*  92:    */     catch (Exception e)
/*  93:    */     {
/*  94: 99 */       log.error("Read " + fileName + " " + key + " getProperty Exception : " + e.getMessage());
/*  95:    */     }
/*  96:102 */     return null;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static String getProperty(String fileName, String key, String defaultValue)
/* 100:    */   {
/* 101:    */     try
/* 102:    */     {
/* 103:113 */       PropertyResourceBundle configBundle = (PropertyResourceBundle)ResourceBundle.getBundle(fileName);
/* 104:114 */       if (configBundle.containsKey(key))
/* 105:    */       {
/* 106:115 */         String sRet = configBundle.getString(key);
/* 107:116 */         if (StringUtils.isNotEmpty(sRet)) {
/* 108:117 */           return sRet;
/* 109:    */         }
/* 110:    */       }
/* 111:    */     }
/* 112:    */     catch (Exception e)
/* 113:    */     {
/* 114:120 */       log.error("Read " + fileName + " " + key + " getProperty Exception : " + e.getMessage());
/* 115:    */     }
/* 116:123 */     return defaultValue;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static int getIntProperty(String fileName, String key, int defaultValue)
/* 120:    */   {
/* 121:    */     try
/* 122:    */     {
/* 123:136 */       PropertyResourceBundle configBundle = (PropertyResourceBundle)ResourceBundle.getBundle(fileName);
/* 124:137 */       if (configBundle.containsKey(key))
/* 125:    */       {
/* 126:138 */         String sRet = configBundle.getString(key);
/* 127:139 */         if (StringUtil.isEmpty(sRet)) {
/* 128:140 */           return defaultValue;
/* 129:    */         }
/* 130:141 */         return Integer.parseInt(sRet);
/* 131:    */       }
/* 132:    */     }
/* 133:    */     catch (Exception e)
/* 134:    */     {
/* 135:145 */       log.error("Read " + fileName + " " + key + " getProperty Exception : " + e.getMessage());
/* 136:    */     }
/* 137:147 */     return defaultValue;
/* 138:    */   }
/* 139:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.PropertyUtil
 * JD-Core Version:    0.7.0.1
 */