/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.util.TreeMap;
/*  5:   */ 
/*  6:   */ @Deprecated
/*  7:   */ public class PageTreeMap<K, V>
/*  8:   */   extends TreeMap<K, V>
/*  9:   */   implements Serializable
/* 10:   */ {
/* 11:   */   private static final long serialVersionUID = 1963503083952338317L;
/* 12:   */   private PageTurn pageTurn;
/* 13:   */   
/* 14:   */   public PageTurn getPageTurn()
/* 15:   */   {
/* 16:20 */     return this.pageTurn;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setPageTurn(PageTurn pageTurn)
/* 20:   */   {
/* 21:27 */     this.pageTurn = pageTurn;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString()
/* 25:   */   {
/* 26:31 */     return "pageTreeMap:" + super.toString() + ",pageTurn:" + this.pageTurn.toString();
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.PageTreeMap
 * JD-Core Version:    0.7.0.1
 */