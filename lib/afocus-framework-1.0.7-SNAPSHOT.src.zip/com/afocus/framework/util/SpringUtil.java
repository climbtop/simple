/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import org.springframework.context.ApplicationContext;
/*  4:   */ import org.springframework.util.Assert;
/*  5:   */ import org.springframework.web.context.ContextLoader;
/*  6:   */ 
/*  7:   */ public final class SpringUtil
/*  8:   */ {
/*  9:20 */   private static ApplicationContext applicationContext = ;
/* 10:   */   
/* 11:   */   public static ApplicationContext getApplicationContext()
/* 12:   */   {
/* 13:34 */     return applicationContext;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static void setApplicationContext(ApplicationContext ctx)
/* 17:   */   {
/* 18:43 */     Assert.notNull(ctx);
/* 19:44 */     applicationContext = ctx;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static Object getBean(String name)
/* 23:   */   {
/* 24:54 */     Assert.hasText(name);
/* 25:55 */     return applicationContext.getBean(name);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static <T> T getBean(String name, Class<T> type)
/* 29:   */   {
/* 30:66 */     Assert.hasText(name);
/* 31:67 */     Assert.notNull(type);
/* 32:68 */     return applicationContext.getBean(name, type);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public static <T> T getBean(Class<T> type)
/* 36:   */   {
/* 37:78 */     Assert.notNull(type);
/* 38:79 */     return applicationContext.getBean(type);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void destroy()
/* 42:   */     throws Exception
/* 43:   */   {
/* 44:83 */     applicationContext = null;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.SpringUtil
 * JD-Core Version:    0.7.0.1
 */