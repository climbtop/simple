/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.awt.AlphaComposite;
/*   4:    */ import java.awt.Graphics2D;
/*   5:    */ import java.awt.RenderingHints;
/*   6:    */ import java.awt.image.BufferedImage;
/*   7:    */ import java.io.PrintStream;
/*   8:    */ 
/*   9:    */ public class ScaleImage
/*  10:    */ {
/*  11:    */   public static BufferedImage scaleImageByMultiStep(BufferedImage img, int targetWidth, int targetHeight, boolean higherQuality)
/*  12:    */   {
/*  13: 30 */     BufferedImage ret = img;
/*  14:    */     int h;
/*  15:    */     int w;
/*  16:    */     int h;
/*  17: 32 */     if (higherQuality)
/*  18:    */     {
/*  19: 33 */       int w = img.getWidth();
/*  20: 34 */       h = img.getHeight();
/*  21:    */     }
/*  22:    */     else
/*  23:    */     {
/*  24: 37 */       w = targetWidth;
/*  25: 38 */       h = targetHeight;
/*  26:    */     }
/*  27: 43 */     int type = img.getTransparency() == 1 ? 1 : 2;
/*  28:    */     do
/*  29:    */     {
/*  30: 45 */       if ((higherQuality) && (w > targetWidth)) {
/*  31: 46 */         w >>= 1;
/*  32:    */       }
/*  33: 48 */       if (w < targetWidth) {
/*  34: 49 */         w = targetWidth;
/*  35:    */       }
/*  36: 52 */       if ((higherQuality) && (h > targetHeight)) {
/*  37: 53 */         h >>= 1;
/*  38:    */       }
/*  39: 55 */       if (h < targetHeight) {
/*  40: 56 */         h = targetHeight;
/*  41:    */       }
/*  42: 59 */       ret = scaleImage(ret, type, RenderingHints.VALUE_INTERPOLATION_BILINEAR, w, h);
/*  43: 61 */     } while ((w != targetWidth) || (h != targetHeight));
/*  44: 63 */     return ret;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static BufferedImage scaleImageByTrilinear(BufferedImage img, int targetWidth, int targetHeight)
/*  48:    */   {
/*  49: 79 */     int iw = img.getWidth();
/*  50: 80 */     int ih = img.getHeight();
/*  51:    */     
/*  52: 82 */     Object hint = RenderingHints.VALUE_INTERPOLATION_BILINEAR;
/*  53: 83 */     int type = img.getTransparency() == 1 ? 1 : 2;
/*  54: 86 */     while ((iw > targetWidth * 2) || (ih > targetHeight * 2))
/*  55:    */     {
/*  56: 87 */       iw = iw > targetWidth * 2 ? iw / 2 : iw;
/*  57: 88 */       ih = ih > targetHeight * 2 ? ih / 2 : ih;
/*  58: 89 */       img = scaleImage(img, type, hint, iw, ih);
/*  59:    */     }
/*  60: 97 */     if (iw > targetWidth)
/*  61:    */     {
/*  62: 98 */       int iw2 = iw / 2;
/*  63: 99 */       BufferedImage img2 = scaleImage(img, type, hint, iw2, ih);
/*  64:100 */       if (iw2 < targetWidth)
/*  65:    */       {
/*  66:101 */         img = scaleImage(img, type, hint, targetWidth, ih);
/*  67:102 */         img2 = scaleImage(img2, type, hint, targetWidth, ih);
/*  68:103 */         interp(img2, img, iw - targetWidth, targetWidth - iw2);
/*  69:    */       }
/*  70:105 */       img = img2;
/*  71:106 */       iw = targetWidth;
/*  72:    */     }
/*  73:112 */     if (ih > targetHeight)
/*  74:    */     {
/*  75:113 */       int ih2 = ih / 2;
/*  76:114 */       BufferedImage img2 = scaleImage(img, type, hint, iw, ih2);
/*  77:115 */       if (ih2 < targetHeight)
/*  78:    */       {
/*  79:116 */         img = scaleImage(img, type, hint, iw, targetHeight);
/*  80:117 */         img2 = scaleImage(img2, type, hint, iw, targetHeight);
/*  81:118 */         interp(img2, img, ih - targetHeight, targetHeight - ih2);
/*  82:    */       }
/*  83:120 */       img = img2;
/*  84:121 */       ih = targetHeight;
/*  85:    */     }
/*  86:127 */     if ((iw < targetWidth) && (ih < targetHeight)) {
/*  87:128 */       img = scaleImage(img, type, hint, targetWidth, targetHeight);
/*  88:    */     }
/*  89:131 */     return img;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static BufferedImage scaleImage(BufferedImage orig, int type, Object hint, int w, int h)
/*  93:    */   {
/*  94:135 */     BufferedImage tmp = new BufferedImage(w, h, type);
/*  95:136 */     Graphics2D g2 = tmp.createGraphics();
/*  96:137 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
/*  97:138 */     g2.drawImage(orig, 0, 0, w, h, null);
/*  98:139 */     g2.dispose();
/*  99:    */     
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:150 */     return tmp;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static void interp(BufferedImage img1, BufferedImage img2, int weight1, int weight2)
/* 113:    */   {
/* 114:154 */     float alpha = weight1;
/* 115:155 */     alpha /= (weight1 + weight2);
/* 116:156 */     Graphics2D g2 = img1.createGraphics();
/* 117:157 */     g2.setComposite(AlphaComposite.getInstance(3, alpha));
/* 118:158 */     g2.drawImage(img2, 0, 0, null);
/* 119:159 */     g2.dispose();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static BufferedImage scaleImageByLanczos(BufferedImage srcBufferImage, int w, int h)
/* 123:    */   {
/* 124:163 */     return new LanczosScaleImage().getScaledInstance(srcBufferImage, w, h);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static class LanczosScaleImage
/* 128:    */   {
/* 129:    */     private int width;
/* 130:    */     private int height;
/* 131:    */     private int scaleWidth;
/* 132:170 */     float support = 1.0F;
/* 133:    */     float[] contrib;
/* 134:    */     float[] normContrib;
/* 135:    */     float[] tmpContrib;
/* 136:    */     int startContrib;
/* 137:    */     int stopContrib;
/* 138:    */     int nDots;
/* 139:    */     int nHalfDots;
/* 140:    */     
/* 141:    */     public LanczosScaleImage(float support)
/* 142:    */     {
/* 143:180 */       if ((support > 0.0F) && (support <= 5.0F)) {
/* 144:181 */         this.support = support;
/* 145:    */       }
/* 146:    */     }
/* 147:    */     
/* 148:    */     public LanczosScaleImage() {}
/* 149:    */     
/* 150:    */     public BufferedImage getScaledInstance(BufferedImage srcBufferImage, int w, int h)
/* 151:    */     {
/* 152:193 */       this.width = srcBufferImage.getWidth();
/* 153:194 */       this.height = srcBufferImage.getHeight();
/* 154:195 */       this.scaleWidth = w;
/* 155:197 */       if (DetermineResultSize(w, h) == 1) {
/* 156:198 */         return srcBufferImage;
/* 157:    */       }
/* 158:200 */       CalContrib();
/* 159:201 */       BufferedImage pbOut = HorizontalFiltering(srcBufferImage, w);
/* 160:202 */       BufferedImage pbFinalOut = VerticalFiltering(pbOut, h);
/* 161:203 */       return pbFinalOut;
/* 162:    */     }
/* 163:    */     
/* 164:    */     private int DetermineResultSize(int w, int h)
/* 165:    */     {
/* 166:209 */       float scaleH = w / this.width;
/* 167:210 */       float scaleV = h / this.height;
/* 168:212 */       if ((scaleH >= 1.0D) && (scaleV >= 1.0D)) {
/* 169:213 */         return 1;
/* 170:    */       }
/* 171:215 */       return 0;
/* 172:    */     }
/* 173:    */     
/* 174:    */     private double Lanczos(float r, float rSupport)
/* 175:    */     {
/* 176:230 */       return Math.sin(r) / r * Math.sin(rSupport) / rSupport;
/* 177:    */     }
/* 178:    */     
/* 179:    */     private void CalContrib()
/* 180:    */     {
/* 181:237 */       this.nHalfDots = ((int)(this.width * this.support / this.scaleWidth));
/* 182:238 */       this.nDots = (this.nHalfDots * 2 + 1);
/* 183:    */       try
/* 184:    */       {
/* 185:243 */         this.contrib = new float[this.nDots];
/* 186:244 */         this.normContrib = new float[this.nDots];
/* 187:245 */         this.tmpContrib = new float[this.nDots];
/* 188:    */       }
/* 189:    */       catch (Exception e)
/* 190:    */       {
/* 191:248 */         System.out.println("init contrib,normContrib,tmpContrib" + e);
/* 192:    */       }
/* 193:251 */       int center = this.nHalfDots;
/* 194:252 */       this.contrib[center] = 1.0F;
/* 195:    */       
/* 196:254 */       float weight = 0.0F;
/* 197:255 */       int i = 0;
/* 198:256 */       float rb = (float)(this.scaleWidth / this.width * 3.141592653589793D);
/* 199:257 */       float rbSupport = rb / this.support;
/* 200:258 */       float r = rb;
/* 201:259 */       float rSupport = rbSupport;
/* 202:260 */       for (i = 1; i <= center; i++)
/* 203:    */       {
/* 204:263 */         this.contrib[(center + i)] = ((float)Lanczos(r, rSupport));
/* 205:264 */         r += rb;
/* 206:265 */         rSupport += rbSupport;
/* 207:266 */         weight += this.contrib[(center + i)];
/* 208:    */       }
/* 209:269 */       for (i = center - 1; i >= 0; i--) {
/* 210:270 */         this.contrib[i] = this.contrib[(center * 2 - i)];
/* 211:    */       }
/* 212:273 */       weight = weight * 2.0F + 1.0F;
/* 213:275 */       for (i = 0; i <= center; i++) {
/* 214:276 */         this.normContrib[i] = (this.contrib[i] / weight);
/* 215:    */       }
/* 216:279 */       for (i = center + 1; i < this.nDots; i++) {
/* 217:280 */         this.normContrib[i] = this.normContrib[(center * 2 - i)];
/* 218:    */       }
/* 219:    */     }
/* 220:    */     
/* 221:    */     private void CalTempContrib(int start, int stop)
/* 222:    */     {
/* 223:286 */       float weight = 0.0F;
/* 224:    */       
/* 225:288 */       int i = 0;
/* 226:289 */       for (i = start; i <= stop; i++) {
/* 227:290 */         weight += this.contrib[i];
/* 228:    */       }
/* 229:293 */       for (i = start; i <= stop; i++) {
/* 230:294 */         this.tmpContrib[i] = (this.contrib[i] / weight);
/* 231:    */       }
/* 232:    */     }
/* 233:    */     
/* 234:    */     private int HorizontalFilter(BufferedImage bufImg, int startX, int stopX, int start, int stop, int y, float[] pContrib)
/* 235:    */     {
/* 236:303 */       float a = 0.0F;
/* 237:304 */       float r = 0.0F;
/* 238:305 */       float g = 0.0F;
/* 239:306 */       float b = 0.0F;
/* 240:307 */       int rgb = 0;
/* 241:    */       
/* 242:    */ 
/* 243:    */ 
/* 244:311 */       int i = startX;
/* 245:311 */       for (int j = start; i <= stopX; j++)
/* 246:    */       {
/* 247:312 */         rgb = bufImg.getRGB(i, y);
/* 248:    */         
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:318 */         a += (rgb >>> 24) * pContrib[j];
/* 254:319 */         r += (rgb >> 16 & 0xFF) * pContrib[j];
/* 255:320 */         g += (rgb >> 8 & 0xFF) * pContrib[j];
/* 256:321 */         b += (rgb & 0xFF) * pContrib[j];i++;
/* 257:    */       }
/* 258:323 */       if (a < 0.0F) {
/* 259:323 */         a = 0.0F;
/* 260:323 */       } else if (a > 255.0F) {
/* 261:323 */         a = 255.0F;
/* 262:    */       }
/* 263:324 */       if (r < 0.0F) {
/* 264:324 */         r = 0.0F;
/* 265:324 */       } else if (r > 255.0F) {
/* 266:324 */         r = 255.0F;
/* 267:    */       }
/* 268:325 */       if (g < 0.0F) {
/* 269:325 */         g = 0.0F;
/* 270:325 */       } else if (g > 255.0F) {
/* 271:325 */         g = 255.0F;
/* 272:    */       }
/* 273:326 */       if (b < 0.0F) {
/* 274:326 */         b = 0.0F;
/* 275:326 */       } else if (b > 255.0F) {
/* 276:326 */         b = 255.0F;
/* 277:    */       }
/* 278:327 */       return (int)a << 24 | (int)r << 16 | (int)g << 8 | (int)b;
/* 279:    */     }
/* 280:    */     
/* 281:    */     private BufferedImage HorizontalFiltering(BufferedImage bufImage, int iOutW)
/* 282:    */     {
/* 283:333 */       int dwInW = bufImage.getWidth();
/* 284:334 */       int dwInH = bufImage.getHeight();
/* 285:335 */       int value = 0;
/* 286:336 */       BufferedImage pbOut = new BufferedImage(iOutW, dwInH, 1);
/* 287:337 */       float rb = dwInW / iOutW;
/* 288:338 */       float r = 0.0F;
/* 289:    */       int y;
/* 290:    */       int startX;
/* 291:    */       int start;
/* 292:    */       int stopX;
/* 293:    */       int stop;
/* 294:339 */       for (int x = 0; x < iOutW; x++)
/* 295:    */       {
/* 296:343 */         int X = (int)(r + 0.5D);
/* 297:344 */         r += rb;
/* 298:345 */         y = 0;
/* 299:    */         
/* 300:347 */         startX = X - this.nHalfDots;
/* 301:    */         int start;
/* 302:348 */         if (startX < 0)
/* 303:    */         {
/* 304:349 */           startX = 0;
/* 305:350 */           start = this.nHalfDots - X;
/* 306:    */         }
/* 307:    */         else
/* 308:    */         {
/* 309:353 */           start = 0;
/* 310:    */         }
/* 311:357 */         stopX = X + this.nHalfDots;
/* 312:    */         int stop;
/* 313:358 */         if (stopX > dwInW - 1)
/* 314:    */         {
/* 315:359 */           stopX = dwInW - 1;
/* 316:360 */           stop = this.nHalfDots + (dwInW - 1 - X);
/* 317:    */         }
/* 318:    */         else
/* 319:    */         {
/* 320:363 */           stop = this.nHalfDots << 1;
/* 321:    */         }
/* 322:366 */         if ((start > 0) || (stop < this.nDots - 1))
/* 323:    */         {
/* 324:367 */           CalTempContrib(start, stop);
/* 325:368 */           for (y = 0; y < dwInH;)
/* 326:    */           {
/* 327:369 */             value = HorizontalFilter(bufImage, startX, stopX, start, stop, y, this.tmpContrib);
/* 328:370 */             pbOut.setRGB(x, y, value);y++; continue;
/* 329:374 */             for (y = 0; y < dwInH; y++)
/* 330:    */             {
/* 331:375 */               value = HorizontalFilter(bufImage, startX, stopX, start, stop, y, this.normContrib);
/* 332:376 */               pbOut.setRGB(x, y, value);
/* 333:    */             }
/* 334:    */           }
/* 335:    */         }
/* 336:    */       }
/* 337:381 */       return pbOut;
/* 338:    */     }
/* 339:    */     
/* 340:    */     private int VerticalFilter(BufferedImage pbInImage, int startY, int stopY, int start, int stop, int x, float[] pContrib)
/* 341:    */     {
/* 342:387 */       float a = 0.0F;
/* 343:388 */       float r = 0.0F;
/* 344:389 */       float g = 0.0F;
/* 345:390 */       float b = 0.0F;
/* 346:391 */       int rgb = 0;
/* 347:    */       
/* 348:    */ 
/* 349:394 */       int i = startY;
/* 350:394 */       for (int j = start; i <= stopY; j++)
/* 351:    */       {
/* 352:395 */         rgb = pbInImage.getRGB(x, i);
/* 353:    */         
/* 354:397 */         a += (rgb >>> 24) * pContrib[j];
/* 355:398 */         r += (rgb >> 16 & 0xFF) * pContrib[j];
/* 356:399 */         g += (rgb >> 8 & 0xFF) * pContrib[j];
/* 357:400 */         b += (rgb & 0xFF) * pContrib[j];i++;
/* 358:    */       }
/* 359:402 */       if (a < 0.0F) {
/* 360:402 */         a = 0.0F;
/* 361:402 */       } else if (a > 255.0F) {
/* 362:402 */         a = 255.0F;
/* 363:    */       }
/* 364:403 */       if (r < 0.0F) {
/* 365:403 */         r = 0.0F;
/* 366:403 */       } else if (r > 255.0F) {
/* 367:403 */         r = 255.0F;
/* 368:    */       }
/* 369:404 */       if (g < 0.0F) {
/* 370:404 */         g = 0.0F;
/* 371:404 */       } else if (g > 255.0F) {
/* 372:404 */         g = 255.0F;
/* 373:    */       }
/* 374:405 */       if (b < 0.0F) {
/* 375:405 */         b = 0.0F;
/* 376:405 */       } else if (b > 255.0F) {
/* 377:405 */         b = 255.0F;
/* 378:    */       }
/* 379:406 */       return (int)a << 24 | (int)r << 16 | (int)g << 8 | (int)b;
/* 380:    */     }
/* 381:    */     
/* 382:    */     private BufferedImage VerticalFiltering(BufferedImage pbImage, int iOutH)
/* 383:    */     {
/* 384:411 */       int iW = pbImage.getWidth();
/* 385:412 */       int iH = pbImage.getHeight();
/* 386:413 */       int value = 0;
/* 387:414 */       BufferedImage pbOut = new BufferedImage(iW, iOutH, 1);
/* 388:    */       
/* 389:416 */       float rb = iH / iOutH;
/* 390:417 */       float r = 0.0F;
/* 391:418 */       for (int y = 0; y < iOutH; y++)
/* 392:    */       {
/* 393:422 */         int Y = (int)(r + 0.5D);
/* 394:423 */         r += rb;
/* 395:    */         
/* 396:425 */         int startY = Y - this.nHalfDots;
/* 397:    */         int start;
/* 398:    */         int start;
/* 399:426 */         if (startY < 0)
/* 400:    */         {
/* 401:427 */           startY = 0;
/* 402:428 */           start = this.nHalfDots - Y;
/* 403:    */         }
/* 404:    */         else
/* 405:    */         {
/* 406:431 */           start = 0;
/* 407:    */         }
/* 408:435 */         int stopY = Y + this.nHalfDots;
/* 409:    */         int stop;
/* 410:    */         int stop;
/* 411:436 */         if (stopY > iH - 1)
/* 412:    */         {
/* 413:437 */           stopY = iH - 1;
/* 414:438 */           stop = this.nHalfDots + (iH - 1 - Y);
/* 415:    */         }
/* 416:    */         else
/* 417:    */         {
/* 418:441 */           stop = this.nHalfDots << 1;
/* 419:    */         }
/* 420:444 */         if ((start > 0) || (stop < this.nDots - 1))
/* 421:    */         {
/* 422:445 */           CalTempContrib(start, stop);
/* 423:446 */           for (int x = 0; x < iW; x++)
/* 424:    */           {
/* 425:447 */             value = VerticalFilter(pbImage, startY, stopY, start, stop, x, this.tmpContrib);
/* 426:448 */             pbOut.setRGB(x, y, value);
/* 427:    */           }
/* 428:    */         }
/* 429:    */         else
/* 430:    */         {
/* 431:452 */           for (int x = 0; x < iW; x++)
/* 432:    */           {
/* 433:453 */             value = VerticalFilter(pbImage, startY, stopY, start, stop, x, this.normContrib);
/* 434:454 */             pbOut.setRGB(x, y, value);
/* 435:    */           }
/* 436:    */         }
/* 437:    */       }
/* 438:460 */       return pbOut;
/* 439:    */     }
/* 440:    */   }
/* 441:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.ScaleImage
 * JD-Core Version:    0.7.0.1
 */