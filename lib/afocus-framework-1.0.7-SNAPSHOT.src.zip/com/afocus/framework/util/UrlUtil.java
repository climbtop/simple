/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.io.UnsupportedEncodingException;
/*   5:    */ import java.net.URLDecoder;
/*   6:    */ import java.net.URLEncoder;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.regex.Matcher;
/*  10:    */ 
/*  11:    */ public class UrlUtil
/*  12:    */ {
/*  13:    */   public static final int All_REFER = 0;
/*  14:    */   public static final int DIRECT_REFER = 1;
/*  15:    */   public static final int SEACHE_ENGINE_REFER = 2;
/*  16:    */   public static final int SITE_REFER = 3;
/*  17:    */   public static final int OUT_SITE_REFER = 4;
/*  18:    */   public static final int SAME_SITE_REFER = 5;
/*  19:    */   
/*  20:    */   public static String encode(String str)
/*  21:    */   {
/*  22: 41 */     if ((str == null) || (str.equals(""))) {
/*  23: 42 */       return "";
/*  24:    */     }
/*  25:    */     try
/*  26:    */     {
/*  27: 44 */       str = URLEncoder.encode(str, "GBK");
/*  28:    */     }
/*  29:    */     catch (UnsupportedEncodingException e)
/*  30:    */     {
/*  31: 47 */       e.printStackTrace();
/*  32:    */     }
/*  33: 49 */     return str;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static String decode(String str)
/*  37:    */   {
/*  38: 53 */     if ((str == null) || (str.equals(""))) {
/*  39: 54 */       return "";
/*  40:    */     }
/*  41:    */     try
/*  42:    */     {
/*  43: 56 */       str = URLDecoder.decode(str, "GBK");
/*  44:    */     }
/*  45:    */     catch (UnsupportedEncodingException e)
/*  46:    */     {
/*  47: 59 */       e.printStackTrace();
/*  48:    */     }
/*  49: 61 */     return str;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static String encode(String str, String code)
/*  53:    */   {
/*  54: 65 */     if ((str == null) || (str.equals(""))) {
/*  55: 66 */       return "";
/*  56:    */     }
/*  57:    */     try
/*  58:    */     {
/*  59: 68 */       str = URLEncoder.encode(str, code);
/*  60:    */     }
/*  61:    */     catch (UnsupportedEncodingException e)
/*  62:    */     {
/*  63: 71 */       e.printStackTrace();
/*  64:    */     }
/*  65: 73 */     return str;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static String decode(String str, String code)
/*  69:    */   {
/*  70: 77 */     if ((str == null) || (str.equals(""))) {
/*  71: 78 */       return "";
/*  72:    */     }
/*  73:    */     try
/*  74:    */     {
/*  75: 80 */       str = URLDecoder.decode(str, code);
/*  76:    */     }
/*  77:    */     catch (UnsupportedEncodingException e)
/*  78:    */     {
/*  79: 83 */       e.printStackTrace();
/*  80:    */     }
/*  81: 85 */     return str;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static String escape(String src)
/*  85:    */   {
/*  86: 89 */     if ((src == null) || (src.equals(""))) {
/*  87: 90 */       return "";
/*  88:    */     }
/*  89: 94 */     StringBuffer tmp = new StringBuffer();
/*  90: 95 */     tmp.ensureCapacity(src.length() * 6);
/*  91: 96 */     for (int i = 0; i < src.length(); i++)
/*  92:    */     {
/*  93: 97 */       char j = src.charAt(i);
/*  94: 98 */       if ((Character.isDigit(j)) || (Character.isLowerCase(j)) || 
/*  95: 99 */         (Character.isUpperCase(j)))
/*  96:    */       {
/*  97:100 */         tmp.append(j);
/*  98:    */       }
/*  99:101 */       else if (j < 'Ā')
/* 100:    */       {
/* 101:102 */         tmp.append("%");
/* 102:103 */         if (j < '\020') {
/* 103:104 */           tmp.append("0");
/* 104:    */         }
/* 105:105 */         tmp.append(Integer.toString(j, 16));
/* 106:    */       }
/* 107:    */       else
/* 108:    */       {
/* 109:107 */         tmp.append("%u");
/* 110:108 */         tmp.append(Integer.toString(j, 16));
/* 111:    */       }
/* 112:    */     }
/* 113:111 */     return tmp.toString();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static String unescape(String src)
/* 117:    */   {
/* 118:115 */     if ((src == null) || (src.equals(""))) {
/* 119:116 */       return "";
/* 120:    */     }
/* 121:118 */     StringBuffer tmp = new StringBuffer();
/* 122:119 */     tmp.ensureCapacity(src.length());
/* 123:120 */     int lastPos = 0;int pos = 0;
/* 124:122 */     while (lastPos < src.length())
/* 125:    */     {
/* 126:123 */       pos = src.indexOf("%", lastPos);
/* 127:124 */       if (pos == lastPos)
/* 128:    */       {
/* 129:125 */         if (src.charAt(pos + 1) == 'u')
/* 130:    */         {
/* 131:126 */           char ch = (char)Integer.parseInt(src
/* 132:127 */             .substring(pos + 2, pos + 6), 16);
/* 133:128 */           tmp.append(ch);
/* 134:129 */           lastPos = pos + 6;
/* 135:    */         }
/* 136:    */         else
/* 137:    */         {
/* 138:131 */           char ch = (char)Integer.parseInt(src
/* 139:132 */             .substring(pos + 1, pos + 3), 16);
/* 140:133 */           tmp.append(ch);
/* 141:134 */           lastPos = pos + 3;
/* 142:    */         }
/* 143:    */       }
/* 144:137 */       else if (pos == -1)
/* 145:    */       {
/* 146:138 */         tmp.append(src.substring(lastPos));
/* 147:139 */         lastPos = src.length();
/* 148:    */       }
/* 149:    */       else
/* 150:    */       {
/* 151:141 */         tmp.append(src.substring(lastPos, pos));
/* 152:142 */         lastPos = pos;
/* 153:    */       }
/* 154:    */     }
/* 155:146 */     return tmp.toString();
/* 156:    */   }
/* 157:    */   
/* 158:    */   public static String getDomain(String url)
/* 159:    */   {
/* 160:154 */     String content = "";
/* 161:155 */     if (!StringUtil.isEmpty(url))
/* 162:    */     {
/* 163:158 */       Matcher matcher = StringUtil.getMatcherGroup(url, ".*?(\\w*?\\.(com|cn|net|org|biz|info|cc|tv))");
/* 164:159 */       while (matcher.find()) {
/* 165:160 */         content = matcher.group(1);
/* 166:    */       }
/* 167:    */     }
/* 168:163 */     return content;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static String getServerName(String url)
/* 172:    */   {
/* 173:175 */     String content = "";
/* 174:176 */     if (!StringUtil.isEmpty(url))
/* 175:    */     {
/* 176:179 */       Matcher matcher = StringUtil.getMatcherGroup(url, "(?<=http://|https://|ftp://)([\\s\\S]*?\\.(com.cn|com|cn|net|org|biz|info|cc|tv))");
/* 177:180 */       while (matcher.find()) {
/* 178:181 */         content = matcher.group();
/* 179:    */       }
/* 180:    */     }
/* 181:184 */     return content;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static String getDirectory(String url)
/* 185:    */   {
/* 186:195 */     String content = "";
/* 187:196 */     if (!StringUtil.isEmpty(url))
/* 188:    */     {
/* 189:198 */       Matcher matcher = StringUtil.getMatcherGroup(url, "(com|cn|net|org|biz|info|cc|tv)(\\/.*\\/)([^\\/]*)$");
/* 190:199 */       while (matcher.find()) {
/* 191:200 */         content = matcher.group(2);
/* 192:    */       }
/* 193:    */     }
/* 194:203 */     return content;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static int getReferType(String referServer, String serverName)
/* 198:    */   {
/* 199:221 */     if (StringUtil.isEmpty(referServer)) {
/* 200:223 */       return 1;
/* 201:    */     }
/* 202:225 */     if (referServer.equals(serverName)) {
/* 203:227 */       return 5;
/* 204:    */     }
/* 205:229 */     if (getDomain(referServer).equals(getDomain(serverName))) {
/* 206:231 */       return 3;
/* 207:    */     }
/* 208:234 */     String searchEngine = SearchEngine.getSearchEngineByPattern(referServer);
/* 209:235 */     if (!StringUtil.isEmpty(searchEngine)) {
/* 210:237 */       return 2;
/* 211:    */     }
/* 212:241 */     return 4;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public static Map<String, String> queryStringToMap(String queryString)
/* 216:    */   {
/* 217:252 */     if ((null == queryString) || ("".equals(queryString))) {
/* 218:253 */       return null;
/* 219:    */     }
/* 220:256 */     Map<String, String> m = new HashMap();
/* 221:257 */     String[] strArray = queryString.split("&");
/* 222:258 */     for (int index = 0; index < strArray.length; index++)
/* 223:    */     {
/* 224:259 */       String pair = strArray[index];
/* 225:260 */       if ((null != pair) && (!"".equals(pair)))
/* 226:    */       {
/* 227:264 */         int indexOf = pair.indexOf("=");
/* 228:265 */         if (-1 != indexOf)
/* 229:    */         {
/* 230:266 */           String k = pair.substring(0, indexOf);
/* 231:267 */           String v = pair.substring(indexOf + 1, pair.length());
/* 232:268 */           if ((null != k) && (!"".equals(k))) {
/* 233:269 */             m.put(k, v);
/* 234:    */           }
/* 235:    */         }
/* 236:    */         else
/* 237:    */         {
/* 238:272 */           m.put(pair, "");
/* 239:    */         }
/* 240:    */       }
/* 241:    */     }
/* 242:276 */     return m;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public static void main(String[] args)
/* 246:    */   {
/* 247:281 */     String url = "http://t.news.21cn.com/tod.ay/79225_03.shtml/#top";
/* 248:282 */     System.out.println(getServerName(url));
/* 249:    */     
/* 250:284 */     String sub = getDirectory(url);
/* 251:285 */     String[] m = sub.split("/");
/* 252:286 */     String newSub = "/";
/* 253:287 */     int max = 3;
/* 254:288 */     int loop = max > m.length ? m.length : max;
/* 255:289 */     for (int i = 0; i < loop; i++) {
/* 256:290 */       if ((!m[i].equals("")) && (m[i].indexOf(".") == -1)) {
/* 257:291 */         newSub = newSub + m[i] + "/";
/* 258:    */       }
/* 259:    */     }
/* 260:293 */     System.out.println(newSub);
/* 261:    */   }
/* 262:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.UrlUtil
 * JD-Core Version:    0.7.0.1
 */