/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.util.concurrent.BlockingQueue;
/*   4:    */ import java.util.concurrent.LinkedBlockingQueue;
/*   5:    */ import java.util.concurrent.ThreadPoolExecutor;
/*   6:    */ import java.util.concurrent.TimeUnit;
/*   7:    */ import java.util.concurrent.atomic.AtomicInteger;
/*   8:    */ import org.apache.log4j.Logger;
/*   9:    */ 
/*  10:    */ public class SimpleThreadPool
/*  11:    */   extends ThreadPoolExecutor
/*  12:    */ {
/*  13: 17 */   private Logger log = Logger.getLogger(getClass());
/*  14: 19 */   private AtomicInteger taskBalance = new AtomicInteger(0);
/*  15: 21 */   private int queueCapacity = 100;
/*  16:    */   
/*  17:    */   public SimpleThreadPool(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue)
/*  18:    */   {
/*  19: 32 */     super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public SimpleThreadPool(int corePoolSize, int maximumPoolSize, long keepAliveSecond, BlockingQueue<Runnable> workQueue)
/*  23:    */   {
/*  24: 43 */     super(corePoolSize, maximumPoolSize, keepAliveSecond, TimeUnit.SECONDS, workQueue);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public SimpleThreadPool(int corePoolSize, int maximumPoolSize, long keepAliveSecond)
/*  28:    */   {
/*  29: 53 */     super(corePoolSize, maximumPoolSize, keepAliveSecond, TimeUnit.SECONDS, new LinkedBlockingQueue());
/*  30:    */   }
/*  31:    */   
/*  32:    */   public SimpleThreadPool(BlockingQueue<Runnable> workQueue)
/*  33:    */   {
/*  34: 61 */     super(1, 1, 1L, TimeUnit.SECONDS, workQueue);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public SimpleThreadPool()
/*  38:    */   {
/*  39: 68 */     super(1, 1, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static SimpleThreadPool createSingleThread()
/*  43:    */   {
/*  44: 76 */     return new SimpleThreadPool();
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected void afterExecute(Runnable r, Throwable t)
/*  48:    */   {
/*  49: 80 */     super.afterExecute(r, t);
/*  50: 81 */     this.taskBalance.decrementAndGet();
/*  51: 83 */     if (this.log.isDebugEnabled()) {
/*  52: 84 */       this.log.debug("task : " + r.getClass().getSimpleName() + " completed,Throwable:" + t + ",taskBalance:" + getTaskBalance());
/*  53:    */     }
/*  54: 86 */     synchronized (this)
/*  55:    */     {
/*  56: 87 */       notifyAll();
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void execute(Runnable task)
/*  61:    */   {
/*  62: 92 */     this.taskBalance.getAndIncrement();
/*  63: 93 */     super.execute(task);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean addTask(Runnable task)
/*  67:    */   {
/*  68:102 */     if (this.queueCapacity < getQueue().size())
/*  69:    */     {
/*  70:103 */       this.log.warn("task Queue full!");
/*  71:104 */       return false;
/*  72:    */     }
/*  73:106 */     execute(task);
/*  74:    */     
/*  75:108 */     return true;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public int getTaskBalance()
/*  79:    */   {
/*  80:115 */     return this.taskBalance.get();
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setQueueCapacity(int capacity)
/*  84:    */   {
/*  85:122 */     this.queueCapacity = capacity;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void setMaxPoolSize(int size)
/*  89:    */   {
/*  90:126 */     super.setMaximumPoolSize(size);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void setKeepAliveSecond(int time)
/*  94:    */   {
/*  95:133 */     super.setKeepAliveTime(time, TimeUnit.SECONDS);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void waitCompleted()
/*  99:    */   {
/* 100:    */     try
/* 101:    */     {
/* 102:141 */       synchronized (this)
/* 103:    */       {
/* 104:142 */         while (getTaskBalance() > 0) {
/* 105:143 */           wait(500L);
/* 106:    */         }
/* 107:    */       }
/* 108:    */     }
/* 109:    */     catch (InterruptedException localInterruptedException) {}
/* 110:147 */     this.log.info("taskBalance: " + getTaskBalance());
/* 111:    */   }
/* 112:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.SimpleThreadPool
 * JD-Core Version:    0.7.0.1
 */