/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.util.Date;
/*   4:    */ import java.util.Objects;
/*   5:    */ import org.apache.commons.lang3.StringUtils;
/*   6:    */ 
/*   7:    */ public final class Guard
/*   8:    */ {
/*   9:    */   public static void checkArgument(boolean expression)
/*  10:    */   {
/*  11: 24 */     if (!expression) {
/*  12: 25 */       throw new IllegalArgumentException();
/*  13:    */     }
/*  14:    */   }
/*  15:    */   
/*  16:    */   public static void checkArgument(boolean expression, Object errorMessage)
/*  17:    */   {
/*  18: 36 */     if (!expression) {
/*  19: 37 */       throw new IllegalArgumentException(String.valueOf(errorMessage));
/*  20:    */     }
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static void checkArgument(boolean expression, String errorMessageTemplate, Object... errorMessageArgs)
/*  24:    */   {
/*  25: 49 */     if (!expression) {
/*  26: 50 */       throw new IllegalArgumentException(String.format(errorMessageTemplate, errorMessageArgs));
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void argumentNotNull(Object value, String errorMessage)
/*  31:    */   {
/*  32: 61 */     checkArgument(!Objects.equals(value, null), errorMessage);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void argumentNotNullOrEmpty(String value, String errorMessage)
/*  36:    */   {
/*  37: 71 */     checkArgument(StringUtils.isNotEmpty(value), errorMessage);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void argumentInRange(int value, int minimum, int maximum, String errorMessage)
/*  41:    */   {
/*  42: 83 */     checkArgument((minimum <= value) && (value <= maximum), errorMessage);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static void argumentInRange(long value, long minimum, long maximum, String errorMessage)
/*  46:    */   {
/*  47: 95 */     checkArgument((minimum <= value) && (value <= maximum), errorMessage);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static void argumentInRange(Date value, Date minimum, Date maximum, String errorMessage)
/*  51:    */   {
/*  52:107 */     argumentInRange(value.getTime(), minimum.getTime(), maximum.getTime(), errorMessage);
/*  53:    */   }
/*  54:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.Guard
 * JD-Core Version:    0.7.0.1
 */