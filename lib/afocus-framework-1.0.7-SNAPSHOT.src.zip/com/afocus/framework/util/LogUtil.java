/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.alibaba.fastjson.JSON;
/*   4:    */ import com.alibaba.fastjson.JSONObject;
/*   5:    */ import javax.servlet.http.HttpServletRequest;
/*   6:    */ import org.apache.commons.lang3.StringUtils;
/*   7:    */ import org.slf4j.Logger;
/*   8:    */ 
/*   9:    */ public final class LogUtil
/*  10:    */ {
/*  11: 16 */   public static String NewLine = "\n";
/*  12:    */   
/*  13:    */   public static void error(Logger logger, String message, HttpServletRequest request, Throwable throwable)
/*  14:    */   {
/*  15: 28 */     logger.error((StringUtils.isEmpty(message) ? "" : message) + NewLine + "URL:" + 
/*  16: 29 */       request.getRequestURL() + " Method:" + 
/*  17: 30 */       request.getMethod() + NewLine + "Parameters:" + 
/*  18: 31 */       JSONObject.toJSON(request.getParameterMap()).toString() + NewLine + 
/*  19: 32 */       getMethodDesc(throwable, null), throwable);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static void error(Logger logger, HttpServletRequest request, Throwable throwable)
/*  23:    */   {
/*  24: 46 */     logger.error("URL:" + request.getRequestURL() + " Method:" + 
/*  25: 47 */       request.getMethod() + NewLine + "Parameters:" + 
/*  26: 48 */       JSONObject.toJSON(request.getParameterMap()).toString() + NewLine + 
/*  27: 49 */       getMethodDesc(throwable, null), throwable);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void error(Logger logger, Throwable throwable)
/*  31:    */   {
/*  32: 64 */     logger.error(
/*  33: 65 */       getMethodDesc(throwable, null), throwable);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static void error(Logger logger, Throwable throwable, Object[] params)
/*  37:    */   {
/*  38: 79 */     logger.error(
/*  39: 80 */       getMethodDesc(throwable, params), throwable);
/*  40:    */   }
/*  41:    */   
/*  42:    */   static String getMethodDesc(Throwable throwable, Object[] params)
/*  43:    */   {
/*  44: 88 */     if (throwable == null) {
/*  45: 89 */       return "";
/*  46:    */     }
/*  47: 91 */     if (throwable.getStackTrace().length > 2)
/*  48:    */     {
/*  49: 92 */       StackTraceElement element = throwable.getStackTrace()[1];
/*  50: 93 */       return String.format("FUNC:%s.%s PARAMS: %s LINE:%s", new Object[] {element
/*  51: 94 */         .getClassName(), element
/*  52: 95 */         .getMethodName(), params == null ? "" : 
/*  53: 96 */         JSON.toJSONString(params), 
/*  54: 97 */         Integer.valueOf(element.getLineNumber()) });
/*  55:    */     }
/*  56:101 */     return "";
/*  57:    */   }
/*  58:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.LogUtil
 * JD-Core Version:    0.7.0.1
 */