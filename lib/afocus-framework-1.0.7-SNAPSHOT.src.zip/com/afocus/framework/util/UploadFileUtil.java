/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.alibaba.fastjson.JSONArray;
/*   4:    */ import com.alibaba.fastjson.JSONObject;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.apache.http.HttpEntity;
/*   9:    */ import org.apache.http.HttpResponse;
/*  10:    */ import org.apache.http.client.HttpClient;
/*  11:    */ import org.apache.http.client.config.RequestConfig;
/*  12:    */ import org.apache.http.client.config.RequestConfig.Builder;
/*  13:    */ import org.apache.http.client.methods.HttpPost;
/*  14:    */ import org.apache.http.entity.ContentType;
/*  15:    */ import org.apache.http.entity.mime.MultipartEntityBuilder;
/*  16:    */ import org.apache.http.entity.mime.content.ByteArrayBody;
/*  17:    */ import org.apache.http.entity.mime.content.StringBody;
/*  18:    */ import org.apache.http.impl.client.HttpClients;
/*  19:    */ import org.apache.http.util.EntityUtils;
/*  20:    */ import org.apache.log4j.Logger;
/*  21:    */ 
/*  22:    */ public final class UploadFileUtil
/*  23:    */ {
/*  24: 28 */   static Logger log = Logger.getLogger(UploadFileUtil.class);
/*  25: 30 */   private static String[] aryImageSize = { "original", "small", "middle", "large" };
/*  26: 32 */   private static RequestConfig requestConfig = RequestConfig.custom()
/*  27: 33 */     .setSocketTimeout(10000)
/*  28: 34 */     .setConnectTimeout(30000)
/*  29: 35 */     .build();
/*  30:    */   
/*  31:    */   public static String uploadFile(String serverUrl, String token, String fileName, byte[] contents)
/*  32:    */   {
/*  33: 50 */     JSONArray result = upload(serverUrl, token, false, fileName, contents);
/*  34: 51 */     return result.getJSONObject(0).getString("original");
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static Map<String, String> uploadImage(String serverUrl, String token, boolean resize, String fileName, byte[] contents)
/*  38:    */   {
/*  39: 69 */     JSONObject result = upload(serverUrl, token, resize, fileName, contents).getJSONObject(0);
/*  40: 70 */     Map<String, String> map = new HashMap();
/*  41: 72 */     for (String size : aryImageSize) {
/*  42: 73 */       if (result.containsKey(size)) {
/*  43: 74 */         map.put(size, result.getString(size));
/*  44:    */       }
/*  45:    */     }
/*  46: 76 */     return map;
/*  47:    */   }
/*  48:    */   
/*  49:    */   static JSONArray upload(String serverUrl, String token, boolean resize, String fileName, byte[] bytes)
/*  50:    */   {
/*  51:    */     try
/*  52:    */     {
/*  53: 85 */       HttpClient httpclient = HttpClients.createMinimal();
/*  54:    */       
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59: 91 */       HttpEntity reqEntity = MultipartEntityBuilder.create().addPart("token", new StringBody(token, ContentType.TEXT_PLAIN)).addPart("resize", new StringBody(resize ? "true" : "false", ContentType.TEXT_PLAIN)).addPart("file", new ByteArrayBody(bytes, fileName)).build();
/*  60: 92 */       HttpPost post = new HttpPost(serverUrl);
/*  61:    */       
/*  62: 94 */       post.setEntity(reqEntity);
/*  63:    */       
/*  64: 96 */       post.setConfig(requestConfig);
/*  65:    */       
/*  66: 98 */       HttpResponse response = httpclient.execute(post);
/*  67:    */       
/*  68:100 */       HttpEntity entity = response.getEntity();
/*  69:    */       
/*  70:102 */       String out = EntityUtils.toString(entity, "UTF-8");
/*  71:    */       
/*  72:104 */       post.releaseConnection();
/*  73:    */       
/*  74:106 */       log.info(out);
/*  75:    */       
/*  76:108 */       JSONObject result = JSONObject.parseObject(out);
/*  77:110 */       if (result.getInteger("code").intValue() == 1) {
/*  78:111 */         return result.getJSONArray("data");
/*  79:    */       }
/*  80:113 */       throw new RuntimeException("文件上传失败：" + result.getString("msg"));
/*  81:    */     }
/*  82:    */     catch (IOException e)
/*  83:    */     {
/*  84:116 */       throw new RuntimeException("文件上传失败：" + e.getMessage());
/*  85:    */     }
/*  86:    */   }
/*  87:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.UploadFileUtil
 * JD-Core Version:    0.7.0.1
 */