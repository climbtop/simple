/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.ObjectOutputStream;
/*  5:   */ import java.io.OutputStream;
/*  6:   */ import java.io.Serializable;
/*  7:   */ 
/*  8:   */ @Deprecated
/*  9:   */ public class SizeCalculatorUtil
/* 10:   */ {
/* 11:   */   public static int calcSize(Serializable o)
/* 12:   */   {
/* 13:19 */     ret = 0;
/* 14:   */     
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:28 */     OutputStream buf = new OutputStream()
/* 23:   */     {
/* 24:21 */       int count = 0;
/* 25:   */       
/* 26:   */       public void write(int b)
/* 27:   */         throws IOException
/* 28:   */       {
/* 29:24 */         this.count += 1;
/* 30:   */       }
/* 31:28 */     };
/* 32:29 */     ObjectOutputStream os = null;
/* 33:   */     try
/* 34:   */     {
/* 35:31 */       os = new ObjectOutputStream(buf);
/* 36:32 */       os.writeObject(o);
/* 37:33 */       return buf.count;
/* 38:   */     }
/* 39:   */     catch (IOException e)
/* 40:   */     {
/* 41:37 */       e.printStackTrace();
/* 42:38 */       ret = -1;
/* 43:   */     }
/* 44:   */     finally
/* 45:   */     {
/* 46:   */       try
/* 47:   */       {
/* 48:41 */         os.close();
/* 49:   */       }
/* 50:   */       catch (Exception localException2) {}
/* 51:   */     }
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static int calcSizeByte(Serializable o)
/* 55:   */   {
/* 56:49 */     int byt = calcSize(o);
/* 57:50 */     return byt;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public static int calcSizeKb(Serializable o)
/* 61:   */   {
/* 62:54 */     return calcSizeByte(o) / 1024;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static int calSizeMb(Serializable o)
/* 66:   */   {
/* 67:58 */     return calcSizeKb(o) / 1024;
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.SizeCalculatorUtil
 * JD-Core Version:    0.7.0.1
 */