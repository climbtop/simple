/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import java.text.DecimalFormat;
/*  4:   */ 
/*  5:   */ @Deprecated
/*  6:   */ public class PriceUtil
/*  7:   */ {
/*  8:13 */   public static final DecimalFormat fnum = new DecimalFormat("##0.00");
/*  9:   */   
/* 10:   */   public static final double multiple(double num1, double num2)
/* 11:   */   {
/* 12:23 */     return Double.parseDouble(fnum.format(num1 * num2));
/* 13:   */   }
/* 14:   */   
/* 15:   */   public static final double multiple(double num1, int num2)
/* 16:   */   {
/* 17:34 */     return Double.parseDouble(fnum.format(num1 * num2));
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static final double add(double num1, double num2)
/* 21:   */   {
/* 22:44 */     return Double.parseDouble(fnum.format(num1 + num2));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static final double sub(double num1, double num2)
/* 26:   */   {
/* 27:54 */     return Double.parseDouble(fnum.format(num1 - num2));
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static final double round(double price)
/* 31:   */   {
/* 32:63 */     return Double.parseDouble(fnum.format(price));
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.PriceUtil
 * JD-Core Version:    0.7.0.1
 */