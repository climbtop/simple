/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.alibaba.fastjson.JSONObject;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.LinkedHashMap;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.Set;
/*  13:    */ 
/*  14:    */ @Deprecated
/*  15:    */ public class MapUtil
/*  16:    */ {
/*  17:    */   public static Object[] convertToArray(Map map)
/*  18:    */   {
/*  19: 29 */     int size = map.keySet().size();
/*  20: 30 */     if (size > 0)
/*  21:    */     {
/*  22: 31 */       Iterator it = map.keySet().iterator();
/*  23: 32 */       Object[] objArray = new Object[size * 2];
/*  24: 33 */       int i = 0;
/*  25: 34 */       while (it.hasNext())
/*  26:    */       {
/*  27: 35 */         Object key = it.next();
/*  28: 36 */         objArray[i] = key;
/*  29: 37 */         objArray[(i + 1)] = map.get(key);
/*  30: 38 */         i += 2;
/*  31:    */       }
/*  32: 40 */       return objArray;
/*  33:    */     }
/*  34: 42 */     return null;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static String[] convertToStringArray(Map map)
/*  38:    */   {
/*  39: 51 */     int size = map.keySet().size();
/*  40: 52 */     if (size > 0)
/*  41:    */     {
/*  42: 53 */       Iterator it = map.keySet().iterator();
/*  43: 54 */       String[] objArray = new String[size * 2];
/*  44: 55 */       int i = 0;
/*  45: 56 */       while (it.hasNext())
/*  46:    */       {
/*  47: 57 */         Object key = it.next();
/*  48: 58 */         objArray[i] = key.toString();
/*  49: 59 */         if (null != map.get(key)) {
/*  50: 60 */           objArray[(i + 1)] = map.get(key).toString();
/*  51:    */         } else {
/*  52: 62 */           objArray[(i + 1)] = "";
/*  53:    */         }
/*  54: 64 */         i += 2;
/*  55:    */       }
/*  56: 66 */       return objArray;
/*  57:    */     }
/*  58: 68 */     return null;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static Map<String, Object> groupList(List<Map<String, Object>> list, String key)
/*  62:    */   {
/*  63: 77 */     Map<String, Object> resultMap = new LinkedHashMap();
/*  64: 78 */     for (Map<String, Object> map : list)
/*  65:    */     {
/*  66: 79 */       String mapKey = String.valueOf(map.get(key));
/*  67: 80 */       if (!resultMap.containsKey(mapKey)) {
/*  68: 81 */         resultMap.put(mapKey, new ArrayList());
/*  69:    */       }
/*  70: 83 */       ((List)resultMap.get(mapKey)).add(map);
/*  71:    */     }
/*  72: 86 */     return resultMap;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static Map<String, Object> convertToMap(List list, String key)
/*  76:    */     throws Exception
/*  77:    */   {
/*  78: 97 */     Map<String, Object> resultMap = new LinkedHashMap();
/*  79: 98 */     for (Object object : list)
/*  80:    */     {
/*  81: 99 */       Class clz = object.getClass();
/*  82:100 */       Method m = clz.getMethod("get" + 
/*  83:101 */         getMethodName(key), new Class[0]);
/*  84:    */       
/*  85:103 */       String mapKey = String.valueOf(m.invoke(object, new Object[0]));
/*  86:    */       
/*  87:105 */       resultMap.put(mapKey, object);
/*  88:    */     }
/*  89:108 */     return resultMap;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static List<Map<String, Object>> convertToList(Map<String, Object> map)
/*  93:    */   {
/*  94:117 */     List<Map<String, Object>> resultList = new ArrayList();
/*  95:118 */     for (Map.Entry<String, Object> entry : map.entrySet())
/*  96:    */     {
/*  97:119 */       Map<String, Object> tmpMap = new HashMap();
/*  98:120 */       tmpMap.put(entry.getKey(), entry.getValue());
/*  99:121 */       resultList.add(tmpMap);
/* 100:    */     }
/* 101:124 */     return resultList;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static Map<String, Object> transferFromObject(Object object)
/* 105:    */     throws Exception
/* 106:    */   {
/* 107:134 */     return (Map)JSONObject.toJavaObject((JSONObject)JSONObject.toJSON(object), Map.class);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static Map<String, Object> asMap(Object... pros)
/* 111:    */   {
/* 112:145 */     Map<String, Object> properties = new HashMap();
/* 113:146 */     if (pros.length % 2 == 1) {
/* 114:147 */       throw new IllegalArgumentException("参数个数必须是偶数个！ ");
/* 115:    */     }
/* 116:149 */     int index = 0;
/* 117:150 */     String name = null;
/* 118:151 */     for (Object s : pros)
/* 119:    */     {
/* 120:152 */       if (index % 2 == 0)
/* 121:    */       {
/* 122:153 */         if ((s == null) || (StringUtil.isNullOrBlank(s.toString()))) {
/* 123:154 */           throw new IllegalArgumentException("字段名称不能为空！ ");
/* 124:    */         }
/* 125:155 */         name = s.toString();
/* 126:    */       }
/* 127:    */       else
/* 128:    */       {
/* 129:157 */         properties.put(name, s);
/* 130:    */       }
/* 131:159 */       index++;
/* 132:    */     }
/* 133:162 */     return properties;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static <T extends Map> T createMap(T properties, Object... params)
/* 137:    */   {
/* 138:172 */     if (params.length % 2 == 1) {
/* 139:173 */       throw new IllegalArgumentException("参数个数必须是偶数个！ ");
/* 140:    */     }
/* 141:175 */     int index = 0;
/* 142:176 */     Object name = null;
/* 143:177 */     for (Object s : params)
/* 144:    */     {
/* 145:178 */       if (index % 2 == 0)
/* 146:    */       {
/* 147:179 */         if ((s == null) || (StringUtil.isNullOrBlank(s.toString()))) {
/* 148:180 */           throw new IllegalArgumentException("字段名称不能为空！ ");
/* 149:    */         }
/* 150:181 */         name = s;
/* 151:    */       }
/* 152:    */       else
/* 153:    */       {
/* 154:183 */         properties.put(name, s);
/* 155:    */       }
/* 156:185 */       index++;
/* 157:    */     }
/* 158:188 */     return properties;
/* 159:    */   }
/* 160:    */   
/* 161:    */   private static String getMethodName(String fildeName)
/* 162:    */     throws Exception
/* 163:    */   {
/* 164:198 */     byte[] items = fildeName.getBytes();
/* 165:199 */     items[0] = ((byte)((char)items[0] - 'a' + 65));
/* 166:200 */     return new String(items);
/* 167:    */   }
/* 168:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.MapUtil
 * JD-Core Version:    0.7.0.1
 */