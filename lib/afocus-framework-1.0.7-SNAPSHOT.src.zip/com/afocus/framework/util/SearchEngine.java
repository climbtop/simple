/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.util.SortedMap;
/*   4:    */ import java.util.TreeMap;
/*   5:    */ import java.util.regex.Matcher;
/*   6:    */ import java.util.regex.Pattern;
/*   7:    */ import org.apache.log4j.Logger;
/*   8:    */ 
/*   9:    */ public class SearchEngine
/*  10:    */ {
/*  11: 21 */   public static Logger logger = Logger.getLogger(SearchEngine.class);
/*  12: 23 */   private static final SortedMap<String, String> keywordRegMap = new TreeMap();
/*  13:    */   
/*  14:    */   static
/*  15:    */   {
/*  16: 26 */     keywordRegMap.put("google", "([?|&])(q|query)=([^&]*)");
/*  17: 27 */     keywordRegMap.put("baidu", "([?|&])(word|wd|w)=([^&]*)");
/*  18: 28 */     keywordRegMap.put("yahoo", "([?|&])(q|p)=([^&]*)");
/*  19: 29 */     keywordRegMap.put("360sou", "([?|&])(q)=([^&]*)");
/*  20: 30 */     keywordRegMap.put("soso", "([?|&])(w)=([^&]*)");
/*  21: 31 */     keywordRegMap.put("bing", "([?|&])(q)=([^&]*)");
/*  22: 32 */     keywordRegMap.put("sogou", "([?|&])(query)=([^&]*)");
/*  23: 33 */     keywordRegMap.put("youdao", "([?|&])(q)=([^&]*)");
/*  24: 34 */     keywordRegMap.put("zhongsou", "([?|&])(w)=([^&]*)");
/*  25: 35 */     keywordRegMap.put("gougou", "([?|&])(search)=([^&]*)");
/*  26: 36 */     keywordRegMap.put("so.39.net", "([?|&])(words)=([^&]*)");
/*  27: 37 */     keywordRegMap.put("so.360.cn", "([?|&])(q)=([^&]*)");
/*  28: 38 */     keywordRegMap.put("www.so.com", "([?|&])(q)=([^&]*)");
/*  29: 39 */     keywordRegMap.put("www.qihoo.com", "([?|&])(kw)=([^&]*)");
/*  30: 40 */     keywordRegMap.put("jike", "([?|&])(q)=([^&]*)");
/*  31:    */   }
/*  32:    */   
/*  33: 43 */   private static String SE_REG = "http(.+?)(\\.google\\.|\\.baidu\\.com|\\.yahoo\\.|\\.360sou\\.|\\.soso\\.com|\\.bing\\.com|www\\.sogou\\.com|\\.youdao\\.com|\\.zhongsou\\.com|\\.gougou\\.com|so\\.39\\.net|so\\.360\\.cn|www\\.so\\.com|www\\.qihoo\\.com|\\.jike\\.com)";
/*  34:    */   
/*  35:    */   public static String getSearchEngineByPattern(String url)
/*  36:    */   {
/*  37: 53 */     String content = "";
/*  38: 55 */     if (!StringUtil.isEmpty(url))
/*  39:    */     {
/*  40: 57 */       if (url.indexOf("http://") != 0) {
/*  41: 58 */         url = "http://" + url;
/*  42:    */       }
/*  43: 60 */       Matcher matcher = StringUtil.getMatcherGroup(url, SE_REG);
/*  44: 61 */       while (matcher.find()) {
/*  45: 62 */         content = matcher.group(2);
/*  46:    */       }
/*  47:    */     }
/*  48: 66 */     if ((!content.equals("so.39.net")) && (!content.equals("so.360.cn")) && (!content.equals("www.so.com")) && (!content.equals("www.jike.com")) && (!content.equals("www.qihoo.com")))
/*  49:    */     {
/*  50: 67 */       content = content.replaceAll("\\.(com|cn|ca|de)", "");
/*  51: 68 */       content = content.replaceAll("www\\.", "");
/*  52: 69 */       content = content.replaceAll("\\.", "");
/*  53:    */     }
/*  54: 72 */     return content;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static String getKeyword(String url)
/*  58:    */   {
/*  59: 83 */     if (StringUtil.isEmpty(url)) {
/*  60: 84 */       return "";
/*  61:    */     }
/*  62: 86 */     String keywordReg = "";
/*  63: 87 */     String engine = getSearchEngineByPattern(url);
/*  64: 88 */     if (!StringUtil.isEmpty(engine)) {
/*  65: 89 */       keywordReg = (String)keywordRegMap.get(engine);
/*  66:    */     }
/*  67: 91 */     if (StringUtil.isEmpty(keywordReg)) {
/*  68: 92 */       return "";
/*  69:    */     }
/*  70: 94 */     Matcher matcher = StringUtil.getMatcherGroup(url, keywordReg);
/*  71: 95 */     String keywordResult = "";
/*  72: 96 */     while (matcher.find()) {
/*  73: 97 */       keywordResult = matcher.group(3);
/*  74:    */     }
/*  75:100 */     return encodeKeyword(keywordResult, url);
/*  76:    */   }
/*  77:    */   
/*  78:    */   private static String encodeKeyword(String keywordResult, String url)
/*  79:    */   {
/*  80:105 */     if (StringUtil.isEmpty(keywordResult)) {
/*  81:106 */       return "";
/*  82:    */     }
/*  83:108 */     String encodeReg = "^(?:[\\x00-\\x7f]|[\\xfc-\\xff][\\x80-\\xbf]{5}|[\\xf8-\\xfb][\\x80-\\xbf]{4}|[\\xf0-\\xf7][\\x80-\\xbf]{3}|[\\xe0-\\xef][\\x80-\\xbf]{2}|[\\xc0-\\xdf][\\x80-\\xbf])+$";
/*  84:    */     
/*  85:110 */     Pattern encodePatt = Pattern.compile(encodeReg);
/*  86:111 */     String unescapeString = StringUtil.unescape(keywordResult);
/*  87:112 */     Matcher encodeMat = encodePatt.matcher(unescapeString);
/*  88:113 */     String encodeString = "gbk";
/*  89:114 */     if (encodeMat.matches()) {
/*  90:115 */       encodeString = "utf-8";
/*  91:    */     }
/*  92:    */     try
/*  93:    */     {
/*  94:118 */       keywordResult = UrlUtil.decode(keywordResult, encodeString);
/*  95:    */     }
/*  96:    */     catch (Exception e)
/*  97:    */     {
/*  98:121 */       keywordResult = UrlUtil.unescape(keywordResult);
/*  99:122 */       logger.error(keywordResult + "||" + url, e);
/* 100:    */     }
/* 101:125 */     return keywordResult;
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.SearchEngine
 * JD-Core Version:    0.7.0.1
 */