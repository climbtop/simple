/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.crypt.Blowfish;
/*   4:    */ import com.afocus.framework.web.HttpRequestUtil;
/*   5:    */ import com.afocus.framework.web.HttpResponseUtil;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Font;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.image.BufferedImage;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Random;
/*  16:    */ import javax.servlet.http.Cookie;
/*  17:    */ import javax.servlet.http.HttpServletRequest;
/*  18:    */ import javax.servlet.http.HttpServletResponse;
/*  19:    */ import org.apache.log4j.Logger;
/*  20:    */ 
/*  21:    */ public class VerifyCodeUtil
/*  22:    */ {
/*  23: 31 */   private static Logger log = Logger.getLogger(VerifyCodeUtil.class);
/*  24: 34 */   private static int maxUsed = 5;
/*  25: 36 */   private static int cacheSize = 20;
/*  26:    */   public static final String VERIFY_CODE_COOKIE = "VerifyCode";
/*  27: 43 */   private static Map<String, List<VerifyCode>> cacheIndex = Collections.synchronizedMap(new HashMap());
/*  28: 47 */   private static String[] letters = { "a", "b", "c", "d", "e", "f", "g", "h", "j", "k", "m", "n", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
/*  29: 48 */   private static String[] numbers = { "2", "3", "4", "5", "6", "7", "8", "9" };
/*  30: 50 */   private static Random rnd = new Random();
/*  31:    */   
/*  32:    */   public static VerifyCode decrypt(String encrypted)
/*  33:    */   {
/*  34: 58 */     return VerifyCode.decrypt(encrypted);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void setVerifyCodeCookie(VerifyCode code, HttpServletResponse response, String cookieName, String domain)
/*  38:    */   {
/*  39: 69 */     HttpResponseUtil.setCookie(response, cookieName, code.toEncryptedString(), domain);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static void setVerifyCodeCookie(VerifyCode code, HttpServletResponse response, String cookieName)
/*  43:    */   {
/*  44: 79 */     HttpResponseUtil.setCookie(response, cookieName, code.toEncryptedString());
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static void setVerifyCodeCookie(VerifyCode code, HttpServletResponse response)
/*  48:    */   {
/*  49: 87 */     HttpResponseUtil.setCookie(response, "VerifyCode", code.toEncryptedString());
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static boolean verifyCookie(HttpServletRequest request, String verifyCodeFormName, String cookieName)
/*  53:    */   {
/*  54: 98 */     Cookie cookie = HttpRequestUtil.getCookie(request, cookieName);
/*  55: 99 */     if (cookie == null) {
/*  56:100 */       return false;
/*  57:    */     }
/*  58:101 */     return verify(cookie.getValue(), HttpRequestUtil.getParameter(request, verifyCodeFormName));
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static boolean verifyCookie(HttpServletRequest request, String verifyCodeFormName)
/*  62:    */   {
/*  63:111 */     return verifyCookie(request, verifyCodeFormName, "VerifyCode");
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static boolean verify(String encrypted, String input)
/*  67:    */   {
/*  68:121 */     return VerifyCode.verify(encrypted, input);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static VerifyCode getMobileVerifyCodeFromCache()
/*  72:    */   {
/*  73:129 */     return getMobileVerifyCodeFromCache(8);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static VerifyCode getMobileVerifyCodeFromCache(int wordCount)
/*  77:    */   {
/*  78:138 */     String key = "mobile_" + wordCount;
/*  79:139 */     VerifyCode ret = getCachedVerifyCode(key);
/*  80:140 */     if (ret == null)
/*  81:    */     {
/*  82:141 */       ret = createVerifyCode(wordCount, true, -1L);
/*  83:142 */       putVerifyCodeCache(key, ret);
/*  84:    */     }
/*  85:144 */     else if (ret.getUsed() > maxUsed)
/*  86:    */     {
/*  87:145 */       ret.code = getRandomCode(wordCount, true);
/*  88:146 */       ret.resetUsed();
/*  89:    */     }
/*  90:    */     else
/*  91:    */     {
/*  92:149 */       ret.addUsed();
/*  93:    */     }
/*  94:150 */     return ret;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static VerifyCode createMobileVerifyCode()
/*  98:    */   {
/*  99:158 */     return createVerifyCode(8, true, -1L);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static VerifyCode createMobileVerifyCode(int wordCount)
/* 103:    */   {
/* 104:167 */     return createVerifyCode(wordCount, true, -1L);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static VerifyCode getVerifyCodeFromCache()
/* 108:    */   {
/* 109:177 */     return getVerifyCodeFromCache(4, 50, 20, "Arial", 16, -1L);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static VerifyCode getVerifyCodeFromCache(int wordCount, int fontSize, long expire)
/* 113:    */   {
/* 114:189 */     return getVerifyCodeFromCache(wordCount, wordCount * fontSize, fontSize + 4, "Arial", fontSize, expire);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static VerifyCode getVerifyCodeFromCache(int wordCount, int width, int height, int fontSize, long expire)
/* 118:    */   {
/* 119:203 */     return getVerifyCodeFromCache(wordCount, width, height, "Arial", fontSize, expire);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static VerifyCode getVerifyCodeFromCache(int wordCount, int width, int height, String fontName, int fontSize, long expire)
/* 123:    */   {
/* 124:217 */     String key = "imageCode_" + width + "x" + height;
/* 125:218 */     VerifyCode ret = getCachedVerifyCode(key);
/* 126:219 */     if ((ret != null) && (ret.getUsed() < maxUsed))
/* 127:    */     {
/* 128:220 */       ret.addUsed();
/* 129:221 */       return ret;
/* 130:    */     }
/* 131:223 */     if ((ret != null) && (ret.used > maxUsed))
/* 132:    */     {
/* 133:224 */       ret.code = getRandomCode(wordCount, false);
/* 134:225 */       ret.resetUsed();
/* 135:    */     }
/* 136:    */     else
/* 137:    */     {
/* 138:228 */       ret = createVerifyCode(wordCount, false, expire);
/* 139:229 */       putVerifyCodeCache(key, ret);
/* 140:    */     }
/* 141:231 */     ret.image = createVerifyImage(ret.code, width, height, new Font(fontName, 1, fontSize));
/* 142:232 */     return ret;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static VerifyCode createVerifyCode()
/* 146:    */   {
/* 147:241 */     return createVerifyCode(4, 50, 20, "Arial", 16, -1L);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static VerifyCode createVerifyCode(int wordCount, int fontSize, long expire)
/* 151:    */   {
/* 152:252 */     return createVerifyCode(wordCount, wordCount * fontSize, fontSize + 4, "Arial", fontSize, expire);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static VerifyCode createVerifyCode(int wordCount, int width, int height, int fontSize, long expire)
/* 156:    */   {
/* 157:265 */     return createVerifyCode(wordCount, width, height, "Arial", fontSize, expire);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static VerifyCode createVerifyCode(int wordCount, int width, int height, String fontName, int fontSize, long expire)
/* 161:    */   {
/* 162:279 */     VerifyCode ret = createVerifyCode(wordCount, false, expire);
/* 163:280 */     ret.image = createVerifyImage(ret.code, width, height, new Font(fontName, 1, fontSize));
/* 164:281 */     return ret;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static VerifyCode createVerifyCode(int wordCount, boolean number, long expire)
/* 168:    */   {
/* 169:292 */     VerifyCode ret = new VerifyCode();
/* 170:293 */     ret.code = getRandomCode(wordCount, number);
/* 171:294 */     ret.expire = expire;
/* 172:295 */     return ret;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static String getRandomCode(int wordCount, boolean number)
/* 176:    */   {
/* 177:305 */     StringBuilder sb = new StringBuilder();
/* 178:306 */     int rndNum = 100;
/* 179:308 */     for (int i = 0; i < wordCount; i++) {
/* 180:309 */       if ((!number) && (rnd.nextInt(100) % 2 == 0))
/* 181:    */       {
/* 182:310 */         String c = letters[rnd.nextInt(letters.length)];
/* 183:311 */         sb.append(rnd.nextInt(100) % 2 == 0 ? c : c.toUpperCase());
/* 184:    */       }
/* 185:    */       else
/* 186:    */       {
/* 187:314 */         sb.append(numbers[rnd.nextInt(numbers.length)]);
/* 188:    */       }
/* 189:    */     }
/* 190:317 */     return sb.toString();
/* 191:    */   }
/* 192:    */   
/* 193:    */   private static BufferedImage createVerifyImage(String text, int imgWidth, int imgHeight, Font font)
/* 194:    */   {
/* 195:329 */     long s = System.currentTimeMillis();
/* 196:    */     
/* 197:331 */     int disturbLine = 3;
/* 198:332 */     int rndNum = 100;
/* 199:    */     
/* 200:334 */     int fontLeftSpace = 2;
/* 201:335 */     int fontTopSpace = 1;
/* 202:    */     
/* 203:337 */     int wordCount = text.length();
/* 204:    */     
/* 205:    */ 
/* 206:340 */     BufferedImage image = new BufferedImage(imgWidth, imgHeight, 1);
/* 207:    */     
/* 208:    */ 
/* 209:343 */     Graphics g = image.getGraphics();
/* 210:344 */     g.setColor(getRandomColor(200, 250));
/* 211:    */     
/* 212:346 */     g.fillRect(0, 0, imgWidth, imgHeight);
/* 213:349 */     for (int i = 0; i < disturbLine; i++)
/* 214:    */     {
/* 215:350 */       int x1 = rnd.nextInt(imgWidth - 1);
/* 216:351 */       int y1 = rnd.nextInt(imgHeight - 1);
/* 217:352 */       int x2 = rnd.nextInt(imgWidth - 1);
/* 218:353 */       int y2 = rnd.nextInt(imgHeight - 1);
/* 219:354 */       g.setColor(getRandomColor(10, 90));
/* 220:355 */       g.drawLine(x1, y1, x2, y2);
/* 221:    */     }
/* 222:359 */     g.setFont(font);
/* 223:    */     
/* 224:    */ 
/* 225:362 */     int fontSpace = imgWidth / wordCount;
/* 226:363 */     int randomFontSpace = fontSpace;
/* 227:    */     
/* 228:365 */     int fontHeight = font.getSize();
/* 229:    */     
/* 230:367 */     int fontLeft = fontSpace / wordCount;
/* 231:    */     
/* 232:369 */     int fontLocal = 0;
/* 233:371 */     for (int i = 0; i < wordCount; i++)
/* 234:    */     {
/* 235:372 */       if (rnd.nextInt(rndNum) % 2 == 0)
/* 236:    */       {
/* 237:373 */         randomFontSpace = fontSpace + rnd.nextInt(fontTopSpace);
/* 238:374 */         fontLocal = i * randomFontSpace + fontLeft + rnd.nextInt(fontLeftSpace);
/* 239:375 */         fontHeight += rnd.nextInt(fontTopSpace);
/* 240:    */       }
/* 241:    */       else
/* 242:    */       {
/* 243:377 */         randomFontSpace = fontSpace - rnd.nextInt(fontTopSpace);
/* 244:378 */         fontLocal = i * randomFontSpace + fontLeft - rnd.nextInt(fontLeftSpace);
/* 245:379 */         fontHeight -= rnd.nextInt(fontTopSpace);
/* 246:    */       }
/* 247:381 */       g.setColor(getRandomColor(0, 150));
/* 248:382 */       g.drawString(String.valueOf(text.charAt(i)), fontLocal, fontHeight);
/* 249:    */     }
/* 250:385 */     g.dispose();
/* 251:386 */     log.debug("createVerifyCode cost:" + (System.currentTimeMillis() - s) + "ms ");
/* 252:387 */     return image;
/* 253:    */   }
/* 254:    */   
/* 255:    */   private static Color getRandomColor(int fc, int bc)
/* 256:    */   {
/* 257:391 */     fc = fc > 255 ? 255 : fc;
/* 258:392 */     bc = bc > 255 ? 255 : bc;
/* 259:    */     
/* 260:394 */     int r = fc + rnd.nextInt(bc - fc);
/* 261:395 */     int g = fc + rnd.nextInt(bc - fc);
/* 262:396 */     int b = fc + rnd.nextInt(bc - fc);
/* 263:397 */     return new Color(r, g, b);
/* 264:    */   }
/* 265:    */   
/* 266:    */   private static VerifyCode getCachedVerifyCode(String key)
/* 267:    */   {
/* 268:402 */     int index = rnd.nextInt(cacheSize);
/* 269:    */     
/* 270:404 */     List<VerifyCode> cache = (List)cacheIndex.get(key);
/* 271:405 */     if (cache == null)
/* 272:    */     {
/* 273:406 */       cache = Collections.synchronizedList(new ArrayList(cacheSize));
/* 274:407 */       cacheIndex.put(key, cache);
/* 275:    */     }
/* 276:410 */     if (index < cache.size()) {
/* 277:411 */       return (VerifyCode)cache.get(index);
/* 278:    */     }
/* 279:413 */     return null;
/* 280:    */   }
/* 281:    */   
/* 282:    */   private static void putVerifyCodeCache(String key, VerifyCode code)
/* 283:    */   {
/* 284:417 */     List<VerifyCode> cache = (List)cacheIndex.get(key);
/* 285:418 */     if (cache == null)
/* 286:    */     {
/* 287:419 */       cache = Collections.synchronizedList(new ArrayList(cacheSize));
/* 288:420 */       cacheIndex.put(key, cache);
/* 289:    */     }
/* 290:422 */     cache.add(code);
/* 291:    */   }
/* 292:    */   
/* 293:    */   public static class VerifyCode
/* 294:    */   {
/* 295:453 */     private String code = "";
/* 296:454 */     private int used = 0;
/* 297:455 */     private BufferedImage image = null;
/* 298:456 */     private long stamp = System.currentTimeMillis();
/* 299:457 */     private long expire = -1L;
/* 300:    */     
/* 301:    */     public String getCode()
/* 302:    */     {
/* 303:464 */       return this.code;
/* 304:    */     }
/* 305:    */     
/* 306:    */     public synchronized int getUsed()
/* 307:    */     {
/* 308:471 */       return this.used;
/* 309:    */     }
/* 310:    */     
/* 311:    */     private synchronized void addUsed()
/* 312:    */     {
/* 313:475 */       this.used += 1;
/* 314:476 */       this.stamp = System.currentTimeMillis();
/* 315:    */     }
/* 316:    */     
/* 317:    */     private synchronized void resetUsed()
/* 318:    */     {
/* 319:480 */       this.used = 0;
/* 320:481 */       this.stamp = System.currentTimeMillis();
/* 321:    */     }
/* 322:    */     
/* 323:    */     public BufferedImage getImage()
/* 324:    */     {
/* 325:488 */       return this.image;
/* 326:    */     }
/* 327:    */     
/* 328:    */     public synchronized long getStamp()
/* 329:    */     {
/* 330:495 */       return this.stamp;
/* 331:    */     }
/* 332:    */     
/* 333:    */     public String toString()
/* 334:    */     {
/* 335:499 */       return this.code + "," + this.used + "," + this.stamp + "," + this.expire;
/* 336:    */     }
/* 337:    */     
/* 338:    */     public long getExpire()
/* 339:    */     {
/* 340:506 */       return this.expire;
/* 341:    */     }
/* 342:    */     
/* 343:    */     public String toEncryptedString()
/* 344:    */     {
/* 345:513 */       return Blowfish.encrypt(toString(), "encryptPassword");
/* 346:    */     }
/* 347:    */     
/* 348:    */     public static VerifyCode decrypt(String encrypted)
/* 349:    */     {
/* 350:522 */       VerifyCode ret = new VerifyCode();
/* 351:    */       try
/* 352:    */       {
/* 353:524 */         String[] p = Blowfish.decrypt(encrypted, "encryptPassword").split(",");
/* 354:525 */         ret.code = p[0];
/* 355:526 */         ret.used = Integer.parseInt(p[1]);
/* 356:527 */         ret.stamp = Long.parseLong(p[2]);
/* 357:528 */         ret.expire = Long.parseLong(p[3]);
/* 358:    */       }
/* 359:    */       catch (Exception e)
/* 360:    */       {
/* 361:530 */         VerifyCodeUtil.log.error("dencrypt VerifyCode error:" + e);
/* 362:531 */         e.printStackTrace();
/* 363:    */       }
/* 364:533 */       return ret;
/* 365:    */     }
/* 366:    */     
/* 367:    */     public static boolean verify(String encrypted, String input)
/* 368:    */     {
/* 369:543 */       if ((StringUtil.isEmpty(encrypted)) || (StringUtil.isEmpty(input))) {
/* 370:544 */         return false;
/* 371:    */       }
/* 372:545 */       VerifyCode code = decrypt(encrypted);
/* 373:546 */       VerifyCodeUtil.log.debug("input:" + input + ",code:" + code);
/* 374:547 */       if (!input.equalsIgnoreCase(code.code)) {
/* 375:548 */         return false;
/* 376:    */       }
/* 377:549 */       if (code.expire <= -1L) {
/* 378:550 */         return true;
/* 379:    */       }
/* 380:551 */       if (code.expire + code.stamp > System.currentTimeMillis()) {
/* 381:552 */         return true;
/* 382:    */       }
/* 383:553 */       return false;
/* 384:    */     }
/* 385:    */   }
/* 386:    */   
/* 387:    */   public static synchronized void setCacheSize(int cacheSize)
/* 388:    */   {
/* 389:563 */     cacheSize = cacheSize;
/* 390:    */   }
/* 391:    */   
/* 392:    */   public static synchronized void setMaxUsed(int maxUsed)
/* 393:    */   {
/* 394:572 */     maxUsed = maxUsed;
/* 395:    */   }
/* 396:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.VerifyCodeUtil
 * JD-Core Version:    0.7.0.1
 */