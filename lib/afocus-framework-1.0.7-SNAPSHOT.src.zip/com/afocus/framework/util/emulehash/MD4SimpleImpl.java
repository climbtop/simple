/*   1:    */ package com.afocus.framework.util.emulehash;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.crypt.MD4;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.PrintStream;
/*   6:    */ import java.io.RandomAccessFile;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ 
/*   9:    */ public class MD4SimpleImpl
/*  10:    */   implements IMD4
/*  11:    */ {
/*  12: 19 */   private final int MD4_PARTSIZE = 9728000;
/*  13: 21 */   private final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*  14:    */   
/*  15:    */   private String hexToString(byte[] ba)
/*  16:    */   {
/*  17: 27 */     int length = ba.length;
/*  18: 28 */     char[] buf = new char[length * 2];
/*  19: 29 */     int i = 0;
/*  20: 29 */     for (int j = 0; i < length;)
/*  21:    */     {
/*  22: 31 */       int k = ba[(i++)];
/*  23: 32 */       buf[(j++)] = this.HEX_DIGITS[(k >>> 4 & 0xF)];
/*  24: 33 */       buf[(j++)] = this.HEX_DIGITS[(k & 0xF)];
/*  25:    */     }
/*  26: 35 */     return new String(buf);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public MD4SimpleImpl()
/*  30:    */   {
/*  31: 40 */     System.out.println("MD4SimpleImpl inited");
/*  32:    */   }
/*  33:    */   
/*  34:    */   public String add(String fileForMD4)
/*  35:    */     throws Exception
/*  36:    */   {
/*  37: 44 */     return addFile(fileForMD4);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String addFile(String fileForMD4)
/*  41:    */     throws Exception
/*  42:    */   {
/*  43: 48 */     File file = new File(fileForMD4);
/*  44: 49 */     return addFile(file);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String addFile(File file)
/*  48:    */     throws Exception
/*  49:    */   {
/*  50: 53 */     long fileLen = file.length();
/*  51: 54 */     if (fileLen == 0L) {
/*  52: 55 */       throw new Exception(file.getName() + " can't be empty!");
/*  53:    */     }
/*  54: 57 */     ArrayList<byte[]> al = new ArrayList();
/*  55: 58 */     getClass();byte[] temp = new byte[9728000];
/*  56: 59 */     RandomAccessFile raf = new RandomAccessFile(file, "r");
/*  57:    */     
/*  58: 61 */     long left = fileLen;
/*  59:    */     for (;;)
/*  60:    */     {
/*  61: 62 */       getClass();
/*  62: 62 */       if (left < 9728000L) {
/*  63:    */         break;
/*  64:    */       }
/*  65: 63 */       getClass();raf.readFully(temp, 0, 9728000);
/*  66: 64 */       getClass();left -= 9728000L;
/*  67: 65 */       byte[] part = MD4.digest(temp);
/*  68: 66 */       al.add(part);
/*  69:    */     }
/*  70: 68 */     if (left == 0L)
/*  71:    */     {
/*  72: 69 */       byte[] part = MD4.digest("".getBytes());
/*  73: 70 */       al.add(part);
/*  74:    */     }
/*  75:    */     else
/*  76:    */     {
/*  77: 71 */       getClass();
/*  78: 71 */       if (left < 9728000L)
/*  79:    */       {
/*  80: 72 */         int k = Integer.parseInt(String.valueOf(left));
/*  81: 73 */         temp = new byte[k];
/*  82: 74 */         raf.readFully(temp, 0, k);
/*  83: 75 */         byte[] part = MD4.digest(temp);
/*  84: 76 */         al.add(part);
/*  85:    */       }
/*  86:    */     }
/*  87: 78 */     raf.close();
/*  88:    */     
/*  89: 80 */     byte[] last = new byte[16 * al.size()];
/*  90: 81 */     for (int i = 0; i < al.size(); i++)
/*  91:    */     {
/*  92: 82 */       byte[] soruce = (byte[])al.get(i);
/*  93: 83 */       System.arraycopy(soruce, 0, last, i * 16, 16);
/*  94:    */     }
/*  95: 86 */     getClass();
/*  96: 86 */     if (fileLen < 9728000L) {
/*  97: 87 */       return hexToString(last);
/*  98:    */     }
/*  99: 89 */     return hexToString(MD4.digest(last));
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String addURL(String url)
/* 103:    */     throws Exception
/* 104:    */   {
/* 105: 97 */     if ((url == null) || (url.length() == 0)) {
/* 106: 98 */       throw new Exception("url can't be empty!");
/* 107:    */     }
/* 108: 99 */     byte[] bytes = url.getBytes();
/* 109:100 */     byte[] part = MD4.digest(bytes);
/* 110:101 */     return hexToString(part);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static void main(String[] args) {}
/* 114:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.emulehash.MD4SimpleImpl
 * JD-Core Version:    0.7.0.1
 */