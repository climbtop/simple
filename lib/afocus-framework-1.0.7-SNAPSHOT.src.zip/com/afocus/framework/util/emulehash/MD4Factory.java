/*  1:   */ package com.afocus.framework.util.emulehash;
/*  2:   */ 
/*  3:   */ public class MD4Factory
/*  4:   */ {
/*  5: 5 */   private static IMD4 md4 = null;
/*  6:   */   
/*  7:   */   public static synchronized IMD4 getInstance()
/*  8:   */     throws Exception
/*  9:   */   {
/* 10: 8 */     if (md4 == null) {
/* 11: 9 */       md4 = new MD4SimpleImpl();
/* 12:   */     }
/* 13:11 */     return md4;
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.emulehash.MD4Factory
 * JD-Core Version:    0.7.0.1
 */