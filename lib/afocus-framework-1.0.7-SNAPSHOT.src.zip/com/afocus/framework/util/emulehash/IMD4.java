package com.afocus.framework.util.emulehash;

import java.io.File;

public abstract interface IMD4
{
  public abstract String add(String paramString)
    throws Exception;
  
  public abstract String addFile(String paramString)
    throws Exception;
  
  public abstract String addFile(File paramFile)
    throws Exception;
  
  public abstract String addURL(String paramString)
    throws Exception;
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.emulehash.IMD4
 * JD-Core Version:    0.7.0.1
 */