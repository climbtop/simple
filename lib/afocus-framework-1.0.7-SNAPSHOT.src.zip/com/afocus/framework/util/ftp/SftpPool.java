/*   1:    */ package com.afocus.framework.util.ftp;
/*   2:    */ 
/*   3:    */ import com.jcraft.jsch.ChannelSftp;
/*   4:    */ import com.jcraft.jsch.JSch;
/*   5:    */ import com.jcraft.jsch.JSchException;
/*   6:    */ import com.jcraft.jsch.Session;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.util.HashMap;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.Properties;
/*  13:    */ import java.util.ResourceBundle;
/*  14:    */ import java.util.Set;
/*  15:    */ import org.slf4j.Logger;
/*  16:    */ import org.slf4j.LoggerFactory;
/*  17:    */ 
/*  18:    */ public class SftpPool
/*  19:    */ {
/*  20: 26 */   private String configPath = "ftp-config";
/*  21:    */   private String host;
/*  22:    */   private int port;
/*  23:    */   private String userName;
/*  24:    */   private String password;
/*  25:    */   private int timeout;
/*  26:    */   private Map<ChannelSftp, Boolean> connectionPool;
/*  27:    */   private static final boolean AVAILABLE = false;
/*  28:    */   private static final boolean NOTAVAILABLE = true;
/*  29: 46 */   private int initSize = 1;
/*  30: 48 */   private int activeSize = 1;
/*  31: 50 */   private int maxSize = 5;
/*  32:    */   private Session session;
/*  33: 54 */   private int reTryNumber = 5;
/*  34: 56 */   private int reTryInterval = 3;
/*  35: 59 */   private final Logger log = LoggerFactory.getLogger(SftpPool.class);
/*  36:    */   
/*  37:    */   public SftpPool()
/*  38:    */   {
/*  39: 62 */     init();
/*  40:    */   }
/*  41:    */   
/*  42:    */   private void setCongfig()
/*  43:    */   {
/*  44: 66 */     this.log.debug("获取SFTP连接池的配置参数...");
/*  45: 67 */     ResourceBundle commonBundle = ResourceBundle.getBundle(this.configPath);
/*  46: 68 */     this.host = commonBundle.getString("sftp.host");
/*  47: 69 */     this.port = Integer.valueOf(commonBundle.getString("sftp.port")).intValue();
/*  48:    */     
/*  49: 71 */     this.userName = commonBundle.getString("sftp.account");
/*  50: 72 */     this.password = commonBundle.getString("sftp.password");
/*  51: 73 */     this.timeout = Integer.valueOf(commonBundle.getString("sftp.timeout").trim()).intValue();
/*  52:    */     
/*  53: 75 */     this.initSize = Integer.valueOf(commonBundle.getString("sftp.initSize")).intValue();
/*  54: 76 */     this.activeSize = Integer.valueOf(commonBundle.getString("sftp.activeSize")).intValue();
/*  55: 77 */     this.maxSize = Integer.valueOf(commonBundle.getString("sftp.maxSize")).intValue();
/*  56: 78 */     this.reTryNumber = Integer.valueOf(commonBundle.getString("sftp.reTryNumber")).intValue();
/*  57: 79 */     this.reTryInterval = Integer.valueOf(commonBundle.getString("sftp.reTryInterval")).intValue();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public SftpPool(String configPath)
/*  61:    */   {
/*  62: 83 */     this.configPath = configPath;
/*  63: 84 */     init();
/*  64:    */   }
/*  65:    */   
/*  66:    */   private void init()
/*  67:    */   {
/*  68: 93 */     if (null == this.connectionPool)
/*  69:    */     {
/*  70: 94 */       setCongfig();
/*  71: 95 */       this.log.debug("开始初始化SFTP连接池...");
/*  72:    */       
/*  73: 97 */       this.connectionPool = new HashMap();
/*  74:    */       try
/*  75:    */       {
/*  76: 99 */         openNewSession();
/*  77:100 */         if ((null != this.session) || (this.session.isConnected())) {
/*  78:101 */           for (int i = 0; i < this.initSize; i++)
/*  79:    */           {
/*  80:102 */             ChannelSftp channel = openNewChannel();
/*  81:103 */             this.connectionPool.put(channel, Boolean.valueOf(false));
/*  82:105 */             if (this.log.isDebugEnabled()) {
/*  83:106 */               this.log.debug("SFTP连接池当前数量：" + this.connectionPool.keySet().size());
/*  84:    */             }
/*  85:    */           }
/*  86:    */         }
/*  87:    */       }
/*  88:    */       catch (JSchException e)
/*  89:    */       {
/*  90:111 */         this.connectionPool = null;
/*  91:112 */         this.log.error("初始化SFTP连接池失败！", e);
/*  92:    */       }
/*  93:    */       catch (IOException e)
/*  94:    */       {
/*  95:114 */         this.connectionPool = null;
/*  96:115 */         this.log.error("初始化SFTP连接池失败！", e);
/*  97:    */       }
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private synchronized void openNewSession()
/* 102:    */     throws JSchException
/* 103:    */   {
/* 104:129 */     if ((null == this.session) || (!this.session.isConnected()))
/* 105:    */     {
/* 106:130 */       int n = this.reTryNumber;
/* 107:131 */       while (((null == this.session) || (!this.session.isConnected())) && (n > 0))
/* 108:    */       {
/* 109:    */         try
/* 110:    */         {
/* 111:133 */           this.session = createSession();
/* 112:134 */           if (this.log.isDebugEnabled()) {
/* 113:135 */             this.log.debug("打开会话：" + this.session);
/* 114:    */           }
/* 115:    */         }
/* 116:    */         catch (JSchException e1)
/* 117:    */         {
/* 118:138 */           this.log.debug("打开会话失败，等待重试！", e1);
/* 119:    */         }
/* 120:    */         catch (IOException e1)
/* 121:    */         {
/* 122:140 */           this.log.debug("打开会话失败，等待重试！", e1);
/* 123:    */         }
/* 124:142 */         if ((null == this.session) || (!this.session.isConnected()))
/* 125:    */         {
/* 126:143 */           this.log.debug("打开会话失败，等待重试！");
/* 127:144 */           n--;
/* 128:    */           try
/* 129:    */           {
/* 130:146 */             Thread.sleep(this.reTryInterval * 1000);
/* 131:    */           }
/* 132:    */           catch (InterruptedException e)
/* 133:    */           {
/* 134:148 */             this.log.error("执行等待时间异常！", e);
/* 135:    */           }
/* 136:    */         }
/* 137:    */       }
/* 138:152 */       if ((null == this.session) || (!this.session.isConnected()))
/* 139:    */       {
/* 140:153 */         this.log.debug("重试" + this.reTryNumber + "次打开会话失败，放弃打开会话。");
/* 141:154 */         throw new JSchException("无法建立SFTP会话，请检查连接参数是否正确！");
/* 142:    */       }
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Session createSession()
/* 147:    */     throws JSchException, IOException
/* 148:    */   {
/* 149:169 */     JSch jsch = new JSch();
/* 150:170 */     Session session = jsch.getSession(this.userName, this.host, this.port);
/* 151:171 */     if (this.password != null) {
/* 152:172 */       session.setPassword(this.password);
/* 153:    */     }
/* 154:174 */     this.log.debug("ftp createSession,userName:" + this.userName + ",host:" + this.host + ",port:" + this.port + ",password:" + this.password);
/* 155:175 */     Properties config = new Properties();
/* 156:176 */     config.put("StrictHostKeyChecking", "no");
/* 157:177 */     session.setConfig(config);
/* 158:178 */     session.setTimeout(this.timeout);
/* 159:179 */     session.connect();
/* 160:180 */     return session;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public ChannelSftp openNewChannel()
/* 164:    */     throws JSchException, IOException
/* 165:    */   {
/* 166:194 */     ChannelSftp channel = null;
/* 167:195 */     if ((null == this.session) || (!this.session.isConnected())) {
/* 168:196 */       openNewSession();
/* 169:    */     }
/* 170:198 */     if ((null != this.session) && (this.session.isConnected()))
/* 171:    */     {
/* 172:199 */       channel = checkChannelSftp(null);
/* 173:200 */       if (this.log.isDebugEnabled()) {
/* 174:201 */         this.log.debug("打开通道：" + channel);
/* 175:    */       }
/* 176:    */     }
/* 177:205 */     return channel;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public ChannelSftp checkChannelSftp(ChannelSftp sftp)
/* 181:    */     throws JSchException
/* 182:    */   {
/* 183:218 */     boolean isNotConnection = (null == sftp) || (sftp.isClosed());
/* 184:219 */     if (isNotConnection)
/* 185:    */     {
/* 186:220 */       int n = this.reTryNumber;
/* 187:221 */       while ((isNotConnection) && (n > 0))
/* 188:    */       {
/* 189:222 */         sftp = (ChannelSftp)this.session.openChannel("sftp");
/* 190:223 */         isNotConnection = (null == sftp) || (sftp.isClosed());
/* 191:224 */         if (isNotConnection)
/* 192:    */         {
/* 193:    */           try
/* 194:    */           {
/* 195:226 */             Thread.sleep(this.reTryInterval * 1000);
/* 196:    */           }
/* 197:    */           catch (InterruptedException e)
/* 198:    */           {
/* 199:228 */             this.log.error("执行等待时间异常！", e);
/* 200:    */           }
/* 201:230 */           n--;
/* 202:    */         }
/* 203:    */       }
/* 204:234 */       isNotConnection = (null == sftp) || (sftp.isClosed());
/* 205:235 */       if (isNotConnection) {
/* 206:236 */         this.log.error("重试" + this.reTryNumber + "次获取通道失败，放弃获取通道！");
/* 207:    */       } else {
/* 208:238 */         sftp.connect();
/* 209:    */       }
/* 210:    */     }
/* 211:241 */     return sftp;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public synchronized ChannelSftp getChannel()
/* 215:    */     throws JSchException
/* 216:    */   {
/* 217:253 */     ChannelSftp sftp = null;
/* 218:254 */     if (null == this.connectionPool) {
/* 219:255 */       init();
/* 220:    */     }
/* 221:257 */     if (null != this.connectionPool) {
/* 222:258 */       while (sftp == null)
/* 223:    */       {
/* 224:259 */         synchronized (this.connectionPool)
/* 225:    */         {
/* 226:260 */           Iterator<Map.Entry<ChannelSftp, Boolean>> iterator = this.connectionPool.entrySet().iterator();
/* 227:261 */           while (iterator.hasNext())
/* 228:    */           {
/* 229:262 */             Map.Entry<ChannelSftp, Boolean> entry = (Map.Entry)iterator.next();
/* 230:263 */             synchronized (entry)
/* 231:    */             {
/* 232:264 */               if (!((Boolean)entry.getValue()).booleanValue())
/* 233:    */               {
/* 234:265 */                 entry.setValue(Boolean.valueOf(true));
/* 235:266 */                 if (this.log.isDebugEnabled())
/* 236:    */                 {
/* 237:267 */                   this.log.debug("SFTP连接池取出：" + entry.getKey());
/* 238:268 */                   this.log.debug("SFTP连接池当前数量：" + this.connectionPool.keySet().size());
/* 239:    */                 }
/* 240:270 */                 sftp = (ChannelSftp)entry.getKey();
/* 241:271 */                 if ((null == sftp) || (sftp.isClosed()) || (!sftp.isConnected())) {
/* 242:272 */                   sftp = null;
/* 243:    */                 }
/* 244:274 */                 break;
/* 245:    */               }
/* 246:    */             }
/* 247:    */           }
/* 248:    */         }
/* 249:279 */         if (null == sftp)
/* 250:    */         {
/* 251:280 */           synchronized (this.connectionPool)
/* 252:    */           {
/* 253:281 */             if (this.maxSize > this.connectionPool.keySet().size()) {
/* 254:    */               try
/* 255:    */               {
/* 256:283 */                 sftp = openNewChannel();
/* 257:284 */                 synchronized (this.connectionPool)
/* 258:    */                 {
/* 259:285 */                   this.connectionPool.put(sftp, Boolean.valueOf(true));
/* 260:286 */                   if (this.log.isDebugEnabled())
/* 261:    */                   {
/* 262:287 */                     this.log.debug("SFTP连接池取出：" + sftp);
/* 263:288 */                     this.log.debug("SFTP连接池当前数量：" + this.connectionPool.keySet().size());
/* 264:    */                   }
/* 265:    */                 }
/* 266:    */               }
/* 267:    */               catch (JSchException e)
/* 268:    */               {
/* 269:292 */                 this.log.error("从SFTP连接池中获取通道失败！", e);
/* 270:    */               }
/* 271:    */               catch (IOException e)
/* 272:    */               {
/* 273:294 */                 this.log.error("从SFTP连接池中获取通道失败！", e);
/* 274:    */               }
/* 275:    */             }
/* 276:    */           }
/* 277:298 */           if (null == sftp) {
/* 278:    */             try
/* 279:    */             {
/* 280:300 */               Thread.sleep(this.reTryInterval * 1000);
/* 281:    */             }
/* 282:    */             catch (InterruptedException e)
/* 283:    */             {
/* 284:302 */               this.log.error("执行等待时间异常！", e);
/* 285:    */             }
/* 286:    */           }
/* 287:    */         }
/* 288:    */       }
/* 289:    */     }
/* 290:309 */     throw new JSchException("无法建立SFTP会话，请检查连接参数是否正确！");
/* 291:    */     
/* 292:311 */     return sftp;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public void closeChannel(ChannelSftp channel)
/* 296:    */   {
/* 297:322 */     if (null != channel) {
/* 298:323 */       synchronized (this.connectionPool)
/* 299:    */       {
/* 300:324 */         if (this.activeSize >= this.connectionPool.entrySet().size())
/* 301:    */         {
/* 302:325 */           Iterator<Map.Entry<ChannelSftp, Boolean>> iterator = this.connectionPool.entrySet().iterator();
/* 303:326 */           while (iterator.hasNext())
/* 304:    */           {
/* 305:327 */             Map.Entry<ChannelSftp, Boolean> entry = (Map.Entry)iterator.next();
/* 306:328 */             if (((ChannelSftp)entry.getKey()).equals(channel))
/* 307:    */             {
/* 308:329 */               if (this.log.isDebugEnabled()) {
/* 309:330 */                 this.log.debug("放入池取出：" + entry.getKey());
/* 310:    */               }
/* 311:332 */               entry.setValue(Boolean.valueOf(false));
/* 312:333 */               break;
/* 313:    */             }
/* 314:    */           }
/* 315:    */         }
/* 316:    */         else
/* 317:    */         {
/* 318:337 */           if (this.log.isDebugEnabled()) {
/* 319:338 */             this.log.debug("从SFTP连接池中移除：" + channel);
/* 320:    */           }
/* 321:340 */           if (channel.isConnected()) {
/* 322:341 */             channel.disconnect();
/* 323:    */           }
/* 324:342 */           if (!channel.isClosed()) {
/* 325:343 */             channel.exit();
/* 326:    */           }
/* 327:344 */           this.connectionPool.remove(channel);
/* 328:    */         }
/* 329:346 */         if (this.log.isDebugEnabled()) {
/* 330:347 */           this.log.debug("SFTP连接池当前数量：" + this.connectionPool.keySet().size());
/* 331:    */         }
/* 332:    */       }
/* 333:    */     }
/* 334:    */   }
/* 335:    */   
/* 336:    */   public synchronized void destroy()
/* 337:    */   {
/* 338:359 */     if (null != this.connectionPool)
/* 339:    */     {
/* 340:360 */       boolean isNotNull = true;
/* 341:361 */       while (isNotNull)
/* 342:    */       {
/* 343:362 */         synchronized (this.connectionPool)
/* 344:    */         {
/* 345:363 */           Iterator<Map.Entry<ChannelSftp, Boolean>> iterator = this.connectionPool.entrySet().iterator();
/* 346:364 */           while (iterator.hasNext())
/* 347:    */           {
/* 348:365 */             Map.Entry<ChannelSftp, Boolean> entry = (Map.Entry)iterator.next();
/* 349:366 */             if (false == ((Boolean)entry.getValue()).booleanValue()) {
/* 350:    */               try
/* 351:    */               {
/* 352:368 */                 if (((ChannelSftp)entry.getKey()).isConnected()) {
/* 353:369 */                   ((ChannelSftp)entry.getKey()).disconnect();
/* 354:    */                 }
/* 355:371 */                 if (!((ChannelSftp)entry.getKey()).isClosed()) {
/* 356:372 */                   ((ChannelSftp)entry.getKey()).exit();
/* 357:    */                 }
/* 358:374 */                 if (this.log.isDebugEnabled()) {
/* 359:375 */                   this.log.debug("关闭通道：" + entry.getKey());
/* 360:    */                 }
/* 361:377 */                 iterator.remove();
/* 362:    */               }
/* 363:    */               catch (Exception e)
/* 364:    */               {
/* 365:379 */                 this.log.debug("关闭通道异常！", e);
/* 366:    */               }
/* 367:    */             }
/* 368:    */           }
/* 369:383 */           isNotNull = !this.connectionPool.entrySet().isEmpty();
/* 370:    */         }
/* 371:385 */         if (isNotNull)
/* 372:    */         {
/* 373:    */           try
/* 374:    */           {
/* 375:387 */             Thread.sleep(this.reTryInterval * 1000);
/* 376:    */           }
/* 377:    */           catch (InterruptedException e)
/* 378:    */           {
/* 379:389 */             this.log.error("执行等待时间异常！", e);
/* 380:    */           }
/* 381:    */         }
/* 382:    */         else
/* 383:    */         {
/* 384:392 */           this.connectionPool = null;
/* 385:    */           try
/* 386:    */           {
/* 387:394 */             closeSession();
/* 388:    */           }
/* 389:    */           catch (Exception e)
/* 390:    */           {
/* 391:396 */             this.log.error("关闭会话异常！", e);
/* 392:    */           }
/* 393:    */         }
/* 394:    */       }
/* 395:    */     }
/* 396:    */   }
/* 397:    */   
/* 398:    */   public synchronized void closeSession()
/* 399:    */     throws Exception
/* 400:    */   {
/* 401:411 */     if ((this.session != null) && (this.session.isConnected())) {
/* 402:412 */       synchronized (this.session)
/* 403:    */       {
/* 404:413 */         if (this.log.isDebugEnabled()) {
/* 405:414 */           this.log.debug("关闭会话：" + this.session);
/* 406:    */         }
/* 407:416 */         this.session.disconnect();
/* 408:417 */         this.session = null;
/* 409:    */       }
/* 410:    */     }
/* 411:    */   }
/* 412:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.ftp.SftpPool
 * JD-Core Version:    0.7.0.1
 */