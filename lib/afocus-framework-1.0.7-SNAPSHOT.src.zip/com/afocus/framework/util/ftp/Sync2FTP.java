/*   1:    */ package com.afocus.framework.util.ftp;
/*   2:    */ 
/*   3:    */ import com.jcraft.jsch.ChannelSftp;
/*   4:    */ import com.jcraft.jsch.SftpException;
/*   5:    */ import org.slf4j.Logger;
/*   6:    */ import org.slf4j.LoggerFactory;
/*   7:    */ 
/*   8:    */ public class Sync2FTP
/*   9:    */ {
/*  10: 20 */   private static final Logger log = LoggerFactory.getLogger(Sync2FTP.class);
/*  11:    */   
/*  12:    */   public static void sycnSFTP(String sourcePath, String path, String fileName, boolean isDelLocalFile, int n)
/*  13:    */   {
/*  14: 35 */     if (n > 0) {
/*  15:    */       try
/*  16:    */       {
/*  17: 37 */         sycnSFTP(sourcePath, path, fileName, isDelLocalFile);
/*  18:    */       }
/*  19:    */       catch (Exception e)
/*  20:    */       {
/*  21: 39 */         log.debug("上传图片到FTP出错，开始重试！图片地址：" + sourcePath, e);
/*  22: 40 */         sycnSFTP(sourcePath, path, fileName, isDelLocalFile, --n);
/*  23:    */       }
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static void sycnSFTP(String sourcePath, String path, String fileName, boolean isDelLocalFile) {}
/*  28:    */   
/*  29:    */   public static void checkDirectory(String path, ChannelSftp sftp)
/*  30:    */     throws SftpException
/*  31:    */   {
/*  32: 95 */     sftp.cd("/");
/*  33: 96 */     if ((null != path) && (!"".equals(path)) && 
/*  34: 97 */       (!sftp.pwd().equals(path)))
/*  35:    */     {
/*  36: 98 */       String[] paths = path.split("/");
/*  37: 99 */       for (int i = 0; i < paths.length; i++) {
/*  38:100 */         if (!"".equals(paths[i])) {
/*  39:    */           try
/*  40:    */           {
/*  41:102 */             sftp.cd(paths[i]);
/*  42:    */           }
/*  43:    */           catch (SftpException e)
/*  44:    */           {
/*  45:104 */             if (2 == e.id)
/*  46:    */             {
/*  47:105 */               sftp.mkdir(paths[i]);
/*  48:106 */               sftp.cd(paths[i]);
/*  49:    */             }
/*  50:    */           }
/*  51:    */         }
/*  52:    */       }
/*  53:    */     }
/*  54:    */   }
/*  55:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.ftp.Sync2FTP
 * JD-Core Version:    0.7.0.1
 */