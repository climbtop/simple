/*   1:    */ package com.afocus.framework.util.ftp;
/*   2:    */ 
/*   3:    */ import com.jcraft.jsch.SftpProgressMonitor;
/*   4:    */ import java.text.DecimalFormat;
/*   5:    */ import java.util.Timer;
/*   6:    */ import java.util.TimerTask;
/*   7:    */ import org.slf4j.Logger;
/*   8:    */ import org.slf4j.LoggerFactory;
/*   9:    */ 
/*  10:    */ public class FileProgressMonitor
/*  11:    */   extends TimerTask
/*  12:    */   implements SftpProgressMonitor
/*  13:    */ {
/*  14: 14 */   private long progressInterval = 1000L;
/*  15: 16 */   private boolean isEnd = false;
/*  16:    */   private long transfered;
/*  17:    */   private long fileSize;
/*  18:    */   private Timer timer;
/*  19: 24 */   private boolean isScheduled = false;
/*  20: 27 */   private static final Logger log = LoggerFactory.getLogger(FileProgressMonitor.class);
/*  21:    */   
/*  22:    */   public FileProgressMonitor(long fileSize)
/*  23:    */   {
/*  24: 30 */     this.fileSize = fileSize;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void run()
/*  28:    */   {
/*  29: 35 */     if (!isEnd())
/*  30:    */     {
/*  31: 36 */       long transfered = getTransfered();
/*  32: 37 */       if (transfered != this.fileSize)
/*  33:    */       {
/*  34: 38 */         log.debug("当前已上传: " + transfered + " bytes");
/*  35: 39 */         sendProgressMessage(transfered);
/*  36:    */       }
/*  37:    */       else
/*  38:    */       {
/*  39: 41 */         log.debug("文件上传完毕！");
/*  40: 42 */         setEnd(true);
/*  41:    */       }
/*  42:    */     }
/*  43:    */     else
/*  44:    */     {
/*  45: 45 */       log.debug("文件上传完毕！");
/*  46: 46 */       stop();
/*  47: 47 */       return;
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void stop()
/*  52:    */   {
/*  53: 52 */     log.debug("开始停止监控器...");
/*  54: 53 */     if (this.timer != null)
/*  55:    */     {
/*  56: 54 */       this.timer.cancel();
/*  57: 55 */       this.timer.purge();
/*  58: 56 */       this.timer = null;
/*  59: 57 */       this.isScheduled = false;
/*  60:    */     }
/*  61: 59 */     log.debug("监控器已停止。");
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void start()
/*  65:    */   {
/*  66: 63 */     log.debug("开始启动监控器...");
/*  67: 64 */     if (this.timer == null) {
/*  68: 65 */       this.timer = new Timer();
/*  69:    */     }
/*  70: 67 */     this.timer.schedule(this, 1000L, this.progressInterval);
/*  71: 68 */     this.isScheduled = true;
/*  72: 69 */     log.debug("监控器已启动！");
/*  73:    */   }
/*  74:    */   
/*  75:    */   private void sendProgressMessage(long transfered)
/*  76:    */   {
/*  77: 77 */     if (this.fileSize != 0L)
/*  78:    */     {
/*  79: 78 */       double d = transfered * 100.0D / this.fileSize;
/*  80: 79 */       DecimalFormat df = new DecimalFormat("#.##");
/*  81: 80 */       log.debug("当前上传进度: " + df.format(d) + "%");
/*  82:    */     }
/*  83:    */     else
/*  84:    */     {
/*  85: 82 */       log.debug("当前上传进度: " + transfered);
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean count(long count)
/*  90:    */   {
/*  91: 90 */     if (isEnd()) {
/*  92: 90 */       return false;
/*  93:    */     }
/*  94: 91 */     if (!this.isScheduled) {
/*  95: 92 */       start();
/*  96:    */     }
/*  97: 94 */     add(count);
/*  98: 95 */     return true;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void end()
/* 102:    */   {
/* 103:102 */     setEnd(true);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private synchronized void add(long count)
/* 107:    */   {
/* 108:106 */     this.transfered += count;
/* 109:    */   }
/* 110:    */   
/* 111:    */   private synchronized long getTransfered()
/* 112:    */   {
/* 113:110 */     return this.transfered;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public synchronized void setTransfered(long transfered)
/* 117:    */   {
/* 118:114 */     this.transfered = transfered;
/* 119:    */   }
/* 120:    */   
/* 121:    */   private synchronized void setEnd(boolean isEnd)
/* 122:    */   {
/* 123:118 */     this.isEnd = isEnd;
/* 124:    */   }
/* 125:    */   
/* 126:    */   private synchronized boolean isEnd()
/* 127:    */   {
/* 128:122 */     return this.isEnd;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void init(int op, String src, String dest, long max) {}
/* 132:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.ftp.FileProgressMonitor
 * JD-Core Version:    0.7.0.1
 */