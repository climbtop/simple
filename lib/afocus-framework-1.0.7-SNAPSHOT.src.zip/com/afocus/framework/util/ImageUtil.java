/*    1:     */ package com.afocus.framework.util;
/*    2:     */ 
/*    3:     */ import com.afocus.framework.util.file.FileUtil;
/*    4:     */ import com.afocus.framework.util.file.FileUtil.FileInfo;
/*    5:     */ import java.awt.AlphaComposite;
/*    6:     */ import java.awt.Color;
/*    7:     */ import java.awt.Font;
/*    8:     */ import java.awt.FontMetrics;
/*    9:     */ import java.awt.Graphics;
/*   10:     */ import java.awt.Graphics2D;
/*   11:     */ import java.awt.Image;
/*   12:     */ import java.awt.color.ColorSpace;
/*   13:     */ import java.awt.geom.AffineTransform;
/*   14:     */ import java.awt.image.AffineTransformOp;
/*   15:     */ import java.awt.image.BufferedImage;
/*   16:     */ import java.awt.image.ColorModel;
/*   17:     */ import java.io.ByteArrayOutputStream;
/*   18:     */ import java.io.File;
/*   19:     */ import java.io.FileInputStream;
/*   20:     */ import java.io.IOException;
/*   21:     */ import java.io.OutputStream;
/*   22:     */ import javax.imageio.ImageIO;
/*   23:     */ import javax.swing.ImageIcon;
/*   24:     */ import org.apache.commons.codec.digest.DigestUtils;
/*   25:     */ import org.apache.log4j.Logger;
/*   26:     */ 
/*   27:     */ public class ImageUtil
/*   28:     */ {
/*   29:  27 */   private static Logger log = Logger.getLogger(ImageUtil.class);
/*   30:  32 */   public static int ZOOM_MULTI_STEP = 1;
/*   31:  37 */   public static int ZOOM_IMAGE_GETSCALEDINSTANCE = 2;
/*   32:  42 */   public static int ZOOM_LANCZOS = 3;
/*   33:  47 */   public static int ZOOM_TRILINEAR = 4;
/*   34:     */   
/*   35:     */   public static class ImageInfo
/*   36:     */   {
/*   37:  53 */     private int width = 0;
/*   38:  54 */     private int height = 0;
/*   39:  55 */     private int colorSpace = 0;
/*   40:  56 */     private BufferedImage image = null;
/*   41:     */     private FileUtil.FileInfo fileInfo;
/*   42:     */     
/*   43:     */     public ImageInfo(FileUtil.FileInfo fileInfo)
/*   44:     */     {
/*   45:  65 */       this.fileInfo = fileInfo;
/*   46:     */       try
/*   47:     */       {
/*   48:  67 */         this.image = ImageUtil.getBufferedImage(fileInfo.getObj());
/*   49:     */         
/*   50:  69 */         this.width = this.image.getWidth();
/*   51:  70 */         this.height = this.image.getHeight();
/*   52:  71 */         this.colorSpace = this.image.getColorModel().getColorSpace().getType();
/*   53:     */       }
/*   54:     */       catch (Exception e)
/*   55:     */       {
/*   56:  73 */         e.printStackTrace();
/*   57:  74 */         ImageUtil.log.error(e);
/*   58:     */       }
/*   59:     */     }
/*   60:     */     
/*   61:     */     public ImageInfo(String fileName)
/*   62:     */     {
/*   63:  84 */       this(new File(fileName));
/*   64:     */     }
/*   65:     */     
/*   66:     */     public ImageInfo(File file)
/*   67:     */     {
/*   68:  93 */       this(new FileUtil.FileInfo(file));
/*   69:     */     }
/*   70:     */     
/*   71:     */     public int getColorSpace()
/*   72:     */     {
/*   73: 100 */       return this.colorSpace;
/*   74:     */     }
/*   75:     */     
/*   76:     */     public FileUtil.FileInfo getFileInfo()
/*   77:     */     {
/*   78: 107 */       return this.fileInfo;
/*   79:     */     }
/*   80:     */     
/*   81:     */     public int getHeight()
/*   82:     */     {
/*   83: 114 */       return this.height;
/*   84:     */     }
/*   85:     */     
/*   86:     */     public int getWidth()
/*   87:     */     {
/*   88: 121 */       return this.width;
/*   89:     */     }
/*   90:     */     
/*   91:     */     public BufferedImage getImage()
/*   92:     */     {
/*   93: 128 */       return this.image;
/*   94:     */     }
/*   95:     */   }
/*   96:     */   
/*   97:     */   public static Image getImage(String imageFileName)
/*   98:     */     throws IOException
/*   99:     */   {
/*  100: 140 */     return getImage(new File(imageFileName));
/*  101:     */   }
/*  102:     */   
/*  103:     */   public static Image getImage(File imageFile)
/*  104:     */     throws IOException
/*  105:     */   {
/*  106: 156 */     String fileType = FileUtil.getFileType(imageFile.getName());
/*  107: 158 */     if ((fileType.equals("jpeg")) || (fileType.equals("jpg")))
/*  108:     */     {
/*  109: 159 */       ImageIcon icon = new ImageIcon(imageFile.getAbsolutePath());
/*  110: 160 */       if (icon.getImageLoadStatus() == 8) {
/*  111: 161 */         return icon.getImage();
/*  112:     */       }
/*  113:     */     }
/*  114: 163 */     return ImageIO.read(imageFile);
/*  115:     */   }
/*  116:     */   
/*  117:     */   public static BufferedImage getBufferedImage(File imageFile)
/*  118:     */     throws IOException
/*  119:     */   {
/*  120: 175 */     return getBufferedImage(getImage(imageFile));
/*  121:     */   }
/*  122:     */   
/*  123:     */   public static BufferedImage getBufferedImage(String imageFileName)
/*  124:     */     throws IOException
/*  125:     */   {
/*  126: 186 */     return getBufferedImage(new File(imageFileName));
/*  127:     */   }
/*  128:     */   
/*  129:     */   public static BufferedImage getBufferedImage(Image image)
/*  130:     */   {
/*  131: 196 */     if ((image instanceof BufferedImage)) {
/*  132: 197 */       return (BufferedImage)image;
/*  133:     */     }
/*  134: 199 */     int w = image.getWidth(null);
/*  135: 200 */     int h = image.getHeight(null);
/*  136:     */     
/*  137: 202 */     BufferedImage srcImage = new BufferedImage(w, h, 1);
/*  138: 203 */     Graphics2D g = srcImage.createGraphics();
/*  139: 204 */     g.drawImage(image, 0, 0, null);
/*  140: 205 */     g.dispose();
/*  141: 206 */     return srcImage;
/*  142:     */   }
/*  143:     */   
/*  144:     */   public static long zoom(String srcPath, String destPath, int newWidth, int newHeight)
/*  145:     */   {
/*  146:     */     try
/*  147:     */     {
/*  148: 221 */       return zoom(getImage(srcPath), destPath, newWidth, newHeight);
/*  149:     */     }
/*  150:     */     catch (Exception e)
/*  151:     */     {
/*  152: 223 */       e.printStackTrace();
/*  153: 224 */       log.error(e);
/*  154:     */     }
/*  155: 225 */     return 0L;
/*  156:     */   }
/*  157:     */   
/*  158:     */   public static long zoom(Image srcImage, String destPath, int newWidth, int newHeight)
/*  159:     */     throws IOException
/*  160:     */   {
/*  161: 239 */     BufferedImage img = zoomImage(srcImage, newWidth, newHeight);
/*  162: 240 */     return writeImage(img, destPath);
/*  163:     */   }
/*  164:     */   
/*  165:     */   public static long zoom(Image srcImage, String destPath, int newWidth, int newHeight, int method)
/*  166:     */     throws IOException
/*  167:     */   {
/*  168: 254 */     BufferedImage img = zoomImage(srcImage, newWidth, newHeight, method);
/*  169: 255 */     return writeImage(img, destPath);
/*  170:     */   }
/*  171:     */   
/*  172:     */   public static BufferedImage zoomImage(Image srcImage, int newWidth, int newHeight)
/*  173:     */   {
/*  174: 267 */     return zoomImage(srcImage, newWidth, newHeight, ZOOM_MULTI_STEP);
/*  175:     */   }
/*  176:     */   
/*  177:     */   public static BufferedImage zoomImage(Image srcImage, int newWidth, int newHeight, int method)
/*  178:     */   {
/*  179:     */     try
/*  180:     */     {
/*  181: 281 */       if ((srcImage == null) || (newWidth < 0) || (newHeight < 0)) {
/*  182: 282 */         return null;
/*  183:     */       }
/*  184: 283 */       int w = srcImage.getWidth(null);
/*  185: 284 */       int h = srcImage.getHeight(null);
/*  186: 285 */       if ((w <= newWidth) && (h <= newHeight)) {
/*  187: 286 */         return getBufferedImage(srcImage);
/*  188:     */       }
/*  189: 287 */       if ((newWidth == 0) && (newHeight == 0)) {
/*  190: 288 */         return getBufferedImage(srcImage);
/*  191:     */       }
/*  192: 289 */       if (newWidth == 0) {
/*  193: 290 */         newWidth = w * newHeight / h;
/*  194: 291 */       } else if (newHeight == 0) {
/*  195: 292 */         newHeight = h * newWidth / w;
/*  196:     */       }
/*  197: 295 */       if ((w <= newWidth) && (h <= newHeight)) {
/*  198: 296 */         return getBufferedImage(srcImage);
/*  199:     */       }
/*  200: 299 */       if (method == ZOOM_MULTI_STEP) {
/*  201: 300 */         return ScaleImage.scaleImageByMultiStep(getBufferedImage(srcImage), newWidth, newHeight, true);
/*  202:     */       }
/*  203: 301 */       if (method == ZOOM_IMAGE_GETSCALEDINSTANCE) {
/*  204: 302 */         return getBufferedImage(getBufferedImage(srcImage).getScaledInstance(newWidth, newHeight, 4));
/*  205:     */       }
/*  206: 303 */       if (method == ZOOM_TRILINEAR) {
/*  207: 304 */         return ScaleImage.scaleImageByTrilinear(getBufferedImage(srcImage), newWidth, newHeight);
/*  208:     */       }
/*  209: 305 */       return ScaleImage.scaleImageByLanczos(getBufferedImage(srcImage), newWidth, newHeight);
/*  210:     */     }
/*  211:     */     catch (Exception e)
/*  212:     */     {
/*  213: 308 */       e.printStackTrace();
/*  214: 309 */       log.error(e);
/*  215:     */     }
/*  216: 310 */     return null;
/*  217:     */   }
/*  218:     */   
/*  219:     */   public static BufferedImage zoomMax(Image srcImage, int maxWidth, int maxHeight)
/*  220:     */   {
/*  221: 324 */     int w = srcImage.getWidth(null);
/*  222: 325 */     int h = srcImage.getHeight(null);
/*  223: 326 */     int[] newWidHgt = getRealWidthHeight(w, h, maxWidth, maxHeight);
/*  224: 328 */     if ((newWidHgt[0] == w) && (newWidHgt[1] == h)) {
/*  225: 329 */       return getBufferedImage(srcImage);
/*  226:     */     }
/*  227: 331 */     return zoomImage(srcImage, newWidHgt[0], newWidHgt[1]);
/*  228:     */   }
/*  229:     */   
/*  230:     */   public static BufferedImage zoomMax(String srcPath, int maxWidth, int maxHeight)
/*  231:     */   {
/*  232:     */     try
/*  233:     */     {
/*  234: 344 */       return zoomMax(getImage(srcPath), maxWidth, maxHeight);
/*  235:     */     }
/*  236:     */     catch (Exception e)
/*  237:     */     {
/*  238: 346 */       e.printStackTrace();
/*  239: 347 */       log.error(e + ":" + srcPath);
/*  240:     */     }
/*  241: 348 */     return null;
/*  242:     */   }
/*  243:     */   
/*  244:     */   public static long zoomMax(String srcPath, String destPath, int maxWidth, int maxHeight)
/*  245:     */   {
/*  246:     */     try
/*  247:     */     {
/*  248: 363 */       return zoomMax(getImage(srcPath), destPath, maxWidth, maxHeight);
/*  249:     */     }
/*  250:     */     catch (Exception e)
/*  251:     */     {
/*  252: 365 */       e.printStackTrace();
/*  253: 366 */       log.error(srcPath + ":" + e);
/*  254:     */     }
/*  255: 367 */     return 0L;
/*  256:     */   }
/*  257:     */   
/*  258:     */   public static long zoomMax(Image srcImage, String destPath, int maxWidth, int maxHeight)
/*  259:     */     throws IOException
/*  260:     */   {
/*  261: 382 */     return zoomMax(srcImage, destPath, maxWidth, maxHeight, false);
/*  262:     */   }
/*  263:     */   
/*  264:     */   public static long zoomMax(Image srcImage, String destPath, int maxWidth, int maxHeight, boolean force)
/*  265:     */     throws IOException
/*  266:     */   {
/*  267: 396 */     if ((srcImage == null) || (destPath == null) || (maxWidth < 0) || (maxHeight < 0)) {
/*  268: 397 */       return 0L;
/*  269:     */     }
/*  270: 399 */     int w = srcImage.getWidth(null);
/*  271: 400 */     int h = srcImage.getHeight(null);
/*  272: 401 */     int[] newWidHgt = getRealWidthHeight(w, h, maxWidth, maxHeight);
/*  273: 402 */     if ((!force) && (newWidHgt[0] >= w) && (newWidHgt[1] >= h)) {
/*  274: 402 */       return 0L;
/*  275:     */     }
/*  276: 403 */     return zoom(srcImage, destPath, newWidHgt[0], newWidHgt[1]);
/*  277:     */   }
/*  278:     */   
/*  279:     */   public static int[] getRealWidthHeight(int w, int h, int maxWidth, int maxHeight)
/*  280:     */   {
/*  281: 416 */     int[] wh = new int[2];
/*  282: 417 */     log.debug(" w:" + w + ",h:" + h + ",maxWidth:" + maxWidth + ",maxHeight:" + maxHeight);
/*  283:     */     
/*  284: 419 */     float r0 = w / h;
/*  285: 420 */     if ((maxWidth == 0) && (maxHeight == 0))
/*  286:     */     {
/*  287: 421 */       wh[0] = w;
/*  288: 422 */       wh[1] = h;
/*  289: 423 */       return wh;
/*  290:     */     }
/*  291: 424 */     if (maxWidth == 0) {
/*  292: 425 */       maxWidth = (int)(r0 * maxHeight);
/*  293: 426 */     } else if (maxHeight == 0) {
/*  294: 427 */       maxHeight = (int)(maxWidth / r0);
/*  295:     */     }
/*  296: 430 */     wh[0] = maxWidth;
/*  297: 431 */     wh[1] = maxHeight;
/*  298: 432 */     float rm = maxWidth / maxHeight;
/*  299: 433 */     if (rm > r0)
/*  300:     */     {
/*  301: 434 */       if (h < wh[1])
/*  302:     */       {
/*  303: 435 */         wh[0] = w;
/*  304: 436 */         wh[1] = h;
/*  305:     */       }
/*  306: 438 */       wh[0] = ((int)(r0 * wh[1]));
/*  307:     */     }
/*  308:     */     else
/*  309:     */     {
/*  310: 440 */       if (w < wh[0])
/*  311:     */       {
/*  312: 441 */         wh[0] = w;
/*  313: 442 */         wh[1] = h;
/*  314:     */       }
/*  315: 444 */       wh[1] = ((int)(wh[0] / r0));
/*  316:     */     }
/*  317: 446 */     wh[0] = (wh[0] <= 0 ? w : wh[0]);
/*  318: 447 */     wh[1] = (wh[1] <= 0 ? h : wh[1]);
/*  319: 448 */     return wh;
/*  320:     */   }
/*  321:     */   
/*  322:     */   public static int[] getRealWidthHeightForMin(int w, int h, int minWidth, int minHeight)
/*  323:     */   {
/*  324: 461 */     int[] wh = new int[2];
/*  325:     */     
/*  326: 463 */     float r0 = w / h;
/*  327: 464 */     if ((minWidth == 0) && (minHeight == 0))
/*  328:     */     {
/*  329: 465 */       wh[0] = w;
/*  330: 466 */       wh[1] = h;
/*  331:     */       
/*  332: 468 */       return wh;
/*  333:     */     }
/*  334: 469 */     if (minWidth == 0) {
/*  335: 470 */       minWidth = (int)(minHeight * r0);
/*  336: 472 */     } else if (minHeight == 0) {
/*  337: 473 */       minHeight = (int)(minWidth / r0);
/*  338:     */     }
/*  339: 476 */     minWidth = minWidth > w ? w : minWidth;
/*  340: 477 */     minHeight = minHeight > h ? h : minHeight;
/*  341:     */     
/*  342: 479 */     wh[0] = minWidth;
/*  343: 480 */     wh[1] = minHeight;
/*  344: 481 */     float rm = minWidth / minHeight;
/*  345: 483 */     if (rm > r0)
/*  346:     */     {
/*  347: 484 */       if (w < wh[1]) {
/*  348: 486 */         wh[0] = w;
/*  349:     */       }
/*  350: 489 */       wh[1] = ((int)(wh[0] / r0));
/*  351:     */     }
/*  352:     */     else
/*  353:     */     {
/*  354: 492 */       if (h < wh[1]) {
/*  355: 495 */         wh[1] = h;
/*  356:     */       }
/*  357: 497 */       wh[0] = ((int)(r0 * wh[1]));
/*  358:     */     }
/*  359: 500 */     return wh;
/*  360:     */   }
/*  361:     */   
/*  362:     */   public static ImageInfo getImageInfo(String fileName)
/*  363:     */   {
/*  364: 510 */     return new ImageInfo(fileName);
/*  365:     */   }
/*  366:     */   
/*  367:     */   public static ImageInfo getImageInfo(File file)
/*  368:     */   {
/*  369: 520 */     return new ImageInfo(file);
/*  370:     */   }
/*  371:     */   
/*  372:     */   public static ImageInfo getImageInfo(FileUtil.FileInfo fileInfo)
/*  373:     */   {
/*  374: 530 */     return new ImageInfo(fileInfo);
/*  375:     */   }
/*  376:     */   
/*  377:     */   public static long rotate(String srcPath, String destPath, int degree)
/*  378:     */   {
/*  379:     */     try
/*  380:     */     {
/*  381: 544 */       return rotate(getBufferedImage(srcPath), destPath, degree);
/*  382:     */     }
/*  383:     */     catch (Exception e)
/*  384:     */     {
/*  385: 546 */       e.printStackTrace();
/*  386: 547 */       log.error(e);
/*  387:     */     }
/*  388: 548 */     return 0L;
/*  389:     */   }
/*  390:     */   
/*  391:     */   public static long rotate(BufferedImage srcImage, String destPath, int degree)
/*  392:     */     throws IOException
/*  393:     */   {
/*  394: 561 */     BufferedImage img = rotateImg(srcImage, degree, Color.WHITE);
/*  395: 562 */     return writeImage(img, destPath);
/*  396:     */   }
/*  397:     */   
/*  398:     */   public static BufferedImage rotateImg(BufferedImage image, int degree, Color bgcolor)
/*  399:     */   {
/*  400: 575 */     degree %= 360;
/*  401: 576 */     if (degree == 0) {
/*  402: 576 */       return image;
/*  403:     */     }
/*  404: 578 */     if (degree < 0) {
/*  405: 578 */       degree = 360 + degree;
/*  406:     */     }
/*  407: 579 */     double ang = degree * 3.141592653589793D / 180.0D;
/*  408:     */     
/*  409: 581 */     int iw = image.getWidth();
/*  410: 582 */     int ih = image.getHeight();
/*  411:     */     
/*  412:     */ 
/*  413:     */ 
/*  414:     */ 
/*  415: 587 */     int w = 0;
/*  416: 588 */     int h = 0;
/*  417: 590 */     if (degree == 180)
/*  418:     */     {
/*  419: 591 */       w = iw;
/*  420: 592 */       h = ih;
/*  421:     */     }
/*  422: 593 */     else if ((degree == 90) || (degree == 270))
/*  423:     */     {
/*  424: 594 */       w = ih;
/*  425: 595 */       h = iw;
/*  426:     */     }
/*  427:     */     else
/*  428:     */     {
/*  429: 597 */       double sin = Math.abs(Math.sin(ang));
/*  430: 598 */       double cos = Math.abs(Math.cos(ang));
/*  431: 599 */       w = (int)(iw * cos + ih * sin);
/*  432: 600 */       h = (int)(ih * cos + iw * sin);
/*  433:     */     }
/*  434: 603 */     BufferedImage rotatedImage = new BufferedImage(w, h, image.getType());
/*  435: 604 */     Graphics gs = rotatedImage.getGraphics();
/*  436: 605 */     gs.setColor(bgcolor);
/*  437: 606 */     gs.fillRect(0, 0, w, h);
/*  438: 607 */     AffineTransform at = new AffineTransform();
/*  439: 608 */     at.rotate(ang, w / 2, h / 2);
/*  440:     */     
/*  441: 610 */     int x = w / 2 - iw / 2;
/*  442: 611 */     int y = h / 2 - ih / 2;
/*  443: 612 */     at.translate(x, y);
/*  444: 613 */     AffineTransformOp op = new AffineTransformOp(at, 1);
/*  445: 614 */     op.filter(image, rotatedImage);
/*  446: 615 */     image = rotatedImage;
/*  447: 616 */     return image;
/*  448:     */   }
/*  449:     */   
/*  450:     */   public static long crop(String srcImageFileName, int x, int y, int w, int h, String destPath)
/*  451:     */   {
/*  452:     */     try
/*  453:     */     {
/*  454: 632 */       return crop(getBufferedImage(srcImageFileName), x, y, w, h, destPath);
/*  455:     */     }
/*  456:     */     catch (Exception e)
/*  457:     */     {
/*  458: 634 */       e.printStackTrace();
/*  459: 635 */       log.error(e);
/*  460:     */     }
/*  461: 636 */     return 0L;
/*  462:     */   }
/*  463:     */   
/*  464:     */   public static long crop(BufferedImage srcImage, int x, int y, int w, int h, String destPath)
/*  465:     */     throws IOException
/*  466:     */   {
/*  467: 652 */     BufferedImage img = cropImage(srcImage, x, y, w, h);
/*  468: 653 */     return writeImage(img, destPath);
/*  469:     */   }
/*  470:     */   
/*  471:     */   public static BufferedImage cropImage(BufferedImage srcImage, int x, int y, int w, int h)
/*  472:     */   {
/*  473: 668 */     int sw = srcImage.getWidth();
/*  474: 669 */     int sh = srcImage.getHeight();
/*  475:     */     
/*  476: 671 */     x = x >= sw ? 0 : x < 0 ? sw + x : x;
/*  477: 672 */     y = y >= sh ? 0 : y < 0 ? sh + y : y;
/*  478: 673 */     w = x + w >= sw ? sw : sw > x ? sw - x : w;
/*  479: 674 */     h = y + h >= sh ? sh : sh > y ? sh - y : h;
/*  480:     */     
/*  481:     */ 
/*  482: 677 */     return srcImage.getSubimage(x, y, w, h);
/*  483:     */   }
/*  484:     */   
/*  485:     */   public static long cropMinImage(String srcImageFileName, int minW, int minH, String destPath)
/*  486:     */   {
/*  487:     */     try
/*  488:     */     {
/*  489: 691 */       return cropMinImage(getImage(srcImageFileName), minW, minH, destPath);
/*  490:     */     }
/*  491:     */     catch (Exception e)
/*  492:     */     {
/*  493: 693 */       e.printStackTrace();
/*  494: 694 */       log.error(e);
/*  495:     */     }
/*  496: 695 */     return 0L;
/*  497:     */   }
/*  498:     */   
/*  499:     */   public static BufferedImage cropMinImage(String srcImageFileName, int minW, int minH)
/*  500:     */   {
/*  501:     */     try
/*  502:     */     {
/*  503: 709 */       return cropMinImage(getImage(srcImageFileName), minW, minH);
/*  504:     */     }
/*  505:     */     catch (Exception e)
/*  506:     */     {
/*  507: 711 */       e.printStackTrace();
/*  508: 712 */       log.error(e);
/*  509:     */     }
/*  510: 713 */     return null;
/*  511:     */   }
/*  512:     */   
/*  513:     */   public static long cropMinImage(Image srcImage, int minW, int minH, String destPath)
/*  514:     */     throws IOException
/*  515:     */   {
/*  516: 727 */     BufferedImage img = cropMinImage(srcImage, minW, minH);
/*  517: 728 */     return writeImage(img, destPath);
/*  518:     */   }
/*  519:     */   
/*  520:     */   public static BufferedImage cropMinImage(Image srcImage, int minW, int minH)
/*  521:     */   {
/*  522: 740 */     int sw = srcImage.getWidth(null);
/*  523: 741 */     int sh = srcImage.getHeight(null);
/*  524: 742 */     float r = minW * sh / minH / sw;
/*  525: 743 */     int minWzoom = minW;
/*  526: 744 */     int minHzoom = minH;
/*  527: 745 */     if (r < 1.0F)
/*  528:     */     {
/*  529: 746 */       minWzoom = (int)(minW * 1.1D);
/*  530: 747 */       minHzoom = (int)(minH * 1.1D);
/*  531:     */     }
/*  532: 749 */     int[] newWH = getRealWidthHeightForMin(sw, sh, minWzoom, minHzoom);
/*  533:     */     
/*  534: 751 */     BufferedImage image = zoomImage(srcImage, newWH[0], newWH[1]);
/*  535: 752 */     log.debug("zoomImage min wh: " + image.getWidth() + "," + image.getHeight());
/*  536:     */     
/*  537: 754 */     int x = (newWH[0] - minW) / 2;
/*  538: 755 */     int y = (int)((newWH[1] - minH) / (4.0F * r));
/*  539: 756 */     int targetW = x >= 0 ? minW : newWH[0];
/*  540: 757 */     int targetH = y >= 0 ? minH : newWH[1];
/*  541: 758 */     x = x >= 0 ? x : 0;
/*  542: 759 */     y = y >= 0 ? y : 0;
/*  543: 760 */     log.debug("x:" + x + ",y:" + y + ",targetW:" + targetW + ",targetH:" + targetH + ",r:" + r);
/*  544: 761 */     return cropImage(image, x, y, targetW, targetH);
/*  545:     */   }
/*  546:     */   
/*  547:     */   public static long waterMark(String srcImageFileName, String iconFileName, int x, int y, float alpha, String destPath)
/*  548:     */     throws IOException
/*  549:     */   {
/*  550: 777 */     BufferedImage img = waterMark(srcImageFileName, iconFileName, x, y, alpha);
/*  551: 778 */     return writeImage(img, destPath);
/*  552:     */   }
/*  553:     */   
/*  554:     */   public static BufferedImage waterMark(String srcImageFileName, String iconFileName, int x, int y, float alpha)
/*  555:     */   {
/*  556:     */     try
/*  557:     */     {
/*  558: 794 */       return waterMark(new File(srcImageFileName), getBufferedImage(iconFileName), x, y, alpha);
/*  559:     */     }
/*  560:     */     catch (Exception e)
/*  561:     */     {
/*  562: 796 */       e.printStackTrace();
/*  563: 797 */       log.error(e);
/*  564:     */     }
/*  565: 798 */     return null;
/*  566:     */   }
/*  567:     */   
/*  568:     */   public static BufferedImage waterMark(String srcImageFileName, BufferedImage icon, int x, int y, float alpha)
/*  569:     */   {
/*  570: 814 */     return waterMark(new File(srcImageFileName), icon, x, y, alpha);
/*  571:     */   }
/*  572:     */   
/*  573:     */   public static BufferedImage waterMark(File srcImageFile, BufferedImage icon, int x, int y, float alpha)
/*  574:     */   {
/*  575:     */     try
/*  576:     */     {
/*  577: 830 */       BufferedImage srcImage = getBufferedImage(srcImageFile);
/*  578: 831 */       return waterMark(srcImage, icon, x, y, alpha);
/*  579:     */     }
/*  580:     */     catch (Exception e)
/*  581:     */     {
/*  582: 833 */       log.warn("watermark error:" + e);
/*  583: 834 */       e.printStackTrace();
/*  584:     */     }
/*  585: 835 */     return null;
/*  586:     */   }
/*  587:     */   
/*  588:     */   public static BufferedImage waterMark(BufferedImage srcImage, BufferedImage icon, int x, int y, float alpha)
/*  589:     */   {
/*  590: 851 */     int sw = srcImage.getWidth();
/*  591: 852 */     int sh = srcImage.getHeight();
/*  592: 853 */     int iw = icon.getWidth();
/*  593: 854 */     int ih = icon.getHeight();
/*  594:     */     
/*  595: 856 */     BufferedImage bimage = srcImage;
/*  596: 857 */     Graphics2D g = bimage.createGraphics();
/*  597: 859 */     if ((alpha > 1.0F) || (alpha < 0.0F)) {
/*  598: 860 */       alpha = 1.0F;
/*  599:     */     }
/*  600: 861 */     AlphaComposite ac = AlphaComposite.getInstance(3, alpha);
/*  601: 862 */     g.setComposite(ac);
/*  602:     */     
/*  603: 864 */     log.debug("watermark before: x:" + x + ",y:" + y);
/*  604: 865 */     x = x < 0 ? sw - iw + x : x;
/*  605: 866 */     y = y < 0 ? sh - ih + y : y;
/*  606: 867 */     x = x + iw >= sw ? sw - iw : x;
/*  607: 868 */     y = y + ih >= sh ? sh - ih : y;
/*  608: 869 */     x = x < 0 ? 0 : x;
/*  609: 870 */     y = y < 0 ? 0 : y;
/*  610: 871 */     log.debug("watermark after: x:" + x + ",y:" + y);
/*  611: 872 */     if ((x + iw > sw) || (y + ih > sh))
/*  612:     */     {
/*  613: 873 */       int dw = x + iw > sw ? sw - x : iw;
/*  614: 874 */       int dh = y + ih > sh ? sh - y : ih;
/*  615: 875 */       BufferedImage image = icon.getSubimage(0, 0, dw, dh);
/*  616: 876 */       g.drawImage(image, x, y, null);
/*  617:     */     }
/*  618:     */     else
/*  619:     */     {
/*  620: 878 */       g.drawImage(icon, x, y, iw, ih, null);
/*  621:     */     }
/*  622: 879 */     g.dispose();
/*  623: 880 */     return bimage;
/*  624:     */   }
/*  625:     */   
/*  626:     */   public static long drawText(String srcImageFileName, String txt, int x, int y, String txtColor, String bgColor, String fontName, int fontSize, float alpha, String destPath)
/*  627:     */     throws IOException
/*  628:     */   {
/*  629: 900 */     BufferedImage img = drawText(srcImageFileName, txt, x, y, txtColor, bgColor, fontName, fontSize, alpha);
/*  630: 901 */     return writeImage(img, destPath);
/*  631:     */   }
/*  632:     */   
/*  633:     */   public static BufferedImage drawText(String srcImageFileName, String txt, int x, int y, String txtColor, String bgColor, String fontName, int fontSize, float alpha)
/*  634:     */   {
/*  635: 920 */     File fin = new File(srcImageFileName);
/*  636: 921 */     return drawText(fin, txt, x, y, txtColor, bgColor, fontName, fontSize, alpha);
/*  637:     */   }
/*  638:     */   
/*  639:     */   public static BufferedImage drawText(File srcImageFile, String txt, int x, int y, String txtColor, String bgColor, String fontName, int fontSize, float alpha)
/*  640:     */   {
/*  641:     */     try
/*  642:     */     {
/*  643: 941 */       BufferedImage srcImage = getBufferedImage(srcImageFile);
/*  644: 942 */       return drawText(srcImage, txt, x, y, txtColor, bgColor, fontName, fontSize, alpha);
/*  645:     */     }
/*  646:     */     catch (Exception e)
/*  647:     */     {
/*  648: 944 */       e.printStackTrace();
/*  649: 945 */       log.error(e);
/*  650:     */     }
/*  651: 946 */     return null;
/*  652:     */   }
/*  653:     */   
/*  654:     */   public static BufferedImage drawText(BufferedImage srcImage, String txt, int x, int y, String txtColor, String bgColor, String fontName, int fontSize, float alpha)
/*  655:     */   {
/*  656: 966 */     Color _txtColor = new Color(Integer.parseInt(txtColor, 16));
/*  657: 967 */     Color _bgColor = new Color(Integer.parseInt(bgColor, 16));
/*  658: 968 */     Font font = new Font(fontName, 1, fontSize);
/*  659: 969 */     return drawText(srcImage, txt, x, y, _txtColor, _bgColor, font, alpha);
/*  660:     */   }
/*  661:     */   
/*  662:     */   public static BufferedImage drawText(BufferedImage srcImage, String txt, int x, int y, Color txtColor, Color bgColor, Font font, float alpha)
/*  663:     */   {
/*  664: 987 */     int sw = srcImage.getWidth();
/*  665: 988 */     int sh = srcImage.getHeight();
/*  666:     */     
/*  667: 990 */     BufferedImage bimage = srcImage;
/*  668: 991 */     Graphics2D g = bimage.createGraphics();
/*  669: 993 */     if ((alpha > 1.0F) || (alpha < 0.0F)) {
/*  670: 994 */       alpha = 1.0F;
/*  671:     */     }
/*  672: 995 */     AlphaComposite ac = AlphaComposite.getInstance(3, alpha);
/*  673: 996 */     g.setComposite(ac);
/*  674: 997 */     g.setFont(font);
/*  675: 998 */     g.setColor(txtColor);
/*  676: 999 */     g.setBackground(bgColor);
/*  677:1000 */     int iw = g.getFontMetrics().stringWidth(txt);
/*  678:     */     
/*  679:1002 */     x = x < 0 ? sw - iw + x : x;
/*  680:1003 */     y = y < 0 ? sh + y : y;
/*  681:1004 */     x = x + iw >= sw ? sw - iw : x;
/*  682:1005 */     x = x < 0 ? 0 : x;
/*  683:1006 */     y = y < 0 ? 0 : y;
/*  684:1007 */     g.drawString(txt, x, y);
/*  685:1008 */     g.dispose();
/*  686:1009 */     return bimage;
/*  687:     */   }
/*  688:     */   
/*  689:     */   public static void drawImageMark(String sourceImg, String targetImg, String waterImg, int x, int y, float alpha)
/*  690:     */   {
/*  691:     */     try
/*  692:     */     {
/*  693:1025 */       File file = new File(sourceImg);
/*  694:1026 */       Image image = ImageIO.read(file);
/*  695:1027 */       int width = image.getWidth(null);
/*  696:1028 */       int height = image.getHeight(null);
/*  697:1029 */       BufferedImage bufferedImage = new BufferedImage(width, height, 1);
/*  698:     */       
/*  699:1031 */       Graphics2D g = bufferedImage.createGraphics();
/*  700:1032 */       g.drawImage(image, 0, 0, width, height, null);
/*  701:     */       
/*  702:1034 */       Image waterImage = ImageIO.read(new File(waterImg));
/*  703:1035 */       int width_1 = waterImage.getWidth(null);
/*  704:1036 */       int height_1 = waterImage.getHeight(null);
/*  705:1037 */       g.setComposite(AlphaComposite.getInstance(10, alpha));
/*  706:     */       
/*  707:     */ 
/*  708:1040 */       int widthDiff = width - width_1;
/*  709:1041 */       int heightDiff = height - height_1;
/*  710:1042 */       if (x < 0) {
/*  711:1043 */         x = widthDiff / 2;
/*  712:1044 */       } else if (x > widthDiff) {
/*  713:1045 */         x = widthDiff;
/*  714:     */       }
/*  715:1047 */       if (y < 0) {
/*  716:1048 */         y = heightDiff / 2;
/*  717:1049 */       } else if (y > heightDiff) {
/*  718:1050 */         y = heightDiff;
/*  719:     */       }
/*  720:1052 */       g.drawImage(waterImage, x, y, width_1, height_1, null);
/*  721:1053 */       g.dispose();
/*  722:1054 */       writeImage(bufferedImage, targetImg);
/*  723:     */     }
/*  724:     */     catch (IOException e)
/*  725:     */     {
/*  726:1056 */       e.printStackTrace();
/*  727:     */     }
/*  728:     */   }
/*  729:     */   
/*  730:     */   public static long writeImage(BufferedImage img, String destPath)
/*  731:     */     throws IOException
/*  732:     */   {
/*  733:1069 */     File fout = new File(destPath);
/*  734:1070 */     String fileType = FileUtil.getFileType(fout.getName());
/*  735:1071 */     ImageIO.write(img, fileType, fout);
/*  736:1072 */     return fout.length();
/*  737:     */   }
/*  738:     */   
/*  739:     */   public static boolean writeImage(BufferedImage img, String fileType, OutputStream out)
/*  740:     */     throws IOException
/*  741:     */   {
/*  742:1085 */     ImageIO.write(img, fileType, out);
/*  743:1086 */     return true;
/*  744:     */   }
/*  745:     */   
/*  746:     */   public static BufferedImage twistImage(BufferedImage srcImg, boolean bXDir, double dMultValue, double dPhase)
/*  747:     */   {
/*  748:1099 */     int w = srcImg.getWidth();
/*  749:1100 */     int h = srcImg.getHeight();
/*  750:1101 */     BufferedImage destImg = new BufferedImage(w, h, 1);
/*  751:     */     
/*  752:     */ 
/*  753:1104 */     Graphics g = destImg.getGraphics();
/*  754:1105 */     g.setColor(Color.WHITE);
/*  755:1106 */     g.fillRect(0, 0, w, h);
/*  756:1107 */     g.dispose();
/*  757:     */     
/*  758:1109 */     double dBaseAxisLen = bXDir ? h : w;
/*  759:1111 */     for (int i = 0; i < w; i++) {
/*  760:1112 */       for (int j = 0; j < h; j++)
/*  761:     */       {
/*  762:1113 */         double dx = 0.0D;
/*  763:1114 */         dx = bXDir ? 6.283185307179586D * j / dBaseAxisLen : 6.283185307179586D * i / dBaseAxisLen;
/*  764:1115 */         dx += dPhase;
/*  765:1116 */         double dy = Math.sin(dx);
/*  766:     */         
/*  767:     */ 
/*  768:1119 */         int nOldX = 0;int nOldY = 0;
/*  769:1120 */         nOldX = bXDir ? i + (int)(dy * dMultValue) : i;
/*  770:1121 */         nOldY = bXDir ? j : j + (int)(dy * dMultValue);
/*  771:     */         
/*  772:1123 */         int color = srcImg.getRGB(i, j);
/*  773:1124 */         if ((nOldX >= 0) && (nOldX < w) && (nOldY >= 0) && (nOldY < h)) {
/*  774:1125 */           destImg.setRGB(nOldX, nOldY, color);
/*  775:     */         }
/*  776:     */       }
/*  777:     */     }
/*  778:1130 */     return destImg;
/*  779:     */   }
/*  780:     */   
/*  781:     */   public static String getMd5Hex(byte[] bytes)
/*  782:     */   {
/*  783:1140 */     return DigestUtils.md5Hex(bytes);
/*  784:     */   }
/*  785:     */   
/*  786:     */   public static String getMd5Hex(File file)
/*  787:     */   {
/*  788:1159 */     return getMd5Hex(getBytes(file));
/*  789:     */   }
/*  790:     */   
/*  791:     */   public static byte[] getBytes(File file)
/*  792:     */   {
/*  793:     */     try
/*  794:     */     {
/*  795:1170 */       FileInputStream fis = new FileInputStream(file);
/*  796:1171 */       ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
/*  797:1172 */       byte[] b = new byte[1000];
/*  798:     */       int n;
/*  799:1174 */       while ((n = fis.read(b)) != -1) {
/*  800:1175 */         bos.write(b, 0, n);
/*  801:     */       }
/*  802:1177 */       fis.close();
/*  803:1178 */       bos.close();
/*  804:1179 */       return bos.toByteArray();
/*  805:     */     }
/*  806:     */     catch (IOException e)
/*  807:     */     {
/*  808:1181 */       e.printStackTrace();
/*  809:     */     }
/*  810:1183 */     return null;
/*  811:     */   }
/*  812:     */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.ImageUtil
 * JD-Core Version:    0.7.0.1
 */