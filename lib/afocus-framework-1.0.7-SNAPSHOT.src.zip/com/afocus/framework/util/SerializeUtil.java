/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import org.apache.log4j.Logger;
/*  4:   */ 
/*  5:   */ public class SerializeUtil
/*  6:   */ {
/*  7:18 */   protected static final Logger LOG = Logger.getLogger(SerializeUtil.class);
/*  8:   */   
/*  9:   */   /* Error */
/* 10:   */   public static byte[] serialize(Object object)
/* 11:   */   {
/* 12:   */     // Byte code:
/* 13:   */     //   0: new 2	java/io/ByteArrayOutputStream
/* 14:   */     //   3: dup
/* 15:   */     //   4: invokespecial 3	java/io/ByteArrayOutputStream:<init>	()V
/* 16:   */     //   7: astore_1
/* 17:   */     //   8: aconst_null
/* 18:   */     //   9: astore_2
/* 19:   */     //   10: new 4	java/io/ObjectOutputStream
/* 20:   */     //   13: dup
/* 21:   */     //   14: aload_1
/* 22:   */     //   15: invokespecial 5	java/io/ObjectOutputStream:<init>	(Ljava/io/OutputStream;)V
/* 23:   */     //   18: astore_3
/* 24:   */     //   19: aconst_null
/* 25:   */     //   20: astore 4
/* 26:   */     //   22: aload_3
/* 27:   */     //   23: aload_0
/* 28:   */     //   24: invokevirtual 6	java/io/ObjectOutputStream:writeObject	(Ljava/lang/Object;)V
/* 29:   */     //   27: aload_1
/* 30:   */     //   28: invokevirtual 7	java/io/ByteArrayOutputStream:toByteArray	()[B
/* 31:   */     //   31: astore 5
/* 32:   */     //   33: aload_3
/* 33:   */     //   34: ifnull +31 -> 65
/* 34:   */     //   37: aload 4
/* 35:   */     //   39: ifnull +22 -> 61
/* 36:   */     //   42: aload_3
/* 37:   */     //   43: invokevirtual 8	java/io/ObjectOutputStream:close	()V
/* 38:   */     //   46: goto +19 -> 65
/* 39:   */     //   49: astore 6
/* 40:   */     //   51: aload 4
/* 41:   */     //   53: aload 6
/* 42:   */     //   55: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 43:   */     //   58: goto +7 -> 65
/* 44:   */     //   61: aload_3
/* 45:   */     //   62: invokevirtual 8	java/io/ObjectOutputStream:close	()V
/* 46:   */     //   65: aload_1
/* 47:   */     //   66: ifnull +29 -> 95
/* 48:   */     //   69: aload_2
/* 49:   */     //   70: ifnull +21 -> 91
/* 50:   */     //   73: aload_1
/* 51:   */     //   74: invokevirtual 11	java/io/ByteArrayOutputStream:close	()V
/* 52:   */     //   77: goto +18 -> 95
/* 53:   */     //   80: astore 6
/* 54:   */     //   82: aload_2
/* 55:   */     //   83: aload 6
/* 56:   */     //   85: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 57:   */     //   88: goto +7 -> 95
/* 58:   */     //   91: aload_1
/* 59:   */     //   92: invokevirtual 11	java/io/ByteArrayOutputStream:close	()V
/* 60:   */     //   95: aload 5
/* 61:   */     //   97: areturn
/* 62:   */     //   98: astore 5
/* 63:   */     //   100: aload 5
/* 64:   */     //   102: astore 4
/* 65:   */     //   104: aload 5
/* 66:   */     //   106: athrow
/* 67:   */     //   107: astore 7
/* 68:   */     //   109: aload_3
/* 69:   */     //   110: ifnull +31 -> 141
/* 70:   */     //   113: aload 4
/* 71:   */     //   115: ifnull +22 -> 137
/* 72:   */     //   118: aload_3
/* 73:   */     //   119: invokevirtual 8	java/io/ObjectOutputStream:close	()V
/* 74:   */     //   122: goto +19 -> 141
/* 75:   */     //   125: astore 8
/* 76:   */     //   127: aload 4
/* 77:   */     //   129: aload 8
/* 78:   */     //   131: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 79:   */     //   134: goto +7 -> 141
/* 80:   */     //   137: aload_3
/* 81:   */     //   138: invokevirtual 8	java/io/ObjectOutputStream:close	()V
/* 82:   */     //   141: aload 7
/* 83:   */     //   143: athrow
/* 84:   */     //   144: astore_3
/* 85:   */     //   145: aload_3
/* 86:   */     //   146: astore_2
/* 87:   */     //   147: aload_3
/* 88:   */     //   148: athrow
/* 89:   */     //   149: astore 9
/* 90:   */     //   151: aload_1
/* 91:   */     //   152: ifnull +29 -> 181
/* 92:   */     //   155: aload_2
/* 93:   */     //   156: ifnull +21 -> 177
/* 94:   */     //   159: aload_1
/* 95:   */     //   160: invokevirtual 11	java/io/ByteArrayOutputStream:close	()V
/* 96:   */     //   163: goto +18 -> 181
/* 97:   */     //   166: astore 10
/* 98:   */     //   168: aload_2
/* 99:   */     //   169: aload 10
/* :0:   */     //   171: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* :1:   */     //   174: goto +7 -> 181
/* :2:   */     //   177: aload_1
/* :3:   */     //   178: invokevirtual 11	java/io/ByteArrayOutputStream:close	()V
/* :4:   */     //   181: aload 9
/* :5:   */     //   183: athrow
/* :6:   */     //   184: astore_1
/* :7:   */     //   185: getstatic 13	com/afocus/framework/util/SerializeUtil:LOG	Lorg/apache/log4j/Logger;
/* :8:   */     //   188: ldc 14
/* :9:   */     //   190: aload_1
/* ;0:   */     //   191: invokevirtual 15	org/apache/log4j/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/* ;1:   */     //   194: aconst_null
/* ;2:   */     //   195: areturn
/* ;3:   */     // Line number table:
/* ;4:   */     //   Java source line #27	-> byte code offset #0
/* ;5:   */     //   Java source line #28	-> byte code offset #10
/* ;6:   */     //   Java source line #27	-> byte code offset #19
/* ;7:   */     //   Java source line #29	-> byte code offset #22
/* ;8:   */     //   Java source line #30	-> byte code offset #27
/* ;9:   */     //   Java source line #31	-> byte code offset #33
/* <0:   */     //   Java source line #30	-> byte code offset #95
/* <1:   */     //   Java source line #27	-> byte code offset #98
/* <2:   */     //   Java source line #31	-> byte code offset #107
/* <3:   */     //   Java source line #27	-> byte code offset #144
/* <4:   */     //   Java source line #31	-> byte code offset #149
/* <5:   */     //   Java source line #32	-> byte code offset #185
/* <6:   */     //   Java source line #34	-> byte code offset #194
/* <7:   */     // Local variable table:
/* <8:   */     //   start	length	slot	name	signature
/* <9:   */     //   0	196	0	object	Object
/* =0:   */     //   7	171	1	baos	java.io.ByteArrayOutputStream
/* =1:   */     //   184	7	1	e	java.io.IOException
/* =2:   */     //   9	160	2	localThrowable6	java.lang.Throwable
/* =3:   */     //   18	120	3	oos	java.io.ObjectOutputStream
/* =4:   */     //   144	4	3	localThrowable4	java.lang.Throwable
/* =5:   */     //   20	108	4	localThrowable7	java.lang.Throwable
/* =6:   */     //   98	7	5	localThrowable2	java.lang.Throwable
/* =7:   */     //   98	7	5	localThrowable8	java.lang.Throwable
/* =8:   */     //   49	5	6	localThrowable	java.lang.Throwable
/* =9:   */     //   80	4	6	localThrowable1	java.lang.Throwable
/* >0:   */     //   107	35	7	localObject1	Object
/* >1:   */     //   125	5	8	localThrowable3	java.lang.Throwable
/* >2:   */     //   149	33	9	localObject2	Object
/* >3:   */     //   166	4	10	localThrowable5	java.lang.Throwable
/* >4:   */     // Exception table:
/* >5:   */     //   from	to	target	type
/* >6:   */     //   42	46	49	java/lang/Throwable
/* >7:   */     //   73	77	80	java/lang/Throwable
/* >8:   */     //   22	33	98	java/lang/Throwable
/* >9:   */     //   22	33	107	finally
/* ?0:   */     //   98	109	107	finally
/* ?1:   */     //   118	122	125	java/lang/Throwable
/* ?2:   */     //   10	65	144	java/lang/Throwable
/* ?3:   */     //   98	144	144	java/lang/Throwable
/* ?4:   */     //   10	65	149	finally
/* ?5:   */     //   98	151	149	finally
/* ?6:   */     //   159	163	166	java/lang/Throwable
/* ?7:   */     //   0	95	184	java/io/IOException
/* ?8:   */     //   98	184	184	java/io/IOException
/* ?9:   */   }
/* @0:   */   
/* @1:   */   /* Error */
/* @2:   */   public static Object unserialize(byte[] bytes)
/* @3:   */   {
/* @4:   */     // Byte code:
/* @5:   */     //   0: new 16	java/io/ByteArrayInputStream
/* @6:   */     //   3: dup
/* @7:   */     //   4: aload_0
/* @8:   */     //   5: invokespecial 17	java/io/ByteArrayInputStream:<init>	([B)V
/* @9:   */     //   8: astore_1
/* A0:   */     //   9: aconst_null
/* A1:   */     //   10: astore_2
/* A2:   */     //   11: new 18	java/io/ObjectInputStream
/* A3:   */     //   14: dup
/* A4:   */     //   15: aload_1
/* A5:   */     //   16: invokespecial 19	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
/* A6:   */     //   19: astore_3
/* A7:   */     //   20: aconst_null
/* A8:   */     //   21: astore 4
/* A9:   */     //   23: aload_3
/* B0:   */     //   24: invokevirtual 20	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
/* B1:   */     //   27: astore 5
/* B2:   */     //   29: aload_3
/* B3:   */     //   30: ifnull +31 -> 61
/* B4:   */     //   33: aload 4
/* B5:   */     //   35: ifnull +22 -> 57
/* B6:   */     //   38: aload_3
/* B7:   */     //   39: invokevirtual 21	java/io/ObjectInputStream:close	()V
/* B8:   */     //   42: goto +19 -> 61
/* B9:   */     //   45: astore 6
/* C0:   */     //   47: aload 4
/* C1:   */     //   49: aload 6
/* C2:   */     //   51: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* C3:   */     //   54: goto +7 -> 61
/* C4:   */     //   57: aload_3
/* C5:   */     //   58: invokevirtual 21	java/io/ObjectInputStream:close	()V
/* C6:   */     //   61: aload_1
/* C7:   */     //   62: ifnull +29 -> 91
/* C8:   */     //   65: aload_2
/* C9:   */     //   66: ifnull +21 -> 87
/* D0:   */     //   69: aload_1
/* D1:   */     //   70: invokevirtual 22	java/io/ByteArrayInputStream:close	()V
/* D2:   */     //   73: goto +18 -> 91
/* D3:   */     //   76: astore 6
/* D4:   */     //   78: aload_2
/* D5:   */     //   79: aload 6
/* D6:   */     //   81: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* D7:   */     //   84: goto +7 -> 91
/* D8:   */     //   87: aload_1
/* D9:   */     //   88: invokevirtual 22	java/io/ByteArrayInputStream:close	()V
/* E0:   */     //   91: aload 5
/* E1:   */     //   93: areturn
/* E2:   */     //   94: astore 5
/* E3:   */     //   96: aload 5
/* E4:   */     //   98: astore 4
/* E5:   */     //   100: aload 5
/* E6:   */     //   102: athrow
/* E7:   */     //   103: astore 7
/* E8:   */     //   105: aload_3
/* E9:   */     //   106: ifnull +31 -> 137
/* F0:   */     //   109: aload 4
/* F1:   */     //   111: ifnull +22 -> 133
/* F2:   */     //   114: aload_3
/* F3:   */     //   115: invokevirtual 21	java/io/ObjectInputStream:close	()V
/* F4:   */     //   118: goto +19 -> 137
/* F5:   */     //   121: astore 8
/* F6:   */     //   123: aload 4
/* F7:   */     //   125: aload 8
/* F8:   */     //   127: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* F9:   */     //   130: goto +7 -> 137
/* G0:   */     //   133: aload_3
/* G1:   */     //   134: invokevirtual 21	java/io/ObjectInputStream:close	()V
/* G2:   */     //   137: aload 7
/* G3:   */     //   139: athrow
/* G4:   */     //   140: astore_3
/* G5:   */     //   141: aload_3
/* G6:   */     //   142: astore_2
/* G7:   */     //   143: aload_3
/* G8:   */     //   144: athrow
/* G9:   */     //   145: astore 9
/* H0:   */     //   147: aload_1
/* H1:   */     //   148: ifnull +29 -> 177
/* H2:   */     //   151: aload_2
/* H3:   */     //   152: ifnull +21 -> 173
/* H4:   */     //   155: aload_1
/* H5:   */     //   156: invokevirtual 22	java/io/ByteArrayInputStream:close	()V
/* H6:   */     //   159: goto +18 -> 177
/* H7:   */     //   162: astore 10
/* H8:   */     //   164: aload_2
/* H9:   */     //   165: aload 10
/* I0:   */     //   167: invokevirtual 10	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* I1:   */     //   170: goto +7 -> 177
/* I2:   */     //   173: aload_1
/* I3:   */     //   174: invokevirtual 22	java/io/ByteArrayInputStream:close	()V
/* I4:   */     //   177: aload 9
/* I5:   */     //   179: athrow
/* I6:   */     //   180: astore_1
/* I7:   */     //   181: getstatic 13	com/afocus/framework/util/SerializeUtil:LOG	Lorg/apache/log4j/Logger;
/* I8:   */     //   184: ldc 24
/* I9:   */     //   186: aload_1
/* J0:   */     //   187: invokevirtual 15	org/apache/log4j/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/* J1:   */     //   190: aconst_null
/* J2:   */     //   191: areturn
/* J3:   */     // Line number table:
/* J4:   */     //   Java source line #44	-> byte code offset #0
/* J5:   */     //   Java source line #45	-> byte code offset #11
/* J6:   */     //   Java source line #44	-> byte code offset #20
/* J7:   */     //   Java source line #46	-> byte code offset #23
/* J8:   */     //   Java source line #47	-> byte code offset #29
/* J9:   */     //   Java source line #46	-> byte code offset #91
/* K0:   */     //   Java source line #44	-> byte code offset #94
/* K1:   */     //   Java source line #47	-> byte code offset #103
/* K2:   */     //   Java source line #44	-> byte code offset #140
/* K3:   */     //   Java source line #47	-> byte code offset #145
/* K4:   */     //   Java source line #48	-> byte code offset #181
/* K5:   */     //   Java source line #50	-> byte code offset #190
/* K6:   */     // Local variable table:
/* K7:   */     //   start	length	slot	name	signature
/* K8:   */     //   0	192	0	bytes	byte[]
/* K9:   */     //   8	166	1	bais	java.io.ByteArrayInputStream
/* L0:   */     //   180	7	1	e	java.lang.Exception
/* L1:   */     //   10	155	2	localThrowable6	java.lang.Throwable
/* L2:   */     //   19	115	3	ois	java.io.ObjectInputStream
/* L3:   */     //   140	4	3	localThrowable4	java.lang.Throwable
/* L4:   */     //   21	103	4	localThrowable7	java.lang.Throwable
/* L5:   */     //   94	7	5	localThrowable2	java.lang.Throwable
/* L6:   */     //   94	7	5	localThrowable8	java.lang.Throwable
/* L7:   */     //   45	5	6	localThrowable	java.lang.Throwable
/* L8:   */     //   76	4	6	localThrowable1	java.lang.Throwable
/* L9:   */     //   103	35	7	localObject2	Object
/* M0:   */     //   121	5	8	localThrowable3	java.lang.Throwable
/* M1:   */     //   145	33	9	localObject3	Object
/* M2:   */     //   162	4	10	localThrowable5	java.lang.Throwable
/* M3:   */     // Exception table:
/* M4:   */     //   from	to	target	type
/* M5:   */     //   38	42	45	java/lang/Throwable
/* M6:   */     //   69	73	76	java/lang/Throwable
/* M7:   */     //   23	29	94	java/lang/Throwable
/* M8:   */     //   23	29	103	finally
/* M9:   */     //   94	105	103	finally
/* N0:   */     //   114	118	121	java/lang/Throwable
/* N1:   */     //   11	61	140	java/lang/Throwable
/* N2:   */     //   94	140	140	java/lang/Throwable
/* N3:   */     //   11	61	145	finally
/* N4:   */     //   94	147	145	finally
/* N5:   */     //   155	159	162	java/lang/Throwable
/* N6:   */     //   0	91	180	java/lang/ClassNotFoundException
/* N7:   */     //   0	91	180	java/io/IOException
/* N8:   */     //   94	180	180	java/lang/ClassNotFoundException
/* N9:   */     //   94	180	180	java/io/IOException
/* O0:   */   }
/* O1:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.SerializeUtil
 * JD-Core Version:    0.7.0.1
 */