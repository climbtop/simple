/*   1:    */ package com.afocus.framework.util.crypt;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.security.NoSuchAlgorithmException;
/*   5:    */ import java.security.SecureRandom;
/*   6:    */ import javax.crypto.Cipher;
/*   7:    */ import javax.crypto.KeyGenerator;
/*   8:    */ import javax.crypto.SecretKey;
/*   9:    */ import javax.crypto.SecretKeyFactory;
/*  10:    */ import javax.crypto.spec.DESKeySpec;
/*  11:    */ import javax.crypto.spec.IvParameterSpec;
/*  12:    */ 
/*  13:    */ public class DES
/*  14:    */ {
/*  15:    */   public static byte[] generateKey()
/*  16:    */   {
/*  17:    */     try
/*  18:    */     {
/*  19: 27 */       SecureRandom sr = new SecureRandom();
/*  20:    */       
/*  21:    */ 
/*  22: 30 */       KeyGenerator kg = KeyGenerator.getInstance("DES");
/*  23: 31 */       kg.init(sr);
/*  24:    */       
/*  25:    */ 
/*  26: 34 */       SecretKey secretKey = kg.generateKey();
/*  27:    */       
/*  28:    */ 
/*  29: 37 */       return secretKey.getEncoded();
/*  30:    */     }
/*  31:    */     catch (NoSuchAlgorithmException e)
/*  32:    */     {
/*  33: 41 */       System.err.println("DES算法，生成密钥出错!");
/*  34: 42 */       e.printStackTrace();
/*  35:    */     }
/*  36: 45 */     return null;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static byte[] encrypt(byte[] data, byte[] key)
/*  40:    */   {
/*  41:    */     try
/*  42:    */     {
/*  43: 62 */       SecureRandom sr = new SecureRandom();
/*  44:    */       
/*  45:    */ 
/*  46: 65 */       DESKeySpec dks = new DESKeySpec(key);
/*  47:    */       
/*  48:    */ 
/*  49:    */ 
/*  50: 69 */       SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
/*  51: 70 */       SecretKey secretKey = keyFactory.generateSecret(dks);
/*  52:    */       
/*  53:    */ 
/*  54: 73 */       Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
/*  55:    */       
/*  56:    */ 
/*  57: 76 */       cipher.init(1, secretKey, sr);
/*  58:    */       
/*  59:    */ 
/*  60: 79 */       return cipher.doFinal(data);
/*  61:    */     }
/*  62:    */     catch (Exception e)
/*  63:    */     {
/*  64: 83 */       System.err.println("DES算法，加密数据出错!");
/*  65: 84 */       e.printStackTrace();
/*  66:    */     }
/*  67: 87 */     return null;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static byte[] decrypt(byte[] data, byte[] key)
/*  71:    */   {
/*  72:    */     try
/*  73:    */     {
/*  74:102 */       SecureRandom sr = new SecureRandom();
/*  75:    */       
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:107 */       DESKeySpec dks = new DESKeySpec(key);
/*  80:    */       
/*  81:    */ 
/*  82:    */ 
/*  83:111 */       SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
/*  84:112 */       SecretKey secretKey = keyFactory.generateSecret(dks);
/*  85:    */       
/*  86:    */ 
/*  87:115 */       Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
/*  88:    */       
/*  89:    */ 
/*  90:118 */       cipher.init(2, secretKey, sr);
/*  91:    */       
/*  92:    */ 
/*  93:121 */       return cipher.doFinal(data);
/*  94:    */     }
/*  95:    */     catch (Exception e)
/*  96:    */     {
/*  97:125 */       System.err.println("DES算法，解密出错。");
/*  98:126 */       e.printStackTrace();
/*  99:    */     }
/* 100:129 */     return null;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static byte[] CBCEncrypt(byte[] data, byte[] key, byte[] iv)
/* 104:    */   {
/* 105:    */     try
/* 106:    */     {
/* 107:145 */       DESKeySpec dks = new DESKeySpec(key);
/* 108:    */       
/* 109:    */ 
/* 110:    */ 
/* 111:149 */       SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
/* 112:150 */       SecretKey secretKey = keyFactory.generateSecret(dks);
/* 113:    */       
/* 114:    */ 
/* 115:153 */       Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
/* 116:    */       
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:158 */       IvParameterSpec param = new IvParameterSpec(iv);
/* 121:159 */       cipher.init(1, secretKey, param);
/* 122:    */       
/* 123:    */ 
/* 124:162 */       return cipher.doFinal(data);
/* 125:    */     }
/* 126:    */     catch (Exception e)
/* 127:    */     {
/* 128:166 */       System.err.println("DES算法，加密数据出错!");
/* 129:167 */       e.printStackTrace();
/* 130:    */     }
/* 131:170 */     return null;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static byte[] CBCDecrypt(byte[] data, byte[] key, byte[] iv)
/* 135:    */   {
/* 136:    */     try
/* 137:    */     {
/* 138:185 */       DESKeySpec dks = new DESKeySpec(key);
/* 139:    */       
/* 140:    */ 
/* 141:    */ 
/* 142:189 */       SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
/* 143:190 */       SecretKey secretKey = keyFactory.generateSecret(dks);
/* 144:    */       
/* 145:    */ 
/* 146:193 */       Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
/* 147:    */       
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:198 */       IvParameterSpec param = new IvParameterSpec(iv);
/* 152:199 */       cipher.init(2, secretKey, param);
/* 153:    */       
/* 154:    */ 
/* 155:202 */       return cipher.doFinal(data);
/* 156:    */     }
/* 157:    */     catch (Exception e)
/* 158:    */     {
/* 159:206 */       System.err.println("DES算法，解密出错。");
/* 160:207 */       e.printStackTrace();
/* 161:    */     }
/* 162:210 */     return null;
/* 163:    */   }
/* 164:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.crypt.DES
 * JD-Core Version:    0.7.0.1
 */