/*  1:   */ package com.afocus.framework.util.crypt;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.security.InvalidKeyException;
/*  5:   */ import java.security.NoSuchAlgorithmException;
/*  6:   */ import java.security.spec.InvalidKeySpecException;
/*  7:   */ import javax.crypto.BadPaddingException;
/*  8:   */ import javax.crypto.Cipher;
/*  9:   */ import javax.crypto.IllegalBlockSizeException;
/* 10:   */ import javax.crypto.NoSuchPaddingException;
/* 11:   */ import javax.crypto.SecretKey;
/* 12:   */ import javax.crypto.spec.SecretKeySpec;
/* 13:   */ import sun.misc.BASE64Decoder;
/* 14:   */ 
/* 15:   */ public class DESede
/* 16:   */ {
/* 17:15 */   private static String Algorithm = "DESede";
/* 18:   */   
/* 19:   */   public static String createDecryptor(String parm, String key)
/* 20:   */     throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeySpecException, IOException
/* 21:   */   {
/* 22:25 */     BASE64Decoder dec = new BASE64Decoder();
/* 23:26 */     byte[] dKey = dec.decodeBuffer(key);
/* 24:27 */     byte[] cipherByte = null;
/* 25:   */     try
/* 26:   */     {
/* 27:29 */       SecretKey deskey = new SecretKeySpec(dKey, Algorithm);
/* 28:30 */       Cipher c = Cipher.getInstance(Algorithm);
/* 29:31 */       byte[] dnParm = dec.decodeBuffer(parm);
/* 30:32 */       c.init(2, deskey);
/* 31:33 */       cipherByte = c.doFinal(dnParm);
/* 32:   */     }
/* 33:   */     catch (InvalidKeyException ex)
/* 34:   */     {
/* 35:37 */       ex.printStackTrace();
/* 36:   */     }
/* 37:   */     catch (BadPaddingException ex)
/* 38:   */     {
/* 39:40 */       ex.printStackTrace();
/* 40:   */     }
/* 41:   */     catch (IllegalBlockSizeException ex)
/* 42:   */     {
/* 43:43 */       ex.printStackTrace();
/* 44:   */     }
/* 45:45 */     return new String(cipherByte, "UTF-8");
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.crypt.DESede
 * JD-Core Version:    0.7.0.1
 */