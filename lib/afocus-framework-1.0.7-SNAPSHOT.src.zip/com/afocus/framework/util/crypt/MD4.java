/*   1:    */ package com.afocus.framework.util.crypt;
/*   2:    */ 
/*   3:    */ public class MD4
/*   4:    */ {
/*   5:    */   private static int A;
/*   6:    */   private static int B;
/*   7:    */   private static int C;
/*   8:    */   private static int D;
/*   9: 13 */   private static int[] X = new int[16];
/*  10:    */   
/*  11:    */   private static int F(int X, int Y, int Z)
/*  12:    */   {
/*  13: 17 */     return X & Y | (X ^ 0xFFFFFFFF) & Z;
/*  14:    */   }
/*  15:    */   
/*  16:    */   private static int G(int X, int Y, int Z)
/*  17:    */   {
/*  18: 22 */     return X & Y | X & Z | Y & Z;
/*  19:    */   }
/*  20:    */   
/*  21:    */   private static int H(int X, int Y, int Z)
/*  22:    */   {
/*  23: 27 */     return X ^ Y ^ Z;
/*  24:    */   }
/*  25:    */   
/*  26:    */   private static int lshift(int x, int s)
/*  27:    */   {
/*  28: 32 */     if (s == 0) {
/*  29: 32 */       return x;
/*  30:    */     }
/*  31: 33 */     return x << s & 0xFFFFFFFF | x >> 32 - s & 2147483647 >> 31 - s;
/*  32:    */   }
/*  33:    */   
/*  34:    */   private static int ROUND1(int a, int b, int c, int d, int k, int s)
/*  35:    */   {
/*  36: 37 */     return lshift(a + F(b, c, d) + X[k], s);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private static int ROUND2(int a, int b, int c, int d, int k, int s)
/*  40:    */   {
/*  41: 41 */     return lshift(a + G(b, c, d) + X[k] + 1518500249, s);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static int ROUND3(int a, int b, int c, int d, int k, int s)
/*  45:    */   {
/*  46: 45 */     return lshift(a + H(b, c, d) + X[k] + 1859775393, s);
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static void mdfour64(int[] M)
/*  50:    */   {
/*  51: 55 */     for (int j = 0; j < 16; j++) {
/*  52: 56 */       X[j] = M[j];
/*  53:    */     }
/*  54: 58 */     int AA = A;int BB = B;int CC = C;int DD = D;
/*  55:    */     
/*  56: 60 */     A = ROUND1(A, B, C, D, 0, 3);D = ROUND1(D, A, B, C, 1, 7);
/*  57: 61 */     C = ROUND1(C, D, A, B, 2, 11);B = ROUND1(B, C, D, A, 3, 19);
/*  58: 62 */     A = ROUND1(A, B, C, D, 4, 3);D = ROUND1(D, A, B, C, 5, 7);
/*  59: 63 */     C = ROUND1(C, D, A, B, 6, 11);B = ROUND1(B, C, D, A, 7, 19);
/*  60: 64 */     A = ROUND1(A, B, C, D, 8, 3);D = ROUND1(D, A, B, C, 9, 7);
/*  61: 65 */     C = ROUND1(C, D, A, B, 10, 11);B = ROUND1(B, C, D, A, 11, 19);
/*  62: 66 */     A = ROUND1(A, B, C, D, 12, 3);D = ROUND1(D, A, B, C, 13, 7);
/*  63: 67 */     C = ROUND1(C, D, A, B, 14, 11);B = ROUND1(B, C, D, A, 15, 19);
/*  64:    */     
/*  65: 69 */     A = ROUND2(A, B, C, D, 0, 3);D = ROUND2(D, A, B, C, 4, 5);
/*  66: 70 */     C = ROUND2(C, D, A, B, 8, 9);B = ROUND2(B, C, D, A, 12, 13);
/*  67: 71 */     A = ROUND2(A, B, C, D, 1, 3);D = ROUND2(D, A, B, C, 5, 5);
/*  68: 72 */     C = ROUND2(C, D, A, B, 9, 9);B = ROUND2(B, C, D, A, 13, 13);
/*  69: 73 */     A = ROUND2(A, B, C, D, 2, 3);D = ROUND2(D, A, B, C, 6, 5);
/*  70: 74 */     C = ROUND2(C, D, A, B, 10, 9);B = ROUND2(B, C, D, A, 14, 13);
/*  71: 75 */     A = ROUND2(A, B, C, D, 3, 3);D = ROUND2(D, A, B, C, 7, 5);
/*  72: 76 */     C = ROUND2(C, D, A, B, 11, 9);B = ROUND2(B, C, D, A, 15, 13);
/*  73:    */     
/*  74: 78 */     A = ROUND3(A, B, C, D, 0, 3);D = ROUND3(D, A, B, C, 8, 9);
/*  75: 79 */     C = ROUND3(C, D, A, B, 4, 11);B = ROUND3(B, C, D, A, 12, 15);
/*  76: 80 */     A = ROUND3(A, B, C, D, 2, 3);D = ROUND3(D, A, B, C, 10, 9);
/*  77: 81 */     C = ROUND3(C, D, A, B, 6, 11);B = ROUND3(B, C, D, A, 14, 15);
/*  78: 82 */     A = ROUND3(A, B, C, D, 1, 3);D = ROUND3(D, A, B, C, 9, 9);
/*  79: 83 */     C = ROUND3(C, D, A, B, 5, 11);B = ROUND3(B, C, D, A, 13, 15);
/*  80: 84 */     A = ROUND3(A, B, C, D, 3, 3);D = ROUND3(D, A, B, C, 11, 9);
/*  81: 85 */     C = ROUND3(C, D, A, B, 7, 11);B = ROUND3(B, C, D, A, 15, 15);
/*  82:    */     
/*  83: 87 */     A += AA;B += BB;C += CC;D += DD;
/*  84:    */     
/*  85: 89 */     A &= 0xFFFFFFFF;B &= 0xFFFFFFFF;
/*  86: 90 */     C &= 0xFFFFFFFF;D &= 0xFFFFFFFF;
/*  87:    */   }
/*  88:    */   
/*  89:    */   private static void copy64(int[] M, byte[] in, int offset)
/*  90:    */   {
/*  91: 97 */     for (int i = 0; i < 16; i++) {
/*  92: 98 */       M[i] = (in[(offset + i * 4 + 3)] << 24 & 0xFF000000 | in[(offset + i * 4 + 2)] << 16 & 0xFF0000 | in[(offset + i * 4 + 1)] << 8 & 0xFF00 | in[(offset + i * 4 + 0)] & 0xFF);
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   private static void copy64(int[] M, byte[] in)
/*  97:    */   {
/*  98:105 */     copy64(M, in, 0);
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static void copy4(byte[] out, int offset, int x)
/* 102:    */   {
/* 103:111 */     out[offset] = ((byte)(x & 0xFF));
/* 104:112 */     out[(1 + offset)] = ((byte)(x >> 8 & 0xFF));
/* 105:113 */     out[(2 + offset)] = ((byte)(x >> 16 & 0xFF));
/* 106:114 */     out[(3 + offset)] = ((byte)(x >> 24 & 0xFF));
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static byte[] digest(byte[] in)
/* 110:    */   {
/* 111:123 */     byte[] out = new byte[16];
/* 112:124 */     byte[] buf = new byte[''];
/* 113:125 */     int n = in.length;
/* 114:126 */     int[] M = new int[16];
/* 115:127 */     int b = n * 8;
/* 116:    */     
/* 117:    */ 
/* 118:    */ 
/* 119:131 */     A = 1732584193;
/* 120:132 */     B = -271733879;
/* 121:133 */     C = -1732584194;
/* 122:134 */     D = 271733878;
/* 123:    */     
/* 124:136 */     int offset = 0;
/* 125:137 */     while (n > 64)
/* 126:    */     {
/* 127:138 */       copy64(M, in, offset);
/* 128:139 */       mdfour64(M);
/* 129:140 */       offset += 64;
/* 130:141 */       n -= 64;
/* 131:    */     }
/* 132:144 */     for (int i = 0; i < 128; i++) {
/* 133:145 */       buf[i] = (i + offset < in.length ? in[(offset + i)] : 0);
/* 134:    */     }
/* 135:146 */     buf[n] = -128;
/* 136:148 */     if (n <= 55)
/* 137:    */     {
/* 138:149 */       copy4(buf, 56, b);
/* 139:150 */       copy64(M, buf);
/* 140:151 */       mdfour64(M);
/* 141:    */     }
/* 142:    */     else
/* 143:    */     {
/* 144:153 */       copy4(buf, 120, b);
/* 145:154 */       copy64(M, buf);
/* 146:155 */       mdfour64(M);
/* 147:156 */       copy64(M, buf, 64);
/* 148:157 */       mdfour64(M);
/* 149:    */     }
/* 150:160 */     for (i = 0; i < 128; i++) {
/* 151:161 */       buf[i] = 0;
/* 152:    */     }
/* 153:162 */     copy64(M, buf);
/* 154:    */     
/* 155:164 */     copy4(out, 0, A);
/* 156:165 */     copy4(out, 4, B);
/* 157:166 */     copy4(out, 8, C);
/* 158:167 */     copy4(out, 12, D);
/* 159:    */     
/* 160:169 */     A = MD4.B = MD4.C = MD4.D = 0;
/* 161:170 */     return out;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static void main(String[] args)
/* 165:    */   {
/* 166:177 */     digest("TST".getBytes());
/* 167:    */   }
/* 168:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.crypt.MD4
 * JD-Core Version:    0.7.0.1
 */