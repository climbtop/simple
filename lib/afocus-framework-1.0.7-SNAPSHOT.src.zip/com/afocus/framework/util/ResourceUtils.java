/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileNotFoundException;
/*   5:    */ import java.net.MalformedURLException;
/*   6:    */ import java.net.URI;
/*   7:    */ import java.net.URISyntaxException;
/*   8:    */ import java.net.URL;
/*   9:    */ 
/*  10:    */ @Deprecated
/*  11:    */ public abstract class ResourceUtils
/*  12:    */ {
/*  13:    */   public static final String CLASSPATH_URL_PREFIX = "classpath:";
/*  14:    */   public static final String FILE_URL_PREFIX = "file:";
/*  15:    */   public static final String URL_PROTOCOL_FILE = "file";
/*  16:    */   public static final String URL_PROTOCOL_JAR = "jar";
/*  17:    */   public static final String URL_PROTOCOL_ZIP = "zip";
/*  18:    */   public static final String URL_PROTOCOL_VFSZIP = "vfszip";
/*  19:    */   public static final String URL_PROTOCOL_VFS = "vfs";
/*  20:    */   public static final String URL_PROTOCOL_WSJAR = "wsjar";
/*  21:    */   public static final String URL_PROTOCOL_CODE_SOURCE = "code-source";
/*  22:    */   public static final String JAR_URL_SEPARATOR = "!/";
/*  23:    */   
/*  24:    */   public static boolean isUrl(String resourceLocation)
/*  25:    */   {
/*  26: 25 */     if (resourceLocation == null) {
/*  27: 26 */       return false;
/*  28:    */     }
/*  29: 28 */     if (resourceLocation.startsWith("classpath:")) {
/*  30: 29 */       return true;
/*  31:    */     }
/*  32:    */     try
/*  33:    */     {
/*  34: 31 */       new URL(resourceLocation);
/*  35: 32 */       return true;
/*  36:    */     }
/*  37:    */     catch (MalformedURLException localMalformedURLException) {}
/*  38: 35 */     return false;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static URL getURL(String resourceLocation)
/*  42:    */     throws FileNotFoundException
/*  43:    */   {
/*  44: 40 */     if (resourceLocation.startsWith("classpath:"))
/*  45:    */     {
/*  46: 41 */       String path = resourceLocation.substring("classpath:".length());
/*  47: 42 */       URL url = ResourceUtils.class.getClassLoader().getResource(path);
/*  48: 43 */       if (url == null)
/*  49:    */       {
/*  50: 44 */         String description = "class path resource [" + path + "]";
/*  51: 45 */         throw new FileNotFoundException(description + " cannot be resolved to URL because it does not exist");
/*  52:    */       }
/*  53: 49 */       return url;
/*  54:    */     }
/*  55:    */     try
/*  56:    */     {
/*  57: 52 */       return new URL(resourceLocation);
/*  58:    */     }
/*  59:    */     catch (MalformedURLException localMalformedURLException1)
/*  60:    */     {
/*  61:    */       try
/*  62:    */       {
/*  63: 55 */         return new File(resourceLocation).toURI().toURL();
/*  64:    */       }
/*  65:    */       catch (MalformedURLException localMalformedURLException2)
/*  66:    */       {
/*  67: 57 */         throw new FileNotFoundException("Resource location [" + resourceLocation + "] is neither a URL not a well-formed file path");
/*  68:    */       }
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static File getFile(String resourceLocation)
/*  73:    */     throws FileNotFoundException
/*  74:    */   {
/*  75: 66 */     if (resourceLocation.startsWith("classpath:"))
/*  76:    */     {
/*  77: 67 */       String path = resourceLocation.substring("classpath:".length());
/*  78: 68 */       String description = "class path resource [" + path + "]";
/*  79: 69 */       URL url = ResourceUtils.class.getClassLoader().getResource(path);
/*  80: 70 */       if (url == null) {
/*  81: 71 */         throw new FileNotFoundException(description + " cannot be resolved to absolute file path because it does not reside in the file system");
/*  82:    */       }
/*  83: 75 */       return getFile(url, description);
/*  84:    */     }
/*  85:    */     try
/*  86:    */     {
/*  87: 78 */       return getFile(new URL(resourceLocation));
/*  88:    */     }
/*  89:    */     catch (MalformedURLException localMalformedURLException) {}
/*  90: 81 */     return new File(resourceLocation);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static File getFile(URL resourceUrl)
/*  94:    */     throws FileNotFoundException
/*  95:    */   {
/*  96: 85 */     return getFile(resourceUrl, "URL");
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static File getFile(URL resourceUrl, String description)
/* 100:    */     throws FileNotFoundException
/* 101:    */   {
/* 102: 90 */     if (!"file".equals(resourceUrl.getProtocol())) {
/* 103: 91 */       throw new FileNotFoundException(description + " cannot be resolved to absolute file path because it does not reside in the file system: " + resourceUrl);
/* 104:    */     }
/* 105:    */     try
/* 106:    */     {
/* 107: 96 */       return new File(toURI(resourceUrl).getSchemeSpecificPart());
/* 108:    */     }
/* 109:    */     catch (URISyntaxException localURISyntaxException) {}
/* 110: 99 */     return new File(resourceUrl.getFile());
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static File getFile(URI resourceUri)
/* 114:    */     throws FileNotFoundException
/* 115:    */   {
/* 116:103 */     return getFile(resourceUri, "URI");
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static File getFile(URI resourceUri, String description)
/* 120:    */     throws FileNotFoundException
/* 121:    */   {
/* 122:108 */     if (!"file".equals(resourceUri.getScheme())) {
/* 123:109 */       throw new FileNotFoundException(description + " cannot be resolved to absolute file path because it does not reside in the file system: " + resourceUri);
/* 124:    */     }
/* 125:114 */     return new File(resourceUri.getSchemeSpecificPart());
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static boolean isJarURL(URL url)
/* 129:    */   {
/* 130:118 */     String protocol = url.getProtocol();
/* 131:    */     
/* 132:120 */     return ("jar".equals(protocol)) || ("zip".equals(protocol)) || 
/* 133:121 */       ("wsjar".equals(protocol)) || (
/* 134:122 */       ("code-source".equals(protocol)) && (url.getPath().contains("!/")));
/* 135:    */   }
/* 136:    */   
/* 137:    */   public static URL extractJarFileURL(URL jarUrl)
/* 138:    */     throws MalformedURLException
/* 139:    */   {
/* 140:127 */     String urlFile = jarUrl.getFile();
/* 141:128 */     int separatorIndex = urlFile.indexOf("!/");
/* 142:129 */     if (separatorIndex != -1)
/* 143:    */     {
/* 144:130 */       String jarFile = urlFile.substring(0, separatorIndex);
/* 145:    */       try
/* 146:    */       {
/* 147:132 */         return new URL(jarFile);
/* 148:    */       }
/* 149:    */       catch (MalformedURLException localMalformedURLException)
/* 150:    */       {
/* 151:134 */         if (!jarFile.startsWith("/")) {
/* 152:135 */           jarFile = "/" + jarFile;
/* 153:    */         }
/* 154:137 */         return new URL("file:" + jarFile);
/* 155:    */       }
/* 156:    */     }
/* 157:141 */     return jarUrl;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static URI toURI(URL url)
/* 161:    */     throws URISyntaxException
/* 162:    */   {
/* 163:145 */     return toURI(url.toString());
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static URI toURI(String location)
/* 167:    */     throws URISyntaxException
/* 168:    */   {
/* 169:149 */     return new URI(replace(location, " ", "%20"));
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static String replace(String inString, String oldPattern, String newPattern)
/* 173:    */   {
/* 174:154 */     if ((!hasLength(inString)) || (!hasLength(oldPattern)) || (newPattern == null)) {
/* 175:156 */       return inString;
/* 176:    */     }
/* 177:158 */     StringBuilder sb = new StringBuilder();
/* 178:159 */     int pos = 0;
/* 179:160 */     int index = inString.indexOf(oldPattern);
/* 180:    */     
/* 181:162 */     int patLen = oldPattern.length();
/* 182:163 */     while (index >= 0)
/* 183:    */     {
/* 184:164 */       sb.append(inString.substring(pos, index));
/* 185:165 */       sb.append(newPattern);
/* 186:166 */       pos = index + patLen;
/* 187:167 */       index = inString.indexOf(oldPattern, pos);
/* 188:    */     }
/* 189:169 */     sb.append(inString.substring(pos));
/* 190:    */     
/* 191:171 */     return sb.toString();
/* 192:    */   }
/* 193:    */   
/* 194:    */   public static boolean hasLength(CharSequence str)
/* 195:    */   {
/* 196:175 */     return (str != null) && (str.length() > 0);
/* 197:    */   }
/* 198:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.ResourceUtils
 * JD-Core Version:    0.7.0.1
 */