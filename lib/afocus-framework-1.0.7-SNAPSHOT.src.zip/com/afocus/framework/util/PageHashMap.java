/*  1:   */ package com.afocus.framework.util;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.util.HashMap;
/*  5:   */ 
/*  6:   */ public class PageHashMap<K, V>
/*  7:   */   extends HashMap<K, V>
/*  8:   */   implements Serializable
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = 1963503083952338317L;
/* 11:   */   private PageTurn pageTurn;
/* 12:   */   
/* 13:   */   public PageTurn getPageTurn()
/* 14:   */   {
/* 15:19 */     return this.pageTurn;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setPageTurn(PageTurn pageTurn)
/* 19:   */   {
/* 20:26 */     this.pageTurn = pageTurn;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String toString()
/* 24:   */   {
/* 25:30 */     return "pageHashMap:" + super.toString() + ",pageTurn:" + this.pageTurn.toString();
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.PageHashMap
 * JD-Core Version:    0.7.0.1
 */