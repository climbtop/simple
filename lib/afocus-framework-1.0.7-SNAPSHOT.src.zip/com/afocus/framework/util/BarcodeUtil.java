/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import com.google.zxing.BarcodeFormat;
/*   4:    */ import com.google.zxing.EncodeHintType;
/*   5:    */ import com.google.zxing.MultiFormatWriter;
/*   6:    */ import com.google.zxing.WriterException;
/*   7:    */ import com.google.zxing.common.BitMatrix;
/*   8:    */ import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
/*   9:    */ import java.awt.Color;
/*  10:    */ import java.awt.Graphics2D;
/*  11:    */ import java.awt.Image;
/*  12:    */ import java.awt.geom.AffineTransform;
/*  13:    */ import java.awt.image.AffineTransformOp;
/*  14:    */ import java.awt.image.BufferedImage;
/*  15:    */ import java.awt.image.WritableRaster;
/*  16:    */ import java.io.File;
/*  17:    */ import java.io.IOException;
/*  18:    */ import java.util.HashMap;
/*  19:    */ import java.util.Map;
/*  20:    */ import javax.imageio.ImageIO;
/*  21:    */ 
/*  22:    */ public class BarcodeUtil
/*  23:    */ {
/*  24:    */   private static final int IMAGE_WIDTH = 80;
/*  25:    */   private static final int IMAGE_HEIGHT = 80;
/*  26:    */   private static final int IMAGE_HALF_WIDTH = 40;
/*  27:    */   private static final int FRAME_WIDTH = 2;
/*  28: 38 */   private static MultiFormatWriter mutiWriter = new MultiFormatWriter();
/*  29:    */   
/*  30:    */   public static void encode(String content, int width, int height, String srcImagePath, String destImagePath)
/*  31:    */   {
/*  32:    */     try
/*  33:    */     {
/*  34: 43 */       ImageIO.write(genBarcode(content, width, height, srcImagePath), "jpg", new File(destImagePath));
/*  35:    */     }
/*  36:    */     catch (IOException e)
/*  37:    */     {
/*  38: 46 */       e.printStackTrace();
/*  39:    */     }
/*  40:    */     catch (WriterException e)
/*  41:    */     {
/*  42: 48 */       e.printStackTrace();
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   private static BufferedImage genBarcode(String content, int width, int height, String srcImagePath)
/*  47:    */     throws WriterException, IOException
/*  48:    */   {
/*  49: 56 */     BufferedImage scaleImage = scale(srcImagePath, 80, 80, true);
/*  50:    */     
/*  51: 58 */     int[][] srcPixels = new int[80][80];
/*  52: 59 */     for (int i = 0; i < scaleImage.getWidth(); i++) {
/*  53: 60 */       for (int j = 0; j < scaleImage.getHeight(); j++) {
/*  54: 61 */         srcPixels[i][j] = scaleImage.getRGB(i, j);
/*  55:    */       }
/*  56:    */     }
/*  57: 65 */     Map<EncodeHintType, Object> hint = new HashMap();
/*  58: 66 */     hint.put(EncodeHintType.CHARACTER_SET, "utf-8");
/*  59: 67 */     hint.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
/*  60:    */     
/*  61: 69 */     BitMatrix matrix = mutiWriter.encode(content, BarcodeFormat.QR_CODE, width, height, hint);
/*  62:    */     
/*  63:    */ 
/*  64:    */ 
/*  65: 73 */     int halfW = matrix.getWidth() / 2;
/*  66: 74 */     int halfH = matrix.getHeight() / 2;
/*  67: 75 */     int[] pixels = new int[width * height];
/*  68: 77 */     for (int y = 0; y < matrix.getHeight(); y++) {
/*  69: 78 */       for (int x = 0; x < matrix.getWidth(); x++) {
/*  70: 80 */         if ((x > halfW - 40) && (x < halfW + 40) && (y > halfH - 40) && (y < halfH + 40)) {
/*  71: 84 */           pixels[(y * width + x)] = srcPixels[(x - halfW + 40)][(y - halfH + 40)];
/*  72: 88 */         } else if (((x > halfW - 40 - 2) && (x < halfW - 40 + 2) && (y > halfH - 40 - 2) && (y < halfH + 40 + 2)) || ((x > halfW + 40 - 2) && (x < halfW + 40 + 2) && (y > halfH - 40 - 2) && (y < halfH + 40 + 2)) || ((x > halfW - 40 - 2) && (x < halfW + 40 + 2) && (y > halfH - 40 - 2) && (y < halfH - 40 + 2)) || ((x > halfW - 40 - 2) && (x < halfW + 40 + 2) && (y > halfH + 40 - 2) && (y < halfH + 40 + 2))) {
/*  73:104 */           pixels[(y * width + x)] = 268435455;
/*  74:    */         } else {
/*  75:107 */           pixels[(y * width + x)] = (matrix.get(x, y) ? -16777216 : 268435455);
/*  76:    */         }
/*  77:    */       }
/*  78:    */     }
/*  79:113 */     BufferedImage image = new BufferedImage(width, height, 1);
/*  80:    */     
/*  81:115 */     image.getRaster().setDataElements(0, 0, width, height, pixels);
/*  82:    */     
/*  83:117 */     return image;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static BufferedImage scale(String srcImageFile, int height, int width, boolean hasFiller)
/*  87:    */     throws IOException
/*  88:    */   {
/*  89:135 */     double ratio = 0.0D;
/*  90:136 */     File file = new File(srcImageFile);
/*  91:137 */     BufferedImage srcImage = ImageIO.read(file);
/*  92:138 */     Image destImage = srcImage.getScaledInstance(width, height, 4);
/*  93:141 */     if ((srcImage.getHeight() > height) || (srcImage.getWidth() > width))
/*  94:    */     {
/*  95:142 */       if (srcImage.getHeight() > srcImage.getWidth()) {
/*  96:144 */         ratio = new Integer(height).doubleValue() / srcImage.getHeight();
/*  97:    */       } else {
/*  98:147 */         ratio = new Integer(width).doubleValue() / srcImage.getWidth();
/*  99:    */       }
/* 100:150 */       AffineTransformOp op = new AffineTransformOp(AffineTransform.getScaleInstance(ratio, ratio), null);
/* 101:151 */       destImage = op.filter(srcImage, null);
/* 102:    */     }
/* 103:153 */     if (hasFiller)
/* 104:    */     {
/* 105:154 */       BufferedImage image = new BufferedImage(width, height, 1);
/* 106:    */       
/* 107:156 */       Graphics2D graphic = image.createGraphics();
/* 108:157 */       graphic.setColor(Color.white);
/* 109:158 */       graphic.fillRect(0, 0, width, height);
/* 110:159 */       if (width == destImage.getWidth(null)) {
/* 111:160 */         graphic.drawImage(destImage, 0, 
/* 112:161 */           (height - destImage.getHeight(null)) / 2, destImage
/* 113:162 */           .getWidth(null), destImage.getHeight(null), Color.white, null);
/* 114:    */       } else {
/* 115:165 */         graphic.drawImage(destImage, 
/* 116:166 */           (width - destImage.getWidth(null)) / 2, 0, destImage
/* 117:167 */           .getWidth(null), destImage.getHeight(null), Color.white, null);
/* 118:    */       }
/* 119:169 */       graphic.dispose();
/* 120:170 */       destImage = image;
/* 121:    */     }
/* 122:172 */     return (BufferedImage)destImage;
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.BarcodeUtil
 * JD-Core Version:    0.7.0.1
 */