/*   1:    */ package com.afocus.framework.util;
/*   2:    */ 
/*   3:    */ import java.util.Date;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Random;
/*   7:    */ import java.util.regex.Matcher;
/*   8:    */ import java.util.regex.Pattern;
/*   9:    */ import org.apache.commons.codec.DecoderException;
/*  10:    */ import org.apache.commons.codec.binary.Base64;
/*  11:    */ import org.apache.commons.codec.binary.Hex;
/*  12:    */ import org.apache.commons.codec.digest.DigestUtils;
/*  13:    */ import org.apache.commons.lang3.StringUtils;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public class StringUtil
/*  18:    */ {
/*  19:    */   static final String digitsBase36 = "0123456789abcdefghijklmnopqrstuvwxyz";
/*  20:    */   static final String digitsBase10 = "0123456789";
/*  21: 37 */   private static final Logger log = LoggerFactory.getLogger(StringUtil.class);
/*  22: 44 */   static char[] charArrayOfRandom = "BCLMHcdefgDFGhijklEm45IJK6S1WZ7abvwXYxyz02n8opq39ANrstTUVuOPQR".toCharArray();
/*  23: 45 */   private static Random rnd = new Random();
/*  24:    */   
/*  25:    */   public static boolean isEmpty(CharSequence cs)
/*  26:    */   {
/*  27: 54 */     return StringUtils.isEmpty(cs);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static boolean isEmpty(Object obj)
/*  31:    */   {
/*  32: 58 */     return (obj == null) || (StringUtils.isEmpty(obj.toString()));
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static String toHex(byte[] byteData)
/*  36:    */   {
/*  37: 86 */     return Hex.encodeHexString(byteData);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static String toHex(byte b)
/*  41:    */   {
/*  42:115 */     return toHex(new byte[] { b });
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static byte[] hex2Bytes(String hex)
/*  46:    */   {
/*  47:    */     try
/*  48:    */     {
/*  49:126 */       return Hex.decodeHex(hex.toCharArray());
/*  50:    */     }
/*  51:    */     catch (DecoderException localDecoderException) {}
/*  52:130 */     return null;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static String charsetConvert(String str, String srcCharset, String dstCharset)
/*  56:    */   {
/*  57:177 */     if (isEmpty(str)) {
/*  58:178 */       return "";
/*  59:    */     }
/*  60:    */     try
/*  61:    */     {
/*  62:180 */       return new String(str.getBytes(srcCharset), dstCharset);
/*  63:    */     }
/*  64:    */     catch (Exception e)
/*  65:    */     {
/*  66:182 */       log.error("charsetConvert:" + e);
/*  67:    */     }
/*  68:184 */     return str;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static String iso2utf8(String str)
/*  72:    */   {
/*  73:195 */     return charsetConvert(str, "ISO-8859-1", "UTF-8");
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static String utf82iso(String str)
/*  77:    */   {
/*  78:206 */     return charsetConvert(str, "UTF-8", "ISO-8859-1");
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static String iso2gbk(String str)
/*  82:    */   {
/*  83:217 */     return charsetConvert(str, "ISO-8859-1", "GBK");
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static String gbk2iso(String str)
/*  87:    */   {
/*  88:228 */     return charsetConvert(str, "GBK", "ISO-8859-1");
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static String utf82gbk(String str)
/*  92:    */   {
/*  93:239 */     return charsetConvert(str, "UTF-8", "GBK");
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static String gbk2utf8(String str)
/*  97:    */   {
/*  98:250 */     return charsetConvert(str, "GBK", "UTF-8");
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static String leftPadString(String str, char padChar, int size)
/* 102:    */   {
/* 103:262 */     return StringUtils.leftPad(str, size, padChar);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static String rightPadString(String str, char padChar, int size)
/* 107:    */   {
/* 108:282 */     return StringUtils.rightPad(str, size, padChar);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static String intPadString(int num, int strLen)
/* 112:    */   {
/* 113:300 */     return leftPadString(String.valueOf(num), '0', strLen);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static String subString(String src, String begin, String end)
/* 117:    */   {
/* 118:313 */     return subString(src, 0, begin, end);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static String subString(String src, int offset, String begin, String end)
/* 122:    */   {
/* 123:327 */     if ((isEmpty(src)) || (offset >= src.length())) {
/* 124:328 */       return "";
/* 125:    */     }
/* 126:329 */     int b = offset;
/* 127:330 */     int e = src.length();
/* 128:331 */     if (!isEmpty(begin))
/* 129:    */     {
/* 130:332 */       b = src.indexOf(begin, offset);
/* 131:333 */       if (b < 0) {
/* 132:334 */         return "";
/* 133:    */       }
/* 134:335 */       b += begin.length();
/* 135:    */     }
/* 136:337 */     if ((!isEmpty(end)) && (b < e))
/* 137:    */     {
/* 138:338 */       e = src.indexOf(end, b);
/* 139:339 */       if (e < 0) {
/* 140:340 */         return "";
/* 141:    */       }
/* 142:    */     }
/* 143:342 */     return src.substring(b, e);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static String getRandomNumberString(int maxValue, int strLen)
/* 147:    */   {
/* 148:353 */     return intPadString(rnd.nextInt(maxValue), strLen);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static String getRandomNumberStringBase36(int strLen)
/* 152:    */   {
/* 153:382 */     StringBuilder sb = new StringBuilder();
/* 154:383 */     for (int i = 0; i < strLen; i++) {
/* 155:384 */       sb.append("0123456789abcdefghijklmnopqrstuvwxyz".charAt(rnd.nextInt(36)));
/* 156:    */     }
/* 157:386 */     return sb.toString();
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static String getRandomNumberInt(int strLen)
/* 161:    */   {
/* 162:390 */     StringBuilder sb = new StringBuilder();
/* 163:391 */     for (int i = 0; i < strLen; i++) {
/* 164:392 */       sb.append("0123456789".charAt(rnd.nextInt(10)));
/* 165:    */     }
/* 166:394 */     return sb.toString();
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static int getRandomNumber(int maxValue)
/* 170:    */   {
/* 171:404 */     return rnd.nextInt(maxValue);
/* 172:    */   }
/* 173:    */   
/* 174:    */   public static String base64Encode(String s)
/* 175:    */   {
/* 176:414 */     if (isNullOrBlank(s)) {
/* 177:415 */       return "";
/* 178:    */     }
/* 179:416 */     return Base64.encodeBase64String(s.getBytes());
/* 180:    */   }
/* 181:    */   
/* 182:    */   public static String base64Decode(String s)
/* 183:    */   {
/* 184:426 */     if (isNullOrBlank(s)) {
/* 185:427 */       return "";
/* 186:    */     }
/* 187:428 */     return new String(Base64.decodeBase64(s.getBytes()));
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static String md5(String s)
/* 191:    */   {
/* 192:438 */     return DigestUtils.md5Hex(s);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static String sha1(String s)
/* 196:    */   {
/* 197:478 */     return DigestUtils.shaHex(s);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static String fixHtml(String content)
/* 201:    */   {
/* 202:507 */     if ((content == null) || (content.trim().length() == 0)) {
/* 203:508 */       return content;
/* 204:    */     }
/* 205:509 */     StringBuilder builder = new StringBuilder(content.length());
/* 206:510 */     for (int i = 0; i < content.length(); i++) {
/* 207:511 */       switch (content.charAt(i))
/* 208:    */       {
/* 209:    */       case '<': 
/* 210:513 */         builder.append("&lt;");
/* 211:514 */         break;
/* 212:    */       case '>': 
/* 213:516 */         builder.append("&gt;");
/* 214:517 */         break;
/* 215:    */       case '"': 
/* 216:519 */         builder.append("&quot;");
/* 217:520 */         break;
/* 218:    */       case '\'': 
/* 219:522 */         builder.append("&#39;");
/* 220:523 */         break;
/* 221:    */       case '%': 
/* 222:525 */         builder.append("&#37;");
/* 223:526 */         break;
/* 224:    */       case ';': 
/* 225:528 */         builder.append("&#59;");
/* 226:529 */         break;
/* 227:    */       case '(': 
/* 228:531 */         builder.append("&#40;");
/* 229:532 */         break;
/* 230:    */       case ')': 
/* 231:534 */         builder.append("&#41;");
/* 232:535 */         break;
/* 233:    */       case '&': 
/* 234:537 */         builder.append("&amp;");
/* 235:538 */         break;
/* 236:    */       case '+': 
/* 237:540 */         builder.append("&#43;");
/* 238:541 */         break;
/* 239:    */       case '\r': 
/* 240:    */         break;
/* 241:    */       case '\n': 
/* 242:545 */         builder.append("&lt;br&gt;");
/* 243:546 */         break;
/* 244:    */       case '\t': 
/* 245:548 */         builder.append("&#09;");
/* 246:549 */         break;
/* 247:    */       case ' ': 
/* 248:551 */         builder.append("&nbsp;");
/* 249:552 */         break;
/* 250:    */       case '\013': 
/* 251:    */       case '\f': 
/* 252:    */       case '\016': 
/* 253:    */       case '\017': 
/* 254:    */       case '\020': 
/* 255:    */       case '\021': 
/* 256:    */       case '\022': 
/* 257:    */       case '\023': 
/* 258:    */       case '\024': 
/* 259:    */       case '\025': 
/* 260:    */       case '\026': 
/* 261:    */       case '\027': 
/* 262:    */       case '\030': 
/* 263:    */       case '\031': 
/* 264:    */       case '\032': 
/* 265:    */       case '\033': 
/* 266:    */       case '\034': 
/* 267:    */       case '\035': 
/* 268:    */       case '\036': 
/* 269:    */       case '\037': 
/* 270:    */       case '!': 
/* 271:    */       case '#': 
/* 272:    */       case '$': 
/* 273:    */       case '*': 
/* 274:    */       case ',': 
/* 275:    */       case '-': 
/* 276:    */       case '.': 
/* 277:    */       case '/': 
/* 278:    */       case '0': 
/* 279:    */       case '1': 
/* 280:    */       case '2': 
/* 281:    */       case '3': 
/* 282:    */       case '4': 
/* 283:    */       case '5': 
/* 284:    */       case '6': 
/* 285:    */       case '7': 
/* 286:    */       case '8': 
/* 287:    */       case '9': 
/* 288:    */       case ':': 
/* 289:    */       case '=': 
/* 290:    */       default: 
/* 291:554 */         builder.append(content.charAt(i));
/* 292:    */       }
/* 293:    */     }
/* 294:558 */     return builder.toString();
/* 295:    */   }
/* 296:    */   
/* 297:    */   public static String unfixHtml(String content)
/* 298:    */   {
/* 299:568 */     String ret = content;
/* 300:569 */     ret = ret.replaceAll("&lt;", "<").replaceAll("&#60;", "<");
/* 301:570 */     ret = ret.replaceAll("&gt;", ">").replaceAll("&#62;", ">");
/* 302:571 */     ret = ret.replaceAll("&quot;", "\"").replaceAll("&#34;", "\"");
/* 303:572 */     ret = ret.replaceAll("&#39;", "'");
/* 304:573 */     ret = ret.replaceAll("&#37;", "%");
/* 305:574 */     ret = ret.replaceAll("&#59;", ";");
/* 306:575 */     ret = ret.replaceAll("&#40;", "(");
/* 307:576 */     ret = ret.replaceAll("&#41;", ")");
/* 308:577 */     ret = ret.replaceAll("&nbsp;", " ");
/* 309:578 */     ret = ret.replaceAll("&amp;", "&");
/* 310:579 */     ret = ret.replaceAll("&#43;", "+");
/* 311:580 */     ret = ret.replaceAll("&#09;", "\t");
/* 312:581 */     ret = ret.replaceAll("<br>", "\n").replaceAll("&#10;", "\n");
/* 313:582 */     return ret;
/* 314:    */   }
/* 315:    */   
/* 316:    */   public static boolean isEmail(String email)
/* 317:    */   {
/* 318:592 */     if (isEmpty(email)) {
/* 319:593 */       return false;
/* 320:    */     }
/* 321:594 */     return Pattern.matches("^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$", email);
/* 322:    */   }
/* 323:    */   
/* 324:    */   public static boolean isMobilePhone(String s)
/* 325:    */   {
/* 326:604 */     if (isEmpty(s)) {
/* 327:605 */       return false;
/* 328:    */     }
/* 329:607 */     return Pattern.matches("^(1)\\d{10}$", s);
/* 330:    */   }
/* 331:    */   
/* 332:    */   public static boolean isPhoneNumber(String s)
/* 333:    */   {
/* 334:611 */     if (isEmpty(s)) {
/* 335:612 */       return false;
/* 336:    */     }
/* 337:613 */     return Pattern.matches("^[0-9\\-\\(\\)\\ ]+$", s);
/* 338:    */   }
/* 339:    */   
/* 340:    */   public static boolean isDate(String s)
/* 341:    */   {
/* 342:617 */     if (isEmpty(s)) {
/* 343:618 */       return false;
/* 344:    */     }
/* 345:619 */     return Pattern.matches("^[0-9]{4}\\-[0-9]{1,2}\\-[0-9]{1,2}$", s);
/* 346:    */   }
/* 347:    */   
/* 348:    */   public static boolean isNumber(String s)
/* 349:    */   {
/* 350:623 */     if (isEmpty(s)) {
/* 351:624 */       return false;
/* 352:    */     }
/* 353:625 */     return Pattern.matches("^[-]*[0-9\\.]+$", s);
/* 354:    */   }
/* 355:    */   
/* 356:    */   public static boolean isOnlyLetter(String s)
/* 357:    */   {
/* 358:629 */     if (isEmpty(s)) {
/* 359:630 */       return false;
/* 360:    */     }
/* 361:631 */     return Pattern.matches("^[a-zA-Z\\ \\']+$", s);
/* 362:    */   }
/* 363:    */   
/* 364:    */   public static boolean isImageFile(String s)
/* 365:    */   {
/* 366:635 */     if (isEmpty(s)) {
/* 367:636 */       return false;
/* 368:    */     }
/* 369:637 */     return Pattern.matches("(.*)\\.(jpeg|jpg|bmp|gif|png)$", s);
/* 370:    */   }
/* 371:    */   
/* 372:    */   public static boolean isOnlyChinese(String s)
/* 373:    */   {
/* 374:641 */     if (isEmpty(s)) {
/* 375:642 */       return false;
/* 376:    */     }
/* 377:643 */     return Pattern.matches("[^u4e00-u9fa5]+$", s);
/* 378:    */   }
/* 379:    */   
/* 380:    */   public static boolean isUrl(String s)
/* 381:    */   {
/* 382:712 */     if (isEmpty(s)) {
/* 383:713 */       return false;
/* 384:    */     }
/* 385:714 */     return Pattern.matches("^(https|http|ftp|rtsp|mms)?:\\/\\/[^s]*$", s);
/* 386:    */   }
/* 387:    */   
/* 388:    */   public static Matcher getMatcherGroup(String src, String reg)
/* 389:    */   {
/* 390:725 */     if (isEmpty(src)) {
/* 391:726 */       return null;
/* 392:    */     }
/* 393:727 */     Pattern p = Pattern.compile(reg, 2);
/* 394:728 */     return p.matcher(src.toLowerCase());
/* 395:    */   }
/* 396:    */   
/* 397:    */   public static String unescape(String src)
/* 398:    */   {
/* 399:738 */     StringBuffer tmp = new StringBuffer();
/* 400:739 */     tmp.ensureCapacity(src.length());
/* 401:740 */     int lastPos = 0;int pos = 0;
/* 402:742 */     while (lastPos < src.length())
/* 403:    */     {
/* 404:743 */       pos = src.indexOf("%", lastPos);
/* 405:744 */       if (pos == lastPos)
/* 406:    */       {
/* 407:745 */         if (src.charAt(pos + 1) == 'u')
/* 408:    */         {
/* 409:746 */           char ch = (char)Integer.parseInt(src.substring(pos + 2, pos + 6), 16);
/* 410:747 */           tmp.append(ch);
/* 411:748 */           lastPos = pos + 6;
/* 412:    */         }
/* 413:    */         else
/* 414:    */         {
/* 415:750 */           char ch = (char)Integer.parseInt(src.substring(pos + 1, pos + 3), 16);
/* 416:751 */           tmp.append(ch);
/* 417:752 */           lastPos = pos + 3;
/* 418:    */         }
/* 419:    */       }
/* 420:755 */       else if (pos == -1)
/* 421:    */       {
/* 422:756 */         tmp.append(src.substring(lastPos));
/* 423:757 */         lastPos = src.length();
/* 424:    */       }
/* 425:    */       else
/* 426:    */       {
/* 427:759 */         tmp.append(src.substring(lastPos, pos));
/* 428:760 */         lastPos = pos;
/* 429:    */       }
/* 430:    */     }
/* 431:764 */     return tmp.toString();
/* 432:    */   }
/* 433:    */   
/* 434:    */   public static String stringValue(String src, String def)
/* 435:    */   {
/* 436:774 */     return isEmpty(src) ? def : src;
/* 437:    */   }
/* 438:    */   
/* 439:    */   public static String stringValueNull(String src, String def)
/* 440:    */   {
/* 441:778 */     return (isEmpty(src)) || (src.equals("null")) ? def : src;
/* 442:    */   }
/* 443:    */   
/* 444:    */   public static int cnNum2Int(String s)
/* 445:    */   {
/* 446:784 */     String numStr = "";
/* 447:785 */     int result = 0;
/* 448:786 */     int util = 1;
/* 449:787 */     for (int i = 0; i < s.length(); i++)
/* 450:    */     {
/* 451:788 */       char c = s.charAt(i);
/* 452:789 */       if ((c > '/') && (c < ':'))
/* 453:    */       {
/* 454:790 */         numStr = numStr + String.valueOf(c);
/* 455:    */       }
/* 456:    */       else
/* 457:    */       {
/* 458:793 */         switch (c)
/* 459:    */         {
/* 460:    */         case '十': 
/* 461:795 */           util = 10;
/* 462:796 */           break;
/* 463:    */         case '百': 
/* 464:798 */           util = 100;
/* 465:799 */           break;
/* 466:    */         case '千': 
/* 467:801 */           util = 1000;
/* 468:802 */           break;
/* 469:    */         case '万': 
/* 470:804 */           util = 10000;
/* 471:805 */           break;
/* 472:    */         case '亿': 
/* 473:807 */           util = 100000000;
/* 474:    */         }
/* 475:810 */         if (!numStr.equals(""))
/* 476:    */         {
/* 477:811 */           int temp = Integer.parseInt(numStr);
/* 478:812 */           result += temp * util;
/* 479:813 */           util = 1;
/* 480:814 */           temp = 0;
/* 481:815 */           numStr = "";
/* 482:    */         }
/* 483:    */         else
/* 484:    */         {
/* 485:818 */           result *= util;
/* 486:819 */           util = 1;
/* 487:    */         }
/* 488:    */       }
/* 489:    */     }
/* 490:821 */     if (!numStr.equals("")) {
/* 491:822 */       result += Integer.parseInt(numStr) * util;
/* 492:    */     }
/* 493:824 */     return result;
/* 494:    */   }
/* 495:    */   
/* 496:    */   public static String randNum(int n)
/* 497:    */   {
/* 498:860 */     char[] arrChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
/* 499:861 */     StringBuilder num = new StringBuilder();
/* 500:862 */     Random rnd = new Random();
/* 501:863 */     for (int i = 0; i < n; i++) {
/* 502:864 */       num.append(arrChar[rnd.nextInt(9)]);
/* 503:    */     }
/* 504:866 */     return num.toString();
/* 505:    */   }
/* 506:    */   
/* 507:    */   public static int parseInt(String idStr)
/* 508:    */     throws Exception
/* 509:    */   {
/* 510:870 */     if (isNullOrBlank(idStr)) {
/* 511:871 */       return -1;
/* 512:    */     }
/* 513:    */     try
/* 514:    */     {
/* 515:874 */       idStr = idStr.trim();
/* 516:875 */       return Integer.parseInt(idStr);
/* 517:    */     }
/* 518:    */     catch (Exception e)
/* 519:    */     {
/* 520:877 */       throw new Exception("抱歉，你输入的id值是非数字型！");
/* 521:    */     }
/* 522:    */   }
/* 523:    */   
/* 524:    */   public static boolean isNullOrBlank(CharSequence cs)
/* 525:    */   {
/* 526:882 */     return StringUtils.isBlank(cs);
/* 527:    */   }
/* 528:    */   
/* 529:    */   public static boolean isNotBlank(CharSequence cs)
/* 530:    */   {
/* 531:892 */     return !isNullOrBlank(cs);
/* 532:    */   }
/* 533:    */   
/* 534:    */   public static String getRandomString(int size)
/* 535:    */   {
/* 536:902 */     Random random = new Random();
/* 537:903 */     StringBuilder sb = new StringBuilder();
/* 538:904 */     for (int i = 0; i < size; i++)
/* 539:    */     {
/* 540:905 */       int number = random.nextInt(charArrayOfRandom.length);
/* 541:906 */       sb.append(charArrayOfRandom[number]);
/* 542:    */     }
/* 543:908 */     return sb.toString();
/* 544:    */   }
/* 545:    */   
/* 546:    */   public static String getUniqueString()
/* 547:    */   {
/* 548:918 */     String key = new Date().getTime() + "";
/* 549:919 */     String base = "lEm45IJK6S1WZ7abvwXYxyz02";
/* 550:920 */     StringBuffer sb = new StringBuffer();
/* 551:921 */     for (int i = 0; i < key.length(); i++) {
/* 552:    */       try
/* 553:    */       {
/* 554:923 */         Thread.sleep(1L);
/* 555:924 */         int index = Integer.parseInt(key.charAt(i) + "");
/* 556:925 */         if (index == 0) {
/* 557:926 */           sb.append(getRandomString(2));
/* 558:    */         }
/* 559:928 */         sb.append(base.charAt(index));
/* 560:    */       }
/* 561:    */       catch (InterruptedException e)
/* 562:    */       {
/* 563:932 */         e.printStackTrace();
/* 564:    */       }
/* 565:    */     }
/* 566:935 */     return sb.toString();
/* 567:    */   }
/* 568:    */   
/* 569:    */   public static String getUniqueNumber()
/* 570:    */   {
/* 571:944 */     String key = String.valueOf(System.currentTimeMillis());
/* 572:    */     
/* 573:946 */     Map<String, String> baseKey = new HashMap();
/* 574:947 */     baseKey.put("0", "3");
/* 575:948 */     baseKey.put("1", "1");
/* 576:949 */     baseKey.put("2", "7");
/* 577:950 */     baseKey.put("3", "5");
/* 578:951 */     baseKey.put("4", "8");
/* 579:952 */     baseKey.put("5", "9");
/* 580:953 */     baseKey.put("6", "4");
/* 581:954 */     baseKey.put("7", "2");
/* 582:955 */     baseKey.put("8", "6");
/* 583:956 */     baseKey.put("9", "0");
/* 584:957 */     StringBuffer sb = new StringBuffer();
/* 585:958 */     for (int i = 0; i < key.length(); i++) {
/* 586:    */       try
/* 587:    */       {
/* 588:960 */         Thread.sleep(1L);
/* 589:961 */         String index = key.charAt(i) + "";
/* 590:962 */         sb = sb.append((String)baseKey.get(index));
/* 591:    */       }
/* 592:    */       catch (InterruptedException e)
/* 593:    */       {
/* 594:965 */         e.printStackTrace();
/* 595:    */       }
/* 596:    */     }
/* 597:969 */     return sb.toString();
/* 598:    */   }
/* 599:    */   
/* 600:    */   public static String StringFilter(String str)
/* 601:    */   {
/* 602:976 */     if ((str == null) || ("".equals(str.trim()))) {
/* 603:977 */       return str;
/* 604:    */     }
/* 605:980 */     String regEx = "[^a-zA-Z0-9`~!@#$%^&*()+=_|{}':;',//[//].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？一-龥]";
/* 606:981 */     Pattern p = Pattern.compile(regEx);
/* 607:982 */     Matcher m = p.matcher(str);
/* 608:983 */     return m.replaceAll("").trim();
/* 609:    */   }
/* 610:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.StringUtil
 * JD-Core Version:    0.7.0.1
 */