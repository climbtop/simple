/*  1:   */ package com.afocus.framework.util.date;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.util.StringUtil;
/*  4:   */ import java.beans.PropertyEditor;
/*  5:   */ import java.beans.PropertyEditorSupport;
/*  6:   */ import java.util.Date;
/*  7:   */ 
/*  8:   */ public class DatePropertyEditor
/*  9:   */   extends PropertyEditorSupport
/* 10:   */   implements PropertyEditor
/* 11:   */ {
/* 12:   */   public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
/* 13:   */   public static final String CHINESE_DATE_FORMAT = "yyyy-MM-dd";
/* 14:   */   public static final String CHINESE_DATE_FORMAT_DOT = "yyyy.MM.dd";
/* 15:   */   public static final String TIME_HHMMSS_FORMAT = "HH:mm:ss";
/* 16:   */   public static final String DATE_HHMM_FORMAT = "yyyy-MM-dd HH:mm";
/* 17:20 */   private String dateFormat = "yyyy-MM-dd HH:mm:ss";
/* 18:21 */   private boolean returnDefaultDate = false;
/* 19:   */   
/* 20:   */   public DatePropertyEditor() {}
/* 21:   */   
/* 22:   */   public DatePropertyEditor(String dateFormat)
/* 23:   */   {
/* 24:31 */     if (StringUtil.isEmpty(dateFormat)) {
/* 25:32 */       dateFormat = "yyyy-MM-dd HH:mm:ss";
/* 26:   */     }
/* 27:33 */     this.dateFormat = dateFormat;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setReturnDefaultDate(boolean b)
/* 31:   */   {
/* 32:37 */     this.returnDefaultDate = b;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getAsText()
/* 36:   */   {
/* 37:41 */     Date value = (Date)getValue();
/* 38:42 */     if (null == value)
/* 39:   */     {
/* 40:43 */       if (!this.returnDefaultDate) {
/* 41:44 */         return "";
/* 42:   */       }
/* 43:45 */       value = new Date();
/* 44:   */     }
/* 45:47 */     return DateUtil.formatDate(value, this.dateFormat);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setAsText(String text)
/* 49:   */     throws IllegalArgumentException
/* 50:   */   {
/* 51:51 */     Date value = null;
/* 52:52 */     if ((null != text) && (!text.equals(""))) {
/* 53:   */       try
/* 54:   */       {
/* 55:54 */         value = DateUtil.parseDate(text, this.dateFormat);
/* 56:55 */         if (value == null) {
/* 57:56 */           if (text.matches("\\d{4}-\\d{2}-\\d{2}")) {
/* 58:57 */             value = DateUtil.parseDate(text, "yyyy-MM-dd");
/* 59:59 */           } else if (text.matches("\\d{4}\\.\\d{2}\\.\\d{2}")) {
/* 60:60 */             value = DateUtil.parseDate(text, "yyyy.MM.dd");
/* 61:62 */           } else if (text.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}")) {
/* 62:63 */             value = DateUtil.parseDate(text, "yyyy-MM-dd HH:mm:ss");
/* 63:65 */           } else if (text.matches("\\d{2}:\\d{2}:\\d{2}")) {
/* 64:66 */             value = DateUtil.parseDate(text, "HH:mm:ss");
/* 65:67 */           } else if (text.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
/* 66:68 */             value = DateUtil.parseDate(text, "yyyy-MM-dd HH:mm");
/* 67:   */           }
/* 68:   */         }
/* 69:   */       }
/* 70:   */       catch (Exception e)
/* 71:   */       {
/* 72:73 */         e.printStackTrace();
/* 73:   */       }
/* 74:   */     }
/* 75:76 */     if ((value == null) && (this.returnDefaultDate)) {
/* 76:77 */       value = new Date();
/* 77:   */     }
/* 78:78 */     setValue(value);
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.date.DatePropertyEditor
 * JD-Core Version:    0.7.0.1
 */