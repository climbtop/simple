/*   1:    */ package com.afocus.framework.util.date;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.exception.ServiceOperationException;
/*   4:    */ import java.sql.Timestamp;
/*   5:    */ import java.text.DateFormat;
/*   6:    */ import java.text.ParseException;
/*   7:    */ import java.text.SimpleDateFormat;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Calendar;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.Date;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Locale;
/*  15:    */ import java.util.Map;
/*  16:    */ import java.util.MissingResourceException;
/*  17:    */ import java.util.ResourceBundle;
/*  18:    */ import org.apache.commons.lang3.StringUtils;
/*  19:    */ import org.springframework.context.i18n.LocaleContextHolder;
/*  20:    */ 
/*  21:    */ public class DateUtil
/*  22:    */ {
/*  23: 28 */   public static final DateFormat FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
/*  24:    */   public static final long ONE_MINUTE_MILLISECOND = 60000L;
/*  25:    */   public static final long ONE_HOUR_MILLISECOND = 3600000L;
/*  26:    */   public static final long ONE_DAY_MILLISECOND = 86400000L;
/*  27:    */   public static final long ONE_WEEK_MILLISECOND = 604800000L;
/*  28:    */   public static final long ONE_MONTH_MILLISECOND = 2592000000L;
/*  29:    */   public static final long ONE_YEAR_MILLISECOND = 31536000000L;
/*  30: 41 */   private static String defaultDatePattern = null;
/*  31:    */   
/*  32:    */   public static Timestamp getCurrTimestamp()
/*  33:    */   {
/*  34: 49 */     return new Timestamp(System.currentTimeMillis());
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static long getCurrentUnixTimeSecond()
/*  38:    */   {
/*  39: 58 */     return getCurrTimestamp().getTime() / 1000L;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static synchronized String getDatePattern()
/*  43:    */   {
/*  44: 67 */     Locale locale = LocaleContextHolder.getLocale();
/*  45:    */     try
/*  46:    */     {
/*  47: 69 */       defaultDatePattern = ResourceBundle.getBundle("ApplicationResources", locale).getString("date.format");
/*  48:    */     }
/*  49:    */     catch (MissingResourceException mse)
/*  50:    */     {
/*  51: 71 */       defaultDatePattern = "yyyy-MM-dd";
/*  52:    */     }
/*  53: 74 */     return defaultDatePattern;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static boolean validationDate(String format, String... dates)
/*  57:    */   {
/*  58:    */     try
/*  59:    */     {
/*  60: 86 */       SimpleDateFormat df = new SimpleDateFormat(format);
/*  61: 87 */       if ((dates != null) && (dates.length > 1)) {
/*  62: 88 */         for (int i = 0; i < dates.length; i++) {
/*  63: 89 */           df.parse(dates[i]);
/*  64:    */         }
/*  65:    */       }
/*  66:    */     }
/*  67:    */     catch (Exception e)
/*  68:    */     {
/*  69: 93 */       throw new ServiceOperationException("日期格式不正确");
/*  70:    */     }
/*  71: 95 */     return true;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static List<String> getDateList(String beginDate, String endDate)
/*  75:    */   {
/*  76:106 */     if ((StringUtils.isEmpty(endDate)) || (StringUtils.isEmpty(endDate))) {
/*  77:107 */       return Collections.emptyList();
/*  78:    */     }
/*  79:109 */     validationDate("yyyy-MM-dd", new String[] { beginDate, endDate });
/*  80:    */     
/*  81:111 */     List<String> list = new ArrayList();
/*  82:    */     try
/*  83:    */     {
/*  84:113 */       Calendar startDay = Calendar.getInstance();
/*  85:114 */       Calendar endDay = Calendar.getInstance();
/*  86:115 */       startDay.setTime(FORMATTER.parse(beginDate));
/*  87:116 */       endDay.setTime(FORMATTER.parse(endDate));
/*  88:119 */       if (startDay.compareTo(endDay) > 0) {
/*  89:120 */         return list;
/*  90:    */       }
/*  91:124 */       Calendar currentPrintDay = startDay;
/*  92:    */       for (;;)
/*  93:    */       {
/*  94:126 */         list.add(FORMATTER.format(currentPrintDay.getTime()));
/*  95:128 */         if (currentPrintDay.compareTo(endDay) == 0) {
/*  96:    */           break;
/*  97:    */         }
/*  98:132 */         currentPrintDay.add(5, 1);
/*  99:    */       }
/* 100:    */     }
/* 101:    */     catch (Exception localException) {}
/* 102:138 */     return list;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static List<Date> getDates(String beginDate, String endDate)
/* 106:    */   {
/* 107:149 */     if ((StringUtils.isEmpty(endDate)) || (StringUtils.isEmpty(endDate))) {
/* 108:150 */       return Collections.emptyList();
/* 109:    */     }
/* 110:152 */     validationDate("yyyy-MM-dd", new String[] { beginDate, endDate });
/* 111:    */     
/* 112:154 */     List<Date> list = new ArrayList();
/* 113:    */     try
/* 114:    */     {
/* 115:156 */       Calendar startDay = Calendar.getInstance();
/* 116:157 */       Calendar endDay = Calendar.getInstance();
/* 117:158 */       startDay.setTime(FORMATTER.parse(beginDate));
/* 118:159 */       endDay.setTime(FORMATTER.parse(endDate));
/* 119:162 */       if (startDay.compareTo(endDay) > 0) {
/* 120:163 */         return list;
/* 121:    */       }
/* 122:167 */       Calendar currentPrintDay = startDay;
/* 123:    */       for (;;)
/* 124:    */       {
/* 125:169 */         list.add(currentPrintDay.getTime());
/* 126:171 */         if (currentPrintDay.compareTo(endDay) == 0) {
/* 127:    */           break;
/* 128:    */         }
/* 129:175 */         currentPrintDay.add(5, 1);
/* 130:    */       }
/* 131:    */     }
/* 132:    */     catch (Exception localException) {}
/* 133:181 */     return list;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static int getYear(Date date)
/* 137:    */   {
/* 138:191 */     return getCalendar(date).get(1);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static int getMonth(Date date)
/* 142:    */   {
/* 143:201 */     return getCalendar(date).get(2);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static int getDay(Date date)
/* 147:    */   {
/* 148:211 */     return getCalendar(date).get(5);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static int getWeek(Date date)
/* 152:    */   {
/* 153:221 */     return getCalendar(date).get(7);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public static int getWeekOfFirstDayOfMonth(Date date)
/* 157:    */   {
/* 158:231 */     return getWeek(getFirstDayOfMonth(date));
/* 159:    */   }
/* 160:    */   
/* 161:    */   public static int getWeekOfLastDayOfMonth(Date date)
/* 162:    */   {
/* 163:241 */     return getWeek(getLastDayOfMonth(date));
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static final Date parseDate(String strDate, String format)
/* 167:    */   {
/* 168:253 */     return parseDate(strDate, format, true);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static final Date parseDate(String strDate, String format, boolean isLenient)
/* 172:    */   {
/* 173:267 */     SimpleDateFormat df = new SimpleDateFormat(format);
/* 174:268 */     df.setLenient(isLenient);
/* 175:    */     try
/* 176:    */     {
/* 177:270 */       return df.parse(strDate);
/* 178:    */     }
/* 179:    */     catch (ParseException pe) {}
/* 180:272 */     return null;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public static Date parseDate(String strDate)
/* 184:    */   {
/* 185:283 */     return parseDate(strDate, getDatePattern());
/* 186:    */   }
/* 187:    */   
/* 188:    */   public static boolean isLeapYear(int year)
/* 189:    */   {
/* 190:294 */     if (year / 4 * 4 != year) {
/* 191:295 */       return false;
/* 192:    */     }
/* 193:296 */     if (year / 100 * 100 != year) {
/* 194:297 */       return true;
/* 195:    */     }
/* 196:298 */     if (year / 400 * 400 != year) {
/* 197:299 */       return false;
/* 198:    */     }
/* 199:301 */     return true;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public static String getCurrentTime()
/* 203:    */   {
/* 204:312 */     return formatDate(new Date());
/* 205:    */   }
/* 206:    */   
/* 207:    */   public static String getCurrentTime(String format)
/* 208:    */   {
/* 209:322 */     return formatDate(new Date(), format);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public static String formatDate(Date date, String format)
/* 213:    */   {
/* 214:334 */     if (date == null) {
/* 215:334 */       date = new Date();
/* 216:    */     }
/* 217:335 */     if (format == null) {
/* 218:335 */       format = getDatePattern();
/* 219:    */     }
/* 220:336 */     SimpleDateFormat formatter = new SimpleDateFormat(format);
/* 221:337 */     return formatter.format(date);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static String formatDefDate(Date date)
/* 225:    */   {
/* 226:341 */     return formatDate(date, "yyyy-MM-dd HH:mm:ss");
/* 227:    */   }
/* 228:    */   
/* 229:    */   public static String formatChineseDate(Date date)
/* 230:    */   {
/* 231:345 */     return formatDate(date, "yyyy-MM-dd");
/* 232:    */   }
/* 233:    */   
/* 234:    */   public static String getCurrDate()
/* 235:    */   {
/* 236:354 */     return formatDate(new Date(), "yyyy-MM-dd");
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static String getCurrDateAfterDays(int days)
/* 240:    */   {
/* 241:363 */     return formatDate(getDateAfterDays(new Date(), days), "yyyy-MM-dd");
/* 242:    */   }
/* 243:    */   
/* 244:    */   public static String formatDate(Date date)
/* 245:    */   {
/* 246:373 */     long offset = System.currentTimeMillis() - date.getTime();
/* 247:374 */     String pos = "前";
/* 248:375 */     if (offset < 0L)
/* 249:    */     {
/* 250:376 */       pos = "后";
/* 251:377 */       offset = -offset;
/* 252:    */     }
/* 253:379 */     if (offset >= 31536000000L) {
/* 254:380 */       return formatDate(date, getDatePattern());
/* 255:    */     }
/* 256:382 */     StringBuilder sb = new StringBuilder();
/* 257:383 */     if (offset >= 5184000000L) {
/* 258:384 */       return (offset + 1296000000L) / 2592000000L + "个月" + pos;
/* 259:    */     }
/* 260:386 */     if (offset > 604800000L) {
/* 261:387 */       return (offset + 302400000L) / 604800000L + "周" + pos;
/* 262:    */     }
/* 263:389 */     if (offset > 86400000L) {
/* 264:390 */       return (offset + 43200000L) / 86400000L + "天" + pos;
/* 265:    */     }
/* 266:392 */     if (offset > 3600000L) {
/* 267:393 */       return (offset + 1800000L) / 3600000L + "小时" + pos;
/* 268:    */     }
/* 269:395 */     if (offset > 60000L) {
/* 270:396 */       return (offset + 30000L) / 60000L + "分钟" + pos;
/* 271:    */     }
/* 272:398 */     return offset / 1000L + "秒" + pos;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public static Date getCleanDay(Date day)
/* 276:    */   {
/* 277:409 */     return getCleanDay(getCalendar(day));
/* 278:    */   }
/* 279:    */   
/* 280:    */   public static Calendar getCalendar(Date day)
/* 281:    */   {
/* 282:419 */     Calendar c = Calendar.getInstance();
/* 283:420 */     if (day != null) {
/* 284:421 */       c.setTime(day);
/* 285:    */     }
/* 286:422 */     return c;
/* 287:    */   }
/* 288:    */   
/* 289:    */   private static Date getCleanDay(Calendar c)
/* 290:    */   {
/* 291:426 */     c.set(11, 0);
/* 292:427 */     c.clear(12);
/* 293:428 */     c.clear(13);
/* 294:429 */     c.clear(14);
/* 295:430 */     return c.getTime();
/* 296:    */   }
/* 297:    */   
/* 298:    */   public static Date makeDate(int year, int month, int day)
/* 299:    */   {
/* 300:442 */     Calendar c = Calendar.getInstance();
/* 301:443 */     getCleanDay(c);
/* 302:444 */     c.set(1, year);
/* 303:445 */     c.set(2, month - 1);
/* 304:446 */     c.set(5, day);
/* 305:447 */     return c.getTime();
/* 306:    */   }
/* 307:    */   
/* 308:    */   private static Date getFirstCleanDay(int datePart, Date date)
/* 309:    */   {
/* 310:451 */     Calendar c = Calendar.getInstance();
/* 311:452 */     if (date != null) {
/* 312:453 */       c.setTime(date);
/* 313:    */     }
/* 314:454 */     c.set(datePart, 1);
/* 315:455 */     return getCleanDay(c);
/* 316:    */   }
/* 317:    */   
/* 318:    */   private static Date add(int datePart, int detal, Date date)
/* 319:    */   {
/* 320:459 */     Calendar c = Calendar.getInstance();
/* 321:460 */     if (date != null) {
/* 322:461 */       c.setTime(date);
/* 323:    */     }
/* 324:462 */     c.add(datePart, detal);
/* 325:463 */     return c.getTime();
/* 326:    */   }
/* 327:    */   
/* 328:    */   public static Date getFirstDayOfWeek(Date date)
/* 329:    */   {
/* 330:473 */     return getFirstCleanDay(7, date);
/* 331:    */   }
/* 332:    */   
/* 333:    */   public static Date getFirstDayOfWeek()
/* 334:    */   {
/* 335:482 */     return getFirstDayOfWeek(null);
/* 336:    */   }
/* 337:    */   
/* 338:    */   public static Date getFirstDayOfMonth(Date date)
/* 339:    */   {
/* 340:492 */     return getFirstCleanDay(5, date);
/* 341:    */   }
/* 342:    */   
/* 343:    */   public static Date getFirstDayOfMonth()
/* 344:    */   {
/* 345:501 */     return getFirstDayOfMonth(null);
/* 346:    */   }
/* 347:    */   
/* 348:    */   public static Date getLastDayOfMonth()
/* 349:    */   {
/* 350:510 */     return getLastDayOfMonth(null);
/* 351:    */   }
/* 352:    */   
/* 353:    */   public static Date getLastDayOfMonth(Date date)
/* 354:    */   {
/* 355:520 */     Calendar c = getCalendar(getFirstDayOfMonth(date));
/* 356:521 */     c.add(2, 1);
/* 357:522 */     c.add(5, -1);
/* 358:523 */     return getCleanDay(c);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public static Date getFirstDayOfSeason(Date date)
/* 362:    */   {
/* 363:533 */     Date d = getFirstDayOfMonth(date);
/* 364:534 */     int delta = getMonth(d) % 3;
/* 365:535 */     if (delta > 0) {
/* 366:536 */       d = getDateAfterMonths(d, -delta);
/* 367:    */     }
/* 368:537 */     return d;
/* 369:    */   }
/* 370:    */   
/* 371:    */   public static Date getFirstDayOfSeason()
/* 372:    */   {
/* 373:546 */     return getFirstDayOfMonth(null);
/* 374:    */   }
/* 375:    */   
/* 376:    */   public static Date getFirstDayOfYear(Date date)
/* 377:    */   {
/* 378:556 */     return makeDate(getYear(date), 1, 1);
/* 379:    */   }
/* 380:    */   
/* 381:    */   public static Date getFirstDayOfYear()
/* 382:    */   {
/* 383:565 */     return getFirstDayOfYear(new Date());
/* 384:    */   }
/* 385:    */   
/* 386:    */   public static Date getLastDayOfYear()
/* 387:    */   {
/* 388:574 */     return parseDate(getYear(new Date()) + "-12-31 23:59:59", "yyyy-MM-dd HH:mm:ss");
/* 389:    */   }
/* 390:    */   
/* 391:    */   public static Date getDateAfterWeeks(Date start, int weeks)
/* 392:    */   {
/* 393:585 */     return getDateAfterMs(start, weeks * 604800000L);
/* 394:    */   }
/* 395:    */   
/* 396:    */   public static Date getDateAfterMonths(Date start, int months)
/* 397:    */   {
/* 398:596 */     return add(2, months, start);
/* 399:    */   }
/* 400:    */   
/* 401:    */   public static Date getDateAfterYears(Date start, int years)
/* 402:    */   {
/* 403:607 */     return add(1, years, start);
/* 404:    */   }
/* 405:    */   
/* 406:    */   public static Date getDateAfterDays(Date start, int days)
/* 407:    */   {
/* 408:618 */     return getDateAfterMs(start, days * 86400000L);
/* 409:    */   }
/* 410:    */   
/* 411:    */   public static Date getDateAfterMs(Date start, long ms)
/* 412:    */   {
/* 413:629 */     return new Date(start.getTime() + ms);
/* 414:    */   }
/* 415:    */   
/* 416:    */   public static long getPeriodNum(Date start, Date end, long msPeriod)
/* 417:    */   {
/* 418:641 */     return getIntervalMs(start, end) / msPeriod;
/* 419:    */   }
/* 420:    */   
/* 421:    */   public static long getIntervalMs(Date start, Date end)
/* 422:    */   {
/* 423:652 */     return end.getTime() - start.getTime();
/* 424:    */   }
/* 425:    */   
/* 426:    */   public static int getIntervalDays(Date start, Date end)
/* 427:    */   {
/* 428:663 */     return (int)getPeriodNum(start, end, 86400000L);
/* 429:    */   }
/* 430:    */   
/* 431:    */   public static int getIntervalWeeks(Date start, Date end)
/* 432:    */   {
/* 433:674 */     return (int)getPeriodNum(start, end, 604800000L);
/* 434:    */   }
/* 435:    */   
/* 436:    */   public static boolean before(Date base, Date date)
/* 437:    */   {
/* 438:685 */     return (date.before(base)) || (date.equals(base));
/* 439:    */   }
/* 440:    */   
/* 441:    */   public static boolean after(Date base, Date date)
/* 442:    */   {
/* 443:696 */     return (date.after(base)) || (date.equals(base));
/* 444:    */   }
/* 445:    */   
/* 446:    */   public static Date max(Date date1, Date date2)
/* 447:    */   {
/* 448:707 */     if (date1.getTime() > date2.getTime()) {
/* 449:708 */       return date1;
/* 450:    */     }
/* 451:710 */     return date2;
/* 452:    */   }
/* 453:    */   
/* 454:    */   public static Date min(Date date1, Date date2)
/* 455:    */   {
/* 456:721 */     if (date1.getTime() < date2.getTime()) {
/* 457:722 */       return date1;
/* 458:    */     }
/* 459:724 */     return date2;
/* 460:    */   }
/* 461:    */   
/* 462:    */   public static boolean inPeriod(Date start, Date end, Date date)
/* 463:    */   {
/* 464:736 */     return ((end.after(date)) || (end.equals(date))) && ((start.before(date)) || (start.equals(date)));
/* 465:    */   }
/* 466:    */   
/* 467:    */   public static String getWeekOfDate(Date dt)
/* 468:    */   {
/* 469:746 */     String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
/* 470:747 */     Calendar cal = Calendar.getInstance();
/* 471:748 */     cal.setTime(dt);
/* 472:749 */     int w = cal.get(7) - 1;
/* 473:750 */     if (w < 0) {
/* 474:751 */       w = 0;
/* 475:    */     }
/* 476:752 */     return weekDays[w];
/* 477:    */   }
/* 478:    */   
/* 479:    */   public static class Milliscond
/* 480:    */   {
/* 481:    */     private static final String format = "dd HH:mm:ss";
/* 482:    */     
/* 483:    */     public static String format2Str(Date start, Date end)
/* 484:    */     {
/* 485:786 */       return replace(start, end, "dd HH:mm:ss");
/* 486:    */     }
/* 487:    */     
/* 488:    */     public static String format2Str(long ms)
/* 489:    */     {
/* 490:791 */       return replace(ms, "dd HH:mm:ss");
/* 491:    */     }
/* 492:    */     
/* 493:    */     public static String format2Str(Date start, Date end, String format)
/* 494:    */     {
/* 495:796 */       return replace(start, end, format);
/* 496:    */     }
/* 497:    */     
/* 498:    */     public static String format2Str(long ms, String format)
/* 499:    */     {
/* 500:801 */       return replace(ms, format);
/* 501:    */     }
/* 502:    */     
/* 503:    */     public static Map<String, String> format2Map(Date start, Date end)
/* 504:    */     {
/* 505:806 */       return format2Map(end.getTime() - start.getTime());
/* 506:    */     }
/* 507:    */     
/* 508:    */     public static Map<String, String> format2Map(long ms)
/* 509:    */     {
/* 510:811 */       long ss = 1000L;
/* 511:812 */       long mi = ss * 60L;
/* 512:813 */       long hh = mi * 60L;
/* 513:814 */       long dd = hh * 24L;
/* 514:    */       
/* 515:816 */       long day = ms / dd;
/* 516:817 */       long hour = (ms - day * dd) / hh;
/* 517:818 */       long minute = (ms - day * dd - hour * hh) / mi;
/* 518:819 */       long second = (ms - day * dd - hour * hh - minute * mi) / ss;
/* 519:820 */       long milliSecond = ms - day * dd - hour * hh - minute * mi - second * ss;
/* 520:    */       
/* 521:822 */       String strDay = "" + day;
/* 522:823 */       String strHour = "" + hour;
/* 523:824 */       String strMinute = "" + minute;
/* 524:825 */       String strSecond = "" + second;
/* 525:826 */       String strMilliSecond = "" + milliSecond;
/* 526:    */       
/* 527:828 */       Map<String, String> resultMap = new HashMap();
/* 528:829 */       resultMap.put("day", strDay);
/* 529:830 */       resultMap.put("hour", strHour);
/* 530:831 */       resultMap.put("minute", strMinute);
/* 531:832 */       resultMap.put("second", strSecond);
/* 532:833 */       resultMap.put("milliSecond", strMilliSecond);
/* 533:834 */       return resultMap;
/* 534:    */     }
/* 535:    */     
/* 536:    */     private static String replace(Date start, Date end, String format)
/* 537:    */     {
/* 538:839 */       String result = null;
/* 539:840 */       if ((format.contains("dd")) && (format.contains("HH")) && 
/* 540:841 */         (format.contains("mm")) && (format.contains("ss")))
/* 541:    */       {
/* 542:842 */         Map<String, String> map = format2Map(start, end);
/* 543:843 */         format = format.replaceAll("dd", (String)map.get("day"));
/* 544:844 */         format = format.replaceAll("HH", (String)map.get("hour"));
/* 545:845 */         format = format.replaceAll("mm", (String)map.get("minute"));
/* 546:846 */         format = format.replaceAll("ss", (String)map.get("second") + "." + (String)map.get("milliSecond"));
/* 547:847 */         result = format;
/* 548:    */       }
/* 549:849 */       return result;
/* 550:    */     }
/* 551:    */     
/* 552:    */     private static String replace(long ms, String format)
/* 553:    */     {
/* 554:854 */       String result = null;
/* 555:855 */       if ((format.contains("dd")) && (format.contains("HH")) && 
/* 556:856 */         (format.contains("mm")) && (format.contains("ss")))
/* 557:    */       {
/* 558:857 */         Map<String, String> map = format2Map(ms);
/* 559:858 */         format = format.replaceAll("dd", (String)map.get("day"));
/* 560:859 */         format = format.replaceAll("HH", (String)map.get("hour"));
/* 561:860 */         format = format.replaceAll("mm", (String)map.get("minute"));
/* 562:861 */         format = format.replaceAll("ss", (String)map.get("second") + "." + (String)map.get("milliSecond"));
/* 563:862 */         result = format;
/* 564:    */       }
/* 565:864 */       return result;
/* 566:    */     }
/* 567:    */   }
/* 568:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.util.date.DateUtil
 * JD-Core Version:    0.7.0.1
 */