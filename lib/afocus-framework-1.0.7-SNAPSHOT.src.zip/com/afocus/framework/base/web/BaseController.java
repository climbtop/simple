/*   1:    */ package com.afocus.framework.base.web;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.StringUtil;
/*   4:    */ import com.afocus.framework.util.date.DatePropertyEditor;
/*   5:    */ import java.beans.PropertyEditor;
/*   6:    */ import java.io.PrintStream;
/*   7:    */ import java.io.UnsupportedEncodingException;
/*   8:    */ import java.net.URLEncoder;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Date;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ import java.util.TreeMap;
/*  17:    */ import javax.servlet.http.HttpServletRequest;
/*  18:    */ import org.apache.log4j.Logger;
/*  19:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  20:    */ import org.springframework.beans.factory.annotation.Qualifier;
/*  21:    */ import org.springframework.ui.ModelMap;
/*  22:    */ import org.springframework.util.StringUtils;
/*  23:    */ import org.springframework.validation.BindingResult;
/*  24:    */ import org.springframework.validation.Validator;
/*  25:    */ import org.springframework.web.bind.ServletRequestDataBinder;
/*  26:    */ import org.springframework.web.bind.annotation.RequestMapping;
/*  27:    */ 
/*  28:    */ @Deprecated
/*  29:    */ public class BaseController
/*  30:    */ {
/*  31: 34 */   protected Logger log = Logger.getLogger(getClass());
/*  32: 35 */   public static int DEFAULT_PAGE_NO = 1;
/*  33: 36 */   public static int DEFAULT_PAGE_SIZE = 20;
/*  34:    */   public static final String ALL_ERRORS = "allErrors";
/*  35:    */   public static final String QUERY_PARAM = "queryParam";
/*  36:    */   public static final String PAGE_NO = "pageNo";
/*  37:    */   public static final String PAGE_SIZE = "pageSize";
/*  38:    */   public static final String LIST = "/list";
/*  39:    */   public static final String CREATE = "/create";
/*  40:    */   public static final String SEARCH = "/search";
/*  41:    */   public static final String SAVE = "/save";
/*  42:    */   public static final String EDIT = "/edit";
/*  43:    */   public static final String SHOW = "/show";
/*  44:    */   public static final String UPDATE = "/update";
/*  45:    */   public static final String DELETE = "/delete";
/*  46:    */   public static final String AUDIT = "/audit";
/*  47:    */   public static final String MOVE = "/move";
/*  48:    */   public static final String UPDATE_STATUS = "/updateStatus";
/*  49:    */   public static final String FORM = "/form";
/*  50:    */   public static final String JSON = "/json";
/*  51:    */   public static final String HOME_VIEW = "/home";
/*  52: 60 */   private String rootUrl = "";
/*  53: 61 */   private String jspRoot = "";
/*  54: 62 */   protected String listView = "/list";
/*  55: 63 */   protected String redirectListView = "redirect:/list.do";
/*  56: 64 */   protected String formView = "/form";
/*  57: 65 */   protected String showView = "/show";
/*  58: 66 */   protected String jsonView = "/json";
/*  59:    */   @Autowired(required=false)
/*  60:    */   @Qualifier("validator")
/*  61:    */   protected Validator validator;
/*  62:    */   
/*  63:    */   protected BaseController(String rootUrl, String jspRoot)
/*  64:    */   {
/*  65: 73 */     setRootUrl(rootUrl);
/*  66: 74 */     setJspRoot(jspRoot);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getRootUrl()
/*  70:    */   {
/*  71: 81 */     return this.rootUrl;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setRootUrl(String rootUrl)
/*  75:    */   {
/*  76: 88 */     this.rootUrl = rootUrl;
/*  77: 89 */     this.redirectListView = ("redirect:" + rootUrl + "/list" + ".do");
/*  78:    */   }
/*  79:    */   
/*  80:    */   @RequestMapping
/*  81:    */   public String home()
/*  82:    */   {
/*  83: 95 */     return this.rootUrl + "/home";
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getJspRoot()
/*  87:    */   {
/*  88:103 */     return this.jspRoot;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setJspRoot(String jspRoot)
/*  92:    */   {
/*  93:110 */     this.jspRoot = jspRoot;
/*  94:111 */     this.listView = (jspRoot + "/list");
/*  95:112 */     this.formView = (jspRoot + "/form");
/*  96:113 */     this.showView = (jspRoot + "/show");
/*  97:114 */     this.jsonView = (jspRoot + "/json");
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static ServletRequestDataBinder initBinder(Object target)
/* 101:    */   {
/* 102:118 */     String objectName = StringUtils.uncapitalize(target.getClass().getSimpleName());
/* 103:119 */     return new ServletRequestDataBinder(target, objectName);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static ServletRequestDataBinder initBinder(Object target, DatePropertyEditor dateEditor)
/* 107:    */   {
/* 108:123 */     ServletRequestDataBinder binder = initBinder(target);
/* 109:124 */     if (dateEditor != null) {
/* 110:125 */       binder.registerCustomEditor(Date.class, dateEditor);
/* 111:    */     }
/* 112:126 */     return binder;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static ServletRequestDataBinder initBinder(Object target, Map<String, DatePropertyEditor> dateEditorMap)
/* 116:    */   {
/* 117:130 */     ServletRequestDataBinder binder = initBinder(target);
/* 118:131 */     if (dateEditorMap != null) {
/* 119:132 */       for (Map.Entry<String, DatePropertyEditor> entry : dateEditorMap.entrySet())
/* 120:    */       {
/* 121:133 */         String field = (String)entry.getKey();
/* 122:134 */         if (field == null) {
/* 123:135 */           binder.registerCustomEditor(Date.class, (PropertyEditor)entry.getValue());
/* 124:    */         } else {
/* 125:137 */           binder.registerCustomEditor(Date.class, field, (PropertyEditor)entry.getValue());
/* 126:    */         }
/* 127:    */       }
/* 128:    */     }
/* 129:140 */     return binder;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static BindingResult bind(HttpServletRequest request, Object target, ModelMap model, Validator... validators)
/* 133:    */   {
/* 134:144 */     ServletRequestDataBinder binder = initBinder(target);
/* 135:145 */     return bind(binder, request, target, model, validators);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static BindingResult bind(HttpServletRequest request, Object target, ModelMap model, DatePropertyEditor dateEditor, Validator... validators)
/* 139:    */   {
/* 140:149 */     ServletRequestDataBinder binder = initBinder(target, dateEditor);
/* 141:150 */     return bind(binder, request, target, model, validators);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public static BindingResult bind(ServletRequestDataBinder binder, HttpServletRequest request, Object target, ModelMap model, Validator... validators)
/* 145:    */   {
/* 146:154 */     binder.bind(request);
/* 147:155 */     BindingResult result = binder.getBindingResult();
/* 148:156 */     for (Validator validator : validators) {
/* 149:157 */       if (validator != null) {
/* 150:158 */         validator.validate(target, result);
/* 151:    */       }
/* 152:    */     }
/* 153:161 */     if (result.hasErrors())
/* 154:    */     {
/* 155:162 */       String objectName = StringUtils.uncapitalize(target.getClass().getSimpleName());
/* 156:163 */       model.addAttribute(objectName, target);
/* 157:164 */       model.addAttribute("allErrors", result.getAllErrors());
/* 158:165 */       model.addAttribute(BindingResult.MODEL_KEY_PREFIX + objectName, result);
/* 159:    */     }
/* 160:167 */     return result;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static void setRequestModelMap(HttpServletRequest request, ModelMap model)
/* 164:    */   {
/* 165:171 */     setRequestModelMap(request, model, false, null);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static void setRequestModelMap(HttpServletRequest request, ModelMap model, boolean query)
/* 169:    */   {
/* 170:175 */     setRequestModelMap(request, model, query, null);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static void setRequestModelMap(HttpServletRequest request, ModelMap model, boolean query, String jsonEncoding)
/* 174:    */   {
/* 175:187 */     Map<String, String[]> parameterMap = request.getParameterMap();
/* 176:    */     
/* 177:189 */     StringBuilder sb = new StringBuilder();
/* 178:190 */     boolean and = false;
/* 179:191 */     String queryParam = null;
/* 180:192 */     for (Map.Entry<String, String[]> entry : parameterMap.entrySet())
/* 181:    */     {
/* 182:193 */       String key = (String)entry.getKey();
/* 183:194 */       String[] values = (String[])entry.getValue();
/* 184:196 */       if ((values != null) && (values.length > 0)) {
/* 185:197 */         if (("queryParam".equalsIgnoreCase(key)) && (!StringUtil.isEmpty(values[0])))
/* 186:    */         {
/* 187:198 */           queryParam = values[0];
/* 188:    */         }
/* 189:    */         else
/* 190:    */         {
/* 191:202 */           List<String> list = new ArrayList();
/* 192:203 */           for (String v : values) {
/* 193:204 */             if (!StringUtil.isEmpty(v))
/* 194:    */             {
/* 195:206 */               list.add(v);
/* 196:207 */               System.out.println();
/* 197:    */               try
/* 198:    */               {
/* 199:209 */                 v = URLEncoder.encode(v, request.getCharacterEncoding());
/* 200:    */               }
/* 201:    */               catch (UnsupportedEncodingException e)
/* 202:    */               {
/* 203:212 */                 e.printStackTrace();
/* 204:    */               }
/* 205:214 */               if (and) {
/* 206:215 */                 sb.append("&");
/* 207:    */               } else {
/* 208:217 */                 and = true;
/* 209:    */               }
/* 210:218 */               sb.append(key).append("=").append(v);
/* 211:    */             }
/* 212:    */           }
/* 213:220 */           if (list.size() == 1)
/* 214:    */           {
/* 215:221 */             if ((key.startsWith("in")) || (key.startsWith("notIn")))
/* 216:    */             {
/* 217:222 */               model.addAttribute(key, list);
/* 218:    */             }
/* 219:    */             else
/* 220:    */             {
/* 221:224 */               String v = (String)list.get(0);
/* 222:225 */               if (jsonEncoding != null)
/* 223:    */               {
/* 224:226 */                 v = StringUtil.charsetConvert(v, request.getCharacterEncoding(), jsonEncoding);
/* 225:227 */                 v = StringUtil.gbk2iso(v);
/* 226:    */               }
/* 227:229 */               model.addAttribute(key, v);
/* 228:    */             }
/* 229:    */           }
/* 230:232 */           else if (list.size() > 1) {
/* 231:233 */             model.addAttribute(key, list);
/* 232:    */           }
/* 233:    */         }
/* 234:    */       }
/* 235:    */     }
/* 236:237 */     if ((query) || (queryParam == null)) {
/* 237:238 */       queryParam = sb.toString();
/* 238:    */     }
/* 239:239 */     model.addAttribute("queryParam", queryParam);
/* 240:241 */     if (parameterMap.get("pageNo") == null) {
/* 241:242 */       model.addAttribute("pageNo", Integer.valueOf(DEFAULT_PAGE_NO));
/* 242:    */     }
/* 243:244 */     if (parameterMap.get("pageSize") == null) {
/* 244:245 */       model.addAttribute("pageSize", Integer.valueOf(DEFAULT_PAGE_SIZE));
/* 245:    */     }
/* 246:    */   }
/* 247:    */   
/* 248:    */   public static Map<String, String> getSubMap(Map<String, String> srcMap, Set<String> subMapKeySet)
/* 249:    */   {
/* 250:257 */     if ((subMapKeySet == null) || (subMapKeySet.size() == 0)) {
/* 251:257 */       return srcMap;
/* 252:    */     }
/* 253:259 */     Map<String, String> subMap = null;
/* 254:260 */     if ((srcMap instanceof TreeMap)) {
/* 255:261 */       subMap = new TreeMap();
/* 256:    */     } else {
/* 257:263 */       subMap = new HashMap();
/* 258:    */     }
/* 259:264 */     for (String key : subMapKeySet) {
/* 260:265 */       if (srcMap.containsKey(key)) {
/* 261:266 */         subMap.put(key, srcMap.get(key));
/* 262:    */       }
/* 263:    */     }
/* 264:269 */     return subMap;
/* 265:    */   }
/* 266:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.web.BaseController
 * JD-Core Version:    0.7.0.1
 */