

com.afocus.framework.common.PageResult
com.afocus.framework.util.PageList
java.util.Date
java.util.List
java.util.Map

BaseDao

  queryEntity, 
  
  query, 
  
  pageQuery, , , 
  
  queryEntity, , 
  
  query, , 
  
  pageQuery, , , , 
  
  selectByMap, , 
  
  selectByMap, , , , 
  
  selectByMap, , , 
  
  selectById
  
  selectCountByMap, 
  
  insert
  
  insertWithReturn
  
  updateByMap, 
  
  update
  
  deleteByMap, 
  
  deleteById
  
  getNameSpace
  
  setNameSpace
  
  getCurrentTime
  
  getSequenceNextValue
  
  getSequenceCurrentValue
  
  getRowCountOfTable
  
  destroy
  
  batchInsert
  
  batchUpdateById
  
  batchUpdateByMap, 



/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.dao.BaseDao
 * JD-Core Version:    0.7.0.1
 */