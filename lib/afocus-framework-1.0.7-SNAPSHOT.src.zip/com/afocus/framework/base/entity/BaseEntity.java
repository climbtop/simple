/*  1:   */ 
/*  2:   */ 
/*  3:   */ java.util.Date
/*  4:   */ 
/*  5:   */ BaseEntity
/*  6:   */   
/*  7:   */ 
/*  8:   */   serialVersionUID = -6963094568196462147L
/*  9:   */   updateTime
/* 10:   */   
/* 11:   */   getUpdateTime
/* 12:   */   
/* 13:16 */     updateTime;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void setUpdateTime(Date updateTime)
/* 17:   */   {
/* 18:19 */     this.updateTime = updateTime;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.entity.BaseEntity
 * JD-Core Version:    0.7.0.1
 */