/*  1:   */ package com.afocus.framework.base.entity;
/*  2:   */ 
/*  3:   */ public class BaseEntitySub
/*  4:   */   extends BaseEntity
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -3758826752346892525L;
/*  7:   */   protected Integer createId;
/*  8:   */   protected Integer updateId;
/*  9:   */   
/* 10:   */   public Integer getCreateId()
/* 11:   */   {
/* 12:15 */     return this.createId;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setCreateId(Integer createId)
/* 16:   */   {
/* 17:19 */     this.createId = createId;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Integer getUpdateId()
/* 21:   */   {
/* 22:23 */     return this.updateId;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setUpdateId(Integer updateId)
/* 26:   */   {
/* 27:27 */     this.updateId = updateId;
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.entity.BaseEntitySub
 * JD-Core Version:    0.7.0.1
 */