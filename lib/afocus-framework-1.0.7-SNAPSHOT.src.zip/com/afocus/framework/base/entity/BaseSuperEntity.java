/*  1:   */ package com.afocus.framework.base.entity;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ 
/*  5:   */ public class BaseSuperEntity
/*  6:   */   extends SuperEntity
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 340041606764885410L;
/*  9:   */   protected Date createTime;
/* 10:   */   
/* 11:   */   public Date getCreateTime()
/* 12:   */   {
/* 13:15 */     return this.createTime;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void setCreateTime(Date createTime)
/* 17:   */   {
/* 18:19 */     this.createTime = createTime;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.entity.BaseSuperEntity
 * JD-Core Version:    0.7.0.1
 */