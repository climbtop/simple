/*  1:   */ package com.afocus.framework.base.entity;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class SuperEntity
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 3588141416872325536L;
/*  9:   */   protected Long id;
/* 10:   */   protected Integer appCode;
/* 11:   */   
/* 12:   */   public Long getId()
/* 13:   */   {
/* 14:16 */     return this.id;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setId(Long id)
/* 18:   */   {
/* 19:20 */     this.id = id;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Integer getAppCode()
/* 23:   */   {
/* 24:24 */     return this.appCode;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setAppCode(Integer appCode)
/* 28:   */   {
/* 29:28 */     this.appCode = appCode;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public int hashCode()
/* 33:   */   {
/* 34:33 */     int prime = 31;
/* 35:34 */     int result = 1;
/* 36:35 */     result = 31 * result + (this.id == null ? 0 : this.id.hashCode());
/* 37:36 */     return result;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public boolean equals(Object obj)
/* 41:   */   {
/* 42:41 */     if (this == obj) {
/* 43:42 */       return true;
/* 44:   */     }
/* 45:43 */     if (obj == null) {
/* 46:44 */       return false;
/* 47:   */     }
/* 48:45 */     if (getClass() != obj.getClass()) {
/* 49:46 */       return false;
/* 50:   */     }
/* 51:47 */     SuperEntity other = (SuperEntity)obj;
/* 52:48 */     if (this.id == null)
/* 53:   */     {
/* 54:49 */       if (other.id != null) {
/* 55:50 */         return false;
/* 56:   */       }
/* 57:   */     }
/* 58:51 */     else if (!this.id.equals(other.id)) {
/* 59:52 */       return false;
/* 60:   */     }
/* 61:53 */     return true;
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.entity.SuperEntity
 * JD-Core Version:    0.7.0.1
 */