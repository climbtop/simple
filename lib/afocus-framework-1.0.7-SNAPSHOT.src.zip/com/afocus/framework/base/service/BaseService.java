package com.afocus.framework.base.service;

import com.afocus.framework.base.service.event.ServiceEventHandler;
import com.afocus.framework.util.PageList;
import java.util.List;
import java.util.Map;

@Deprecated
public abstract interface BaseService<T>
{
  public abstract ServiceEventHandler getEventHandler();
  
  public abstract void insert(T paramT);
  
  public abstract int update(T paramT);
  
  public abstract int update(Map<String, Object> paramMap);
  
  public abstract int delete(Map<String, Object> paramMap);
  
  public abstract int delete(Object paramObject);
  
  public abstract T getById(Object paramObject);
  
  public abstract int getCount(Map<String, Object> paramMap);
  
  public abstract PageList<T> getList(Map<String, Object> paramMap, int paramInt1, int paramInt2, boolean paramBoolean);
  
  public abstract PageList<T> getList(Map<String, Object> paramMap, int paramInt1, int paramInt2);
  
  public abstract void batchInsert(List<T> paramList);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.service.BaseService
 * JD-Core Version:    0.7.0.1
 */