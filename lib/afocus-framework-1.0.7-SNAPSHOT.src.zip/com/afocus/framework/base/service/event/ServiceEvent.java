/*  1:   */ package com.afocus.framework.base.service.event;
/*  2:   */ 
/*  3:   */ import java.util.EventObject;
/*  4:   */ 
/*  5:   */ public class ServiceEvent
/*  6:   */   extends EventObject
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 1832282528630934999L;
/*  9:   */   private String methodName;
/* 10:   */   private Object param;
/* 11:16 */   private Object returnValue = null;
/* 12:   */   
/* 13:   */   protected ServiceEvent(Object service, Object param)
/* 14:   */   {
/* 15:24 */     this(service, null, param, null);
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected ServiceEvent(Object service, String methodName, Object param)
/* 19:   */   {
/* 20:28 */     this(service, methodName, param, null);
/* 21:   */   }
/* 22:   */   
/* 23:   */   protected ServiceEvent(Object service, String methodName, Object param, Object returnValue)
/* 24:   */   {
/* 25:32 */     super(service);
/* 26:33 */     this.methodName = methodName;
/* 27:34 */     this.param = param;
/* 28:35 */     this.returnValue = returnValue;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Object getService()
/* 32:   */   {
/* 33:42 */     return getSource();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Object getParam()
/* 37:   */   {
/* 38:49 */     return this.param;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setReturnValue(Object returnValue)
/* 42:   */   {
/* 43:56 */     this.returnValue = returnValue;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public Object getReturnValue()
/* 47:   */   {
/* 48:63 */     return this.returnValue;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public String getMethodName()
/* 52:   */   {
/* 53:70 */     return this.methodName;
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.service.event.ServiceEvent
 * JD-Core Version:    0.7.0.1
 */