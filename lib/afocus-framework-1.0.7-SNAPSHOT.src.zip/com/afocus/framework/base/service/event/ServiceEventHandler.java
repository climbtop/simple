/*  1:   */ package com.afocus.framework.base.service.event;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.base.service.ServiceEventListener;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ import java.util.List;
/*  6:   */ 
/*  7:   */ public class ServiceEventHandler
/*  8:   */   implements ServiceEventListener
/*  9:   */ {
/* 10:14 */   private List<ServiceEventListener> listeners = new ArrayList();
/* 11:   */   
/* 12:   */   public void addListener(ServiceEventListener listener)
/* 13:   */   {
/* 14:21 */     this.listeners.add(listener);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setListeners(List<ServiceEventListener> listeners)
/* 18:   */   {
/* 19:29 */     this.listeners.addAll(listeners);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void removeListener(ServiceEventListener listener)
/* 23:   */   {
/* 24:37 */     this.listeners.remove(listener);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void onAfterEvent(ServiceEvent event)
/* 28:   */   {
/* 29:45 */     for (ServiceEventListener listener : this.listeners) {
/* 30:46 */       listener.onAfterEvent(event);
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void onBeforeEvent(ServiceEvent event)
/* 35:   */   {
/* 36:50 */     for (ServiceEventListener listener : this.listeners) {
/* 37:51 */       listener.onBeforeEvent(event);
/* 38:   */     }
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.service.event.ServiceEventHandler
 * JD-Core Version:    0.7.0.1
 */