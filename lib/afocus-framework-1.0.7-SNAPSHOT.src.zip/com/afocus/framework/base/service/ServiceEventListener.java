package com.afocus.framework.base.service;

import com.afocus.framework.base.service.event.ServiceEvent;

public abstract interface ServiceEventListener
{
  public abstract void onAfterEvent(ServiceEvent paramServiceEvent);
  
  public abstract void onBeforeEvent(ServiceEvent paramServiceEvent);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.service.ServiceEventListener
 * JD-Core Version:    0.7.0.1
 */