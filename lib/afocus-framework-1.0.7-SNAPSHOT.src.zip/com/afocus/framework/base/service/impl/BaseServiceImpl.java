/*   1:    */ package com.afocus.framework.base.service.impl;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.base.dao.BaseDao;
/*   4:    */ import com.afocus.framework.base.service.BaseService;
/*   5:    */ import com.afocus.framework.base.service.ServiceEventListener;
/*   6:    */ import com.afocus.framework.base.service.event.ServiceEventHandler;
/*   7:    */ import com.afocus.framework.util.PageList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import org.apache.log4j.Logger;
/*  11:    */ 
/*  12:    */ @Deprecated
/*  13:    */ public abstract class BaseServiceImpl<T>
/*  14:    */   implements BaseService<T>
/*  15:    */ {
/*  16: 21 */   protected Logger log = Logger.getLogger(getClass());
/*  17: 26 */   protected ServiceEventHandler eventHandler = null;
/*  18:    */   
/*  19:    */   protected BaseDao<T> getBaseDao()
/*  20:    */   {
/*  21: 36 */     throw new UnsupportedOperationException("If need use directly BaseService's method, the sub-class must override this method.");
/*  22:    */   }
/*  23:    */   
/*  24:    */   public ServiceEventHandler getEventHandler()
/*  25:    */   {
/*  26: 45 */     return this.eventHandler;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setEventHandler(ServiceEventHandler eventHandler)
/*  30:    */   {
/*  31: 55 */     this.eventHandler = eventHandler;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public synchronized void addEventListener(ServiceEventListener listener)
/*  35:    */   {
/*  36: 65 */     if (this.eventHandler == null) {
/*  37: 66 */       this.eventHandler = new ServiceEventHandler();
/*  38:    */     }
/*  39: 67 */     this.eventHandler.addListener(listener);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void insert(T object)
/*  43:    */   {
/*  44: 71 */     getBaseDao().insert(object);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int update(T object)
/*  48:    */   {
/*  49: 75 */     return getBaseDao().update(object);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public int update(Map<String, Object> param)
/*  53:    */   {
/*  54: 79 */     return getBaseDao().updateByMap(param);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int delete(Map<String, Object> param)
/*  58:    */   {
/*  59: 83 */     return getBaseDao().deleteByMap(param);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public int delete(Object id)
/*  63:    */   {
/*  64: 87 */     return getBaseDao().deleteById(id);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public T getById(Object id)
/*  68:    */   {
/*  69: 91 */     return getBaseDao().selectById(id);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public int getCount(Map<String, Object> param)
/*  73:    */   {
/*  74: 95 */     return getBaseDao().selectCountByMap(param);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public PageList<T> getList(Map<String, Object> params, int pageNo, int pageSize, boolean doCount)
/*  78:    */   {
/*  79: 99 */     return getBaseDao().selectByMap(params, pageNo, pageSize, doCount);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public PageList<T> getList(Map<String, Object> params, int pageNo, int pageSize)
/*  83:    */   {
/*  84:103 */     return getBaseDao().selectByMap(params, pageNo, pageSize);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public PageList<T> getList(Map<String, Object> params)
/*  88:    */   {
/*  89:107 */     return getBaseDao().selectByMap(params, false);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void batchInsert(List<T> list)
/*  93:    */   {
/*  94:112 */     getBaseDao().batchInsert(list);
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.base.service.impl.BaseServiceImpl
 * JD-Core Version:    0.7.0.1
 */