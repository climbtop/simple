/*   1:    */ package com.afocus.framework.common;
/*   2:    */ 
/*   3:    */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*   4:    */ import org.apache.commons.lang3.StringUtils;
/*   5:    */ 
/*   6:    */ public class RemoteResult<T>
/*   7:    */ {
/*   8:    */   public static final String COMMON_ERROR_MESSAGE = "啊哦，出现了一点问题，请稍后再试";
/*   9:    */   private int code;
/*  10:    */   private T data;
/*  11:    */   private String msg;
/*  12:    */   
/*  13:    */   private RemoteResult() {}
/*  14:    */   
/*  15:    */   public RemoteResult(int code, T data, String msg)
/*  16:    */   {
/*  17: 38 */     this.code = code;
/*  18: 39 */     this.data = data;
/*  19: 40 */     this.msg = msg;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static <E> RemoteResult<E> success(E data)
/*  23:    */   {
/*  24: 50 */     return new RemoteResult(0, data, "");
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <E> RemoteResult<E> success(E data, String msg)
/*  28:    */   {
/*  29: 61 */     return new RemoteResult(0, data, msg);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <E> RemoteResult<E> fail(String msg)
/*  33:    */   {
/*  34: 71 */     return new RemoteResult(-2, null, StringUtils.isEmpty(msg) ? "啊哦，出现了一点问题，请稍后再试" : msg);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <E> RemoteResult<E> fail(Throwable throwable)
/*  38:    */   {
/*  39: 81 */     return fail(throwable.getMessage());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static <E> RemoteResult<E> illegal(String msg)
/*  43:    */   {
/*  44: 92 */     return new RemoteResult(-1, null, msg);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getCode()
/*  48:    */   {
/*  49:101 */     return this.code;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setCode(int code)
/*  53:    */   {
/*  54:110 */     this.code = code;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public T getData()
/*  58:    */   {
/*  59:119 */     return this.data;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setData(T data)
/*  63:    */   {
/*  64:128 */     this.data = data;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getMsg()
/*  68:    */   {
/*  69:137 */     return this.msg;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setMsg(String msg)
/*  73:    */   {
/*  74:146 */     this.msg = msg;
/*  75:    */   }
/*  76:    */   
/*  77:    */   @JsonIgnore
/*  78:    */   public boolean isSuccess()
/*  79:    */   {
/*  80:156 */     return this.code == 0;
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.common.RemoteResult
 * JD-Core Version:    0.7.0.1
 */