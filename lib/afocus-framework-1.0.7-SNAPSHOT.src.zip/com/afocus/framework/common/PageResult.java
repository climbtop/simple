/*  1:   */ package com.afocus.framework.common;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.util.PageList;
/*  4:   */ import com.afocus.framework.util.PageTurn;
/*  5:   */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*  6:   */ import java.util.Collections;
/*  7:   */ import java.util.Iterator;
/*  8:   */ import java.util.List;
/*  9:   */ 
/* 10:   */ public class PageResult<E>
/* 11:   */   implements Iterable<E>
/* 12:   */ {
/* 13:17 */   public static final PageResult Empty = new PageResult(0, 0, 0, 0, Collections.emptyList());
/* 14:   */   private List<E> data;
/* 15:20 */   private int totalPages = 0;
/* 16:21 */   private int totalRecords = 0;
/* 17:22 */   private int pageSize = 0;
/* 18:23 */   private int pageNumber = 0;
/* 19:   */   
/* 20:   */   private PageResult() {}
/* 21:   */   
/* 22:   */   public PageResult(int totalRecords, int totalPages, int pageSize, int pageNumber, List<E> data)
/* 23:   */   {
/* 24:30 */     this.totalPages = totalPages;
/* 25:31 */     this.totalRecords = totalRecords;
/* 26:32 */     this.pageSize = pageSize;
/* 27:33 */     this.pageNumber = pageNumber;
/* 28:34 */     this.data = data;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static <T> PageResult<T> from(PageList<T> pageList)
/* 32:   */   {
/* 33:38 */     return from(pageList.getPageTurn(), pageList);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static <T> PageResult<T> from(PageTurn turn, List<T> data)
/* 37:   */   {
/* 38:42 */     int totalPages = turn == null ? 0 : turn.getPageCount().intValue();
/* 39:43 */     int totalRecords = turn == null ? 0 : turn.getRowCount().intValue();
/* 40:44 */     int pageSize = turn == null ? 0 : turn.getPageSize().intValue();
/* 41:45 */     int pageNumber = turn == null ? 0 : turn.getPage().intValue();
/* 42:46 */     return new PageResult(totalRecords, totalPages, pageSize, pageNumber, data);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public List<E> getData()
/* 46:   */   {
/* 47:51 */     return this.data;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public int getTotalPages()
/* 51:   */   {
/* 52:55 */     return this.totalPages;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int getTotalRecords()
/* 56:   */   {
/* 57:59 */     return this.totalRecords;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public int getPageSize()
/* 61:   */   {
/* 62:63 */     return this.pageSize;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public int getPageNumber()
/* 66:   */   {
/* 67:67 */     return this.pageNumber;
/* 68:   */   }
/* 69:   */   
/* 70:   */   @JsonIgnore
/* 71:   */   public int size()
/* 72:   */   {
/* 73:72 */     if (this.data == null) {
/* 74:73 */       return 0;
/* 75:   */     }
/* 76:74 */     return this.data.size();
/* 77:   */   }
/* 78:   */   
/* 79:   */   @JsonIgnore
/* 80:   */   public Iterator<E> iterator()
/* 81:   */   {
/* 82:80 */     if (this.data != null) {
/* 83:81 */       return this.data.iterator();
/* 84:   */     }
/* 85:82 */     return Collections.emptyIterator();
/* 86:   */   }
/* 87:   */   
/* 88:   */   @JsonIgnore
/* 89:   */   public Object[] toArray()
/* 90:   */   {
/* 91:87 */     if (this.data == null) {
/* 92:88 */       return new Object[0];
/* 93:   */     }
/* 94:89 */     return this.data.toArray();
/* 95:   */   }
/* 96:   */   
/* 97:   */   @JsonIgnore
/* 98:   */   public List<E> asList()
/* 99:   */   {
/* :0:94 */     if (this.data == null) {
/* :1:95 */       return Collections.emptyList();
/* :2:   */     }
/* :3:96 */     return this.data;
/* :4:   */   }
/* :5:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.common.PageResult
 * JD-Core Version:    0.7.0.1
 */