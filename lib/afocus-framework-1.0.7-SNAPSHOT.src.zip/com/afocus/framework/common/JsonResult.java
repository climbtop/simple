/*   1:    */ package com.afocus.framework.common;
/*   2:    */ 
/*   3:    */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*   4:    */ import org.apache.commons.lang3.StringUtils;
/*   5:    */ 
/*   6:    */ public class JsonResult
/*   7:    */ {
/*   8:    */   public static final String COMMON_ERROR_MESSAGE = "啊哦，出现了一点问题，请稍后再试";
/*   9:    */   private int code;
/*  10:    */   private Object data;
/*  11:    */   private String msg;
/*  12:    */   
/*  13:    */   private JsonResult() {}
/*  14:    */   
/*  15:    */   public JsonResult(int code, Object data, String msg)
/*  16:    */   {
/*  17: 39 */     this.code = code;
/*  18: 40 */     this.data = data;
/*  19: 41 */     this.msg = msg;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static JsonResult success(Object data)
/*  23:    */   {
/*  24: 51 */     return new JsonResult(0, data, "");
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static JsonResult success(Object data, String msg)
/*  28:    */   {
/*  29: 62 */     return new JsonResult(0, data, msg);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static JsonResult fail(String msg)
/*  33:    */   {
/*  34: 72 */     return new JsonResult(-2, null, StringUtils.isEmpty(msg) ? "啊哦，出现了一点问题，请稍后再试" : msg);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static JsonResult fail(Throwable throwable)
/*  38:    */   {
/*  39: 82 */     return fail(throwable.getMessage());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static JsonResult illegal(String msg)
/*  43:    */   {
/*  44: 93 */     return new JsonResult(-1, null, msg);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getCode()
/*  48:    */   {
/*  49: 97 */     return this.code;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setCode(int code)
/*  53:    */   {
/*  54:101 */     this.code = code;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Object getData()
/*  58:    */   {
/*  59:105 */     return this.data;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setData(Object data)
/*  63:    */   {
/*  64:109 */     this.data = data;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getMsg()
/*  68:    */   {
/*  69:113 */     return this.msg;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setMsg(String msg)
/*  73:    */   {
/*  74:117 */     this.msg = msg;
/*  75:    */   }
/*  76:    */   
/*  77:    */   @JsonIgnore
/*  78:    */   public boolean isSuccess()
/*  79:    */   {
/*  80:127 */     return this.code == 0;
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.common.JsonResult
 * JD-Core Version:    0.7.0.1
 */