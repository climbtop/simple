/*  1:   */ package com.afocus.framework.component.image;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.component.image._enum.ImageEnum;
/*  4:   */ import java.awt.image.BufferedImage;
/*  5:   */ import java.io.File;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.util.Map;
/*  8:   */ import javax.imageio.ImageIO;
/*  9:   */ 
/* 10:   */ public class ImagesResize
/* 11:   */   implements Runnable
/* 12:   */ {
/* 13:   */   private int type;
/* 14:   */   private File imgFile;
/* 15:   */   private Map<String, String> sizeMap;
/* 16:   */   
/* 17:   */   public ImagesResize(File imgFile, int type, Map<String, String> sizeMap)
/* 18:   */   {
/* 19:42 */     this.imgFile = imgFile;
/* 20:43 */     this.type = type;
/* 21:44 */     this.sizeMap = sizeMap;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void run()
/* 25:   */   {
/* 26:   */     try
/* 27:   */     {
/* 28:51 */       if ((0 == this.type) || (1 == this.type)) {
/* 29:52 */         ImgResize.resize(this.imgFile, 1, Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_LARGE.getName())).split("\\*")[0]), Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_LARGE.getName())).split("\\*")[1]), "_" + ImageEnum.IMG_LARGE.getName());
/* 30:   */       }
/* 31:53 */       if ((0 == this.type) || (2 == this.type)) {
/* 32:54 */         ImgResize.resize(this.imgFile, 1, Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_MIDDLE.getName())).split("\\*")[0]), Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_MIDDLE.getName())).split("\\*")[1]), "_" + ImageEnum.IMG_MIDDLE.getName());
/* 33:   */       }
/* 34:55 */       if ((0 == this.type) || (3 == this.type)) {
/* 35:56 */         ImgResize.resize(this.imgFile, 1, Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_SMALL.getName())).split("\\*")[0]), Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_SMALL.getName())).split("\\*")[1]), "_" + ImageEnum.IMG_SMALL.getName());
/* 36:   */       }
/* 37:57 */       if (4 == this.type)
/* 38:   */       {
/* 39:58 */         int width = ImageIO.read(this.imgFile).getWidth(null);
/* 40:59 */         if (750 < width) {
/* 41:60 */           ImgResize.resize(this.imgFile, 2, 750, 0, "");
/* 42:61 */         } else if (200L < this.imgFile.length() / 1024L) {
/* 43:62 */           ImgResize.resize(this.imgFile, 2, width, 0, "");
/* 44:   */         }
/* 45:   */       }
/* 46:   */     }
/* 47:   */     catch (IOException e)
/* 48:   */     {
/* 49:66 */       e.printStackTrace();
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.component.image.ImagesResize
 * JD-Core Version:    0.7.0.1
 */