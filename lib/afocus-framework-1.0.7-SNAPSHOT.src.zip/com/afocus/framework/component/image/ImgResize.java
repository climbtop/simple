/*   1:    */ package com.afocus.framework.component.image;
/*   2:    */ 
/*   3:    */ import java.awt.Graphics;
/*   4:    */ import java.awt.Image;
/*   5:    */ import java.awt.image.BufferedImage;
/*   6:    */ import java.io.File;
/*   7:    */ import java.io.FileOutputStream;
/*   8:    */ import java.io.IOException;
/*   9:    */ import javax.imageio.ImageIO;
/*  10:    */ 
/*  11:    */ public class ImgResize
/*  12:    */ {
/*  13:    */   public static final int MAX_BIG = 1200;
/*  14:    */   public static final int MIN_BIG = 16;
/*  15:    */   public static final int TYPE_FOR_COPY = 0;
/*  16:    */   public static final int TYPE_FOR_SIZE = 1;
/*  17:    */   public static final int TYPE_FOR_WIDTH = 2;
/*  18:    */   public static final int TYPE_FOR_HEIGHT = 3;
/*  19:    */   public static final int TYPE_FOR_MAX = 4;
/*  20:    */   public static final int TYPE_FOR_MIN = 5;
/*  21:    */   
/*  22:    */   public static String resize(File _file, int createType, int newW, int newH, String suffix)
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 46 */     if (_file == null) {
/*  26: 47 */       return null;
/*  27:    */     }
/*  28: 48 */     String imgPath = _file.getPath();
/*  29: 49 */     if ((imgPath == null) || ("".equals(imgPath)) || (imgPath.lastIndexOf(".") == -1)) {
/*  30: 50 */       return null;
/*  31:    */     }
/*  32: 55 */     outImgPath = imgPath.substring(0, imgPath.lastIndexOf(".")) + suffix + imgPath.substring(imgPath.lastIndexOf("."), imgPath.length());
/*  33:    */     
/*  34: 57 */     String fileExtName = imgPath.substring(imgPath.lastIndexOf(".") + 1, imgPath.length());
/*  35:    */     
/*  36: 59 */     newW = checkMinAndMax(newW);
/*  37: 60 */     newH = checkMinAndMax(newH);
/*  38: 62 */     if ((!_file.exists()) || (!_file.isFile()) || (!checkImageFile(fileExtName))) {
/*  39: 63 */       return null;
/*  40:    */     }
/*  41: 66 */     FileOutputStream out = null;
/*  42:    */     try
/*  43:    */     {
/*  44: 68 */       Image src = ImageIO.read(_file);
/*  45:    */       
/*  46: 70 */       int[] wh = getSize(src, createType, newW, newH);
/*  47: 71 */       int nw = wh[0];
/*  48: 72 */       int nh = wh[1];
/*  49: 74 */       if (new File(outImgPath).exists()) {
/*  50: 75 */         new File(outImgPath).delete();
/*  51:    */       }
/*  52: 79 */       BufferedImage tag = new BufferedImage(nw, nh, 1);
/*  53:    */       
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59: 86 */       tag.getGraphics().drawImage(src, 0, 0, nw, nh, null);
/*  60:    */       
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65: 92 */       ImageIO.write(tag, fileExtName, new File(outImgPath));
/*  66: 97 */       if (null != out) {
/*  67:    */         try
/*  68:    */         {
/*  69: 99 */           out.close();
/*  70:    */         }
/*  71:    */         catch (IOException e)
/*  72:    */         {
/*  73:101 */           e.printStackTrace();
/*  74:    */         }
/*  75:    */       }
/*  76:    */       Image src;
/*  77:105 */       return outImgPath;
/*  78:    */     }
/*  79:    */     catch (IOException e)
/*  80:    */     {
/*  81: 94 */       e.printStackTrace();
/*  82: 95 */       throw e;
/*  83:    */     }
/*  84:    */     finally
/*  85:    */     {
/*  86: 97 */       if (null != out) {
/*  87:    */         try
/*  88:    */         {
/*  89: 99 */           out.close();
/*  90:    */         }
/*  91:    */         catch (IOException e)
/*  92:    */         {
/*  93:101 */           e.printStackTrace();
/*  94:    */         }
/*  95:    */       }
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static int checkMinAndMax(int n)
/* 100:    */   {
/* 101:113 */     if (n < 16) {
/* 102:114 */       n = 16;
/* 103:115 */     } else if (n > 1200) {
/* 104:116 */       n = 1200;
/* 105:    */     }
/* 106:117 */     return n;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static int[] getSize(Image src, int createType, int newW, int newH)
/* 110:    */   {
/* 111:128 */     int w = src.getWidth(null);
/* 112:129 */     int h = src.getHeight(null);
/* 113:130 */     int[] size = { w, h };
/* 114:132 */     if (createType != 0) {
/* 115:133 */       if (createType == 1)
/* 116:    */       {
/* 117:134 */         size[0] = newW;
/* 118:135 */         size[1] = newH;
/* 119:    */       }
/* 120:136 */       else if (createType == 2)
/* 121:    */       {
/* 122:137 */         size[0] = newW;
/* 123:138 */         size[1] = ((int)(h / w * size[0]));
/* 124:    */       }
/* 125:139 */       else if (createType == 3)
/* 126:    */       {
/* 127:140 */         size[1] = newH;
/* 128:141 */         size[0] = ((int)(w / h * size[1]));
/* 129:    */       }
/* 130:142 */       else if (createType == 4)
/* 131:    */       {
/* 132:143 */         if (w / h >= newW / newH)
/* 133:    */         {
/* 134:144 */           size[1] = newH;
/* 135:145 */           size[0] = ((int)(w / h * size[1]));
/* 136:    */         }
/* 137:    */         else
/* 138:    */         {
/* 139:147 */           size[0] = newW;
/* 140:148 */           size[1] = ((int)(h / w * size[0]));
/* 141:    */         }
/* 142:    */       }
/* 143:150 */       else if (createType == 5)
/* 144:    */       {
/* 145:151 */         if (w / h <= newW / newH)
/* 146:    */         {
/* 147:152 */           size[1] = newH;
/* 148:153 */           size[0] = ((int)(w / h * size[1]));
/* 149:    */         }
/* 150:    */         else
/* 151:    */         {
/* 152:155 */           size[0] = newW;
/* 153:156 */           size[1] = ((int)(h / w * size[0]));
/* 154:    */         }
/* 155:    */       }
/* 156:    */     }
/* 157:160 */     return size;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static boolean checkImageFile(String extName)
/* 161:    */   {
/* 162:169 */     if ("jpg".equalsIgnoreCase(extName)) {
/* 163:170 */       return true;
/* 164:    */     }
/* 165:171 */     if ("gif".equalsIgnoreCase(extName)) {
/* 166:172 */       return true;
/* 167:    */     }
/* 168:173 */     if ("bmp".equalsIgnoreCase(extName)) {
/* 169:174 */       return true;
/* 170:    */     }
/* 171:175 */     if ("jpeg".equalsIgnoreCase(extName)) {
/* 172:176 */       return true;
/* 173:    */     }
/* 174:177 */     if ("png".equalsIgnoreCase(extName)) {
/* 175:178 */       return true;
/* 176:    */     }
/* 177:179 */     return false;
/* 178:    */   }
/* 179:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.component.image.ImgResize
 * JD-Core Version:    0.7.0.1
 */