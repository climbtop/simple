/*  1:   */ package com.afocus.framework.component.image._enum;
/*  2:   */ 
/*  3:   */ public enum ImgStatusEnum
/*  4:   */ {
/*  5:10 */   NOT_FORCE_RENEW(0, "not_force"),  FORCE_RENEW(1, "force"),  UN_NEED_RESIZE(0, "un_need_resize"),  NEED_RESIZE(1, "need_resize"),  IMG_DELETE(0, "delete"),  IMG_NOT_DELETE(1, "not_delete"),  IMG_OPER_UPLOAD(1, "upload"),  IMG_OPER_DELETE(2, "delete"),  IMG_OPER_LIST(3, "list");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private ImgStatusEnum(int id, String name)
/* 11:   */   {
/* 12:27 */     this.id = id;
/* 13:28 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:31 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:34 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:37 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:40 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static String getNameById(int id)
/* 37:   */   {
/* 38:44 */     for (ImgStatusEnum inst : ) {
/* 39:45 */       if (id == inst.id) {
/* 40:46 */         return inst.getName();
/* 41:   */       }
/* 42:   */     }
/* 43:48 */     throw new IllegalArgumentException("不支持的常量：" + id);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static int getIdByName(String name)
/* 47:   */   {
/* 48:52 */     for (ImgStatusEnum inst : ) {
/* 49:53 */       if (name == inst.name) {
/* 50:54 */         return inst.getId();
/* 51:   */       }
/* 52:   */     }
/* 53:56 */     throw new IllegalArgumentException("不支持的常量：" + name);
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.component.image._enum.ImgStatusEnum
 * JD-Core Version:    0.7.0.1
 */