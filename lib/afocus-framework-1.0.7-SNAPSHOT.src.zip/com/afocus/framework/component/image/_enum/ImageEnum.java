/*  1:   */ package com.afocus.framework.component.image._enum;
/*  2:   */ 
/*  3:   */ public enum ImageEnum
/*  4:   */ {
/*  5:11 */   IMG_LARGE(1, "large"),  IMG_MIDDLE(2, "middle"),  IMG_SMALL(3, "small"),  IMG_DEFAULT(0, "default"),  IMG_WITH_MARK(1, "mark");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private ImageEnum(int id, String name)
/* 11:   */   {
/* 12:22 */     this.id = id;
/* 13:23 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:27 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:31 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:35 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:39 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:43 */     for (ImageEnum goodsEnum : ) {
/* 39:44 */       if (id == goodsEnum.getId()) {
/* 40:45 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:48 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.component.image._enum.ImageEnum
 * JD-Core Version:    0.7.0.1
 */