/*   1:    */ package com.afocus.framework.component.image;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.component.image._enum.ImageEnum;
/*   4:    */ import com.afocus.framework.util.ftp.Sync2FTP;
/*   5:    */ import java.awt.image.BufferedImage;
/*   6:    */ import java.io.File;
/*   7:    */ import java.util.Map;
/*   8:    */ import javax.imageio.ImageIO;
/*   9:    */ 
/*  10:    */ public class ImagesResizeAndSendFTP
/*  11:    */   implements Runnable
/*  12:    */ {
/*  13:    */   private int type;
/*  14:    */   private String filePath;
/*  15:    */   private String ftpPath;
/*  16:    */   private String fileName;
/*  17:    */   private boolean isDelFile;
/*  18:    */   private String basicFilePath;
/*  19: 38 */   private int reTryNumber = 5;
/*  20:    */   private boolean needSync;
/*  21:    */   private Map<String, String> sizeMap;
/*  22:    */   
/*  23:    */   public ImagesResizeAndSendFTP(String filePath, String ftpPath, String fileName, int type, Map<String, String> sizeMap, boolean isDelFile, boolean needSync)
/*  24:    */   {
/*  25: 54 */     this.filePath = filePath;
/*  26: 55 */     this.ftpPath = ftpPath;
/*  27: 56 */     this.fileName = fileName;
/*  28: 57 */     this.type = type;
/*  29: 58 */     this.isDelFile = isDelFile;
/*  30: 59 */     this.basicFilePath = filePath.substring(0, filePath.indexOf(this.fileName));
/*  31: 60 */     this.sizeMap = sizeMap;
/*  32: 61 */     this.needSync = needSync;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void run()
/*  36:    */   {
/*  37: 67 */     resizeImg();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void resizeImg()
/*  41:    */   {
/*  42: 70 */     File imgFile = new File(this.filePath);
/*  43: 71 */     if (imgFile.exists()) {
/*  44:    */       try
/*  45:    */       {
/*  46: 74 */         String newFileName = null;
/*  47: 75 */         if ((0 == this.type) || (1 == this.type))
/*  48:    */         {
/*  49: 76 */           ImgResize.resize(imgFile, 1, Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_LARGE.getName())).split("\\*")[0]), Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_LARGE.getName())).split("\\*")[1]), "_" + ImageEnum.IMG_LARGE.getName());
/*  50: 77 */           newFileName = getLargeImgPath();
/*  51: 78 */           if (this.needSync) {
/*  52: 79 */             Sync2FTP.sycnSFTP(this.basicFilePath + newFileName, this.ftpPath, newFileName, this.isDelFile, this.reTryNumber);
/*  53:    */           }
/*  54:    */         }
/*  55: 82 */         if ((0 == this.type) || (2 == this.type))
/*  56:    */         {
/*  57: 83 */           ImgResize.resize(imgFile, 1, Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_MIDDLE.getName())).split("\\*")[0]), Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_MIDDLE.getName())).split("\\*")[1]), "_" + ImageEnum.IMG_MIDDLE.getName());
/*  58: 84 */           newFileName = getMiddelImgPath();
/*  59: 85 */           if (this.needSync) {
/*  60: 86 */             Sync2FTP.sycnSFTP(this.basicFilePath + newFileName, this.ftpPath, newFileName, this.isDelFile, this.reTryNumber);
/*  61:    */           }
/*  62:    */         }
/*  63: 89 */         if ((0 == this.type) || (3 == this.type))
/*  64:    */         {
/*  65: 90 */           ImgResize.resize(imgFile, 1, Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_SMALL.getName())).split("\\*")[0]), Integer.parseInt(((String)this.sizeMap.get(ImageEnum.IMG_SMALL.getName())).split("\\*")[1]), "_" + ImageEnum.IMG_SMALL.getName());
/*  66: 91 */           newFileName = getSmallImgPath();
/*  67: 92 */           if (this.needSync) {
/*  68: 93 */             Sync2FTP.sycnSFTP(this.basicFilePath + newFileName, this.ftpPath, newFileName, this.isDelFile, this.reTryNumber);
/*  69:    */           }
/*  70:    */         }
/*  71: 96 */         if (4 == this.type)
/*  72:    */         {
/*  73: 97 */           int width = ImageIO.read(imgFile).getWidth(null);
/*  74: 98 */           if (750 < width) {
/*  75: 99 */             ImgResize.resize(imgFile, 2, 750, 0, "");
/*  76:100 */           } else if (200L < imgFile.length() / 1024L) {
/*  77:101 */             ImgResize.resize(imgFile, 2, width, 0, "");
/*  78:    */           }
/*  79:    */         }
/*  80:104 */         if (this.isDelFile) {
/*  81:105 */           imgFile.delete();
/*  82:    */         }
/*  83:    */       }
/*  84:    */       catch (Exception e)
/*  85:    */       {
/*  86:108 */         e.printStackTrace();
/*  87:    */       }
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String getLargeImgPath()
/*  92:    */   {
/*  93:121 */     int index = this.fileName.lastIndexOf(".");
/*  94:122 */     return this.fileName.substring(0, index) + "_large." + this.fileName.substring(index + 1);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public String getMiddelImgPath()
/*  98:    */   {
/*  99:133 */     int index = this.fileName.lastIndexOf(".");
/* 100:134 */     return this.fileName.substring(0, index) + "_middle." + this.fileName.substring(index + 1);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getSmallImgPath()
/* 104:    */   {
/* 105:145 */     int index = this.fileName.lastIndexOf(".");
/* 106:146 */     return this.fileName.substring(0, index) + "_small." + this.fileName.substring(index + 1);
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.component.image.ImagesResizeAndSendFTP
 * JD-Core Version:    0.7.0.1
 */