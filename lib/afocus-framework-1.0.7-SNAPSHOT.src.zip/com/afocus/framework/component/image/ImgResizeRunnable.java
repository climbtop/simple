/*   1:    */ package com.afocus.framework.component.image;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ 
/*   6:    */ public class ImgResizeRunnable
/*   7:    */   implements Runnable
/*   8:    */ {
/*   9:    */   private int type;
/*  10:    */   private String suffix;
/*  11:    */   private File imgFile;
/*  12:    */   private int newW;
/*  13:    */   private int newH;
/*  14:    */   
/*  15:    */   public void copy(File imgFile, String suffix)
/*  16:    */   {
/*  17: 37 */     this.imgFile = imgFile;
/*  18: 38 */     this.suffix = suffix;
/*  19: 39 */     this.type = 0;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void resize(File imgFile, int newW, int newH, String suffix)
/*  23:    */   {
/*  24: 49 */     this.imgFile = imgFile;
/*  25: 50 */     this.newH = newH;
/*  26: 51 */     this.newW = newW;
/*  27: 52 */     this.suffix = suffix;
/*  28: 53 */     this.type = 1;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void resizeByHeight(File imgFile, int newH, String suffix)
/*  32:    */   {
/*  33: 62 */     this.imgFile = imgFile;
/*  34: 63 */     this.newH = newH;
/*  35: 64 */     this.suffix = suffix;
/*  36: 65 */     this.type = 3;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void resizeByWidth(File imgFile, int newW, String suffix)
/*  40:    */   {
/*  41: 75 */     this.imgFile = imgFile;
/*  42: 76 */     this.newW = newW;
/*  43: 77 */     this.suffix = suffix;
/*  44: 78 */     this.type = 2;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void resizeByMax(File imgFile, int newW, int newH, String suffix)
/*  48:    */   {
/*  49: 88 */     this.imgFile = imgFile;
/*  50: 89 */     this.newH = newH;
/*  51: 90 */     this.newW = newW;
/*  52: 91 */     this.suffix = suffix;
/*  53: 92 */     this.type = 4;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void resizeByMin(File imgFile, int newW, int newH, String suffix)
/*  57:    */   {
/*  58:102 */     this.imgFile = imgFile;
/*  59:103 */     this.newH = newH;
/*  60:104 */     this.newW = newW;
/*  61:105 */     this.suffix = suffix;
/*  62:106 */     this.type = 5;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void run()
/*  66:    */   {
/*  67:    */     try
/*  68:    */     {
/*  69:113 */       ImgResize.resize(this.imgFile, this.type, this.newW, this.newH, this.suffix);
/*  70:    */     }
/*  71:    */     catch (IOException e)
/*  72:    */     {
/*  73:115 */       e.printStackTrace();
/*  74:    */     }
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.component.image.ImgResizeRunnable
 * JD-Core Version:    0.7.0.1
 */