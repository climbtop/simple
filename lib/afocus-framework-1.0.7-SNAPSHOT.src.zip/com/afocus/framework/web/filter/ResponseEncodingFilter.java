/*   1:    */ package com.afocus.framework.web.filter;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.StringUtil;
/*   4:    */ import java.io.ByteArrayOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.PrintWriter;
/*   7:    */ import java.io.StringWriter;
/*   8:    */ import java.util.zip.GZIPOutputStream;
/*   9:    */ import javax.servlet.Filter;
/*  10:    */ import javax.servlet.FilterChain;
/*  11:    */ import javax.servlet.FilterConfig;
/*  12:    */ import javax.servlet.ServletException;
/*  13:    */ import javax.servlet.ServletOutputStream;
/*  14:    */ import javax.servlet.ServletRequest;
/*  15:    */ import javax.servlet.ServletResponse;
/*  16:    */ import javax.servlet.http.HttpServletRequest;
/*  17:    */ import javax.servlet.http.HttpServletResponse;
/*  18:    */ import javax.servlet.http.HttpServletResponseWrapper;
/*  19:    */ import org.apache.log4j.Logger;
/*  20:    */ 
/*  21:    */ public class ResponseEncodingFilter
/*  22:    */   implements Filter
/*  23:    */ {
/*  24: 30 */   private Logger log = Logger.getLogger(getClass());
/*  25: 35 */   protected String encoding = "GBK";
/*  26: 41 */   protected String defaultEncoding = "GBK";
/*  27: 46 */   private String excludeUrl = "";
/*  28: 47 */   private String[] excludeUrlArray = null;
/*  29: 52 */   protected boolean gzip = false;
/*  30:    */   
/*  31:    */   public void destroy() {}
/*  32:    */   
/*  33:    */   public void init(FilterConfig filterConfig)
/*  34:    */     throws ServletException
/*  35:    */   {
/*  36: 70 */     String value = filterConfig.getInitParameter("defaultEncoding");
/*  37: 71 */     if (value != null) {
/*  38: 72 */       this.defaultEncoding = value;
/*  39:    */     }
/*  40: 73 */     value = filterConfig.getInitParameter("encoding");
/*  41: 74 */     if (value != null) {
/*  42: 75 */       this.encoding = value;
/*  43:    */     }
/*  44: 76 */     value = filterConfig.getInitParameter("gzip");
/*  45: 77 */     if ((value != null) && ((value.equalsIgnoreCase("true")) || (value.equalsIgnoreCase("yes")))) {
/*  46: 78 */       this.gzip = true;
/*  47:    */     }
/*  48: 80 */     this.excludeUrl = filterConfig.getInitParameter("excludeUrl");
/*  49: 81 */     if (!StringUtil.isEmpty(this.excludeUrl)) {
/*  50: 82 */       this.excludeUrlArray = this.excludeUrl.split(",");
/*  51:    */     }
/*  52: 85 */     this.log.debug("responseEncoding filter inited");
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*  56:    */     throws IOException, ServletException
/*  57:    */   {
/*  58: 99 */     HttpServletRequest request = (HttpServletRequest)req;
/*  59:100 */     HttpServletResponse response = (HttpServletResponse)res;
/*  60:    */     
/*  61:    */ 
/*  62:103 */     StringBuffer requestUrl = request.getRequestURL();
/*  63:104 */     String queryString = request.getQueryString();
/*  64:106 */     if ((queryString != null) && (queryString.length() > 0))
/*  65:    */     {
/*  66:107 */       requestUrl.append('?');
/*  67:108 */       requestUrl.append(queryString);
/*  68:    */     }
/*  69:111 */     String currentRequestUrl = requestUrl.toString();
/*  70:112 */     if (this.excludeUrlArray != null) {
/*  71:113 */       for (int i = 0; i < this.excludeUrlArray.length; i++) {
/*  72:114 */         if (currentRequestUrl.indexOf(this.excludeUrlArray[i]) >= 0)
/*  73:    */         {
/*  74:115 */           chain.doFilter(req, res);
/*  75:116 */           return;
/*  76:    */         }
/*  77:    */       }
/*  78:    */     }
/*  79:121 */     EncodingResponseWrapper responseWrapper = new EncodingResponseWrapper(response);
/*  80:122 */     chain.doFilter(request, responseWrapper);
/*  81:123 */     if ((!responseWrapper.needConvert) && (!this.gzip)) {
/*  82:124 */       return;
/*  83:    */     }
/*  84:125 */     String content = responseWrapper.writer.toString();
/*  85:126 */     if (responseWrapper.needConvert)
/*  86:    */     {
/*  87:127 */       this.log.debug("encoding converted .");
/*  88:128 */       content = StringUtil.iso2gbk(content);
/*  89:    */     }
/*  90:130 */     if (this.gzip)
/*  91:    */     {
/*  92:131 */       String requestAcceptEncoding = request.getHeader("Accept-Encoding");
/*  93:132 */       if ((requestAcceptEncoding != null) && ((requestAcceptEncoding.indexOf("gzip") > -1) || (requestAcceptEncoding.indexOf("deflate") > -1)))
/*  94:    */       {
/*  95:133 */         byte[] data = zip(content);
/*  96:134 */         this.log.debug("gzipped,ContentLength:" + content.length() + " to " + data.length);
/*  97:135 */         response.setContentLength(data.length);
/*  98:136 */         response.setHeader("Content-Encoding", "gzip");
/*  99:137 */         response.getOutputStream().write(data);
/* 100:138 */         response.getOutputStream().flush();
/* 101:139 */         return;
/* 102:    */       }
/* 103:    */     }
/* 104:142 */     if (!StringUtil.isEmpty(content))
/* 105:    */     {
/* 106:143 */       response.getWriter().println(content);
/* 107:144 */       response.getWriter().flush();
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   private byte[] zip(String src)
/* 112:    */     throws IOException
/* 113:    */   {
/* 114:149 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 115:150 */     GZIPOutputStream zipOut = new GZIPOutputStream(out);
/* 116:151 */     zipOut.write(src.getBytes(this.encoding));
/* 117:152 */     zipOut.finish();
/* 118:153 */     return out.toByteArray();
/* 119:    */   }
/* 120:    */   
/* 121:    */   private class EncodingResponseWrapper
/* 122:    */     extends HttpServletResponseWrapper
/* 123:    */   {
/* 124:158 */     private String internalEncoding = null;
/* 125:159 */     private boolean needConvert = false;
/* 126:160 */     private StringWriter writer = new StringWriter();
/* 127:    */     
/* 128:    */     public EncodingResponseWrapper(HttpServletResponse response)
/* 129:    */     {
/* 130:164 */       super();
/* 131:    */     }
/* 132:    */     
/* 133:    */     private boolean isIso88591(String enc)
/* 134:    */     {
/* 135:168 */       String e = null;
/* 136:169 */       if (enc != null) {
/* 137:170 */         e = enc.toLowerCase();
/* 138:    */       } else {
/* 139:172 */         e = System.getProperty("file.encoding").toLowerCase();
/* 140:    */       }
/* 141:173 */       return (e.indexOf("iso") > -1) && (e.indexOf("8859") > -1) && (e.endsWith("1"));
/* 142:    */     }
/* 143:    */     
/* 144:    */     public void setContentType(String value)
/* 145:    */     {
/* 146:177 */       this.needConvert = false;
/* 147:178 */       if ((value.toLowerCase().indexOf("text/") <= -1) && (value.toLowerCase().indexOf("javascript") <= -1))
/* 148:    */       {
/* 149:179 */         super.setContentType(value);
/* 150:180 */         return;
/* 151:    */       }
/* 152:182 */       int index = value.toLowerCase().indexOf("charset=");
/* 153:183 */       String contentType = null;
/* 154:184 */       if (index > -1)
/* 155:    */       {
/* 156:185 */         this.internalEncoding = value.substring(index + "charset=".length());
/* 157:186 */         contentType = value.substring(0, index);
/* 158:    */       }
/* 159:    */       else
/* 160:    */       {
/* 161:189 */         this.internalEncoding = super.getCharacterEncoding();
/* 162:190 */         contentType = value + ";";
/* 163:191 */         if (this.internalEncoding == null) {
/* 164:192 */           this.internalEncoding = ResponseEncodingFilter.this.defaultEncoding;
/* 165:    */         }
/* 166:    */       }
/* 167:194 */       if ((!ResponseEncodingFilter.this.encoding.equalsIgnoreCase(this.internalEncoding)) && (isIso88591(this.internalEncoding))) {
/* 168:195 */         this.needConvert = true;
/* 169:    */       }
/* 170:197 */       contentType = contentType + "charset=" + ResponseEncodingFilter.this.encoding;
/* 171:198 */       ResponseEncodingFilter.this.log.debug("contentType:" + contentType + ", convert " + this.internalEncoding + " to " + ResponseEncodingFilter.this.encoding);
/* 172:199 */       super.setContentType(contentType);
/* 173:    */     }
/* 174:    */     
/* 175:    */     public void setHeader(String name, String value)
/* 176:    */     {
/* 177:203 */       if (!name.equalsIgnoreCase("Content-Type")) {
/* 178:204 */         super.setHeader(name, value);
/* 179:    */       } else {
/* 180:206 */         setContentType(value);
/* 181:    */       }
/* 182:    */     }
/* 183:    */     
/* 184:    */     public void addHeader(String name, String value)
/* 185:    */     {
/* 186:212 */       if (!name.equalsIgnoreCase("Content-Type")) {
/* 187:213 */         super.addHeader(name, value);
/* 188:    */       } else {
/* 189:215 */         setContentType(value);
/* 190:    */       }
/* 191:    */     }
/* 192:    */     
/* 193:    */     public PrintWriter getWriter()
/* 194:    */       throws IOException
/* 195:    */     {
/* 196:220 */       if ((!this.needConvert) && (!ResponseEncodingFilter.this.gzip)) {
/* 197:221 */         return super.getWriter();
/* 198:    */       }
/* 199:222 */       return new PrintWriter(this.writer, true);
/* 200:    */     }
/* 201:    */     
/* 202:    */     public ServletOutputStream getOutputStream()
/* 203:    */       throws IOException
/* 204:    */     {
/* 205:226 */       if (!this.needConvert) {
/* 206:227 */         return super.getOutputStream();
/* 207:    */       }
/* 208:228 */       return new EncodingServletOutputStream(super.getOutputStream());
/* 209:    */     }
/* 210:    */     
/* 211:    */     private class EncodingServletOutputStream
/* 212:    */       extends ServletOutputStream
/* 213:    */     {
/* 214:    */       private ServletOutputStream out;
/* 215:    */       
/* 216:    */       public EncodingServletOutputStream(ServletOutputStream out)
/* 217:    */       {
/* 218:234 */         this.out = out;
/* 219:    */       }
/* 220:    */       
/* 221:    */       public void print(String arg0)
/* 222:    */         throws IOException
/* 223:    */       {
/* 224:237 */         this.out.print(StringUtil.iso2gbk(arg0));
/* 225:    */       }
/* 226:    */       
/* 227:    */       public void println(String arg0)
/* 228:    */         throws IOException
/* 229:    */       {
/* 230:240 */         this.out.println(StringUtil.iso2gbk(arg0));
/* 231:    */       }
/* 232:    */       
/* 233:    */       public void write(int arg0)
/* 234:    */         throws IOException
/* 235:    */       {
/* 236:243 */         this.out.write(arg0);
/* 237:    */       }
/* 238:    */       
/* 239:    */       public void print(char arg0)
/* 240:    */         throws IOException
/* 241:    */       {
/* 242:246 */         this.out.print(arg0);
/* 243:    */       }
/* 244:    */       
/* 245:    */       public void println(char arg0)
/* 246:    */         throws IOException
/* 247:    */       {
/* 248:249 */         this.out.println(arg0);
/* 249:    */       }
/* 250:    */       
/* 251:    */       public void print(boolean arg0)
/* 252:    */         throws IOException
/* 253:    */       {
/* 254:252 */         this.out.print(arg0);
/* 255:    */       }
/* 256:    */       
/* 257:    */       public void print(double arg0)
/* 258:    */         throws IOException
/* 259:    */       {
/* 260:255 */         this.out.print(arg0);
/* 261:    */       }
/* 262:    */       
/* 263:    */       public void print(float arg0)
/* 264:    */         throws IOException
/* 265:    */       {
/* 266:258 */         this.out.print(arg0);
/* 267:    */       }
/* 268:    */       
/* 269:    */       public void print(int arg0)
/* 270:    */         throws IOException
/* 271:    */       {
/* 272:261 */         this.out.print(arg0);
/* 273:    */       }
/* 274:    */       
/* 275:    */       public void print(long arg0)
/* 276:    */         throws IOException
/* 277:    */       {
/* 278:264 */         this.out.print(arg0);
/* 279:    */       }
/* 280:    */       
/* 281:    */       public void println(boolean arg0)
/* 282:    */         throws IOException
/* 283:    */       {
/* 284:267 */         this.out.println(arg0);
/* 285:    */       }
/* 286:    */       
/* 287:    */       public void println(double arg0)
/* 288:    */         throws IOException
/* 289:    */       {
/* 290:270 */         this.out.println(arg0);
/* 291:    */       }
/* 292:    */       
/* 293:    */       public void println(float arg0)
/* 294:    */         throws IOException
/* 295:    */       {
/* 296:273 */         this.out.println(arg0);
/* 297:    */       }
/* 298:    */       
/* 299:    */       public void println(int arg0)
/* 300:    */         throws IOException
/* 301:    */       {
/* 302:276 */         this.out.println(arg0);
/* 303:    */       }
/* 304:    */       
/* 305:    */       public void println(long arg0)
/* 306:    */         throws IOException
/* 307:    */       {
/* 308:279 */         this.out.println(arg0);
/* 309:    */       }
/* 310:    */       
/* 311:    */       public void close()
/* 312:    */         throws IOException
/* 313:    */       {
/* 314:282 */         this.out.close();
/* 315:    */       }
/* 316:    */       
/* 317:    */       public void flush()
/* 318:    */         throws IOException
/* 319:    */       {
/* 320:285 */         this.out.flush();
/* 321:    */       }
/* 322:    */       
/* 323:    */       public void write(byte[] arg0, int arg1, int arg2)
/* 324:    */         throws IOException
/* 325:    */       {
/* 326:288 */         this.out.write(arg0, arg1, arg2);
/* 327:    */       }
/* 328:    */       
/* 329:    */       public void write(byte[] arg0)
/* 330:    */         throws IOException
/* 331:    */       {
/* 332:291 */         this.out.write(arg0);
/* 333:    */       }
/* 334:    */       
/* 335:    */       public void println()
/* 336:    */         throws IOException
/* 337:    */       {
/* 338:294 */         this.out.println();
/* 339:    */       }
/* 340:    */     }
/* 341:    */   }
/* 342:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.web.filter.ResponseEncodingFilter
 * JD-Core Version:    0.7.0.1
 */