/*   1:    */ package com.afocus.framework.web.filter;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.PrintWriter;
/*   5:    */ import javax.servlet.Filter;
/*   6:    */ import javax.servlet.FilterChain;
/*   7:    */ import javax.servlet.FilterConfig;
/*   8:    */ import javax.servlet.ServletException;
/*   9:    */ import javax.servlet.ServletRequest;
/*  10:    */ import javax.servlet.ServletResponse;
/*  11:    */ import javax.servlet.http.HttpServlet;
/*  12:    */ import javax.servlet.http.HttpServletRequest;
/*  13:    */ import javax.servlet.http.HttpServletResponse;
/*  14:    */ import org.apache.log4j.Logger;
/*  15:    */ import org.springframework.beans.BeansException;
/*  16:    */ import org.springframework.web.context.WebApplicationContext;
/*  17:    */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*  18:    */ 
/*  19:    */ public class SpringContextFilter
/*  20:    */   extends HttpServlet
/*  21:    */   implements Filter
/*  22:    */ {
/*  23:    */   private static final long serialVersionUID = 7379407269970059301L;
/*  24: 29 */   private static Logger log = Logger.getLogger(SpringContextFilter.class);
/*  25:    */   
/*  26:    */   public void init(FilterConfig filterConfig)
/*  27:    */     throws ServletException
/*  28:    */   {
/*  29: 38 */     if (SpringWebContext.servletContext == null) {
/*  30: 39 */       SpringWebContext.servletContext = filterConfig.getServletContext();
/*  31:    */     }
/*  32: 41 */     if (SpringWebContext.springContext == null) {
/*  33: 42 */       SpringWebContext.springContext = WebApplicationContextUtils.getRequiredWebApplicationContext(filterConfig.getServletContext());
/*  34:    */     }
/*  35: 44 */     log.info("SpringContextFilter is inited");
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void init()
/*  39:    */     throws ServletException
/*  40:    */   {
/*  41: 53 */     if (SpringWebContext.servletContext == null) {
/*  42: 54 */       SpringWebContext.servletContext = getServletContext();
/*  43:    */     }
/*  44: 56 */     if (SpringWebContext.springContext == null) {
/*  45: 57 */       SpringWebContext.springContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
/*  46:    */     }
/*  47: 59 */     log.info("SpringContextFilter is inited as a servlet");
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*  51:    */     throws ServletException, IOException
/*  52:    */   {
/*  53: 73 */     PrintWriter out = response.getWriter();
/*  54:    */     try
/*  55:    */     {
/*  56: 75 */       SpringWebContext.getSpringContext().getBean("dataSource");
/*  57: 76 */       out.print("OK. Just a test.");
/*  58:    */     }
/*  59:    */     catch (BeansException e)
/*  60:    */     {
/*  61: 78 */       out.print("OK. Just a test. but Spring context no bean: dataSource");
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
/*  66:    */     throws IOException, ServletException
/*  67:    */   {
/*  68:    */     try
/*  69:    */     {
/*  70: 95 */       SpringWebContext.servletRequestLocal.set((HttpServletRequest)servletRequest);
/*  71: 96 */       SpringWebContext.servletResponseLocal.set((HttpServletResponse)servletResponse);
/*  72: 97 */       filterChain.doFilter(servletRequest, servletResponse);
/*  73:    */     }
/*  74:    */     finally
/*  75:    */     {
/*  76:100 */       SpringWebContext.servletRequestLocal.remove();
/*  77:101 */       SpringWebContext.servletResponseLocal.remove();
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void destroy() {}
/*  82:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.web.filter.SpringContextFilter
 * JD-Core Version:    0.7.0.1
 */