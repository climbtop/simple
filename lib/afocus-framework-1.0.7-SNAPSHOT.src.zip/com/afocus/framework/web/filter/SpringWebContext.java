/*   1:    */ package com.afocus.framework.web.filter;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.StringUtil;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ import java.net.URL;
/*   6:    */ import javax.servlet.ServletContext;
/*   7:    */ import javax.servlet.http.HttpServletRequest;
/*   8:    */ import javax.servlet.http.HttpServletResponse;
/*   9:    */ import org.apache.log4j.Logger;
/*  10:    */ import org.springframework.beans.BeansException;
/*  11:    */ import org.springframework.web.context.ContextLoader;
/*  12:    */ import org.springframework.web.context.WebApplicationContext;
/*  13:    */ import org.springframework.web.servlet.DispatcherServlet;
/*  14:    */ 
/*  15:    */ public class SpringWebContext
/*  16:    */ {
/*  17: 21 */   private static Logger log = Logger.getLogger(SpringWebContext.class);
/*  18: 23 */   static WebApplicationContext springContext = null;
/*  19: 24 */   static ServletContext servletContext = null;
/*  20: 25 */   static ThreadLocal<HttpServletRequest> servletRequestLocal = new ThreadLocal();
/*  21: 26 */   static ThreadLocal<HttpServletResponse> servletResponseLocal = new ThreadLocal();
/*  22:    */   
/*  23:    */   public static WebApplicationContext getSpringContext()
/*  24:    */   {
/*  25: 32 */     if (springContext == null) {
/*  26: 33 */       springContext = ContextLoader.getCurrentWebApplicationContext();
/*  27:    */     }
/*  28: 34 */     return springContext;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static WebApplicationContext getControllerSpringContext(HttpServletRequest request)
/*  32:    */   {
/*  33: 43 */     WebApplicationContext wac = (WebApplicationContext)request.getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*  34: 44 */     if (springContext == null) {
/*  35: 45 */       springContext = wac;
/*  36:    */     }
/*  37: 46 */     return wac;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static Object getSpringBean(String beanName)
/*  41:    */   {
/*  42:    */     try
/*  43:    */     {
/*  44: 56 */       return getSpringContext().getBean(beanName);
/*  45:    */     }
/*  46:    */     catch (Exception e)
/*  47:    */     {
/*  48: 58 */       log.error("not defined:" + beanName + "," + e);
/*  49:    */     }
/*  50: 59 */     return null;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static Object getSpringBean(String beanName, Class clazz)
/*  54:    */   {
/*  55:    */     try
/*  56:    */     {
/*  57: 72 */       return getSpringContext().getBean(beanName, clazz);
/*  58:    */     }
/*  59:    */     catch (BeansException e)
/*  60:    */     {
/*  61: 74 */       log.error("not defined:" + beanName + "," + e);
/*  62: 75 */       e.printStackTrace();
/*  63:    */     }
/*  64: 76 */     return null;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static String getRealPath(String filePath)
/*  68:    */   {
/*  69: 86 */     if (StringUtil.isEmpty(filePath)) {
/*  70: 87 */       filePath = "/";
/*  71:    */     }
/*  72: 89 */     if (filePath.startsWith("classpath:"))
/*  73:    */     {
/*  74: 90 */       filePath = filePath.substring("classpath:".length());
/*  75: 91 */       String path = getClassesPath();
/*  76: 92 */       StringBuilder sb = new StringBuilder(path);
/*  77: 93 */       if (StringUtil.isEmpty(filePath)) {
/*  78: 94 */         return "/";
/*  79:    */       }
/*  80: 95 */       if (filePath.startsWith("/")) {
/*  81: 96 */         return filePath;
/*  82:    */       }
/*  83: 97 */       return "/" + filePath;
/*  84:    */     }
/*  85: 99 */     if (servletContext != null) {
/*  86:100 */       return servletContext.getRealPath(filePath);
/*  87:    */     }
/*  88:102 */     if (filePath.startsWith("/WEB-INF/"))
/*  89:    */     {
/*  90:103 */       String path = getClassesPath();
/*  91:104 */       StringBuilder sb = new StringBuilder(path);
/*  92:105 */       int index = path.indexOf("/WEB-INF/classes");
/*  93:106 */       if (index > -1) {
/*  94:107 */         sb.setLength(index);
/*  95:    */       }
/*  96:108 */       if (StringUtil.isEmpty(filePath)) {
/*  97:109 */         return "/";
/*  98:    */       }
/*  99:110 */       if (filePath.startsWith("/")) {
/* 100:111 */         return filePath;
/* 101:    */       }
/* 102:112 */       return "/" + filePath;
/* 103:    */     }
/* 104:114 */     return filePath;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static String getClassesPath()
/* 108:    */   {
/* 109:123 */     String path = SpringWebContext.class.getResource("/" + SpringWebContext.class.getCanonicalName().replace('.', '/') + ".class").getPath();
/* 110:124 */     if (path == null)
/* 111:    */     {
/* 112:125 */       path = Thread.currentThread().getContextClassLoader().getResource(".").getPath();
/* 113:126 */       log.debug(path);
/* 114:    */     }
/* 115:    */     else
/* 116:    */     {
/* 117:129 */       path = path.substring(0, path.indexOf(SpringWebContext.class.getCanonicalName().replace('.', '/') + ".class"));
/* 118:    */     }
/* 119:131 */     if (path.endsWith("/classes/")) {
/* 120:132 */       return path;
/* 121:    */     }
/* 122:133 */     if ((path.endsWith(".jar!/")) && (path.startsWith("file:")))
/* 123:    */     {
/* 124:134 */       path = path.substring(5);
/* 125:135 */       path = path.substring(0, path.lastIndexOf(".jar!/"));
/* 126:136 */       path = path.substring(0, path.lastIndexOf("/") + 1);
/* 127:137 */       return path.replace("/lib/", "/classes/");
/* 128:    */     }
/* 129:139 */     return path;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static void main(String[] args)
/* 133:    */     throws Exception
/* 134:    */   {
/* 135:143 */     System.out.println(getClassesPath());
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static ServletContext getServletContext()
/* 139:    */   {
/* 140:150 */     if (servletContext == null) {
/* 141:151 */       log.error("SpringContextFilter not inited");
/* 142:    */     }
/* 143:152 */     return servletContext;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static HttpServletRequest getServletRequest()
/* 147:    */   {
/* 148:159 */     return (HttpServletRequest)servletRequestLocal.get();
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static HttpServletResponse getServletResponse()
/* 152:    */   {
/* 153:166 */     return (HttpServletResponse)servletResponseLocal.get();
/* 154:    */   }
/* 155:    */   
/* 156:    */   static void destroy()
/* 157:    */   {
/* 158:173 */     springContext = null;
/* 159:174 */     servletContext = null;
/* 160:    */   }
/* 161:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.web.filter.SpringWebContext
 * JD-Core Version:    0.7.0.1
 */