/*  1:   */ package com.afocus.framework.web.servlet;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.util.VerifyCodeUtil;
/*  4:   */ import com.afocus.framework.util.VerifyCodeUtil.VerifyCode;
/*  5:   */ import com.afocus.framework.web.HttpRequestUtil;
/*  6:   */ import java.io.IOException;
/*  7:   */ import javax.imageio.ImageIO;
/*  8:   */ import javax.servlet.ServletException;
/*  9:   */ import javax.servlet.http.HttpServlet;
/* 10:   */ import javax.servlet.http.HttpServletRequest;
/* 11:   */ import javax.servlet.http.HttpServletResponse;
/* 12:   */ 
/* 13:   */ public class VerifyCodeServlet
/* 14:   */   extends HttpServlet
/* 15:   */ {
/* 16:   */   private static final long serialVersionUID = 6143249224331707839L;
/* 17:   */   
/* 18:   */   public void destroy()
/* 19:   */   {
/* 20:34 */     super.destroy();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/* 24:   */     throws ServletException, IOException
/* 25:   */   {
/* 26:56 */     int wordCount = HttpRequestUtil.getIntParameter(request, "wc", 4);
/* 27:57 */     int fast = HttpRequestUtil.getIntParameter(request, "f");
/* 28:58 */     int width = HttpRequestUtil.getIntParameter(request, "w", 50);
/* 29:59 */     int height = HttpRequestUtil.getIntParameter(request, "h", 20);
/* 30:60 */     int fontSize = HttpRequestUtil.getIntParameter(request, "fs", 16);
/* 31:61 */     int expire = HttpRequestUtil.getIntParameter(request, "e", -1);
/* 32:62 */     String ext = HttpRequestUtil.getParameter(request, "ext", "png");
/* 33:63 */     String cookieName = HttpRequestUtil.getParameter(request, "cn", "VerifyCode");
/* 34:   */     
/* 35:65 */     response.setHeader("Pragma", "No-cache");
/* 36:66 */     response.setHeader("Cache-Control", "no-cache");
/* 37:67 */     response.setDateHeader("Expires", 0L);
/* 38:68 */     response.setContentType("image/" + ext);
/* 39:   */     
/* 40:   */ 
/* 41:71 */     String domain = HttpRequestUtil.getHeader(request, "Host");
/* 42:72 */     int root = HttpRequestUtil.getIntParameter(request, "r");
/* 43:73 */     domain = domain.split(":")[0];
/* 44:74 */     if (root > 0) {
/* 45:75 */       domain = domain.substring(domain.indexOf("."));
/* 46:   */     }
/* 47:79 */     VerifyCodeUtil.VerifyCode code = fast > 0 ? VerifyCodeUtil.getVerifyCodeFromCache(wordCount, width, height, fontSize, expire) : VerifyCodeUtil.createVerifyCode(wordCount, width, height, fontSize, expire);
/* 48:   */     
/* 49:81 */     VerifyCodeUtil.setVerifyCodeCookie(code, response, cookieName, domain);
/* 50:82 */     ImageIO.write(code.getImage(), ext.toUpperCase(), response.getOutputStream());
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void init()
/* 54:   */     throws ServletException
/* 55:   */   {}
/* 56:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.web.servlet.VerifyCodeServlet
 * JD-Core Version:    0.7.0.1
 */