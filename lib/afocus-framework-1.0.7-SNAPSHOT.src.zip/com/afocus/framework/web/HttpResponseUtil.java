/*   1:    */ package com.afocus.framework.web;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.StringUtil;
/*   4:    */ import com.afocus.framework.util.UrlUtil;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.util.Date;
/*   7:    */ import javax.servlet.http.Cookie;
/*   8:    */ import javax.servlet.http.HttpServletResponse;
/*   9:    */ 
/*  10:    */ public final class HttpResponseUtil
/*  11:    */ {
/*  12:    */   public static void setCookie(HttpServletResponse response, String name, String value, String domain, String path, int expireSecond)
/*  13:    */   {
/*  14: 31 */     value = UrlUtil.encode(value, "UTF-8").replace("+", "%20");
/*  15: 32 */     Cookie cookie = new Cookie(name, value);
/*  16: 33 */     cookie.setSecure(false);
/*  17: 34 */     cookie.setPath(path);
/*  18: 35 */     cookie.setMaxAge(expireSecond);
/*  19: 36 */     if (!StringUtil.isEmpty(domain)) {
/*  20: 37 */       cookie.setDomain(domain);
/*  21:    */     }
/*  22: 38 */     response.addCookie(cookie);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static void setCookie(HttpServletResponse response, String name, String value, String domain, String path)
/*  26:    */   {
/*  27: 51 */     setCookie(response, name, value, domain, path, -1);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void setCookie(HttpServletResponse response, String name, String value, String domain)
/*  31:    */   {
/*  32: 63 */     setCookie(response, name, value, domain, "/", -1);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void setCookie(HttpServletResponse response, String name, String value)
/*  36:    */   {
/*  37: 74 */     setCookie(response, name, value, null, "/", -1);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void deleteCookie(HttpServletResponse response, Cookie cookie)
/*  41:    */   {
/*  42: 84 */     if (cookie != null)
/*  43:    */     {
/*  44: 85 */       cookie.setMaxAge(0);
/*  45: 86 */       response.addCookie(cookie);
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static void deleteCookie(HttpServletResponse response, String name)
/*  50:    */   {
/*  51: 97 */     setCookie(response, name, null, null, "/", 0);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static void deleteCookie(HttpServletResponse response, String name, String domain)
/*  55:    */   {
/*  56:108 */     setCookie(response, name, null, domain, "/", 0);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static void deleteCookie(HttpServletResponse response, String name, String domain, String path)
/*  60:    */   {
/*  61:120 */     setCookie(response, name, null, domain, path, 0);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static void setCacheHeader(HttpServletResponse response, int expireSeconds, Date lastModified)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67:125 */     response.setHeader("Cache-Control", "public, max-age=" + expireSeconds);
/*  68:126 */     if (lastModified != null) {
/*  69:128 */       response.setDateHeader("Last-Modified", lastModified.getTime());
/*  70:    */     }
/*  71:131 */     response.setDateHeader("Expires", System.currentTimeMillis() + expireSeconds * 1000);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static void cacheAndRedriect(HttpServletResponse response, int expireSeconds, String url)
/*  75:    */     throws IOException
/*  76:    */   {
/*  77:135 */     setCacheHeader(response, expireSeconds, new Date());
/*  78:136 */     response.sendRedirect(url);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static void noCacheAndRedriect(HttpServletResponse response, String url)
/*  82:    */     throws IOException
/*  83:    */   {
/*  84:140 */     setNoCacheHeader(response);
/*  85:141 */     response.sendRedirect(url);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static void setNoCacheHeader(HttpServletResponse response)
/*  89:    */     throws IOException
/*  90:    */   {
/*  91:145 */     response.setHeader("Pragma", "no-cache");
/*  92:146 */     response.setHeader("Cache-Control", "max-age=0");
/*  93:    */     
/*  94:148 */     response.setHeader("Expires", "0");
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.web.HttpResponseUtil
 * JD-Core Version:    0.7.0.1
 */