/*   1:    */ package com.afocus.framework.web;
/*   2:    */ 
/*   3:    */ import java.math.BigDecimal;
/*   4:    */ import java.text.DateFormat;
/*   5:    */ import java.text.ParseException;
/*   6:    */ import java.text.SimpleDateFormat;
/*   7:    */ import java.util.Date;
/*   8:    */ import java.util.Enumeration;
/*   9:    */ import java.util.HashMap;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Objects;
/*  12:    */ import java.util.Properties;
/*  13:    */ import javax.servlet.http.Cookie;
/*  14:    */ import javax.servlet.http.HttpServletRequest;
/*  15:    */ import org.apache.commons.lang3.StringUtils;
/*  16:    */ 
/*  17:    */ public final class HttpRequestUtil
/*  18:    */ {
/*  19:    */   public static String getAppURL(HttpServletRequest request)
/*  20:    */   {
/*  21: 31 */     StringBuilder url = new StringBuilder();
/*  22: 32 */     int port = request.getServerPort();
/*  23: 33 */     if (port < 0) {
/*  24: 34 */       port = 80;
/*  25:    */     }
/*  26: 36 */     String scheme = request.getScheme();
/*  27: 37 */     url.append(scheme);
/*  28: 38 */     url.append("://");
/*  29: 39 */     url.append(request.getServerName());
/*  30: 40 */     if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443)))
/*  31:    */     {
/*  32: 41 */       url.append(':');
/*  33: 42 */       url.append(port);
/*  34:    */     }
/*  35: 44 */     url.append(request.getContextPath());
/*  36: 45 */     return url.toString();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static String getUserIp(HttpServletRequest request)
/*  40:    */   {
/*  41: 57 */     String ip = request.getHeader("X-Forwarded-For");
/*  42: 58 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  43: 59 */       ip = request.getHeader("X-Real-IP");
/*  44:    */     }
/*  45: 61 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  46: 62 */       ip = request.getHeader("Cdn-Src-Ip");
/*  47:    */     }
/*  48: 64 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  49: 65 */       ip = request.getHeader("Proxy-Client-IP");
/*  50:    */     }
/*  51: 67 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  52: 68 */       ip = request.getHeader("WL-Proxy-Client-IP");
/*  53:    */     }
/*  54: 70 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  55: 71 */       ip = request.getRemoteAddr();
/*  56:    */     }
/*  57: 73 */     if (ip.contains(",")) {
/*  58: 74 */       ip = ip.substring(0, ip.indexOf(","));
/*  59:    */     }
/*  60: 76 */     return ip;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static String getParameter(HttpServletRequest request, String name, String defaultValue)
/*  64:    */   {
/*  65: 88 */     String value = request.getParameter(name);
/*  66: 89 */     return StringUtils.isEmpty(value) ? defaultValue : value;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static String getParameter(HttpServletRequest request, String name)
/*  70:    */   {
/*  71: 99 */     return getParameter(request, name, null);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static String getHeader(HttpServletRequest request, String name, String defaultValue)
/*  75:    */   {
/*  76:111 */     String value = request.getHeader(name);
/*  77:112 */     return StringUtils.isEmpty(value) ? defaultValue : value;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static String getHeader(HttpServletRequest request, String name)
/*  81:    */   {
/*  82:122 */     return getHeader(request, name, null);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static int getIntParameter(HttpServletRequest request, String name)
/*  86:    */   {
/*  87:132 */     return getIntParameter(request, name, 0);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static int getIntParameter(HttpServletRequest request, String name, int defaultValue)
/*  91:    */   {
/*  92:144 */     return convertInt(request.getParameter(name), defaultValue);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static BigDecimal getBigDecimalParameter(HttpServletRequest request, String name)
/*  96:    */   {
/*  97:154 */     return convertBigDecimal(request.getParameter(name));
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static int getIntAttribute(HttpServletRequest request, String name)
/* 101:    */   {
/* 102:164 */     return getIntAttribute(request, name, 0);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static int getIntAttribute(HttpServletRequest request, String name, int defaultValue)
/* 106:    */   {
/* 107:175 */     Object value = request.getAttribute(name);
/* 108:176 */     return value == null ? defaultValue : convertInt(value.toString(), defaultValue);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static String getStringAttribute(HttpServletRequest request, String name, String defaultValue)
/* 112:    */   {
/* 113:187 */     Object value = request.getAttribute(name);
/* 114:188 */     return !Objects.equals(value, null) ? value.toString() : defaultValue;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static long getLongParameter(HttpServletRequest request, String name)
/* 118:    */   {
/* 119:198 */     return getLongParameter(request, name, 0L);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static long getLongParameter(HttpServletRequest request, String name, long defaultValue)
/* 123:    */   {
/* 124:209 */     return convertLong(request.getParameter(name), defaultValue);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static float getFloatParameter(HttpServletRequest request, String name)
/* 128:    */   {
/* 129:219 */     return getFloatParameter(request, name, 0.0F);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static float getFloatParameter(HttpServletRequest request, String name, float defaultValue)
/* 133:    */   {
/* 134:230 */     return convertFloat(request.getParameter(name), defaultValue);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public static Date getDateParameter(HttpServletRequest request, String name, String dateFormat)
/* 138:    */   {
/* 139:241 */     return getDateParameter(request, name, dateFormat, null);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static Date getDateParameter(HttpServletRequest request, String name, String dateFormat, Date defaultValue)
/* 143:    */   {
/* 144:253 */     return convertDate(request.getParameter(name), dateFormat, defaultValue);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static int getIntHeader(HttpServletRequest request, String name)
/* 148:    */   {
/* 149:263 */     return getIntHeader(request, name, 0);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static int getIntHeader(HttpServletRequest request, String name, int defaultValue)
/* 153:    */   {
/* 154:274 */     return convertInt(request.getHeader(name), defaultValue);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static Date getDateHeader(HttpServletRequest request, String name, String dateFormat)
/* 158:    */   {
/* 159:285 */     return getDateHeader(request, name, dateFormat, null);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static Date getDateHeader(HttpServletRequest request, String name, String dateFormat, Date defaultValue)
/* 163:    */   {
/* 164:297 */     return convertDate(request.getHeader(name), dateFormat, defaultValue);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static Cookie getCookie(HttpServletRequest request, String cookieName)
/* 168:    */   {
/* 169:307 */     Cookie[] cookies = getCookies(request);
/* 170:308 */     if (cookies == null) {
/* 171:309 */       return null;
/* 172:    */     }
/* 173:310 */     for (Cookie cookie : cookies) {
/* 174:311 */       if (cookie.getName().equalsIgnoreCase(cookieName)) {
/* 175:312 */         return cookie;
/* 176:    */       }
/* 177:    */     }
/* 178:314 */     return null;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static String getCookieValue(HttpServletRequest request, String cookieName, String defaultValue)
/* 182:    */   {
/* 183:325 */     Cookie c = getCookie(request, cookieName);
/* 184:326 */     if (c == null) {
/* 185:327 */       return defaultValue;
/* 186:    */     }
/* 187:328 */     String value = c.getValue();
/* 188:329 */     return StringUtils.isEmpty(value) ? defaultValue : value;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static int getCookieIntValue(HttpServletRequest request, String cookieName, int defaultValue)
/* 192:    */   {
/* 193:340 */     return convertInt(getCookieValue(request, cookieName, ""), defaultValue);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static long getCookieLongValue(HttpServletRequest request, String cookieName, long defaultValue)
/* 197:    */   {
/* 198:351 */     return convertLong(getCookieValue(request, cookieName, ""), defaultValue);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static float getCookieLongValue(HttpServletRequest request, String cookieName, float defaultValue)
/* 202:    */   {
/* 203:362 */     return convertFloat(getCookieValue(request, cookieName, ""), defaultValue);
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static Cookie[] getCookies(HttpServletRequest request)
/* 207:    */   {
/* 208:369 */     return request.getCookies();
/* 209:    */   }
/* 210:    */   
/* 211:    */   public static synchronized Properties getHeaders(HttpServletRequest request)
/* 212:    */   {
/* 213:377 */     Properties headers = new Properties();
/* 214:378 */     for (Enumeration<String> names = request.getHeaderNames(); names.hasMoreElements();)
/* 215:    */     {
/* 216:379 */       String name = (String)names.nextElement();
/* 217:380 */       headers.setProperty(name, request.getHeader(name));
/* 218:    */     }
/* 219:382 */     return headers;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public static synchronized Properties getParameters(HttpServletRequest request)
/* 223:    */   {
/* 224:390 */     Properties parameters = new Properties();
/* 225:391 */     for (Enumeration<String> names = request.getParameterNames(); names.hasMoreElements();)
/* 226:    */     {
/* 227:392 */       String name = (String)names.nextElement();
/* 228:393 */       parameters.setProperty(name, request.getParameter(name));
/* 229:    */     }
/* 230:395 */     return parameters;
/* 231:    */   }
/* 232:    */   
/* 233:    */   public static synchronized Map<String, Object> getAttributes(HttpServletRequest request)
/* 234:    */   {
/* 235:403 */     HashMap<String, Object> attributes = new HashMap();
/* 236:404 */     for (Enumeration<String> names = request.getAttributeNames(); names.hasMoreElements();)
/* 237:    */     {
/* 238:405 */       String name = (String)names.nextElement();
/* 239:406 */       attributes.put(name, request.getAttribute(name));
/* 240:    */     }
/* 241:408 */     return attributes;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public static String getUrl(HttpServletRequest request)
/* 245:    */   {
/* 246:415 */     return request.getRequestURI() + (request.getQueryString() != null ? "?" + request.getQueryString() : "");
/* 247:    */   }
/* 248:    */   
/* 249:    */   private static int convertInt(String value, int defaultValue)
/* 250:    */   {
/* 251:420 */     if (StringUtils.isEmpty(value)) {
/* 252:421 */       return defaultValue;
/* 253:    */     }
/* 254:    */     try
/* 255:    */     {
/* 256:423 */       return Integer.parseInt(value);
/* 257:    */     }
/* 258:    */     catch (NumberFormatException e) {}
/* 259:425 */     return defaultValue;
/* 260:    */   }
/* 261:    */   
/* 262:    */   private static BigDecimal convertBigDecimal(String value)
/* 263:    */   {
/* 264:430 */     if (StringUtils.isEmpty(value)) {
/* 265:431 */       return null;
/* 266:    */     }
/* 267:    */     try
/* 268:    */     {
/* 269:433 */       return new BigDecimal(value);
/* 270:    */     }
/* 271:    */     catch (Exception e) {}
/* 272:435 */     return null;
/* 273:    */   }
/* 274:    */   
/* 275:    */   private static float convertFloat(String value, float defaultValue)
/* 276:    */   {
/* 277:440 */     if (StringUtils.isEmpty(value)) {
/* 278:441 */       return defaultValue;
/* 279:    */     }
/* 280:    */     try
/* 281:    */     {
/* 282:443 */       return Float.parseFloat(value);
/* 283:    */     }
/* 284:    */     catch (NumberFormatException e) {}
/* 285:445 */     return defaultValue;
/* 286:    */   }
/* 287:    */   
/* 288:    */   private static long convertLong(String value, long defaultValue)
/* 289:    */   {
/* 290:450 */     if (StringUtils.isEmpty(value)) {
/* 291:451 */       return defaultValue;
/* 292:    */     }
/* 293:    */     try
/* 294:    */     {
/* 295:453 */       return Long.parseLong(value);
/* 296:    */     }
/* 297:    */     catch (NumberFormatException e) {}
/* 298:455 */     return defaultValue;
/* 299:    */   }
/* 300:    */   
/* 301:    */   private static Date convertDate(String value, String dateFormat, Date defaultValue)
/* 302:    */   {
/* 303:460 */     if (StringUtils.isEmpty(value)) {
/* 304:461 */       return defaultValue;
/* 305:    */     }
/* 306:462 */     DateFormat df = new SimpleDateFormat(dateFormat);
/* 307:    */     try
/* 308:    */     {
/* 309:464 */       return df.parse(value);
/* 310:    */     }
/* 311:    */     catch (ParseException e) {}
/* 312:466 */     return defaultValue;
/* 313:    */   }
/* 314:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.web.HttpRequestUtil
 * JD-Core Version:    0.7.0.1
 */