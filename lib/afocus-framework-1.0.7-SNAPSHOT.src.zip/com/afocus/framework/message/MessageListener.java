package com.afocus.framework.message;

public abstract interface MessageListener
{
  public abstract boolean onReceived(Message paramMessage, MessageSender paramMessageSender);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.MessageListener
 * JD-Core Version:    0.7.0.1
 */