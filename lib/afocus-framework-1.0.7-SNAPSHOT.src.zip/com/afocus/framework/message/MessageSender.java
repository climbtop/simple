package com.afocus.framework.message;

public abstract interface MessageSender
{
  public abstract void send(Message paramMessage);
  
  public abstract Object getLocalAddress();
  
  public abstract void close();
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.MessageSender
 * JD-Core Version:    0.7.0.1
 */