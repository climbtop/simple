/* 1:  */ package com.afocus.framework.message.rpc;
/* 2:  */ 
/* 3:  */ public class StatusCheckRequestMessage
/* 4:  */   extends RequestMessage
/* 5:  */ {
/* 6:  */   private static final long serialVersionUID = -2185305896037360194L;
/* 7:  */   
/* 8:  */   public StatusCheckRequestMessage()
/* 9:  */   {
/* ::9 */     super("StatusCheck", null);
/* ;:  */   }
/* <:  */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.StatusCheckRequestMessage
 * JD-Core Version:    0.7.0.1
 */