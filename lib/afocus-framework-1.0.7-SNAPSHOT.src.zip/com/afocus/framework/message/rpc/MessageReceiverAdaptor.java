/*   1:    */ package com.afocus.framework.message.rpc;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.message.Message;
/*   4:    */ import com.afocus.framework.message.MessageListener;
/*   5:    */ import com.afocus.framework.util.SimpleThreadPool;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.apache.log4j.Logger;
/*   9:    */ 
/*  10:    */ public class MessageReceiverAdaptor
/*  11:    */   implements MessageReceiver
/*  12:    */ {
/*  13: 21 */   protected Logger log = Logger.getLogger(getClass());
/*  14: 23 */   protected Map<String, MessageListener> listenerMap = new HashMap();
/*  15: 25 */   private SimpleThreadPool hardTaskThreadPool = new SimpleThreadPool(1, 2, 10L);
/*  16:    */   
/*  17:    */   public void onReceived(Message msg, MessageSender sender)
/*  18:    */   {
/*  19: 32 */     if (this.log.isDebugEnabled()) {
/*  20: 33 */       this.log.debug("onReceived " + msg.getClass().getSimpleName() + ":" + msg);
/*  21:    */     }
/*  22: 35 */     if ((msg instanceof RequestMessage)) {
/*  23: 36 */       processRequest((RequestMessage)msg, sender);
/*  24:    */     } else {
/*  25: 39 */       processResponse((ResponseMessage)msg, sender);
/*  26:    */     }
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected MessageListener getTopicListener(String topic)
/*  30:    */   {
/*  31: 43 */     return (MessageListener)this.listenerMap.get(topic);
/*  32:    */   }
/*  33:    */   
/*  34:    */   protected void processRequest(RequestMessage request, MessageSender sender)
/*  35:    */   {
/*  36: 47 */     MessageListener listener = getTopicListener(request.getTopic());
/*  37:    */     try
/*  38:    */     {
/*  39: 49 */       if (null == listener) {
/*  40: 50 */         throw new RPCException((byte)5, "unrecognizable command:" + request.getTopic());
/*  41:    */       }
/*  42: 52 */       if ((request instanceof HardTaskRequestMessage))
/*  43:    */       {
/*  44: 53 */         HardTask task = new HardTask(request, sender, listener);
/*  45: 54 */         if (!this.hardTaskThreadPool.addTask(task)) {
/*  46: 55 */           throw new RPCException((byte)1, "system busy, thread pool is full.");
/*  47:    */         }
/*  48: 57 */         return;
/*  49:    */       }
/*  50: 59 */       listener.onReceived(request, sender);
/*  51:    */     }
/*  52:    */     catch (Exception e)
/*  53:    */     {
/*  54: 62 */       e.printStackTrace();
/*  55: 63 */       onException(request, sender, e);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected void processResponse(ResponseMessage response, MessageSender sender) {}
/*  60:    */   
/*  61:    */   public void destroy()
/*  62:    */   {
/*  63: 71 */     if (this.hardTaskThreadPool != null)
/*  64:    */     {
/*  65: 72 */       this.hardTaskThreadPool.waitCompleted();
/*  66: 73 */       this.hardTaskThreadPool.shutdown();
/*  67: 74 */       this.hardTaskThreadPool = null;
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   private class HardTask
/*  72:    */     implements Runnable
/*  73:    */   {
/*  74:    */     Message msg;
/*  75:    */     MessageSender sender;
/*  76:    */     MessageListener listener;
/*  77:    */     
/*  78:    */     HardTask(Message msg, MessageSender sender, MessageListener listener)
/*  79:    */     {
/*  80: 85 */       this.msg = msg;
/*  81: 86 */       this.sender = sender;
/*  82: 87 */       this.listener = listener;
/*  83:    */     }
/*  84:    */     
/*  85:    */     public void run()
/*  86:    */     {
/*  87:    */       try
/*  88:    */       {
/*  89: 92 */         this.listener.onReceived(this.msg, this.sender);
/*  90:    */       }
/*  91:    */       catch (Exception e)
/*  92:    */       {
/*  93: 94 */         e.printStackTrace();
/*  94: 95 */         MessageReceiverAdaptor.this.onException(this.msg, this.sender, e);
/*  95:    */       }
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setListenerMap(Map<String, MessageListener> map)
/* 100:    */   {
/* 101:102 */     this.listenerMap.putAll(map);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void addMessageProcessor(String commandName, MessageListener processor)
/* 105:    */   {
/* 106:106 */     this.listenerMap.put(commandName, processor);
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected void onException(Message msg, MessageSender sender, Exception e)
/* 110:    */   {
/* 111:    */     try
/* 112:    */     {
/* 113:111 */       sender.send(new ExceptionMessage(msg.getSequence(), msg.getTopic(), e));
/* 114:112 */       this.log.error("process msg: " + msg + ", err=" + e);
/* 115:    */     }
/* 116:    */     catch (RuntimeException e1)
/* 117:    */     {
/* 118:114 */       this.log.error("exception when send exceptionMessage: " + msg + ", err=" + e);
/* 119:115 */       e1.printStackTrace();
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void setHardTaskQueueCapacity(short size)
/* 124:    */   {
/* 125:119 */     this.hardTaskThreadPool.setQueueCapacity(size);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setHardTaskMaxPoolSize(int size)
/* 129:    */   {
/* 130:123 */     this.hardTaskThreadPool.setMaximumPoolSize(size);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setHardTaskCorePoolSize(int size)
/* 134:    */   {
/* 135:127 */     this.hardTaskThreadPool.setCorePoolSize(size);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setHardTaskKeepAliveSecond(int time)
/* 139:    */   {
/* 140:131 */     this.hardTaskThreadPool.setKeepAliveSecond(time);
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.MessageReceiverAdaptor
 * JD-Core Version:    0.7.0.1
 */