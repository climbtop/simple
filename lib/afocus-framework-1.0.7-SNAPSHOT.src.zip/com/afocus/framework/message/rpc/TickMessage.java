/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.message.Message;
/*  4:   */ 
/*  5:   */ public class TickMessage
/*  6:   */   extends Message
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = -2185305896037360194L;
/*  9:   */   
/* 10:   */   public TickMessage()
/* 11:   */   {
/* 12:11 */     super("TICK", null);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.TickMessage
 * JD-Core Version:    0.7.0.1
 */