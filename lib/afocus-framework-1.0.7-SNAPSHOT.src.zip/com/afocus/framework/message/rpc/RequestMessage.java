/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.message.Message;
/*  4:   */ import java.io.Serializable;
/*  5:   */ 
/*  6:   */ public class RequestMessage
/*  7:   */   extends Message
/*  8:   */   implements Serializable
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = -9166818350349684114L;
/* 11:18 */   protected transient int pendingTTL = -1;
/* 12:20 */   protected boolean pending = false;
/* 13:   */   
/* 14:   */   public RequestMessage() {}
/* 15:   */   
/* 16:   */   public RequestMessage(String command, Object parameter)
/* 17:   */   {
/* 18:26 */     super(command, parameter);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public RequestMessage(String command, Object parameter, boolean pending)
/* 22:   */   {
/* 23:30 */     super(command, parameter);
/* 24:31 */     setPending(pending);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public RequestMessage(String command, Object parameter, int pendingTTL)
/* 28:   */   {
/* 29:35 */     super(command, parameter);
/* 30:36 */     setPending(true);
/* 31:37 */     setPendingTTL(pendingTTL);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String toString()
/* 35:   */   {
/* 36:41 */     return this.sequence + ":" + this.stamp + ":" + this.pendingTTL + ":" + this.pending + ":" + this.topic + ":" + this.body;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public int getPendingTTL()
/* 40:   */   {
/* 41:48 */     return this.pendingTTL;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void setPendingTTL(int pendingTTL)
/* 45:   */   {
/* 46:55 */     this.pendingTTL = (pendingTTL * 1000);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public boolean isPending()
/* 50:   */   {
/* 51:62 */     return this.pending;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void setPending(boolean pending)
/* 55:   */   {
/* 56:69 */     this.pending = pending;
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.RequestMessage
 * JD-Core Version:    0.7.0.1
 */