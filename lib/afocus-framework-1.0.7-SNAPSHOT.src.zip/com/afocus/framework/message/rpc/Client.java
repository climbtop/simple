package com.afocus.framework.message.rpc;

import java.util.Set;

public abstract interface Client
{
  public abstract MessageSender getSender();
  
  public abstract MessageSender getSender(String paramString);
  
  public abstract Set<String> getHostSet();
  
  public abstract Object syncRequest(RequestMessage paramRequestMessage)
    throws RPCException;
  
  public abstract Object syncRequest(String paramString, RequestMessage paramRequestMessage)
    throws RPCException;
  
  public abstract void asyncRequest(RequestMessage paramRequestMessage);
  
  public abstract void asyncRequest(String paramString, RequestMessage paramRequestMessage);
  
  public abstract Object syncRequestHardTask(String paramString, Object paramObject)
    throws RPCException;
  
  public abstract Object syncRequestHardTask(String paramString, Object paramObject, int paramInt)
    throws RPCException;
  
  public abstract Object syncRequest(String paramString, Object paramObject)
    throws RPCException;
  
  public abstract Object syncRequest(String paramString, Object paramObject, int paramInt)
    throws RPCException;
  
  public abstract Object syncRequestHardTask(MessageSender paramMessageSender, String paramString, Object paramObject)
    throws RPCException;
  
  public abstract Object syncRequestHardTask(MessageSender paramMessageSender, String paramString, Object paramObject, int paramInt)
    throws RPCException;
  
  public abstract Object syncRequest(MessageSender paramMessageSender, String paramString, Object paramObject)
    throws RPCException;
  
  public abstract Object syncRequest(MessageSender paramMessageSender, String paramString, Object paramObject, int paramInt)
    throws RPCException;
  
  public abstract Object syncRequest(String paramString1, String paramString2, Object paramObject)
    throws RPCException;
  
  public abstract Object syncRequest(String paramString1, String paramString2, Object paramObject, int paramInt)
    throws RPCException;
  
  public abstract Object syncRequestHardTask(String paramString1, String paramString2, Object paramObject)
    throws RPCException;
  
  public abstract Object syncRequestHardTask(String paramString1, String paramString2, Object paramObject, int paramInt)
    throws RPCException;
  
  public abstract void asyncRequest(String paramString1, String paramString2, Object paramObject);
  
  public abstract void asyncRequestPending(String paramString1, String paramString2, Object paramObject);
  
  public abstract void asyncRequestHardTask(String paramString1, String paramString2, Object paramObject);
  
  public abstract void asyncRequestHardTaskPending(String paramString1, String paramString2, Object paramObject);
  
  public abstract void asyncRequestHardTask(String paramString, Object paramObject);
  
  public abstract void asyncRequestHardTaskPending(String paramString, Object paramObject);
  
  public abstract void asyncRequest(String paramString, Object paramObject);
  
  public abstract void asyncRequestPending(String paramString, Object paramObject);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.Client
 * JD-Core Version:    0.7.0.1
 */