/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.message.MessageListener;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.springframework.util.AntPathMatcher;
/*  6:   */ import org.springframework.util.PathMatcher;
/*  7:   */ 
/*  8:   */ public class MessageReceiverWildcardImpl
/*  9:   */   extends MessageReceiverAdaptor
/* 10:   */ {
/* 11:18 */   private PathMatcher pathMatcher = new AntPathMatcher();
/* 12:   */   
/* 13:   */   protected MessageListener getTopicListener(String topic)
/* 14:   */   {
/* 15:24 */     MessageListener listener = (MessageListener)this.listenerMap.get(topic);
/* 16:   */     String bestMatch;
/* 17:25 */     if (listener == null)
/* 18:   */     {
/* 19:27 */       bestMatch = null;
/* 20:28 */       for (String registeredTopic : this.listenerMap.keySet()) {
/* 21:29 */         if ((this.pathMatcher.match(registeredTopic, topic)) && ((bestMatch == null) || (bestMatch.length() <= registeredTopic.length())))
/* 22:   */         {
/* 23:30 */           listener = (MessageListener)this.listenerMap.get(registeredTopic);
/* 24:31 */           bestMatch = registeredTopic;
/* 25:   */         }
/* 26:   */       }
/* 27:   */     }
/* 28:35 */     return listener;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public PathMatcher getPathMatcher()
/* 32:   */   {
/* 33:39 */     return this.pathMatcher;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void setPathMatcher(PathMatcher pathMatcher)
/* 37:   */   {
/* 38:43 */     if (pathMatcher == null) {
/* 39:43 */       return;
/* 40:   */     }
/* 41:44 */     this.pathMatcher = pathMatcher;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.MessageReceiverWildcardImpl
 * JD-Core Version:    0.7.0.1
 */