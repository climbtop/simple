/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.message.MessageListener;
/*  4:   */ import org.apache.log4j.Logger;
/*  5:   */ 
/*  6:   */ public class AsyncMessageReceiver
/*  7:   */   extends MessageReceiverAdaptor
/*  8:   */ {
/*  9:   */   private AsyncPendingManager asyncPendingManager;
/* 10:12 */   private int maxRetryNum = 3;
/* 11:13 */   private int retryWaitMilliSeconds = 3000;
/* 12:   */   
/* 13:   */   protected void processResponse(ResponseMessage response, MessageSender sender)
/* 14:   */   {
/* 15:16 */     super.processResponse(response, sender);
/* 16:17 */     int msgId = response.getSequence();
/* 17:18 */     RequestMessage request = this.asyncPendingManager.getRequest(msgId);
/* 18:19 */     if (request == null)
/* 19:   */     {
/* 20:20 */       this.log.debug("received: " + response);
/* 21:21 */       return;
/* 22:   */     }
/* 23:24 */     if ((response instanceof ExceptionMessage))
/* 24:   */     {
/* 25:25 */       this.log.warn("receive Exception: " + response + ", will retry send request:" + request);
/* 26:26 */       if ((request.isPending()) && (this.asyncPendingManager.getResendCount(msgId) <= this.maxRetryNum))
/* 27:   */       {
/* 28:   */         try
/* 29:   */         {
/* 30:28 */           Thread.sleep(this.retryWaitMilliSeconds);
/* 31:   */         }
/* 32:   */         catch (InterruptedException localInterruptedException) {}
/* 33:32 */         this.asyncPendingManager.resend(msgId);
/* 34:33 */         return;
/* 35:   */       }
/* 36:   */     }
/* 37:37 */     this.asyncPendingManager.removeRequest(msgId);
/* 38:   */     try
/* 39:   */     {
/* 40:39 */       if ((response instanceof ExceptionMessage))
/* 41:   */       {
/* 42:40 */         this.log.error("receive ExceptionMessage: " + response);
/* 43:41 */         throw new RuntimeException(response.toString());
/* 44:   */       }
/* 45:44 */       MessageListener listener = getTopicListener(request.getTopic());
/* 46:45 */       if (listener != null)
/* 47:   */       {
/* 48:46 */         response.setRequestBody(request.getBody());
/* 49:47 */         listener.onReceived(response, sender);
/* 50:   */       }
/* 51:   */     }
/* 52:   */     finally
/* 53:   */     {
/* 54:51 */       if (request.isPending()) {
/* 55:52 */         sender.close();
/* 56:   */       }
/* 57:   */     }
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void setAsyncPendingManager(AsyncPendingManager pendingManager)
/* 61:   */   {
/* 62:57 */     this.asyncPendingManager = pendingManager;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public AsyncPendingManager getAsyncPendingManager()
/* 66:   */   {
/* 67:61 */     return this.asyncPendingManager;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public int getMaxRetryNum()
/* 71:   */   {
/* 72:68 */     return this.maxRetryNum;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public void setMaxRetryNum(int maxRetryNum)
/* 76:   */   {
/* 77:75 */     if ((maxRetryNum > 0) && (maxRetryNum <= 10)) {
/* 78:76 */       this.maxRetryNum = maxRetryNum;
/* 79:   */     }
/* 80:   */   }
/* 81:   */   
/* 82:   */   public int getRetryWaitSeconds()
/* 83:   */   {
/* 84:83 */     return this.retryWaitMilliSeconds / 1000;
/* 85:   */   }
/* 86:   */   
/* 87:   */   public void setRetryWaitSeconds(int retryWaitSeconds)
/* 88:   */   {
/* 89:91 */     if ((retryWaitSeconds > 0) && (retryWaitSeconds <= 60)) {
/* 90:92 */       this.retryWaitMilliSeconds = (retryWaitSeconds * 1000);
/* 91:   */     }
/* 92:   */   }
/* 93:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.AsyncMessageReceiver
 * JD-Core Version:    0.7.0.1
 */