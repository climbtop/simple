/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import org.apache.log4j.Logger;
/*  5:   */ 
/*  6:   */ public class AsyncPendingManagerImpl
/*  7:   */   implements AsyncPendingManager
/*  8:   */ {
/*  9:15 */   protected Logger log = Logger.getLogger(getClass());
/* 10:17 */   protected int maxSize = 1000;
/* 11:19 */   private HashMap<Integer, RequestMessage> requests = new HashMap();
/* 12:20 */   private HashMap<Integer, MessageSender> senders = new HashMap();
/* 13:21 */   private HashMap<Integer, Integer> resendCount = new HashMap();
/* 14:   */   
/* 15:   */   public synchronized boolean addRequest(RequestMessage msg, MessageSender sender)
/* 16:   */   {
/* 17:24 */     Integer key = new Integer(msg.getSequence());
/* 18:25 */     if (this.requests.size() < this.maxSize)
/* 19:   */     {
/* 20:26 */       this.requests.put(key, msg);
/* 21:27 */       this.senders.put(key, sender);
/* 22:28 */       this.resendCount.put(key, new Integer(0));
/* 23:29 */       return true;
/* 24:   */     }
/* 25:31 */     this.log.warn("TOO BUSY: pendingRequest pool is full: " + msg);
/* 26:32 */     return false;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public MessageSender getSender(int requestSequence)
/* 30:   */   {
/* 31:36 */     return (MessageSender)this.senders.get(new Integer(requestSequence));
/* 32:   */   }
/* 33:   */   
/* 34:   */   public synchronized void removeRequest(int requestSequence)
/* 35:   */   {
/* 36:40 */     Integer key = new Integer(requestSequence);
/* 37:41 */     this.requests.remove(key);
/* 38:42 */     this.senders.remove(key);
/* 39:43 */     this.resendCount.remove(key);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public synchronized RequestMessage getRequest(int requestSequence)
/* 43:   */   {
/* 44:47 */     return (RequestMessage)this.requests.get(new Integer(requestSequence));
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void resend(int requestSequence)
/* 48:   */   {
/* 49:51 */     Integer key = new Integer(requestSequence);
/* 50:52 */     MessageSender sender = (MessageSender)this.senders.get(key);
/* 51:53 */     sender.asyncSendRequest((RequestMessage)this.requests.get(key));
/* 52:54 */     int count = ((Integer)this.resendCount.get(new Integer(requestSequence))).intValue() + 1;
/* 53:55 */     this.resendCount.put(key, new Integer(count));
/* 54:   */   }
/* 55:   */   
/* 56:   */   public int getResendCount(int requestSequence)
/* 57:   */   {
/* 58:60 */     return ((Integer)this.resendCount.get(new Integer(requestSequence))).intValue();
/* 59:   */   }
/* 60:   */   
/* 61:   */   public int getMaxSize()
/* 62:   */   {
/* 63:64 */     return this.maxSize;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void setMaxSize(int maxSize)
/* 67:   */   {
/* 68:68 */     this.maxSize = maxSize;
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.AsyncPendingManagerImpl
 * JD-Core Version:    0.7.0.1
 */