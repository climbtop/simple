/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import com.afocus.framework.message.Message;
/*  4:   */ import java.io.Serializable;
/*  5:   */ 
/*  6:   */ public class ResponseMessage
/*  7:   */   extends Message
/*  8:   */   implements Serializable
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = -3421293547777420902L;
/* 11:17 */   private Object requestBody = null;
/* 12:   */   
/* 13:   */   public ResponseMessage() {}
/* 14:   */   
/* 15:   */   public ResponseMessage(Object result, RequestMessage request)
/* 16:   */   {
/* 17:24 */     this.body = result;
/* 18:25 */     this.topic = request.getTopic();
/* 19:26 */     this.sequence = request.getSequence();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Object getResult()
/* 23:   */   {
/* 24:30 */     return this.body;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Object getRequestBody()
/* 28:   */   {
/* 29:37 */     return this.requestBody;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setRequestBody(Object requestBody)
/* 33:   */   {
/* 34:44 */     this.requestBody = requestBody;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String toString()
/* 38:   */   {
/* 39:48 */     return this.sequence + ":" + this.topic + ":" + this.body;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.ResponseMessage
 * JD-Core Version:    0.7.0.1
 */