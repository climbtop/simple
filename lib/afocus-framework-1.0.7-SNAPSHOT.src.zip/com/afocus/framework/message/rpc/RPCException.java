/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ public class RPCException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -2667892432940425747L;
/*  7:   */   public static final byte SIGNAL = 0;
/*  8:   */   public static final byte SYSTEM_BUSY = 1;
/*  9:   */   public static final byte SOCKET = 2;
/* 10:   */   public static final byte INTERNAL = 3;
/* 11:   */   public static final byte USREIP_IS_HACKER = 4;
/* 12:   */   public static final byte DATA_INVALID = 5;
/* 13:   */   public static final byte REMOTE_EXCEPTION = 6;
/* 14:18 */   private static final String[] errorType = { "SIGNAL", "SYSTEM_BUSY", "SOCKET", "INTERNAL", "USREIP_IS_HACKER", "DATA_INVALID", "REMOTE_EXCEPTION" };
/* 15:   */   private byte exceptionId;
/* 16:   */   
/* 17:   */   public RPCException(byte exceptionId)
/* 18:   */   {
/* 19:24 */     this.exceptionId = exceptionId;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public RPCException(byte exceptionId, String msg)
/* 23:   */   {
/* 24:28 */     super(msg);
/* 25:29 */     this.exceptionId = exceptionId;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public RPCException(byte exceptionId, Exception e)
/* 29:   */   {
/* 30:33 */     super(e);
/* 31:34 */     this.exceptionId = exceptionId;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public RPCException(Exception e)
/* 35:   */   {
/* 36:38 */     super(e);
/* 37:39 */     this.exceptionId = 3;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public byte getExceptionId()
/* 41:   */   {
/* 42:43 */     return this.exceptionId;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String toString()
/* 46:   */   {
/* 47:47 */     return getClass().getName() + ":" + errorType[java.lang.Math.abs(this.exceptionId)] + "(" + this.exceptionId + ")," + getMessage();
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.RPCException
 * JD-Core Version:    0.7.0.1
 */