package com.afocus.framework.message.rpc;

public abstract interface AsyncPendingManager
{
  public abstract boolean addRequest(RequestMessage paramRequestMessage, MessageSender paramMessageSender);
  
  public abstract MessageSender getSender(int paramInt);
  
  public abstract RequestMessage getRequest(int paramInt);
  
  public abstract void removeRequest(int paramInt);
  
  public abstract void resend(int paramInt);
  
  public abstract int getResendCount(int paramInt);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.AsyncPendingManager
 * JD-Core Version:    0.7.0.1
 */