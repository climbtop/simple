/*   1:    */ package com.afocus.framework.message.rpc;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.SimpleThreadPool;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.apache.log4j.Logger;
/*   6:    */ 
/*   7:    */ public abstract class AbstractClient
/*   8:    */   implements Client
/*   9:    */ {
/*  10: 24 */   protected Logger log = Logger.getLogger(getClass());
/*  11: 26 */   private SimpleThreadPool asyncRequestThreadPool = new SimpleThreadPool(1, 5, 10L);
/*  12:    */   
/*  13:    */   public MessageSender getSender()
/*  14:    */   {
/*  15: 32 */     return getSender(null);
/*  16:    */   }
/*  17:    */   
/*  18:    */   public abstract MessageSender getSender(String paramString);
/*  19:    */   
/*  20:    */   public Object syncRequest(RequestMessage request)
/*  21:    */     throws RPCException
/*  22:    */   {
/*  23: 38 */     return syncRequestAndCloseSender(getSender(), request);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public Object syncRequest(String host, RequestMessage request)
/*  27:    */     throws RPCException
/*  28:    */   {
/*  29: 42 */     return syncRequestAndCloseSender(getSender(host), request);
/*  30:    */   }
/*  31:    */   
/*  32:    */   private Object syncRequestAndCloseSender(MessageSender sender, RequestMessage request)
/*  33:    */     throws RPCException
/*  34:    */   {
/*  35:    */     try
/*  36:    */     {
/*  37: 47 */       request.setPending(true);
/*  38: 48 */       return sender.syncSendRequest(request);
/*  39:    */     }
/*  40:    */     finally
/*  41:    */     {
/*  42: 50 */       if (sender != null)
/*  43:    */       {
/*  44: 51 */         this.log.debug("close sender:" + sender);
/*  45: 52 */         sender.close();
/*  46:    */       }
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void asyncRequest(RequestMessage request)
/*  51:    */   {
/*  52: 58 */     asyncRequest(null, request);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void asyncRequest(String host, RequestMessage request)
/*  56:    */   {
/*  57: 62 */     request.setDestAddress(host);
/*  58: 63 */     this.asyncRequestThreadPool.execute(new Task(request));
/*  59:    */   }
/*  60:    */   
/*  61:    */   private class Task
/*  62:    */     implements Runnable
/*  63:    */   {
/*  64: 67 */     RequestMessage request = null;
/*  65:    */     
/*  66:    */     Task(RequestMessage request)
/*  67:    */     {
/*  68: 70 */       this.request = request;
/*  69:    */     }
/*  70:    */     
/*  71:    */     public void run()
/*  72:    */     {
/*  73: 74 */       MessageSender sender = AbstractClient.this.getSender((String)this.request.getDestAddress());
/*  74:    */       try
/*  75:    */       {
/*  76: 76 */         sender.asyncSendRequest(this.request);
/*  77: 78 */         if ((sender != null) && (!this.request.isPending())) {
/*  78: 79 */           sender.close();
/*  79:    */         }
/*  80:    */       }
/*  81:    */       finally
/*  82:    */       {
/*  83: 78 */         if ((sender != null) && (!this.request.isPending())) {
/*  84: 79 */           sender.close();
/*  85:    */         }
/*  86:    */       }
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Object syncRequestHardTask(String command, Object param)
/*  91:    */     throws RPCException
/*  92:    */   {
/*  93: 87 */     return syncRequest(new HardTaskRequestMessage(command, param, true));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Object syncRequestHardTask(String command, Object param, int pendingTTL)
/*  97:    */     throws RPCException
/*  98:    */   {
/*  99: 91 */     return syncRequest(new HardTaskRequestMessage(command, param, pendingTTL));
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Object syncRequest(String command, Object param)
/* 103:    */     throws RPCException
/* 104:    */   {
/* 105: 95 */     return syncRequest(new RequestMessage(command, param, true));
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Object syncRequest(String command, Object param, int pendingTTL)
/* 109:    */     throws RPCException
/* 110:    */   {
/* 111: 99 */     return syncRequest(new RequestMessage(command, param, pendingTTL));
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Object syncRequestHardTask(MessageSender sender, String command, Object param)
/* 115:    */     throws RPCException
/* 116:    */   {
/* 117:103 */     return sender.syncSendRequest(new HardTaskRequestMessage(command, param, true));
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Object syncRequestHardTask(MessageSender sender, String command, Object param, int pendingTTL)
/* 121:    */     throws RPCException
/* 122:    */   {
/* 123:107 */     return sender.syncSendRequest(new HardTaskRequestMessage(command, param, pendingTTL));
/* 124:    */   }
/* 125:    */   
/* 126:    */   public Object syncRequest(MessageSender sender, String command, Object param)
/* 127:    */     throws RPCException
/* 128:    */   {
/* 129:111 */     return sender.syncSendRequest(new RequestMessage(command, param, true));
/* 130:    */   }
/* 131:    */   
/* 132:    */   public Object syncRequest(MessageSender sender, String command, Object param, int pendingTTL)
/* 133:    */     throws RPCException
/* 134:    */   {
/* 135:115 */     return sender.syncSendRequest(new RequestMessage(command, param, pendingTTL));
/* 136:    */   }
/* 137:    */   
/* 138:    */   public Object syncRequest(String host, String command, Object param)
/* 139:    */     throws RPCException
/* 140:    */   {
/* 141:119 */     return syncRequest(host, new RequestMessage(command, param, true));
/* 142:    */   }
/* 143:    */   
/* 144:    */   public Object syncRequest(String host, String command, Object param, int pendingTTL)
/* 145:    */     throws RPCException
/* 146:    */   {
/* 147:123 */     return syncRequest(host, new RequestMessage(command, param, pendingTTL));
/* 148:    */   }
/* 149:    */   
/* 150:    */   public Object syncRequestHardTask(String host, String command, Object param)
/* 151:    */     throws RPCException
/* 152:    */   {
/* 153:127 */     return syncRequest(host, new HardTaskRequestMessage(command, param, true));
/* 154:    */   }
/* 155:    */   
/* 156:    */   public Object syncRequestHardTask(String host, String command, Object param, int pendingTTL)
/* 157:    */     throws RPCException
/* 158:    */   {
/* 159:131 */     return syncRequest(host, new HardTaskRequestMessage(command, param, pendingTTL));
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void asyncRequest(String host, String command, Object param)
/* 163:    */   {
/* 164:136 */     asyncRequest(host, new RequestMessage(command, param, false));
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void asyncRequestPending(String host, String command, Object param)
/* 168:    */   {
/* 169:140 */     asyncRequest(host, new RequestMessage(command, param, true));
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void asyncRequestHardTask(String host, String command, Object param)
/* 173:    */   {
/* 174:144 */     asyncRequest(host, new HardTaskRequestMessage(command, param, false));
/* 175:    */   }
/* 176:    */   
/* 177:    */   public void asyncRequestHardTaskPending(String host, String command, Object param)
/* 178:    */   {
/* 179:148 */     asyncRequest(host, new HardTaskRequestMessage(command, param, true));
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void asyncRequestHardTask(String command, Object param)
/* 183:    */   {
/* 184:152 */     asyncRequest(new HardTaskRequestMessage(command, param, false));
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void asyncRequestHardTaskPending(String command, Object param)
/* 188:    */   {
/* 189:156 */     asyncRequest(new HardTaskRequestMessage(command, param, true));
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void asyncRequest(String command, Object param)
/* 193:    */   {
/* 194:160 */     asyncRequest(new RequestMessage(command, param, false));
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void asyncRequestPending(String command, Object param)
/* 198:    */   {
/* 199:164 */     asyncRequest(new RequestMessage(command, param, true));
/* 200:    */   }
/* 201:    */   
/* 202:    */   public abstract Set<String> getHostSet();
/* 203:    */   
/* 204:    */   public int getAsyncRequestQueueSize()
/* 205:    */   {
/* 206:170 */     return this.asyncRequestThreadPool.getTaskBalance();
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void setAsyncRequestThreadQueueCapacity(short size)
/* 210:    */   {
/* 211:174 */     this.asyncRequestThreadPool.setQueueCapacity(size);
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void setAsyncRequestThreadMaxPoolSize(int size)
/* 215:    */   {
/* 216:178 */     this.asyncRequestThreadPool.setMaximumPoolSize(size);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void setAsyncRequestThreadCorePoolSize(int size)
/* 220:    */   {
/* 221:182 */     this.asyncRequestThreadPool.setCorePoolSize(size);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void setAsyncRequestThreadKeepAliveSecond(int time)
/* 225:    */   {
/* 226:186 */     this.asyncRequestThreadPool.setKeepAliveSecond(time);
/* 227:    */   }
/* 228:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.AbstractClient
 * JD-Core Version:    0.7.0.1
 */