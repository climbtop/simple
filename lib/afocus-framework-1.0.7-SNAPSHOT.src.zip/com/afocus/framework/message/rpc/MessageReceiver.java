package com.afocus.framework.message.rpc;

import com.afocus.framework.message.Message;

public abstract interface MessageReceiver
{
  public abstract void onReceived(Message paramMessage, MessageSender paramMessageSender);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.MessageReceiver
 * JD-Core Version:    0.7.0.1
 */