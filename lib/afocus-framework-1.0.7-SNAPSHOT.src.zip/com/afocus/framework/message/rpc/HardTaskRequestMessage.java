/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ public class HardTaskRequestMessage
/*  4:   */   extends RequestMessage
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 7874304371881568954L;
/*  7:   */   
/*  8:   */   public HardTaskRequestMessage() {}
/*  9:   */   
/* 10:   */   public HardTaskRequestMessage(String command, Object parameter)
/* 11:   */   {
/* 12:18 */     super(command, parameter);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public HardTaskRequestMessage(String command, Object parameter, int pendingTTL)
/* 16:   */   {
/* 17:22 */     super(command, parameter, pendingTTL);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public HardTaskRequestMessage(String command, Object parameter, boolean pending)
/* 21:   */   {
/* 22:26 */     super(command, parameter, pending);
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.HardTaskRequestMessage
 * JD-Core Version:    0.7.0.1
 */