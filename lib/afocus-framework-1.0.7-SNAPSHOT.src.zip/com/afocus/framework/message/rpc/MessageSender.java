package com.afocus.framework.message.rpc;

public abstract interface MessageSender
  extends com.afocus.framework.message.MessageSender
{
  public abstract Object syncSendRequest(RequestMessage paramRequestMessage)
    throws RPCException;
  
  public abstract void asyncSendRequest(RequestMessage paramRequestMessage);
  
  public abstract void sendResponse(RequestMessage paramRequestMessage, Object paramObject);
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.MessageSender
 * JD-Core Version:    0.7.0.1
 */