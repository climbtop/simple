/*  1:   */ package com.afocus.framework.message.rpc;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class ExceptionMessage
/*  6:   */   extends ResponseMessage
/*  7:   */   implements Serializable
/*  8:   */ {
/*  9:   */   private static final long serialVersionUID = 3556287271787919229L;
/* 10:   */   
/* 11:   */   public ExceptionMessage() {}
/* 12:   */   
/* 13:   */   public ExceptionMessage(int sequence, String command, String message)
/* 14:   */   {
/* 15:22 */     this.sequence = sequence;
/* 16:23 */     this.topic = command;
/* 17:24 */     this.body = message;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public ExceptionMessage(int sequence, String command, Exception e)
/* 21:   */   {
/* 22:28 */     this.sequence = sequence;
/* 23:29 */     this.topic = command;
/* 24:30 */     this.body = e.toString();
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.rpc.ExceptionMessage
 * JD-Core Version:    0.7.0.1
 */