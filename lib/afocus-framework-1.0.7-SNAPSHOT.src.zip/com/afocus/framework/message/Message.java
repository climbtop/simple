/*   1:    */ package com.afocus.framework.message;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ import java.util.concurrent.atomic.AtomicInteger;
/*   5:    */ 
/*   6:    */ public class Message
/*   7:    */   implements Serializable
/*   8:    */ {
/*   9:    */   private static final long serialVersionUID = 8381017822273124136L;
/*  10: 14 */   private static AtomicInteger sequenceGenerator = new AtomicInteger(0);
/*  11: 16 */   protected int sequence = 0;
/*  12: 17 */   protected long stamp = System.currentTimeMillis();
/*  13: 19 */   protected Object srcAddress = null;
/*  14: 20 */   protected Object destAddress = null;
/*  15: 22 */   protected String topic = null;
/*  16: 23 */   protected Object body = null;
/*  17:    */   
/*  18:    */   public Message() {}
/*  19:    */   
/*  20:    */   public Message(String topic, Object body)
/*  21:    */   {
/*  22: 39 */     setTopic(topic);
/*  23: 40 */     setBody(body);
/*  24: 41 */     makeSequence();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public String toString()
/*  28:    */   {
/*  29: 49 */     return this.sequence + ":" + this.stamp + ":" + this.srcAddress + ":" + this.destAddress + ":" + this.topic + ":" + this.body;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public long getLiveTime()
/*  33:    */   {
/*  34: 56 */     return System.currentTimeMillis() - this.stamp;
/*  35:    */   }
/*  36:    */   
/*  37:    */   protected int makeSequence()
/*  38:    */   {
/*  39: 63 */     this.sequence = sequenceGenerator.getAndIncrement();
/*  40: 64 */     return this.sequence;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Object getBody()
/*  44:    */   {
/*  45: 71 */     return this.body;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setBody(Object body)
/*  49:    */   {
/*  50: 78 */     this.body = body;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int getSequence()
/*  54:    */   {
/*  55: 85 */     return this.sequence;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setSequence(int sequence)
/*  59:    */   {
/*  60: 92 */     this.sequence = sequence;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public long getStamp()
/*  64:    */   {
/*  65: 99 */     return this.stamp;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setStamp(long stamp)
/*  69:    */   {
/*  70:106 */     this.stamp = stamp;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public String getTopic()
/*  74:    */   {
/*  75:113 */     return this.topic;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void setTopic(String topic)
/*  79:    */   {
/*  80:120 */     this.topic = topic;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Object getDestAddress()
/*  84:    */   {
/*  85:127 */     return this.destAddress;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void setDestAddress(Object destAddress)
/*  89:    */   {
/*  90:134 */     this.destAddress = destAddress;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Object getSrcAddress()
/*  94:    */   {
/*  95:141 */     return this.srcAddress;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setSrcAddress(Object srcAddress)
/*  99:    */   {
/* 100:148 */     this.srcAddress = srcAddress;
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.Message
 * JD-Core Version:    0.7.0.1
 */