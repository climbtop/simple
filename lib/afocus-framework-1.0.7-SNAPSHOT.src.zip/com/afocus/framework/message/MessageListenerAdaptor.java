/*  1:   */ package com.afocus.framework.message;
/*  2:   */ 
/*  3:   */ import org.apache.log4j.Logger;
/*  4:   */ 
/*  5:   */ public class MessageListenerAdaptor
/*  6:   */   implements MessageListener
/*  7:   */ {
/*  8:19 */   protected Logger log = Logger.getLogger(getClass());
/*  9:   */   
/* 10:   */   public boolean onReceived(Message msg, MessageSender sender)
/* 11:   */   {
/* 12:28 */     this.log.debug("onReceived msg:" + msg);
/* 13:29 */     return true;
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.MessageListenerAdaptor
 * JD-Core Version:    0.7.0.1
 */