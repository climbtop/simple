/*   1:    */ package com.afocus.framework.message.email;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.util.SimpleThreadPool;
/*   4:    */ import java.io.InputStream;
/*   5:    */ import java.util.Properties;
/*   6:    */ import javax.mail.MessagingException;
/*   7:    */ import javax.mail.internet.MimeMessage;
/*   8:    */ import org.apache.log4j.Logger;
/*   9:    */ import org.springframework.mail.MailException;
/*  10:    */ import org.springframework.mail.MailSender;
/*  11:    */ import org.springframework.mail.SimpleMailMessage;
/*  12:    */ import org.springframework.mail.javamail.JavaMailSender;
/*  13:    */ import org.springframework.mail.javamail.MimeMessagePreparator;
/*  14:    */ 
/*  15:    */ public class PooledMailSender
/*  16:    */   implements MailSender, JavaMailSender
/*  17:    */ {
/*  18: 49 */   protected Logger log = Logger.getLogger(getClass());
/*  19:    */   private MailSender mailSender;
/*  20: 54 */   private Properties mailHeaders = new Properties();
/*  21: 56 */   private SimpleThreadPool threadPool = new SimpleThreadPool(1, 2, 10L);
/*  22:    */   
/*  23:    */   public Properties getMailHeaders()
/*  24:    */   {
/*  25: 62 */     return this.mailHeaders;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void setMailHeaders(Properties mailHeaders)
/*  29:    */   {
/*  30: 71 */     this.mailHeaders = mailHeaders;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public MailSender getMailSender()
/*  34:    */   {
/*  35: 76 */     return this.mailSender;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setMailSender(MailSender mailSender)
/*  39:    */   {
/*  40: 85 */     this.mailSender = mailSender;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void close()
/*  44:    */   {
/*  45: 94 */     this.threadPool.waitCompleted();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean isEmpty()
/*  49:    */   {
/*  50: 98 */     return this.threadPool.getTaskBalance() == 0;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int getQueneSize()
/*  54:    */   {
/*  55:102 */     return this.threadPool.getTaskBalance();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void send(SimpleMailMessage simpleMessage)
/*  59:    */     throws MailException
/*  60:    */   {
/*  61:109 */     this.threadPool.execute(new SimpleMailMessageTask(simpleMessage));
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void send(SimpleMailMessage[] simpleMessages)
/*  65:    */     throws MailException
/*  66:    */   {
/*  67:113 */     for (SimpleMailMessage message : simpleMessages) {
/*  68:114 */       this.threadPool.execute(new SimpleMailMessageTask(message));
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void send(MimeMessage message)
/*  73:    */     throws MailException
/*  74:    */   {
/*  75:119 */     injectMailHeader(message);
/*  76:120 */     this.threadPool.execute(new MimeMessageTask(message));
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void send(MimeMessage[] mimeMessages)
/*  80:    */     throws MailException
/*  81:    */   {
/*  82:124 */     for (MimeMessage message : mimeMessages) {
/*  83:125 */       send(message);
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void send(MimeMessagePreparator preparator)
/*  88:    */     throws MailException
/*  89:    */   {
/*  90:130 */     this.threadPool.execute(new MimeMessagePreparatorTask(preparator));
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void send(MimeMessagePreparator[] mimeMessagePreparators)
/*  94:    */     throws MailException
/*  95:    */   {
/*  96:137 */     for (MimeMessagePreparator preparator : mimeMessagePreparators) {
/*  97:138 */       this.threadPool.execute(new MimeMessagePreparatorTask(preparator));
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public MimeMessage createMimeMessage()
/* 102:    */   {
/* 103:143 */     return ((JavaMailSender)this.mailSender).createMimeMessage();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public MimeMessage createMimeMessage(InputStream contentStream)
/* 107:    */     throws MailException
/* 108:    */   {
/* 109:147 */     return ((JavaMailSender)this.mailSender).createMimeMessage(contentStream);
/* 110:    */   }
/* 111:    */   
/* 112:    */   private void injectMailHeader(MimeMessage mm)
/* 113:    */   {
/* 114:151 */     for (Object name : this.mailHeaders.keySet()) {
/* 115:    */       try
/* 116:    */       {
/* 117:153 */         mm.setHeader((String)name, this.mailHeaders.getProperty((String)name));
/* 118:    */       }
/* 119:    */       catch (MessagingException e)
/* 120:    */       {
/* 121:155 */         e.printStackTrace();
/* 122:    */       }
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private class SimpleMailMessageTask
/* 127:    */     implements Runnable
/* 128:    */   {
/* 129:    */     SimpleMailMessage message;
/* 130:    */     
/* 131:    */     SimpleMailMessageTask(SimpleMailMessage message)
/* 132:    */     {
/* 133:164 */       this.message = message;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public void run()
/* 137:    */     {
/* 138:168 */       PooledMailSender.this.mailSender.send(this.message);
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   private class MimeMessageTask
/* 143:    */     implements Runnable
/* 144:    */   {
/* 145:    */     MimeMessage message;
/* 146:    */     
/* 147:    */     MimeMessageTask(MimeMessage message)
/* 148:    */     {
/* 149:176 */       this.message = message;
/* 150:    */     }
/* 151:    */     
/* 152:    */     public void run()
/* 153:    */     {
/* 154:180 */       ((JavaMailSender)PooledMailSender.this.mailSender).send(this.message);
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   private class MimeMessagePreparatorTask
/* 159:    */     implements Runnable
/* 160:    */   {
/* 161:    */     MimeMessagePreparator message;
/* 162:    */     
/* 163:    */     MimeMessagePreparatorTask(MimeMessagePreparator message)
/* 164:    */     {
/* 165:188 */       this.message = message;
/* 166:    */     }
/* 167:    */     
/* 168:    */     public void run()
/* 169:    */     {
/* 170:192 */       ((JavaMailSender)PooledMailSender.this.mailSender).send(this.message);
/* 171:    */     }
/* 172:    */   }
/* 173:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.message.email.PooledMailSender
 * JD-Core Version:    0.7.0.1
 */