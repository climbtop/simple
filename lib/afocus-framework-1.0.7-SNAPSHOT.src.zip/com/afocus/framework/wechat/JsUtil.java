/*   1:    */ package com.afocus.framework.wechat;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.common.JsonResult;
/*   4:    */ import com.afocus.framework.util.StringUtil;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.apache.commons.lang3.StringUtils;
/*   9:    */ 
/*  10:    */ @Deprecated
/*  11:    */ public final class JsUtil
/*  12:    */ {
/*  13:    */   public static JsonResult initJsAPI(TokenHolder tokenHolder, int appCode, String url)
/*  14:    */   {
/*  15: 24 */     String jsapiTicket = tokenHolder.getJsApiTicket(appCode);
/*  16: 25 */     if (StringUtils.isNotEmpty(jsapiTicket))
/*  17:    */     {
/*  18: 26 */       String nonceStr = StringUtil.getRandomString(24);
/*  19: 27 */       String timestamp = String.valueOf(System.currentTimeMillis() / 1000L);
/*  20: 28 */       String signature = SignatureUtil.getJsAPISignature(jsapiTicket, url, nonceStr, timestamp);
/*  21: 29 */       if (StringUtils.isNotEmpty(signature))
/*  22:    */       {
/*  23: 30 */         Map<String, Object> data = new HashMap();
/*  24: 31 */         data.put("api_ticket", jsapiTicket);
/*  25: 32 */         data.put("url", url);
/*  26: 33 */         data.put("timestamp", timestamp);
/*  27: 34 */         data.put("nonce_str", nonceStr);
/*  28: 35 */         data.put("signature", signature);
/*  29: 36 */         return JsonResult.success(data, "初始化成功！");
/*  30:    */       }
/*  31:    */     }
/*  32: 39 */     return JsonResult.fail("初始化失败！");
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static JsonResult initAddCard(TokenHolder tokenHolder, int appCode, String cardId, String code, String openId, String balance)
/*  36:    */   {
/*  37: 49 */     String cardTicket = tokenHolder.getCardTicket(appCode);
/*  38: 50 */     if (StringUtils.isNotEmpty(cardTicket))
/*  39:    */     {
/*  40: 51 */       String nonceStr = StringUtil.getRandomString(24);
/*  41: 52 */       String timestamp = String.valueOf(System.currentTimeMillis() / 1000L);
/*  42:    */       
/*  43: 54 */       ArrayList<String> list = new ArrayList();
/*  44: 55 */       list.add(cardTicket);
/*  45: 56 */       list.add(timestamp);
/*  46: 57 */       list.add(nonceStr);
/*  47: 58 */       list.add(cardId);
/*  48: 59 */       list.add(code);
/*  49: 60 */       list.add(openId);
/*  50: 61 */       list.add(balance);
/*  51: 62 */       String signature = SignatureUtil.getCardSignature(list);
/*  52: 63 */       if (StringUtils.isNotEmpty(signature))
/*  53:    */       {
/*  54: 64 */         Map<String, Object> data = new HashMap();
/*  55: 65 */         data.put("api_ticket", cardTicket);
/*  56: 66 */         data.put("timestamp", timestamp);
/*  57: 67 */         data.put("nonce_str", nonceStr);
/*  58: 68 */         data.put("card_id", cardId);
/*  59: 69 */         data.put("code", code);
/*  60: 70 */         data.put("openid", openId);
/*  61: 71 */         data.put("balance", balance);
/*  62: 72 */         data.put("signature", signature);
/*  63: 73 */         return JsonResult.success(data, "初始化成功！");
/*  64:    */       }
/*  65:    */     }
/*  66: 76 */     return JsonResult.fail("初始化失败！");
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static JsonResult initChooseCard(TokenHolder tokenHolder, int appCode, String appId, String locationId, String cardId, String cardType)
/*  70:    */   {
/*  71: 86 */     String cardTicket = tokenHolder.getCardTicket(appCode);
/*  72: 87 */     if (StringUtils.isNotEmpty(cardTicket))
/*  73:    */     {
/*  74: 88 */       String nonceStr = StringUtil.getRandomString(24);
/*  75: 89 */       String timestamp = String.valueOf(System.currentTimeMillis() / 1000L);
/*  76:    */       
/*  77: 91 */       ArrayList<String> list = new ArrayList();
/*  78: 92 */       list.add(cardTicket);
/*  79: 93 */       list.add(appId);
/*  80: 94 */       list.add(locationId);
/*  81: 95 */       list.add(timestamp);
/*  82: 96 */       list.add(nonceStr);
/*  83: 97 */       list.add(cardId);
/*  84: 98 */       list.add(cardType);
/*  85: 99 */       String signature = SignatureUtil.getCardSignature(list);
/*  86:100 */       if (StringUtils.isNotEmpty(signature))
/*  87:    */       {
/*  88:101 */         Map<String, Object> data = new HashMap();
/*  89:102 */         data.put("api_ticket", cardTicket);
/*  90:103 */         data.put("app_id", appId);
/*  91:104 */         data.put("location_id", locationId);
/*  92:105 */         data.put("time_stamp", timestamp);
/*  93:106 */         data.put("nonce_str", nonceStr);
/*  94:107 */         data.put("card_id", cardId);
/*  95:108 */         data.put("card_type", cardType);
/*  96:109 */         data.put("signature", signature);
/*  97:110 */         return JsonResult.success(data, "初始化成功！");
/*  98:    */       }
/*  99:    */     }
/* 100:113 */     return JsonResult.fail("初始化失败！");
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.JsUtil
 * JD-Core Version:    0.7.0.1
 */