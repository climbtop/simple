package com.afocus.framework.wechat;

public final class TokenCacheKeys
{
  public static final int AUTHORIZER_CACHE_LIFECYCLE = 7200;
  public static final int COMPONENT_PREAUTH_LIFECYCLE = 600;
  public static final int COMPONENT_TOKEN_LIFECYCLE = 7200;
  public static final String COMPONENT_ACCESS_TOKEN = "COMPONENT_ACCESS_TOKEN";
  public static final String AUTHORIZER_ACCESS_TOKEN = "AUTHORIZER_ACCESS_TOKEN";
  public static final String AUTHORIZER_JSAPI_TICKET = "AUTHORIZER_JSAPI_TICKET";
  public static final String AUTHORIZER_CARD_TICKET = "AUTHORIZER_CARD_TICKET";
}


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.TokenCacheKeys
 * JD-Core Version:    0.7.0.1
 */