/*  1:   */ package com.afocus.framework.wechat;
/*  2:   */ 
/*  3:   */ import com.alibaba.fastjson.JSON;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import javax.jms.JMSException;
/*  6:   */ import javax.jms.Message;
/*  7:   */ import javax.jms.Session;
/*  8:   */ import org.slf4j.Logger;
/*  9:   */ import org.slf4j.LoggerFactory;
/* 10:   */ import org.springframework.jms.JmsException;
/* 11:   */ import org.springframework.jms.core.JmsTemplate;
/* 12:   */ import org.springframework.jms.core.MessageCreator;
/* 13:   */ 
/* 14:   */ public abstract class AbstractMessageQueue<T extends Serializable>
/* 15:   */ {
/* 16:23 */   protected static Logger log = LoggerFactory.getLogger(AbstractMessageQueue.class);
/* 17:   */   protected final JmsTemplate jmsTemplate;
/* 18:   */   
/* 19:   */   public AbstractMessageQueue(JmsTemplate jmsTemplate)
/* 20:   */   {
/* 21:33 */     this.jmsTemplate = jmsTemplate;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public abstract void onRecevied(T paramT);
/* 25:   */   
/* 26:   */   public void send(final T entity)
/* 27:   */   {
/* 28:   */     try
/* 29:   */     {
/* 30:51 */       this.jmsTemplate.send(new MessageCreator()
/* 31:   */       {
/* 32:   */         public Message createMessage(Session session)
/* 33:   */           throws JMSException
/* 34:   */         {
/* 35:53 */           return session.createObjectMessage(entity);
/* 36:   */         }
/* 37:   */       });
/* 38:   */     }
/* 39:   */     catch (JmsException exception)
/* 40:   */     {
/* 41:57 */       log.error("消息队列:{} 消息:{},异常:{} , ", new Object[] { this.jmsTemplate.getDefaultDestinationName(), JSON.toJSON(entity), exception.getMessage() });
/* 42:   */     }
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.AbstractMessageQueue
 * JD-Core Version:    0.7.0.1
 */