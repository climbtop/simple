/*   1:    */ package com.afocus.framework.wechat;
/*   2:    */ 
/*   3:    */ import com.afocus.framework.cache.RedisCache;
/*   4:    */ import com.afocus.framework.common.JsonResult;
/*   5:    */ import org.apache.commons.lang3.StringUtils;
/*   6:    */ import redis.clients.jedis.JedisPool;
/*   7:    */ 
/*   8:    */ public final class TokenHolder
/*   9:    */ {
/*  10:    */   private final RedisCache cache;
/*  11:    */   
/*  12:    */   public TokenHolder(JedisPool jedisPool)
/*  13:    */   {
/*  14: 23 */     this(new RedisCache(jedisPool));
/*  15:    */   }
/*  16:    */   
/*  17:    */   public TokenHolder(RedisCache redisCache)
/*  18:    */   {
/*  19: 32 */     this.cache = redisCache;
/*  20:    */   }
/*  21:    */   
/*  22:    */   @Deprecated
/*  23:    */   public TokenHolder(String tokenServiceUrl, JedisPool jedisPool)
/*  24:    */   {
/*  25: 43 */     this(jedisPool);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public final String getAuthorizerAccessToken(int appCode)
/*  29:    */   {
/*  30: 55 */     String token = this.cache.hget("AUTHORIZER_ACCESS_TOKEN", String.valueOf(appCode));
/*  31: 56 */     assertNotEmpty(token, appCode, "accessToken");
/*  32: 57 */     return token;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public final String getJsApiTicket(int appCode)
/*  36:    */   {
/*  37: 68 */     String token = this.cache.hget("AUTHORIZER_JSAPI_TICKET", String.valueOf(appCode));
/*  38: 69 */     assertNotEmpty(token, appCode, "JsApiTicket");
/*  39: 70 */     return token;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public final String getCardTicket(int appCode)
/*  43:    */   {
/*  44: 80 */     String token = this.cache.hget("AUTHORIZER_CARD_TICKET", String.valueOf(appCode));
/*  45: 81 */     assertNotEmpty(token, appCode, "CardTicket");
/*  46: 82 */     return token;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public final String getComponentToken(int id)
/*  50:    */   {
/*  51: 93 */     return this.cache.hget("COMPONENT_ACCESS_TOKEN", String.valueOf(id));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public final String getComponentAccessToken(String componentAppId)
/*  55:    */   {
/*  56:104 */     return this.cache.hget("COMPONENT_ACCESS_TOKEN", componentAppId);
/*  57:    */   }
/*  58:    */   
/*  59:    */   private void assertNotEmpty(String token, int appCode, String tokenName)
/*  60:    */   {
/*  61:109 */     if (StringUtils.isEmpty(token)) {
/*  62:110 */       throw new RuntimeException("获取指定接入者 " + appCode + tokenName + " 失败");
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   @Deprecated
/*  67:    */   public JsonResult initJsAPI(int appCode, String url)
/*  68:    */   {
/*  69:121 */     return JsUtil.initJsAPI(this, appCode, url);
/*  70:    */   }
/*  71:    */   
/*  72:    */   @Deprecated
/*  73:    */   public JsonResult initAddCard(int appCode, String cardId, String code, String openId, String balance)
/*  74:    */   {
/*  75:132 */     return JsUtil.initAddCard(this, appCode, cardId, code, openId, balance);
/*  76:    */   }
/*  77:    */   
/*  78:    */   @Deprecated
/*  79:    */   public JsonResult initChooseCard(int appCode, String appId, String locationId, String cardId, String cardType)
/*  80:    */   {
/*  81:143 */     return JsUtil.initChooseCard(this, appCode, appId, locationId, cardId, cardType);
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.TokenHolder
 * JD-Core Version:    0.7.0.1
 */