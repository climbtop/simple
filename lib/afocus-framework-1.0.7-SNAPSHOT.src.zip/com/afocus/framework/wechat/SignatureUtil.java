/*  1:   */ package com.afocus.framework.wechat;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Collections;
/*  5:   */ import org.apache.commons.codec.digest.DigestUtils;
/*  6:   */ import org.apache.commons.lang3.StringUtils;
/*  7:   */ import org.apache.log4j.Logger;
/*  8:   */ 
/*  9:   */ @Deprecated
/* 10:   */ public final class SignatureUtil
/* 11:   */ {
/* 12:17 */   private static final Logger log = Logger.getLogger(SignatureUtil.class);
/* 13:   */   
/* 14:   */   @Deprecated
/* 15:   */   public static String getJsAPISignature(String jsapiTicket, String url, String nonceStr, String timestamp)
/* 16:   */   {
/* 17:32 */     String string1 = "jsapi_ticket=" + jsapiTicket;
/* 18:33 */     string1 = string1 + "&noncestr=" + nonceStr;
/* 19:34 */     string1 = string1 + "&timestamp=" + timestamp;
/* 20:35 */     string1 = string1 + "&url=" + url;
/* 21:36 */     log.info("生成签名前：" + string1);
/* 22:   */     
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:51 */     String signature = DigestUtils.sha1Hex(string1);
/* 37:52 */     log.info("得到签名：" + signature);
/* 38:53 */     return signature;
/* 39:   */   }
/* 40:   */   
/* 41:   */   @Deprecated
/* 42:   */   public static String getCardSignature(ArrayList<String> list)
/* 43:   */   {
/* 44:67 */     Collections.sort(list);
/* 45:68 */     StringBuilder sb = new StringBuilder();
/* 46:69 */     for (String str : list) {
/* 47:70 */       if (StringUtils.isNotEmpty(str)) {
/* 48:71 */         sb.append(str);
/* 49:   */       }
/* 50:   */     }
/* 51:74 */     log.info("生成签名前：" + sb);
/* 52:   */     
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */ 
/* 62:   */ 
/* 63:   */ 
/* 64:   */ 
/* 65:   */ 
/* 66:89 */     String signature = DigestUtils.sha1Hex(sb.toString());
/* 67:90 */     log.info("得到签名：" + signature);
/* 68:91 */     return signature;
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.SignatureUtil
 * JD-Core Version:    0.7.0.1
 */