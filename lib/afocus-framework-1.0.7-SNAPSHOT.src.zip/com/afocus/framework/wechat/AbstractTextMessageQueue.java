/*  1:   */ package com.afocus.framework.wechat;
/*  2:   */ 
/*  3:   */ import com.alibaba.fastjson.JSON;
/*  4:   */ import javax.jms.JMSException;
/*  5:   */ import javax.jms.Message;
/*  6:   */ import javax.jms.Session;
/*  7:   */ import org.slf4j.Logger;
/*  8:   */ import org.springframework.jms.JmsException;
/*  9:   */ import org.springframework.jms.core.JmsTemplate;
/* 10:   */ import org.springframework.jms.core.MessageCreator;
/* 11:   */ 
/* 12:   */ public abstract class AbstractTextMessageQueue
/* 13:   */   extends AbstractMessageQueue<String>
/* 14:   */ {
/* 15:   */   public AbstractTextMessageQueue(JmsTemplate jmsTemplate)
/* 16:   */   {
/* 17:25 */     super(jmsTemplate);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void send(final String entity)
/* 21:   */   {
/* 22:   */     try
/* 23:   */     {
/* 24:31 */       this.jmsTemplate.send(new MessageCreator()
/* 25:   */       {
/* 26:   */         public Message createMessage(Session session)
/* 27:   */           throws JMSException
/* 28:   */         {
/* 29:33 */           return session.createTextMessage(entity);
/* 30:   */         }
/* 31:   */       });
/* 32:   */     }
/* 33:   */     catch (JmsException exception)
/* 34:   */     {
/* 35:37 */       log.error("消息队列:{} 消息:{},异常:{} , ", new Object[] { this.jmsTemplate.getDefaultDestinationName(), JSON.toJSON(entity), exception.getMessage() });
/* 36:   */     }
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.AbstractTextMessageQueue
 * JD-Core Version:    0.7.0.1
 */