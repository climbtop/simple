/*  1:   */ package com.afocus.framework.wechat;
/*  2:   */ 
/*  3:   */ import javax.annotation.Resource;
/*  4:   */ import org.slf4j.Logger;
/*  5:   */ import org.slf4j.LoggerFactory;
/*  6:   */ 
/*  7:   */ public abstract class WechatComponent
/*  8:   */ {
/*  9:16 */   protected static final Logger log = LoggerFactory.getLogger(WechatComponent.class);
/* 10:   */   @Resource
/* 11:   */   private TokenHolder tokenHolder;
/* 12:   */   
/* 13:   */   protected String getAccessToken(Integer appCode)
/* 14:   */   {
/* 15:28 */     String token = this.tokenHolder.getAuthorizerAccessToken(appCode.intValue());
/* 16:29 */     log.debug("token=" + token);
/* 17:30 */     return token;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus-framework-1.0.7-SNAPSHOT.jar
 * Qualified Name:     com.afocus.framework.wechat.WechatComponent
 * JD-Core Version:    0.7.0.1
 */