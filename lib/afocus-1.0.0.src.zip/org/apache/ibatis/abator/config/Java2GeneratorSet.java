/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.internal.java.dao.GenericCIJava2DAOGenerator;
/*  4:   */ import org.apache.ibatis.abator.internal.java.dao.GenericSIJava2DAOGenerator;
/*  5:   */ import org.apache.ibatis.abator.internal.java.dao.IbatisJava2DAOGenerator;
/*  6:   */ import org.apache.ibatis.abator.internal.java.dao.SpringAbatorJava2DAOGenerator;
/*  7:   */ import org.apache.ibatis.abator.internal.java.dao.SpringJava2DAOGenerator;
/*  8:   */ import org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorJava2Impl;
/*  9:   */ import org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorIterateImpl;
/* 10:   */ import org.apache.ibatis.abator.internal.types.JavaTypeResolverDefaultImpl;
/* 11:   */ 
/* 12:   */ public class Java2GeneratorSet
/* 13:   */   extends GeneratorSet
/* 14:   */ {
/* 15:   */   public Java2GeneratorSet()
/* 16:   */   {
/* 17:39 */     this.javaModelGeneratorType = JavaModelGeneratorJava2Impl.class.getName();
/* 18:40 */     this.javaTypeResolverType = JavaTypeResolverDefaultImpl.class.getName();
/* 19:41 */     this.sqlMapGeneratorType = SqlMapGeneratorIterateImpl.class.getName();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String translateDAOGeneratorType(String configurationType)
/* 23:   */   {
/* 24:45 */     String answer = null;
/* 25:47 */     if ("IBATIS".equalsIgnoreCase(configurationType)) {
/* 26:48 */       answer = IbatisJava2DAOGenerator.class.getName();
/* 27:49 */     } else if ("SPRING".equalsIgnoreCase(configurationType)) {
/* 28:50 */       answer = SpringJava2DAOGenerator.class.getName();
/* 29:51 */     } else if ("GENERIC-CI".equalsIgnoreCase(configurationType)) {
/* 30:52 */       answer = GenericCIJava2DAOGenerator.class.getName();
/* 31:53 */     } else if ("GENERIC-SI".equalsIgnoreCase(configurationType)) {
/* 32:54 */       answer = GenericSIJava2DAOGenerator.class.getName();
/* 33:55 */     } else if (!"E2XPERT".equalsIgnoreCase(configurationType)) {
/* 34:59 */       if ("BUILD".equalsIgnoreCase(configurationType)) {
/* 35:60 */         answer = SpringAbatorJava2DAOGenerator.class.getName();
/* 36:   */       } else {
/* 37:62 */         answer = configurationType;
/* 38:   */       }
/* 39:   */     }
/* 40:65 */     return answer;
/* 41:   */   }
/* 42:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.Java2GeneratorSet
 * JD-Core Version:    0.7.0.1
 */