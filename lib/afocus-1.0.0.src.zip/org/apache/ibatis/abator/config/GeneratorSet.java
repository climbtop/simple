/*   1:    */ package org.apache.ibatis.abator.config;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.internal.java.aop.BaseAopGenerator;
/*   4:    */ import org.apache.ibatis.abator.internal.java.aop.SpringAbatorAopGenerator;
/*   5:    */ import org.apache.ibatis.abator.internal.java.controller.BaseControllerGenerator;
/*   6:    */ import org.apache.ibatis.abator.internal.java.controller.SpringAbatorJava5ControllerGenerator;
/*   7:    */ import org.apache.ibatis.abator.internal.java.jsp.BaseJspGenerator;
/*   8:    */ import org.apache.ibatis.abator.internal.java.jsp.SpringAbatorJava5JspGenerator;
/*   9:    */ import org.apache.ibatis.abator.internal.java.service.BaseServiceGenerator;
/*  10:    */ import org.apache.ibatis.abator.internal.java.service.SpringAbatorServiceGenerator;
/*  11:    */ import org.apache.ibatis.abator.internal.java.service.SpringE2xpertServiceGenerator;
/*  12:    */ 
/*  13:    */ public abstract class GeneratorSet
/*  14:    */ {
/*  15:    */   protected String javaModelGeneratorType;
/*  16:    */   protected String sqlMapGeneratorType;
/*  17:    */   protected String javaTypeResolverType;
/*  18:    */   
/*  19:    */   public abstract String translateDAOGeneratorType(String paramString);
/*  20:    */   
/*  21:    */   public String translateAopGeneratorType(String configurationType)
/*  22:    */   {
/*  23:    */     String answer;
/*  24:    */     String answer;
/*  25: 61 */     if ("BASE".equalsIgnoreCase(configurationType))
/*  26:    */     {
/*  27: 62 */       answer = BaseAopGenerator.class.getName();
/*  28:    */     }
/*  29:    */     else
/*  30:    */     {
/*  31:    */       String answer;
/*  32: 63 */       if ("BUILD".equalsIgnoreCase(configurationType)) {
/*  33: 64 */         answer = SpringAbatorAopGenerator.class.getName();
/*  34:    */       } else {
/*  35: 66 */         answer = configurationType;
/*  36:    */       }
/*  37:    */     }
/*  38: 68 */     return answer;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public String translateServiceGeneratorType(String configurationType)
/*  42:    */   {
/*  43:    */     String answer;
/*  44:    */     String answer;
/*  45: 74 */     if ("BASE".equalsIgnoreCase(configurationType))
/*  46:    */     {
/*  47: 75 */       answer = BaseServiceGenerator.class.getName();
/*  48:    */     }
/*  49:    */     else
/*  50:    */     {
/*  51:    */       String answer;
/*  52: 78 */       if ("BUILD".equalsIgnoreCase(configurationType))
/*  53:    */       {
/*  54: 79 */         answer = SpringAbatorServiceGenerator.class.getName();
/*  55:    */       }
/*  56:    */       else
/*  57:    */       {
/*  58:    */         String answer;
/*  59: 80 */         if ("E2XPERT".equalsIgnoreCase(configurationType)) {
/*  60: 81 */           answer = SpringE2xpertServiceGenerator.class.getName();
/*  61:    */         } else {
/*  62: 83 */           answer = configurationType;
/*  63:    */         }
/*  64:    */       }
/*  65:    */     }
/*  66: 86 */     return answer;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String translateControllerGeneratorType(String configurationType)
/*  70:    */   {
/*  71:    */     String answer;
/*  72:    */     String answer;
/*  73: 92 */     if ("BASE".equalsIgnoreCase(configurationType))
/*  74:    */     {
/*  75: 93 */       answer = BaseControllerGenerator.class.getName();
/*  76:    */     }
/*  77:    */     else
/*  78:    */     {
/*  79:    */       String answer;
/*  80: 94 */       if ("BUILD".equalsIgnoreCase(configurationType)) {
/*  81: 95 */         answer = SpringAbatorJava5ControllerGenerator.class.getName();
/*  82:    */       } else {
/*  83: 97 */         answer = configurationType;
/*  84:    */       }
/*  85:    */     }
/*  86:100 */     return answer;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String translateJspGeneratorType(String configurationType)
/*  90:    */   {
/*  91:    */     String answer;
/*  92:    */     String answer;
/*  93:106 */     if ("BASE".equalsIgnoreCase(configurationType))
/*  94:    */     {
/*  95:107 */       answer = BaseJspGenerator.class.getName();
/*  96:    */     }
/*  97:    */     else
/*  98:    */     {
/*  99:    */       String answer;
/* 100:108 */       if ("BUILD".equalsIgnoreCase(configurationType)) {
/* 101:109 */         answer = SpringAbatorJava5JspGenerator.class.getName();
/* 102:    */       } else {
/* 103:111 */         answer = configurationType;
/* 104:    */       }
/* 105:    */     }
/* 106:114 */     return answer;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public String getJavaModelGeneratorType()
/* 110:    */   {
/* 111:118 */     return this.javaModelGeneratorType;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setJavaModelGeneratorType(String javaModelGeneratorType)
/* 115:    */   {
/* 116:122 */     if (!"DEFAULT".equalsIgnoreCase(javaModelGeneratorType)) {
/* 117:123 */       this.javaModelGeneratorType = javaModelGeneratorType;
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public String getJavaTypeResolverType()
/* 122:    */   {
/* 123:128 */     return this.javaTypeResolverType;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setJavaTypeResolverType(String javaTypeResolverType)
/* 127:    */   {
/* 128:132 */     if (!"DEFAULT".equalsIgnoreCase(javaTypeResolverType)) {
/* 129:133 */       this.javaTypeResolverType = javaTypeResolverType;
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String getSqlMapGeneratorType()
/* 134:    */   {
/* 135:138 */     return this.sqlMapGeneratorType;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setSqlMapGeneratorType(String sqlMapGeneratorType)
/* 139:    */   {
/* 140:142 */     if (!"DEFAULT".equalsIgnoreCase(sqlMapGeneratorType)) {
/* 141:143 */       this.sqlMapGeneratorType = sqlMapGeneratorType;
/* 142:    */     }
/* 143:    */   }
/* 144:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.GeneratorSet
 * JD-Core Version:    0.7.0.1
 */