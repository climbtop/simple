/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*  4:   */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  5:   */ import org.apache.ibatis.abator.internal.db.DatabaseDialects;
/*  6:   */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  7:   */ 
/*  8:   */ public class GeneratedKey
/*  9:   */ {
/* 10:   */   private String column;
/* 11:   */   private String sqlStatementParam;
/* 12:   */   private String sqlStatement;
/* 13:   */   private String type;
/* 14:36 */   private boolean post = false;
/* 15:   */   private boolean isIdentity;
/* 16:   */   
/* 17:   */   public GeneratedKey(String column, String sqlStatement, boolean isIdentity, String type)
/* 18:   */   {
/* 19:45 */     this.column = column;
/* 20:46 */     this.isIdentity = isIdentity;
/* 21:47 */     this.type = type;
/* 22:48 */     if ("post".equalsIgnoreCase(type)) {
/* 23:49 */       this.post = true;
/* 24:   */     }
/* 25:51 */     this.sqlStatementParam = sqlStatement;
/* 26:53 */     if ("DB2".equalsIgnoreCase(sqlStatement)) {
/* 27:54 */       this.sqlStatement = 
/* 28:55 */         DatabaseDialects.getIdentityClause(DatabaseDialects.DB2);
/* 29:56 */     } else if ("MySQL".equalsIgnoreCase(sqlStatement)) {
/* 30:57 */       this.sqlStatement = 
/* 31:58 */         DatabaseDialects.getIdentityClause(DatabaseDialects.MYSQL);
/* 32:59 */     } else if ("SqlServer".equalsIgnoreCase(sqlStatement)) {
/* 33:60 */       this.sqlStatement = 
/* 34:61 */         DatabaseDialects.getIdentityClause(DatabaseDialects.SQLSERVER);
/* 35:62 */     } else if ("Cloudscape".equalsIgnoreCase(sqlStatement)) {
/* 36:63 */       this.sqlStatement = 
/* 37:64 */         DatabaseDialects.getIdentityClause(DatabaseDialects.CLOUDSCAPE);
/* 38:65 */     } else if ("Derby".equalsIgnoreCase(sqlStatement)) {
/* 39:66 */       this.sqlStatement = 
/* 40:67 */         DatabaseDialects.getIdentityClause(DatabaseDialects.DERBY);
/* 41:68 */     } else if ("HSQLDB".equalsIgnoreCase(sqlStatement)) {
/* 42:69 */       this.sqlStatement = 
/* 43:70 */         DatabaseDialects.getIdentityClause(DatabaseDialects.HSQLDB);
/* 44:   */     } else {
/* 45:72 */       this.sqlStatement = sqlStatement;
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String getColumn()
/* 50:   */   {
/* 51:77 */     return this.column;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public boolean isPost()
/* 55:   */   {
/* 56:81 */     return this.post;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public boolean isIdentity()
/* 60:   */   {
/* 61:85 */     return this.isIdentity;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public String getSqlStatement()
/* 65:   */   {
/* 66:89 */     return this.sqlStatement;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public XmlElement toXml()
/* 70:   */   {
/* 71:93 */     XmlElement answer = new XmlElement("generatedKey");
/* 72:94 */     answer.addAttribute(new Attribute("column", this.column));
/* 73:95 */     answer.addAttribute(new Attribute("identity", Boolean.toString(this.isIdentity)));
/* 74:96 */     answer.addAttribute(new Attribute("sqlStatement", this.sqlStatementParam));
/* 75:97 */     if (StringUtility.stringHasValue(this.type)) {
/* 76:98 */       answer.addAttribute(new Attribute("type", this.type));
/* 77:   */     }
/* 78:99 */     return answer;
/* 79:   */   }
/* 80:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.GeneratedKey
 * JD-Core Version:    0.7.0.1
 */