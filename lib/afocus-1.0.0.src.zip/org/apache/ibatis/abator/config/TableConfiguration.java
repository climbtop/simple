/*   1:    */ package org.apache.ibatis.abator.config;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*  12:    */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  13:    */ import org.apache.ibatis.abator.internal.util.EqualsUtil;
/*  14:    */ import org.apache.ibatis.abator.internal.util.HashCodeUtil;
/*  15:    */ 
/*  16:    */ public class TableConfiguration
/*  17:    */   extends PropertyHolder
/*  18:    */ {
/*  19:    */   private boolean insertStatementEnabled;
/*  20:    */   private boolean selectByPrimaryKeyStatementEnabled;
/*  21:    */   private boolean selectByExampleStatementEnabled;
/*  22:    */   private boolean updateByPrimaryKeyStatementEnabled;
/*  23:    */   private boolean deleteByPrimaryKeyStatementEnabled;
/*  24:    */   private boolean deleteByExampleStatementEnabled;
/*  25:    */   private Map columnOverrides;
/*  26:    */   private Map<String, Boolean> ignoredColumns;
/*  27:    */   private GeneratedKey generatedKey;
/*  28:    */   private String selectByPrimaryKeyQueryId;
/*  29:    */   private String selectByExampleQueryId;
/*  30:    */   private String catalog;
/*  31:    */   private String schema;
/*  32:    */   private String tableName;
/*  33:    */   private String domainObjectName;
/*  34:    */   private String alias;
/*  35:    */   private String label;
/*  36:    */   private ModelType modelType;
/*  37:    */   private boolean wildcardEscapingEnabled;
/*  38:    */   
/*  39:    */   public TableConfiguration(AbatorContext abatorContext)
/*  40:    */   {
/*  41: 68 */     this.modelType = abatorContext.getDefaultModelType();
/*  42:    */     
/*  43: 70 */     this.columnOverrides = new HashMap();
/*  44: 71 */     this.ignoredColumns = new HashMap();
/*  45:    */     
/*  46: 73 */     this.insertStatementEnabled = true;
/*  47: 74 */     this.selectByPrimaryKeyStatementEnabled = true;
/*  48: 75 */     this.selectByExampleStatementEnabled = true;
/*  49: 76 */     this.updateByPrimaryKeyStatementEnabled = true;
/*  50: 77 */     this.deleteByPrimaryKeyStatementEnabled = true;
/*  51: 78 */     this.deleteByExampleStatementEnabled = true;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean isDeleteByPrimaryKeyStatementEnabled()
/*  55:    */   {
/*  56: 82 */     return this.deleteByPrimaryKeyStatementEnabled;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setDeleteByPrimaryKeyStatementEnabled(boolean deleteByPrimaryKeyStatementEnabled)
/*  60:    */   {
/*  61: 87 */     this.deleteByPrimaryKeyStatementEnabled = deleteByPrimaryKeyStatementEnabled;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isInsertStatementEnabled()
/*  65:    */   {
/*  66: 91 */     return this.insertStatementEnabled;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setInsertStatementEnabled(boolean insertStatementEnabled)
/*  70:    */   {
/*  71: 95 */     this.insertStatementEnabled = insertStatementEnabled;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean isSelectByPrimaryKeyStatementEnabled()
/*  75:    */   {
/*  76: 99 */     return this.selectByPrimaryKeyStatementEnabled;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setSelectByPrimaryKeyStatementEnabled(boolean selectByPrimaryKeyStatementEnabled)
/*  80:    */   {
/*  81:104 */     this.selectByPrimaryKeyStatementEnabled = selectByPrimaryKeyStatementEnabled;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isUpdateByPrimaryKeyStatementEnabled()
/*  85:    */   {
/*  86:108 */     return this.updateByPrimaryKeyStatementEnabled;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void setUpdateByPrimaryKeyStatementEnabled(boolean updateByPrimaryKeyStatementEnabled)
/*  90:    */   {
/*  91:113 */     this.updateByPrimaryKeyStatementEnabled = updateByPrimaryKeyStatementEnabled;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean isColumnIgnored(String column)
/*  95:    */   {
/*  96:117 */     String key = column.toUpperCase();
/*  97:    */     
/*  98:119 */     boolean rc = this.ignoredColumns.containsKey(key);
/*  99:121 */     if (rc) {
/* 100:122 */       this.ignoredColumns.put(key, Boolean.TRUE);
/* 101:    */     }
/* 102:125 */     return rc;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void addIgnoredColumn(String column)
/* 106:    */   {
/* 107:129 */     this.ignoredColumns.put(column.toUpperCase(), Boolean.FALSE);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void addIgnoredColumns2TableConfigureXml(XmlElement tableXmlElement)
/* 111:    */   {
/* 112:132 */     for (String column : this.ignoredColumns.keySet())
/* 113:    */     {
/* 114:133 */       XmlElement element = new XmlElement("ignoreColumn");
/* 115:134 */       element.addAttribute(new Attribute("column", column));
/* 116:135 */       tableXmlElement.addElement(element);
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void addColumnOverride(ColumnOverride columnOverride)
/* 121:    */   {
/* 122:139 */     this.columnOverrides.put(columnOverride.getColumnName().toUpperCase(), 
/* 123:140 */       columnOverride);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean equals(Object obj)
/* 127:    */   {
/* 128:144 */     if (this == obj) {
/* 129:145 */       return true;
/* 130:    */     }
/* 131:148 */     if (!(obj instanceof TableConfiguration)) {
/* 132:149 */       return false;
/* 133:    */     }
/* 134:152 */     TableConfiguration other = (TableConfiguration)obj;
/* 135:    */     
/* 136:154 */     return (EqualsUtil.areEqual(this.catalog, other.catalog)) && 
/* 137:155 */       (EqualsUtil.areEqual(this.schema, other.schema)) && 
/* 138:156 */       (EqualsUtil.areEqual(this.tableName, other.tableName));
/* 139:    */   }
/* 140:    */   
/* 141:    */   public int hashCode()
/* 142:    */   {
/* 143:160 */     int result = 23;
/* 144:161 */     result = HashCodeUtil.hash(result, this.catalog);
/* 145:162 */     result = HashCodeUtil.hash(result, this.schema);
/* 146:163 */     result = HashCodeUtil.hash(result, this.tableName);
/* 147:    */     
/* 148:165 */     return result;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean isSelectByExampleStatementEnabled()
/* 152:    */   {
/* 153:169 */     return this.selectByExampleStatementEnabled;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void setSelectByExampleStatementEnabled(boolean selectByExampleStatementEnabled)
/* 157:    */   {
/* 158:174 */     this.selectByExampleStatementEnabled = selectByExampleStatementEnabled;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public ColumnOverride getColumnOverride(String columnName)
/* 162:    */   {
/* 163:184 */     return (ColumnOverride)this.columnOverrides.get(columnName.toUpperCase());
/* 164:    */   }
/* 165:    */   
/* 166:    */   public GeneratedKey getGeneratedKey()
/* 167:    */   {
/* 168:188 */     return this.generatedKey;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public String getSelectByExampleQueryId()
/* 172:    */   {
/* 173:192 */     return this.selectByExampleQueryId;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public void setSelectByExampleQueryId(String selectByExampleQueryId)
/* 177:    */   {
/* 178:196 */     this.selectByExampleQueryId = selectByExampleQueryId;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public String getSelectByPrimaryKeyQueryId()
/* 182:    */   {
/* 183:200 */     return this.selectByPrimaryKeyQueryId;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void setSelectByPrimaryKeyQueryId(String selectByPrimaryKeyQueryId)
/* 187:    */   {
/* 188:204 */     this.selectByPrimaryKeyQueryId = selectByPrimaryKeyQueryId;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public boolean isDeleteByExampleStatementEnabled()
/* 192:    */   {
/* 193:208 */     return this.deleteByExampleStatementEnabled;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void setDeleteByExampleStatementEnabled(boolean deleteByExampleStatementEnabled)
/* 197:    */   {
/* 198:213 */     this.deleteByExampleStatementEnabled = deleteByExampleStatementEnabled;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public boolean areAnyStatementsEnabled()
/* 202:    */   {
/* 203:217 */     return (this.selectByExampleStatementEnabled) || 
/* 204:218 */       (this.selectByPrimaryKeyStatementEnabled) || 
/* 205:219 */       (this.insertStatementEnabled) || 
/* 206:220 */       (this.updateByPrimaryKeyStatementEnabled) || 
/* 207:221 */       (this.deleteByExampleStatementEnabled) || 
/* 208:222 */       (this.deleteByPrimaryKeyStatementEnabled);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void setGeneratedKey(GeneratedKey generatedKey)
/* 212:    */   {
/* 213:226 */     this.generatedKey = generatedKey;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public String getAlias()
/* 217:    */   {
/* 218:230 */     return this.alias;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void setAlias(String alias)
/* 222:    */   {
/* 223:234 */     this.alias = alias;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public String getCatalog()
/* 227:    */   {
/* 228:238 */     return this.catalog;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void setCatalog(String catalog)
/* 232:    */   {
/* 233:242 */     this.catalog = catalog;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public String getDomainObjectName()
/* 237:    */   {
/* 238:246 */     return this.domainObjectName;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void setDomainObjectName(String domainObjectName)
/* 242:    */   {
/* 243:250 */     this.domainObjectName = domainObjectName;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public String getSchema()
/* 247:    */   {
/* 248:254 */     return this.schema;
/* 249:    */   }
/* 250:    */   
/* 251:    */   public void setSchema(String schema)
/* 252:    */   {
/* 253:258 */     this.schema = schema;
/* 254:    */   }
/* 255:    */   
/* 256:    */   public String getTableName()
/* 257:    */   {
/* 258:262 */     return this.tableName;
/* 259:    */   }
/* 260:    */   
/* 261:    */   public void setTableName(String tableName)
/* 262:    */   {
/* 263:266 */     this.tableName = tableName;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public Iterator getColumnOverrides()
/* 267:    */   {
/* 268:270 */     return this.columnOverrides.values().iterator();
/* 269:    */   }
/* 270:    */   
/* 271:    */   public Iterator getIgnoredColumnsInError()
/* 272:    */   {
/* 273:282 */     List answer = new ArrayList();
/* 274:    */     
/* 275:284 */     Iterator iter = this.ignoredColumns.entrySet().iterator();
/* 276:285 */     while (iter.hasNext())
/* 277:    */     {
/* 278:286 */       Map.Entry entry = (Map.Entry)iter.next();
/* 279:288 */       if (Boolean.FALSE.equals(entry.getValue())) {
/* 280:289 */         answer.add(entry.getKey());
/* 281:    */       }
/* 282:    */     }
/* 283:293 */     return answer.iterator();
/* 284:    */   }
/* 285:    */   
/* 286:    */   public ModelType getModelType()
/* 287:    */   {
/* 288:297 */     return this.modelType;
/* 289:    */   }
/* 290:    */   
/* 291:    */   public void setModelType(ModelType modelType)
/* 292:    */   {
/* 293:301 */     this.modelType = modelType;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public boolean isWildcardEscapingEnabled()
/* 297:    */   {
/* 298:305 */     return this.wildcardEscapingEnabled;
/* 299:    */   }
/* 300:    */   
/* 301:    */   public void setWildcardEscapingEnabled(boolean wildcardEscapingEnabled)
/* 302:    */   {
/* 303:309 */     this.wildcardEscapingEnabled = wildcardEscapingEnabled;
/* 304:    */   }
/* 305:    */   
/* 306:    */   public String getLabel()
/* 307:    */   {
/* 308:316 */     return this.label;
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void setLabel(String label)
/* 312:    */   {
/* 313:323 */     this.label = label;
/* 314:    */   }
/* 315:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.TableConfiguration
 * JD-Core Version:    0.7.0.1
 */