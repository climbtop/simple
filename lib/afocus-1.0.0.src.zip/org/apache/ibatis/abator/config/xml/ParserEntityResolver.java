/*  1:   */ package org.apache.ibatis.abator.config.xml;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.InputStream;
/*  5:   */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  6:   */ import org.xml.sax.EntityResolver;
/*  7:   */ import org.xml.sax.InputSource;
/*  8:   */ import org.xml.sax.SAXException;
/*  9:   */ 
/* 10:   */ public class ParserEntityResolver
/* 11:   */   implements EntityResolver
/* 12:   */ {
/* 13:   */   public InputSource resolveEntity(String publicId, String systemId)
/* 14:   */     throws SAXException, IOException
/* 15:   */   {
/* 16:47 */     if ("-//Apache Software Foundation//DTD Abator for iBATIS Configuration 1.0//EN".equals(publicId))
/* 17:   */     {
/* 18:48 */       InputStream is = getClass()
/* 19:49 */         .getClassLoader()
/* 20:50 */         .getResourceAsStream(
/* 21:51 */         "org/apache/ibatis/abator/config/xml/abator-config_1_0.dtd");
/* 22:52 */       InputSource ins = new InputSource(is);
/* 23:   */       
/* 24:54 */       return ins;
/* 25:   */     }
/* 26:56 */     throw new SAXException(Messages.getString("RuntimeError.5"));
/* 27:   */   }
/* 28:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.xml.ParserEntityResolver
 * JD-Core Version:    0.7.0.1
 */