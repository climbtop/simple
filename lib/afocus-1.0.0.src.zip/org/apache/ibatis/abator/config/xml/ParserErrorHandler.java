/*  1:   */ package org.apache.ibatis.abator.config.xml;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  5:   */ import org.xml.sax.ErrorHandler;
/*  6:   */ import org.xml.sax.SAXException;
/*  7:   */ import org.xml.sax.SAXParseException;
/*  8:   */ 
/*  9:   */ public class ParserErrorHandler
/* 10:   */   implements ErrorHandler
/* 11:   */ {
/* 12:   */   private List warnings;
/* 13:   */   private List errors;
/* 14:   */   
/* 15:   */   public ParserErrorHandler(List warnings, List errors)
/* 16:   */   {
/* 17:38 */     this.warnings = warnings;
/* 18:39 */     this.errors = errors;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void warning(SAXParseException exception)
/* 22:   */     throws SAXException
/* 23:   */   {
/* 24:48 */     this.warnings.add(Messages.getString("Warning.7", 
/* 25:49 */       Integer.toString(exception.getLineNumber()), 
/* 26:50 */       exception.getMessage()));
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void error(SAXParseException exception)
/* 30:   */     throws SAXException
/* 31:   */   {
/* 32:59 */     this.errors.add(Messages.getString("RuntimeError.4", 
/* 33:60 */       Integer.toString(exception.getLineNumber()), 
/* 34:61 */       exception.getMessage()));
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void fatalError(SAXParseException exception)
/* 38:   */     throws SAXException
/* 39:   */   {
/* 40:70 */     this.errors.add(Messages.getString("RuntimeError.4", 
/* 41:71 */       Integer.toString(exception.getLineNumber()), 
/* 42:72 */       exception.getMessage()));
/* 43:   */   }
/* 44:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.xml.ParserErrorHandler
 * JD-Core Version:    0.7.0.1
 */