/*   1:    */ package org.apache.ibatis.abator.config.xml;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileReader;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.Reader;
/*   8:    */ import java.net.URL;
/*   9:    */ import java.net.URLConnection;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Arrays;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Properties;
/*  14:    */ import javax.xml.parsers.DocumentBuilder;
/*  15:    */ import javax.xml.parsers.DocumentBuilderFactory;
/*  16:    */ import javax.xml.parsers.ParserConfigurationException;
/*  17:    */ import org.apache.ibatis.abator.config.AbatorConfiguration;
/*  18:    */ import org.apache.ibatis.abator.config.AbatorContext;
/*  19:    */ import org.apache.ibatis.abator.config.AopGeneratorConfiguration;
/*  20:    */ import org.apache.ibatis.abator.config.ColumnOverride;
/*  21:    */ import org.apache.ibatis.abator.config.ControllerGeneratorConfiguration;
/*  22:    */ import org.apache.ibatis.abator.config.DAOGeneratorConfiguration;
/*  23:    */ import org.apache.ibatis.abator.config.GeneratedKey;
/*  24:    */ import org.apache.ibatis.abator.config.JDBCConnectionConfiguration;
/*  25:    */ import org.apache.ibatis.abator.config.JavaModelGeneratorConfiguration;
/*  26:    */ import org.apache.ibatis.abator.config.JavaTypeResolverConfiguration;
/*  27:    */ import org.apache.ibatis.abator.config.JspGeneratorConfiguration;
/*  28:    */ import org.apache.ibatis.abator.config.ModelType;
/*  29:    */ import org.apache.ibatis.abator.config.PropertyHolder;
/*  30:    */ import org.apache.ibatis.abator.config.ServiceGeneratorConfiguration;
/*  31:    */ import org.apache.ibatis.abator.config.SqlMapGeneratorConfiguration;
/*  32:    */ import org.apache.ibatis.abator.config.TableConfiguration;
/*  33:    */ import org.apache.ibatis.abator.exception.XMLParserException;
/*  34:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  35:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  36:    */ import org.w3c.dom.Document;
/*  37:    */ import org.w3c.dom.NamedNodeMap;
/*  38:    */ import org.w3c.dom.Node;
/*  39:    */ import org.w3c.dom.NodeList;
/*  40:    */ import org.xml.sax.InputSource;
/*  41:    */ import org.xml.sax.SAXException;
/*  42:    */ import org.xml.sax.SAXParseException;
/*  43:    */ 
/*  44:    */ public class AbatorConfigurationParser
/*  45:    */ {
/*  46:    */   private List warnings;
/*  47:    */   private List parseErrors;
/*  48:    */   private Properties properties;
/*  49:    */   
/*  50:    */   public AbatorConfigurationParser(List warnings)
/*  51:    */   {
/*  52: 74 */     this(null, warnings);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public AbatorConfigurationParser(Properties properties, List warnings)
/*  56:    */   {
/*  57: 79 */     if (properties == null) {
/*  58: 80 */       this.properties = new Properties();
/*  59:    */     } else {
/*  60: 83 */       this.properties = properties;
/*  61:    */     }
/*  62: 86 */     if (warnings == null) {
/*  63: 87 */       this.warnings = new ArrayList();
/*  64:    */     } else {
/*  65: 90 */       this.warnings = warnings;
/*  66:    */     }
/*  67: 93 */     this.parseErrors = new ArrayList();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public AbatorConfiguration parseAbatorConfiguration(File inputFile)
/*  71:    */     throws IOException, XMLParserException
/*  72:    */   {
/*  73: 98 */     FileReader fr = new FileReader(inputFile);
/*  74:    */     
/*  75:100 */     return parseAbatorConfiguration(fr);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public AbatorConfiguration parseAbatorConfiguration(Reader reader)
/*  79:    */     throws IOException, XMLParserException
/*  80:    */   {
/*  81:105 */     InputSource is = new InputSource(reader);
/*  82:    */     
/*  83:107 */     return parseAbatorConfiguration(is);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public AbatorConfiguration parseAbatorConfiguration(InputStream inputStream)
/*  87:    */     throws IOException, XMLParserException
/*  88:    */   {
/*  89:112 */     InputSource is = new InputSource(inputStream);
/*  90:    */     
/*  91:114 */     return parseAbatorConfiguration(is);
/*  92:    */   }
/*  93:    */   
/*  94:    */   private AbatorConfiguration parseAbatorConfiguration(InputSource inputSource)
/*  95:    */     throws IOException, XMLParserException
/*  96:    */   {
/*  97:118 */     this.parseErrors.clear();
/*  98:119 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  99:120 */     factory.setValidating(true);
/* 100:    */     try
/* 101:    */     {
/* 102:123 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 103:124 */       builder.setEntityResolver(new ParserEntityResolver());
/* 104:    */       
/* 105:126 */       ParserErrorHandler handler = new ParserErrorHandler(this.warnings, this.parseErrors);
/* 106:127 */       builder.setErrorHandler(handler);
/* 107:    */       
/* 108:129 */       Document document = null;
/* 109:    */       try
/* 110:    */       {
/* 111:131 */         document = builder.parse(inputSource);
/* 112:    */       }
/* 113:    */       catch (SAXParseException e)
/* 114:    */       {
/* 115:134 */         throw new XMLParserException(this.parseErrors);
/* 116:    */       }
/* 117:    */       catch (SAXException e)
/* 118:    */       {
/* 119:137 */         if (e.getException() == null) {
/* 120:138 */           this.parseErrors.add(Arrays.deepToString(e.getStackTrace()));
/* 121:    */         } else {
/* 122:141 */           this.parseErrors.add(Arrays.deepToString(e.getStackTrace()));
/* 123:    */         }
/* 124:    */       }
/* 125:145 */       if (this.parseErrors.size() > 0) {
/* 126:146 */         throw new XMLParserException(this.parseErrors);
/* 127:    */       }
/* 128:149 */       NodeList nodeList = document.getChildNodes();
/* 129:150 */       AbatorConfiguration gc = null;
/* 130:151 */       for (int i = 0; i < nodeList.getLength(); i++)
/* 131:    */       {
/* 132:152 */         Node node = nodeList.item(i);
/* 133:154 */         if ((node.getNodeType() == 1) && ("abatorConfiguration".equals(node.getNodeName())))
/* 134:    */         {
/* 135:155 */           gc = parseAbatorConfiguration(node);
/* 136:156 */           break;
/* 137:    */         }
/* 138:    */       }
/* 139:160 */       if (this.parseErrors.size() > 0) {
/* 140:161 */         throw new XMLParserException(this.parseErrors);
/* 141:    */       }
/* 142:164 */       return gc;
/* 143:    */     }
/* 144:    */     catch (ParserConfigurationException e)
/* 145:    */     {
/* 146:167 */       this.parseErrors.add(Arrays.deepToString(e.getStackTrace()));
/* 147:168 */       throw new XMLParserException(this.parseErrors);
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   private AbatorConfiguration parseAbatorConfiguration(Node node)
/* 152:    */     throws XMLParserException
/* 153:    */   {
/* 154:174 */     AbatorConfiguration abatorConfiguration = new AbatorConfiguration();
/* 155:    */     
/* 156:176 */     NodeList nodeList = node.getChildNodes();
/* 157:177 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 158:    */     {
/* 159:178 */       Node childNode = nodeList.item(i);
/* 160:180 */       if (childNode.getNodeType() == 1) {
/* 161:184 */         if ("properties".equals(childNode.getNodeName())) {
/* 162:185 */           parseProperties(abatorConfiguration, childNode);
/* 163:187 */         } else if ("abatorContext".equals(childNode.getNodeName())) {
/* 164:188 */           parseAbatorContext(abatorConfiguration, childNode);
/* 165:    */         }
/* 166:    */       }
/* 167:    */     }
/* 168:192 */     return abatorConfiguration;
/* 169:    */   }
/* 170:    */   
/* 171:    */   private void parseProperties(AbatorConfiguration abatorConfiguration, Node node)
/* 172:    */     throws XMLParserException
/* 173:    */   {
/* 174:196 */     Properties attributes = parseAttributes(node);
/* 175:197 */     String resource = attributes.getProperty("resource");
/* 176:198 */     String url = attributes.getProperty("url");
/* 177:200 */     if ((!StringUtility.stringHasValue(resource)) && (!StringUtility.stringHasValue(url))) {
/* 178:201 */       throw new XMLParserException(Messages.getString("RuntimeError.14"));
/* 179:    */     }
/* 180:204 */     if ((StringUtility.stringHasValue(resource)) && (StringUtility.stringHasValue(url))) {
/* 181:205 */       throw new XMLParserException(Messages.getString("RuntimeError.14"));
/* 182:    */     }
/* 183:    */     try
/* 184:    */     {
/* 185:    */       URL resourceUrl;
/* 186:211 */       if (StringUtility.stringHasValue(resource))
/* 187:    */       {
/* 188:212 */         URL resourceUrl = Thread.currentThread().getContextClassLoader().getResource(resource);
/* 189:213 */         if (resourceUrl == null) {
/* 190:214 */           throw new XMLParserException(Messages.getString("RuntimeError.15", resource));
/* 191:    */         }
/* 192:    */       }
/* 193:    */       else
/* 194:    */       {
/* 195:218 */         resourceUrl = new URL(url);
/* 196:    */       }
/* 197:221 */       InputStream inputStream = resourceUrl.openConnection().getInputStream();
/* 198:    */       
/* 199:223 */       this.properties.load(inputStream);
/* 200:224 */       inputStream.close();
/* 201:    */     }
/* 202:    */     catch (IOException e)
/* 203:    */     {
/* 204:227 */       if (StringUtility.stringHasValue(resource)) {
/* 205:228 */         throw new XMLParserException(Messages.getString("RuntimeError.16", resource));
/* 206:    */       }
/* 207:231 */       throw new XMLParserException(Messages.getString("RuntimeError.17", url));
/* 208:    */     }
/* 209:    */     URL resourceUrl;
/* 210:    */   }
/* 211:    */   
/* 212:    */   private void parseAbatorContext(AbatorConfiguration abatorConfiguration, Node node)
/* 213:    */   {
/* 214:238 */     Properties attributes = parseAttributes(node);
/* 215:239 */     String generatorSet = attributes.getProperty("generatorSet");
/* 216:240 */     String defaultModelType = attributes.getProperty("defaultModelType");
/* 217:241 */     String id = attributes.getProperty("id");
/* 218:    */     
/* 219:243 */     ModelType mt = defaultModelType == null ? null : ModelType.getModelType(defaultModelType);
/* 220:    */     
/* 221:245 */     AbatorContext abatorContext = new AbatorContext(generatorSet, mt);
/* 222:246 */     abatorContext.setId(id);
/* 223:    */     
/* 224:248 */     abatorConfiguration.addAbatorContext(abatorContext);
/* 225:    */     
/* 226:250 */     NodeList nodeList = node.getChildNodes();
/* 227:251 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 228:    */     {
/* 229:252 */       Node childNode = nodeList.item(i);
/* 230:254 */       if (childNode.getNodeType() == 1) {
/* 231:258 */         if ("property".equals(childNode.getNodeName())) {
/* 232:259 */           parseProperty(abatorContext, childNode);
/* 233:261 */         } else if ("jdbcConnection".equals(childNode.getNodeName())) {
/* 234:262 */           parseJdbcConnection(abatorContext, childNode);
/* 235:264 */         } else if ("javaModelGenerator".equals(childNode.getNodeName())) {
/* 236:265 */           parseJavaModelGenerator(abatorContext, childNode);
/* 237:267 */         } else if ("javaTypeResolver".equals(childNode.getNodeName())) {
/* 238:268 */           parseJavaTypeResolver(abatorContext, childNode);
/* 239:270 */         } else if ("sqlMapGenerator".equals(childNode.getNodeName())) {
/* 240:271 */           parseSqlMapGenerator(abatorContext, childNode);
/* 241:273 */         } else if ("daoGenerator".equals(childNode.getNodeName())) {
/* 242:274 */           parseDaoGenerator(abatorContext, childNode);
/* 243:276 */         } else if ("serviceGenerator".equals(childNode.getNodeName())) {
/* 244:277 */           parseServiceGenerator(abatorContext, childNode);
/* 245:279 */         } else if ("controllerGenerator".equals(childNode.getNodeName())) {
/* 246:280 */           parseControllerGenerator(abatorContext, childNode);
/* 247:282 */         } else if ("aopGenerator".equals(childNode.getNodeName())) {
/* 248:283 */           parseAopGenerator(abatorContext, childNode);
/* 249:285 */         } else if ("jspGenerator".equals(childNode.getNodeName())) {
/* 250:286 */           parseJspGenerator(abatorContext, childNode);
/* 251:288 */         } else if ("table".equals(childNode.getNodeName())) {
/* 252:289 */           parseTable(abatorContext, childNode);
/* 253:    */         }
/* 254:    */       }
/* 255:    */     }
/* 256:    */   }
/* 257:    */   
/* 258:    */   private void parseSqlMapGenerator(AbatorContext abatorContext, Node node)
/* 259:    */   {
/* 260:295 */     SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration = new SqlMapGeneratorConfiguration();
/* 261:    */     
/* 262:297 */     abatorContext.setSqlMapGeneratorConfiguration(sqlMapGeneratorConfiguration);
/* 263:    */     
/* 264:299 */     Properties attributes = parseAttributes(node);
/* 265:300 */     String type = attributes.getProperty("type");
/* 266:301 */     String targetPackage = attributes.getProperty("targetPackage");
/* 267:302 */     String targetProject = attributes.getProperty("targetProject");
/* 268:304 */     if (StringUtility.stringHasValue(type)) {
/* 269:305 */       sqlMapGeneratorConfiguration.setConfigurationType(type);
/* 270:    */     }
/* 271:308 */     sqlMapGeneratorConfiguration.setTargetPackage(targetPackage);
/* 272:309 */     sqlMapGeneratorConfiguration.setTargetProject(targetProject);
/* 273:    */     
/* 274:311 */     NodeList nodeList = node.getChildNodes();
/* 275:312 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 276:    */     {
/* 277:313 */       Node childNode = nodeList.item(i);
/* 278:315 */       if (childNode.getNodeType() == 1) {
/* 279:319 */         if ("property".equals(childNode.getNodeName())) {
/* 280:320 */           parseProperty(sqlMapGeneratorConfiguration, childNode);
/* 281:    */         }
/* 282:    */       }
/* 283:    */     }
/* 284:    */   }
/* 285:    */   
/* 286:    */   private void parseTable(AbatorContext abatorContext, Node node)
/* 287:    */   {
/* 288:326 */     TableConfiguration tc = new TableConfiguration(abatorContext);
/* 289:327 */     abatorContext.addTableConfiguration(tc);
/* 290:    */     
/* 291:329 */     Properties attributes = parseAttributes(node);
/* 292:330 */     String catalog = attributes.getProperty("catalog");
/* 293:331 */     String schema = attributes.getProperty("schema");
/* 294:332 */     String tableName = attributes.getProperty("tableName");
/* 295:333 */     String domainObjectName = attributes.getProperty("domainObjectName");
/* 296:334 */     String alias = attributes.getProperty("alias");
/* 297:335 */     String label = attributes.getProperty("label");
/* 298:336 */     String enableInsert = attributes.getProperty("enableInsert");
/* 299:337 */     String enableSelectByPrimaryKey = attributes.getProperty("enableSelectByPrimaryKey");
/* 300:338 */     String enableSelectByExample = attributes.getProperty("enableSelectByExample");
/* 301:339 */     String enableUpdateByPrimaryKey = attributes.getProperty("enableUpdateByPrimaryKey");
/* 302:340 */     String enableDeleteByPrimaryKey = attributes.getProperty("enableDeleteByPrimaryKey");
/* 303:341 */     String enableDeleteByExample = attributes.getProperty("enableDeleteByExample");
/* 304:342 */     String selectByPrimaryKeyQueryId = attributes.getProperty("selectByPrimaryKeyQueryId");
/* 305:343 */     String selectByExampleQueryId = attributes.getProperty("selectByExampleQueryId");
/* 306:344 */     String modelType = attributes.getProperty("modelType");
/* 307:345 */     String escapeWildcards = attributes.getProperty("escapeWildcards");
/* 308:347 */     if (StringUtility.stringHasValue(catalog)) {
/* 309:348 */       tc.setCatalog(catalog);
/* 310:    */     }
/* 311:351 */     if (StringUtility.stringHasValue(schema)) {
/* 312:352 */       tc.setSchema(schema);
/* 313:    */     }
/* 314:355 */     if (StringUtility.stringHasValue(tableName)) {
/* 315:356 */       tc.setTableName(tableName);
/* 316:    */     }
/* 317:359 */     if (StringUtility.stringHasValue(domainObjectName)) {
/* 318:360 */       tc.setDomainObjectName(domainObjectName);
/* 319:    */     }
/* 320:363 */     if (StringUtility.stringHasValue(alias)) {
/* 321:364 */       tc.setAlias(alias);
/* 322:    */     }
/* 323:367 */     if (StringUtility.stringHasValue(label))
/* 324:    */     {
/* 325:369 */       String temp = label;
/* 326:    */       
/* 327:    */ 
/* 328:372 */       tc.setLabel(temp);
/* 329:    */     }
/* 330:375 */     if (StringUtility.stringHasValue(enableInsert)) {
/* 331:376 */       tc.setInsertStatementEnabled("true"
/* 332:377 */         .equals(enableInsert));
/* 333:    */     }
/* 334:380 */     if (StringUtility.stringHasValue(enableSelectByPrimaryKey)) {
/* 335:381 */       tc.setSelectByPrimaryKeyStatementEnabled("true"
/* 336:382 */         .equals(enableSelectByPrimaryKey));
/* 337:    */     }
/* 338:385 */     if (StringUtility.stringHasValue(enableSelectByExample)) {
/* 339:386 */       tc.setSelectByExampleStatementEnabled("true"
/* 340:387 */         .equals(enableSelectByExample));
/* 341:    */     }
/* 342:390 */     if (StringUtility.stringHasValue(enableUpdateByPrimaryKey)) {
/* 343:391 */       tc.setUpdateByPrimaryKeyStatementEnabled("true"
/* 344:392 */         .equals(enableUpdateByPrimaryKey));
/* 345:    */     }
/* 346:395 */     if (StringUtility.stringHasValue(enableDeleteByPrimaryKey)) {
/* 347:396 */       tc.setDeleteByPrimaryKeyStatementEnabled("true"
/* 348:397 */         .equals(enableDeleteByPrimaryKey));
/* 349:    */     }
/* 350:400 */     if (StringUtility.stringHasValue(enableDeleteByExample)) {
/* 351:401 */       tc.setDeleteByExampleStatementEnabled("true"
/* 352:402 */         .equals(enableDeleteByExample));
/* 353:    */     }
/* 354:405 */     if (StringUtility.stringHasValue(selectByPrimaryKeyQueryId)) {
/* 355:406 */       tc.setSelectByPrimaryKeyQueryId(selectByPrimaryKeyQueryId);
/* 356:    */     }
/* 357:409 */     if (StringUtility.stringHasValue(selectByExampleQueryId)) {
/* 358:410 */       tc.setSelectByExampleQueryId(selectByExampleQueryId);
/* 359:    */     }
/* 360:413 */     if (StringUtility.stringHasValue(modelType)) {
/* 361:414 */       tc.setModelType(ModelType.getModelType(modelType));
/* 362:    */     }
/* 363:417 */     if (StringUtility.stringHasValue(escapeWildcards)) {
/* 364:418 */       tc.setWildcardEscapingEnabled("true"
/* 365:419 */         .equals(escapeWildcards));
/* 366:    */     }
/* 367:422 */     NodeList nodeList = node.getChildNodes();
/* 368:423 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 369:    */     {
/* 370:424 */       Node childNode = nodeList.item(i);
/* 371:426 */       if (childNode.getNodeType() == 1) {
/* 372:430 */         if ("property".equals(childNode.getNodeName())) {
/* 373:431 */           parseProperty(tc, childNode);
/* 374:433 */         } else if ("columnOverride".equals(childNode.getNodeName())) {
/* 375:434 */           parseColumnOverride(tc, childNode);
/* 376:436 */         } else if ("ignoreColumn".equals(childNode.getNodeName())) {
/* 377:437 */           parseIgnoreColumn(tc, childNode);
/* 378:439 */         } else if ("generatedKey".equals(childNode.getNodeName())) {
/* 379:440 */           parseGeneratedKey(tc, childNode);
/* 380:    */         }
/* 381:    */       }
/* 382:    */     }
/* 383:    */   }
/* 384:    */   
/* 385:    */   private void parseColumnOverride(TableConfiguration tc, Node node)
/* 386:    */   {
/* 387:446 */     Properties attributes = parseAttributes(node);
/* 388:447 */     String column = attributes.getProperty("column");
/* 389:448 */     String property = attributes.getProperty("property");
/* 390:449 */     String javaType = attributes.getProperty("javaType");
/* 391:450 */     String jdbcType = attributes.getProperty("jdbcType");
/* 392:451 */     String typeHandler = attributes.getProperty("typeHandler");
/* 393:    */     
/* 394:453 */     String listable = attributes.getProperty("listable");
/* 395:454 */     String queryable = attributes.getProperty("queryable");
/* 396:455 */     String mainFk = attributes.getProperty("mainFk");
/* 397:456 */     String label = attributes.getProperty("label");
/* 398:457 */     String defaultValue = attributes.getProperty("defaultValue");
/* 399:458 */     String optionValue = attributes.getProperty("optionValue");
/* 400:459 */     String htmlEditor = attributes.getProperty("htmlEditor");
/* 401:460 */     String validator = attributes.getProperty("validator");
/* 402:461 */     String memo = attributes.getProperty("memo");
/* 403:    */     
/* 404:463 */     ColumnOverride co = new ColumnOverride();
/* 405:    */     
/* 406:465 */     co.setColumnName(column);
/* 407:467 */     if (StringUtility.stringHasValue(property)) {
/* 408:468 */       co.setJavaProperty(property);
/* 409:    */     }
/* 410:471 */     if (StringUtility.stringHasValue(javaType)) {
/* 411:472 */       co.setJavaType(javaType);
/* 412:    */     }
/* 413:475 */     if (StringUtility.stringHasValue(jdbcType)) {
/* 414:476 */       co.setJdbcType(jdbcType);
/* 415:    */     }
/* 416:479 */     if (StringUtility.stringHasValue(typeHandler)) {
/* 417:480 */       co.setTypeHandler(typeHandler);
/* 418:    */     }
/* 419:483 */     if (StringUtility.stringHasValue(label))
/* 420:    */     {
/* 421:485 */       String temp = label;
/* 422:    */       
/* 423:    */ 
/* 424:488 */       co.setLabel(temp);
/* 425:    */     }
/* 426:491 */     if (StringUtility.stringHasValue(defaultValue)) {
/* 427:492 */       co.setDefaultValue(defaultValue);
/* 428:    */     }
/* 429:495 */     if (StringUtility.stringHasValue(optionValue)) {
/* 430:496 */       co.setOptionValue(optionValue);
/* 431:    */     }
/* 432:499 */     if (StringUtility.stringHasValue(htmlEditor)) {
/* 433:500 */       co.setHtmlEditor(htmlEditor);
/* 434:    */     }
/* 435:503 */     if (StringUtility.stringHasValue(validator)) {
/* 436:504 */       co.setValidator(validator);
/* 437:    */     }
/* 438:507 */     if (StringUtility.stringHasValue(memo)) {
/* 439:508 */       co.setMemo(memo);
/* 440:    */     }
/* 441:511 */     if (StringUtility.stringHasValue(listable)) {
/* 442:512 */       co.setListable("true".equalsIgnoreCase(listable));
/* 443:    */     }
/* 444:515 */     if (StringUtility.stringHasValue(queryable)) {
/* 445:516 */       co.setQueryable("true".equalsIgnoreCase(queryable));
/* 446:    */     }
/* 447:519 */     if (StringUtility.stringHasValue(mainFk)) {
/* 448:520 */       co.setMainFk("true".equalsIgnoreCase(mainFk));
/* 449:    */     }
/* 450:523 */     tc.addColumnOverride(co);
/* 451:    */   }
/* 452:    */   
/* 453:    */   private void parseGeneratedKey(TableConfiguration tc, Node node)
/* 454:    */   {
/* 455:527 */     Properties attributes = parseAttributes(node);
/* 456:    */     
/* 457:529 */     String column = attributes.getProperty("column");
/* 458:530 */     boolean identity = "true".equals(attributes.getProperty("identity"));
/* 459:531 */     String sqlStatement = attributes.getProperty("sqlStatement");
/* 460:532 */     String type = attributes.getProperty("type");
/* 461:    */     
/* 462:534 */     GeneratedKey gk = new GeneratedKey(column, sqlStatement, identity, type);
/* 463:535 */     tc.setGeneratedKey(gk);
/* 464:    */   }
/* 465:    */   
/* 466:    */   private void parseIgnoreColumn(TableConfiguration tc, Node node)
/* 467:    */   {
/* 468:539 */     Properties attributes = parseAttributes(node);
/* 469:540 */     String column = attributes.getProperty("column");
/* 470:    */     
/* 471:542 */     tc.addIgnoredColumn(column);
/* 472:    */   }
/* 473:    */   
/* 474:    */   private void parseJavaTypeResolver(AbatorContext abatorContext, Node node)
/* 475:    */   {
/* 476:546 */     JavaTypeResolverConfiguration javaTypeResolverConfiguration = new JavaTypeResolverConfiguration();
/* 477:    */     
/* 478:548 */     abatorContext.setJavaTypeResolverConfiguration(javaTypeResolverConfiguration);
/* 479:    */     
/* 480:550 */     Properties attributes = parseAttributes(node);
/* 481:551 */     String type = attributes.getProperty("type");
/* 482:553 */     if (StringUtility.stringHasValue(type)) {
/* 483:554 */       javaTypeResolverConfiguration.setConfigurationType(type);
/* 484:    */     }
/* 485:557 */     NodeList nodeList = node.getChildNodes();
/* 486:558 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 487:    */     {
/* 488:559 */       Node childNode = nodeList.item(i);
/* 489:561 */       if (childNode.getNodeType() == 1) {
/* 490:565 */         if ("property".equals(childNode.getNodeName())) {
/* 491:566 */           parseProperty(javaTypeResolverConfiguration, childNode);
/* 492:    */         }
/* 493:    */       }
/* 494:    */     }
/* 495:    */   }
/* 496:    */   
/* 497:    */   private void parseJavaModelGenerator(AbatorContext abatorContext, Node node)
/* 498:    */   {
/* 499:572 */     JavaModelGeneratorConfiguration javaModelGeneratorConfiguration = new JavaModelGeneratorConfiguration();
/* 500:    */     
/* 501:574 */     abatorContext.setJavaModelGeneratorConfiguration(javaModelGeneratorConfiguration);
/* 502:    */     
/* 503:576 */     Properties attributes = parseAttributes(node);
/* 504:577 */     String type = attributes.getProperty("type");
/* 505:578 */     String targetPackage = attributes.getProperty("targetPackage");
/* 506:579 */     String targetProject = attributes.getProperty("targetProject");
/* 507:581 */     if (StringUtility.stringHasValue(type)) {
/* 508:582 */       javaModelGeneratorConfiguration.setConfigurationType(type);
/* 509:    */     }
/* 510:585 */     javaModelGeneratorConfiguration.setTargetPackage(targetPackage);
/* 511:586 */     javaModelGeneratorConfiguration.setTargetProject(targetProject);
/* 512:    */     
/* 513:588 */     NodeList nodeList = node.getChildNodes();
/* 514:589 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 515:    */     {
/* 516:590 */       Node childNode = nodeList.item(i);
/* 517:592 */       if (childNode.getNodeType() == 1) {
/* 518:596 */         if ("property".equals(childNode.getNodeName())) {
/* 519:597 */           parseProperty(javaModelGeneratorConfiguration, childNode);
/* 520:    */         }
/* 521:    */       }
/* 522:    */     }
/* 523:    */   }
/* 524:    */   
/* 525:    */   private void parseDaoGenerator(AbatorContext abatorContext, Node node)
/* 526:    */   {
/* 527:603 */     DAOGeneratorConfiguration daoGeneratorConfiguration = new DAOGeneratorConfiguration();
/* 528:    */     
/* 529:605 */     abatorContext.setDaoGeneratorConfiguration(daoGeneratorConfiguration);
/* 530:    */     
/* 531:607 */     Properties attributes = parseAttributes(node);
/* 532:608 */     String type = attributes.getProperty("type");
/* 533:609 */     String targetPackage = attributes.getProperty("targetPackage");
/* 534:610 */     String targetProject = attributes.getProperty("targetProject");
/* 535:    */     
/* 536:612 */     daoGeneratorConfiguration.setConfigurationType(type);
/* 537:613 */     daoGeneratorConfiguration.setTargetPackage(targetPackage);
/* 538:614 */     daoGeneratorConfiguration.setTargetProject(targetProject);
/* 539:    */     
/* 540:616 */     NodeList nodeList = node.getChildNodes();
/* 541:617 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 542:    */     {
/* 543:618 */       Node childNode = nodeList.item(i);
/* 544:620 */       if (childNode.getNodeType() == 1) {
/* 545:624 */         if ("property".equals(childNode.getNodeName())) {
/* 546:625 */           parseProperty(daoGeneratorConfiguration, childNode);
/* 547:    */         }
/* 548:    */       }
/* 549:    */     }
/* 550:    */   }
/* 551:    */   
/* 552:    */   private void parseServiceGenerator(AbatorContext abatorContext, Node node)
/* 553:    */   {
/* 554:631 */     ServiceGeneratorConfiguration serviceGeneratorConfiguration = new ServiceGeneratorConfiguration();
/* 555:    */     
/* 556:633 */     abatorContext.setServiceGeneratorConfiguration(serviceGeneratorConfiguration);
/* 557:    */     
/* 558:635 */     Properties attributes = parseAttributes(node);
/* 559:636 */     String type = attributes.getProperty("type");
/* 560:637 */     String targetPackage = attributes.getProperty("targetPackage");
/* 561:638 */     String targetProject = attributes.getProperty("targetProject");
/* 562:    */     
/* 563:640 */     serviceGeneratorConfiguration.setConfigurationType(type);
/* 564:641 */     serviceGeneratorConfiguration.setTargetPackage(targetPackage);
/* 565:642 */     serviceGeneratorConfiguration.setTargetProject(targetProject);
/* 566:    */     
/* 567:644 */     NodeList nodeList = node.getChildNodes();
/* 568:645 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 569:    */     {
/* 570:646 */       Node childNode = nodeList.item(i);
/* 571:648 */       if (childNode.getNodeType() == 1) {
/* 572:652 */         if ("property".equals(childNode.getNodeName())) {
/* 573:653 */           parseProperty(serviceGeneratorConfiguration, childNode);
/* 574:    */         }
/* 575:    */       }
/* 576:    */     }
/* 577:    */   }
/* 578:    */   
/* 579:    */   private void parseAopGenerator(AbatorContext abatorContext, Node node)
/* 580:    */   {
/* 581:659 */     AopGeneratorConfiguration aopGeneratorConfiguration = new AopGeneratorConfiguration();
/* 582:    */     
/* 583:661 */     abatorContext.setAopGeneratorConfiguration(aopGeneratorConfiguration);
/* 584:    */     
/* 585:663 */     Properties attributes = parseAttributes(node);
/* 586:664 */     String type = attributes.getProperty("type");
/* 587:665 */     String targetPackage = attributes.getProperty("targetPackage");
/* 588:666 */     String targetProject = attributes.getProperty("targetProject");
/* 589:    */     
/* 590:668 */     aopGeneratorConfiguration.setConfigurationType(type);
/* 591:669 */     aopGeneratorConfiguration.setTargetPackage(targetPackage);
/* 592:670 */     aopGeneratorConfiguration.setTargetProject(targetProject);
/* 593:    */     
/* 594:672 */     NodeList nodeList = node.getChildNodes();
/* 595:673 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 596:    */     {
/* 597:674 */       Node childNode = nodeList.item(i);
/* 598:676 */       if (childNode.getNodeType() == 1) {
/* 599:680 */         if ("property".equals(childNode.getNodeName())) {
/* 600:681 */           parseProperty(aopGeneratorConfiguration, childNode);
/* 601:    */         }
/* 602:    */       }
/* 603:    */     }
/* 604:    */   }
/* 605:    */   
/* 606:    */   private void parseControllerGenerator(AbatorContext abatorContext, Node node)
/* 607:    */   {
/* 608:687 */     ControllerGeneratorConfiguration controllerGeneratorConfiguration = new ControllerGeneratorConfiguration();
/* 609:    */     
/* 610:689 */     abatorContext.setControllerGeneratorConfiguration(controllerGeneratorConfiguration);
/* 611:    */     
/* 612:691 */     Properties attributes = parseAttributes(node);
/* 613:692 */     String type = attributes.getProperty("type");
/* 614:693 */     String targetPackage = attributes.getProperty("targetPackage");
/* 615:694 */     String targetProject = attributes.getProperty("targetProject");
/* 616:    */     
/* 617:696 */     controllerGeneratorConfiguration.setConfigurationType(type);
/* 618:697 */     controllerGeneratorConfiguration.setTargetPackage(targetPackage);
/* 619:698 */     controllerGeneratorConfiguration.setTargetProject(targetProject);
/* 620:    */     
/* 621:700 */     NodeList nodeList = node.getChildNodes();
/* 622:701 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 623:    */     {
/* 624:702 */       Node childNode = nodeList.item(i);
/* 625:704 */       if (childNode.getNodeType() == 1) {
/* 626:708 */         if ("property".equals(childNode.getNodeName())) {
/* 627:709 */           parseProperty(controllerGeneratorConfiguration, childNode);
/* 628:    */         }
/* 629:    */       }
/* 630:    */     }
/* 631:    */   }
/* 632:    */   
/* 633:    */   private void parseJspGenerator(AbatorContext abatorContext, Node node)
/* 634:    */   {
/* 635:715 */     JspGeneratorConfiguration jspGeneratorConfiguration = new JspGeneratorConfiguration();
/* 636:    */     
/* 637:717 */     abatorContext.setJspGeneratorConfiguration(jspGeneratorConfiguration);
/* 638:    */     
/* 639:719 */     Properties attributes = parseAttributes(node);
/* 640:720 */     String type = attributes.getProperty("type");
/* 641:721 */     String targetPackage = attributes.getProperty("targetPackage");
/* 642:722 */     String targetProject = attributes.getProperty("targetProject");
/* 643:    */     
/* 644:724 */     jspGeneratorConfiguration.setConfigurationType(type);
/* 645:725 */     jspGeneratorConfiguration.setTargetPackage(targetPackage);
/* 646:726 */     jspGeneratorConfiguration.setTargetProject(targetProject);
/* 647:    */     
/* 648:728 */     NodeList nodeList = node.getChildNodes();
/* 649:729 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 650:    */     {
/* 651:730 */       Node childNode = nodeList.item(i);
/* 652:732 */       if (childNode.getNodeType() == 1) {
/* 653:736 */         if ("property".equals(childNode.getNodeName())) {
/* 654:737 */           parseProperty(jspGeneratorConfiguration, childNode);
/* 655:    */         }
/* 656:    */       }
/* 657:    */     }
/* 658:    */   }
/* 659:    */   
/* 660:    */   private void parseJdbcConnection(AbatorContext abatorContext, Node node)
/* 661:    */   {
/* 662:743 */     JDBCConnectionConfiguration jdbcConnectionConfiguration = new JDBCConnectionConfiguration();
/* 663:    */     
/* 664:745 */     abatorContext.setJdbcConnectionConfiguration(jdbcConnectionConfiguration);
/* 665:    */     
/* 666:747 */     Properties attributes = parseAttributes(node);
/* 667:748 */     String driverClass = attributes.getProperty("driverClass");
/* 668:749 */     String connectionURL = attributes.getProperty("connectionURL");
/* 669:750 */     String userId = attributes.getProperty("userId");
/* 670:751 */     String password = attributes.getProperty("password");
/* 671:    */     
/* 672:753 */     jdbcConnectionConfiguration.setDriverClass(driverClass);
/* 673:754 */     jdbcConnectionConfiguration.setConnectionURL(connectionURL);
/* 674:756 */     if (StringUtility.stringHasValue(userId)) {
/* 675:757 */       jdbcConnectionConfiguration.setUserId(userId);
/* 676:    */     }
/* 677:760 */     if (StringUtility.stringHasValue(password)) {
/* 678:761 */       jdbcConnectionConfiguration.setPassword(password);
/* 679:    */     }
/* 680:764 */     NodeList nodeList = node.getChildNodes();
/* 681:765 */     for (int i = 0; i < nodeList.getLength(); i++)
/* 682:    */     {
/* 683:766 */       Node childNode = nodeList.item(i);
/* 684:768 */       if (childNode.getNodeType() == 1) {
/* 685:772 */         if ("classPathEntry".equals(childNode.getNodeName())) {
/* 686:773 */           parseClassPathEntry(jdbcConnectionConfiguration, childNode);
/* 687:775 */         } else if ("property".equals(childNode.getNodeName())) {
/* 688:776 */           parseProperty(jdbcConnectionConfiguration, childNode);
/* 689:    */         }
/* 690:    */       }
/* 691:    */     }
/* 692:    */   }
/* 693:    */   
/* 694:    */   private void parseClassPathEntry(JDBCConnectionConfiguration jdbcConnectionConfiguration, Node node)
/* 695:    */   {
/* 696:782 */     Properties attributes = parseAttributes(node);
/* 697:    */     
/* 698:784 */     jdbcConnectionConfiguration.addClasspathEntry(attributes.getProperty("location"));
/* 699:    */   }
/* 700:    */   
/* 701:    */   private void parseProperty(PropertyHolder propertyHolder, Node node)
/* 702:    */   {
/* 703:788 */     Properties attributes = parseAttributes(node);
/* 704:    */     
/* 705:790 */     String name = attributes.getProperty("name");
/* 706:791 */     String value = attributes.getProperty("value");
/* 707:792 */     if (!StringUtility.stringHasValue(value))
/* 708:    */     {
/* 709:793 */       NodeList nodeList = node.getChildNodes();
/* 710:794 */       for (int i = 0; i < nodeList.getLength(); i++)
/* 711:    */       {
/* 712:795 */         Node childNode = nodeList.item(i);
/* 713:797 */         if (childNode.getNodeType() == 1) {
/* 714:800 */           if ("value".equals(childNode.getNodeName()))
/* 715:    */           {
/* 716:801 */             value = childNode.getTextContent();
/* 717:    */             
/* 718:803 */             break;
/* 719:    */           }
/* 720:    */         }
/* 721:    */       }
/* 722:    */     }
/* 723:807 */     propertyHolder.addProperty(name, value);
/* 724:    */   }
/* 725:    */   
/* 726:    */   private Properties parseAttributes(Node node)
/* 727:    */   {
/* 728:811 */     Properties attributes = new Properties();
/* 729:812 */     NamedNodeMap nnm = node.getAttributes();
/* 730:813 */     for (int i = 0; i < nnm.getLength(); i++)
/* 731:    */     {
/* 732:814 */       Node attribute = nnm.item(i);
/* 733:815 */       String value = parsePropertyTokens(attribute.getNodeValue());
/* 734:816 */       attributes.put(attribute.getNodeName(), value);
/* 735:    */     }
/* 736:819 */     return attributes;
/* 737:    */   }
/* 738:    */   
/* 739:    */   private String parsePropertyTokens(String string)
/* 740:    */   {
/* 741:823 */     String OPEN = "${";
/* 742:824 */     String CLOSE = "}";
/* 743:    */     
/* 744:826 */     String newString = string;
/* 745:827 */     if (newString != null)
/* 746:    */     {
/* 747:828 */       int start = newString.indexOf("${");
/* 748:829 */       int end = newString.indexOf("}");
/* 749:831 */       while ((start > -1) && (end > start))
/* 750:    */       {
/* 751:832 */         String prepend = newString.substring(0, start);
/* 752:833 */         String append = newString.substring(end + "}".length());
/* 753:834 */         String propName = newString.substring(start + "${".length(), end);
/* 754:835 */         String propValue = this.properties.getProperty(propName);
/* 755:836 */         if (propValue == null) {
/* 756:837 */           newString = prepend + propName + append;
/* 757:    */         } else {
/* 758:840 */           newString = prepend + propValue + append;
/* 759:    */         }
/* 760:843 */         start = newString.indexOf("${");
/* 761:844 */         end = newString.indexOf("}");
/* 762:    */       }
/* 763:    */     }
/* 764:848 */     return newString;
/* 765:    */   }
/* 766:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.xml.AbatorConfigurationParser
 * JD-Core Version:    0.7.0.1
 */