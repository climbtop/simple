/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Iterator;
/*  5:   */ import java.util.List;
/*  6:   */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  7:   */ import org.apache.ibatis.abator.exception.InvalidConfigurationException;
/*  8:   */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  9:   */ 
/* 10:   */ public class AbatorConfiguration
/* 11:   */ {
/* 12:   */   private List<AbatorContext> abatorContexts;
/* 13:   */   
/* 14:   */   public AbatorConfiguration()
/* 15:   */   {
/* 16:36 */     this.abatorContexts = new ArrayList();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void validate()
/* 20:   */     throws InvalidConfigurationException
/* 21:   */   {
/* 22:47 */     List errors = new ArrayList();
/* 23:49 */     if (this.abatorContexts.size() == 0)
/* 24:   */     {
/* 25:50 */       errors.add(Messages.getString("ValidationError.11"));
/* 26:   */     }
/* 27:   */     else
/* 28:   */     {
/* 29:52 */       Iterator iter = this.abatorContexts.iterator();
/* 30:53 */       while (iter.hasNext())
/* 31:   */       {
/* 32:54 */         AbatorContext abatorContext = (AbatorContext)iter.next();
/* 33:55 */         abatorContext.validate(errors);
/* 34:   */       }
/* 35:   */     }
/* 36:59 */     if (errors.size() > 0) {
/* 37:60 */       throw new InvalidConfigurationException(errors);
/* 38:   */     }
/* 39:   */   }
/* 40:   */   
/* 41:   */   public List getAbatorContexts()
/* 42:   */   {
/* 43:65 */     return this.abatorContexts;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void addAbatorContext(AbatorContext abatorContext)
/* 47:   */   {
/* 48:69 */     this.abatorContexts.add(abatorContext);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public XmlElement toXml()
/* 52:   */   {
/* 53:73 */     XmlElement answer = new XmlElement("abatorConfiguration");
/* 54:74 */     for (AbatorContext context : this.abatorContexts) {
/* 55:75 */       answer.addElement(context.toXml());
/* 56:   */     }
/* 57:76 */     return answer;
/* 58:   */   }
/* 59:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.AbatorConfiguration
 * JD-Core Version:    0.7.0.1
 */