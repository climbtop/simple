/*   1:    */ package org.apache.ibatis.abator.config;
/*   2:    */ 
/*   3:    */ public class ColumnOverride
/*   4:    */ {
/*   5:    */   private String columnName;
/*   6:    */   private String javaProperty;
/*   7:    */   private String jdbcType;
/*   8:    */   private String javaType;
/*   9:    */   private String typeHandler;
/*  10:    */   private String memo;
/*  11: 36 */   private boolean listable = true;
/*  12: 38 */   private boolean queryable = true;
/*  13: 40 */   private boolean mainFk = false;
/*  14:    */   private String label;
/*  15: 44 */   private String htmlEditor = "text";
/*  16:    */   private String optionValue;
/*  17:    */   private String validator;
/*  18:    */   private String defaultValue;
/*  19:    */   
/*  20:    */   public String getColumnName()
/*  21:    */   {
/*  22: 60 */     return this.columnName;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void setColumnName(String columnName)
/*  26:    */   {
/*  27: 64 */     this.columnName = columnName;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public String getJavaProperty()
/*  31:    */   {
/*  32: 68 */     return this.javaProperty;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setJavaProperty(String javaProperty)
/*  36:    */   {
/*  37: 72 */     this.javaProperty = javaProperty;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String getJavaType()
/*  41:    */   {
/*  42: 76 */     return this.javaType;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setJavaType(String javaType)
/*  46:    */   {
/*  47: 80 */     this.javaType = javaType;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getJdbcType()
/*  51:    */   {
/*  52: 84 */     return this.jdbcType;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setJdbcType(String jdbcType)
/*  56:    */   {
/*  57: 88 */     this.jdbcType = jdbcType;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getTypeHandler()
/*  61:    */   {
/*  62: 92 */     return this.typeHandler;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setTypeHandler(String typeHandler)
/*  66:    */   {
/*  67: 96 */     this.typeHandler = typeHandler;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String getMemo()
/*  71:    */   {
/*  72:103 */     return this.memo;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setMemo(String memo)
/*  76:    */   {
/*  77:110 */     this.memo = memo;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isListable()
/*  81:    */   {
/*  82:117 */     return this.listable;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setListable(boolean listable)
/*  86:    */   {
/*  87:124 */     this.listable = listable;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean isQueryable()
/*  91:    */   {
/*  92:131 */     return this.queryable;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setQueryable(boolean queryable)
/*  96:    */   {
/*  97:138 */     this.queryable = queryable;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isMainFk()
/* 101:    */   {
/* 102:142 */     return this.mainFk;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setMainFk(boolean mainFk)
/* 106:    */   {
/* 107:146 */     this.mainFk = mainFk;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getLabel()
/* 111:    */   {
/* 112:153 */     return this.label;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setLabel(String label)
/* 116:    */   {
/* 117:160 */     this.label = label;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public String getHtmlEditor()
/* 121:    */   {
/* 122:167 */     return this.htmlEditor;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setHtmlEditor(String htmlEditor)
/* 126:    */   {
/* 127:174 */     this.htmlEditor = htmlEditor;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public String getOptionValue()
/* 131:    */   {
/* 132:181 */     return this.optionValue;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setOptionValue(String optionValue)
/* 136:    */   {
/* 137:188 */     this.optionValue = optionValue;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String getValidator()
/* 141:    */   {
/* 142:195 */     return this.validator;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setValidator(String validator)
/* 146:    */   {
/* 147:202 */     this.validator = validator;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public String getDefaultValue()
/* 151:    */   {
/* 152:209 */     return this.defaultValue;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setDefaultValue(String defaultValue)
/* 156:    */   {
/* 157:216 */     this.defaultValue = defaultValue;
/* 158:    */   }
/* 159:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.ColumnOverride
 * JD-Core Version:    0.7.0.1
 */