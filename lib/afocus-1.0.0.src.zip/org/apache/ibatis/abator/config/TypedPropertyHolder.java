/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*  4:   */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  5:   */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  6:   */ 
/*  7:   */ public abstract class TypedPropertyHolder
/*  8:   */   extends PropertyHolder
/*  9:   */ {
/* 10:   */   private String targetPackage;
/* 11:   */   private String targetProject;
/* 12:   */   private String tagName;
/* 13:   */   private String configurationType;
/* 14:   */   
/* 15:   */   protected TypedPropertyHolder(String tagName)
/* 16:   */   {
/* 17:40 */     this.tagName = tagName;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getConfigurationType()
/* 21:   */   {
/* 22:44 */     return this.configurationType;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getTargetProject()
/* 26:   */   {
/* 27:48 */     return this.targetProject;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setTargetProject(String targetProject)
/* 31:   */   {
/* 32:52 */     this.targetProject = targetProject;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getTargetPackage()
/* 36:   */   {
/* 37:56 */     return this.targetPackage;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setTargetPackage(String targetPackage)
/* 41:   */   {
/* 42:60 */     this.targetPackage = targetPackage;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setConfigurationType(String configurationType)
/* 46:   */   {
/* 47:70 */     if (!"DEFAULT".equalsIgnoreCase(configurationType)) {
/* 48:71 */       this.configurationType = configurationType;
/* 49:   */     }
/* 50:   */   }
/* 51:   */   
/* 52:   */   public XmlElement toXml()
/* 53:   */   {
/* 54:76 */     XmlElement answer = new XmlElement(this.tagName);
/* 55:77 */     if (StringUtility.stringHasValue(this.configurationType)) {
/* 56:78 */       answer.addAttribute(new Attribute("type", this.configurationType));
/* 57:   */     }
/* 58:79 */     if (StringUtility.stringHasValue(this.targetPackage)) {
/* 59:80 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/* 60:   */     }
/* 61:81 */     if (StringUtility.stringHasValue(this.targetProject)) {
/* 62:82 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/* 63:   */     }
/* 64:83 */     toXml(answer);
/* 65:84 */     return answer;
/* 66:   */   }
/* 67:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.TypedPropertyHolder
 * JD-Core Version:    0.7.0.1
 */