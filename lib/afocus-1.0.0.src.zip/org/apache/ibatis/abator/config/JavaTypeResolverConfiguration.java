/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ public class JavaTypeResolverConfiguration
/*  4:   */   extends TypedPropertyHolder
/*  5:   */ {
/*  6:   */   public JavaTypeResolverConfiguration()
/*  7:   */   {
/*  8:27 */     super("javaTypeResolver");
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.JavaTypeResolverConfiguration
 * JD-Core Version:    0.7.0.1
 */