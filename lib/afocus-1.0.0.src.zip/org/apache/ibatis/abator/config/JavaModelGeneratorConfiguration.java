/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ public class JavaModelGeneratorConfiguration
/*  4:   */   extends TypedPropertyHolder
/*  5:   */ {
/*  6:   */   public JavaModelGeneratorConfiguration()
/*  7:   */   {
/*  8:28 */     super("javaModelGenerator");
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.JavaModelGeneratorConfiguration
 * JD-Core Version:    0.7.0.1
 */