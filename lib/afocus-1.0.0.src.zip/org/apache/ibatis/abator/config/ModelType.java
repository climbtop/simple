/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  4:   */ 
/*  5:   */ public class ModelType
/*  6:   */ {
/*  7:   */   private String modelType;
/*  8:29 */   public static final ModelType HIERARCHICAL = new ModelType("hierarchical");
/*  9:30 */   public static final ModelType FLAT = new ModelType("flat");
/* 10:31 */   public static final ModelType CONDITIONAL = new ModelType("conditional");
/* 11:   */   
/* 12:   */   private ModelType(String modelType)
/* 13:   */   {
/* 14:38 */     this.modelType = modelType;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String getModelType()
/* 18:   */   {
/* 19:42 */     return this.modelType;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static ModelType getModelType(String type)
/* 23:   */   {
/* 24:46 */     if (HIERARCHICAL.getModelType().equalsIgnoreCase(type)) {
/* 25:47 */       return HIERARCHICAL;
/* 26:   */     }
/* 27:48 */     if (FLAT.getModelType().equalsIgnoreCase(type)) {
/* 28:49 */       return FLAT;
/* 29:   */     }
/* 30:50 */     if (CONDITIONAL.getModelType().equalsIgnoreCase(type)) {
/* 31:51 */       return CONDITIONAL;
/* 32:   */     }
/* 33:53 */     throw new RuntimeException(Messages.getString("RuntimeError.13", type));
/* 34:   */   }
/* 35:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.ModelType
 * JD-Core Version:    0.7.0.1
 */