/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorSimpleImpl;
/*  4:   */ import org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorLegacyImpl;
/*  5:   */ import org.apache.ibatis.abator.internal.types.JavaTypeResolverDefaultImpl;
/*  6:   */ 
/*  7:   */ public class SimpleGeneratorSet
/*  8:   */   extends LegacyGeneratorSet
/*  9:   */ {
/* 10:   */   public SimpleGeneratorSet()
/* 11:   */   {
/* 12:34 */     this.javaModelGeneratorType = JavaModelGeneratorSimpleImpl.class.getName();
/* 13:35 */     this.javaTypeResolverType = JavaTypeResolverDefaultImpl.class.getName();
/* 14:36 */     this.sqlMapGeneratorType = SqlMapGeneratorLegacyImpl.class.getName();
/* 15:   */   }
/* 16:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.SimpleGeneratorSet
 * JD-Core Version:    0.7.0.1
 */