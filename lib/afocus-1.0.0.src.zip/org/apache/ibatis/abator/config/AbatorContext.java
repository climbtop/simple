/*   1:    */ package org.apache.ibatis.abator.config;
/*   2:    */ 
/*   3:    */ import java.io.BufferedWriter;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.FileWriter;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.sql.Connection;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import org.apache.ibatis.abator.api.AopGenerator;
/*  15:    */ import org.apache.ibatis.abator.api.ControllerGenerator;
/*  16:    */ import org.apache.ibatis.abator.api.DAOGenerator;
/*  17:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  18:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  19:    */ import org.apache.ibatis.abator.api.JavaTypeResolver;
/*  20:    */ import org.apache.ibatis.abator.api.JspGenerator;
/*  21:    */ import org.apache.ibatis.abator.api.ProgressCallback;
/*  22:    */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*  23:    */ import org.apache.ibatis.abator.api.ShellCallback;
/*  24:    */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*  25:    */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*  26:    */ import org.apache.ibatis.abator.api.dom.xml.Document;
/*  27:    */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  28:    */ import org.apache.ibatis.abator.exception.InvalidConfigurationException;
/*  29:    */ import org.apache.ibatis.abator.internal.AbatorObjectFactory;
/*  30:    */ import org.apache.ibatis.abator.internal.NullProgressCallback;
/*  31:    */ import org.apache.ibatis.abator.internal.db.ConnectionFactory;
/*  32:    */ import org.apache.ibatis.abator.internal.db.DatabaseIntrospector;
/*  33:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  34:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  35:    */ 
/*  36:    */ public class AbatorContext
/*  37:    */   extends PropertyHolder
/*  38:    */ {
/*  39:    */   private String id;
/*  40:    */   private JDBCConnectionConfiguration jdbcConnectionConfiguration;
/*  41:    */   private SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration;
/*  42:    */   private JavaTypeResolverConfiguration javaTypeResolverConfiguration;
/*  43:    */   private JavaModelGeneratorConfiguration javaModelGeneratorConfiguration;
/*  44:    */   private DAOGeneratorConfiguration daoGeneratorConfiguration;
/*  45:    */   private ServiceGeneratorConfiguration serviceGeneratorConfiguration;
/*  46:    */   private AopGeneratorConfiguration aopGeneratorConfiguration;
/*  47:    */   private ControllerGeneratorConfiguration controllerGeneratorConfiguration;
/*  48:    */   private JspGeneratorConfiguration jspGeneratorConfiguration;
/*  49:    */   private ArrayList tableConfigurations;
/*  50:    */   private GeneratorSet generatorSet;
/*  51:    */   private String generatorSetType;
/*  52:    */   private ModelType defaultModelType;
/*  53:    */   private ShellCallback shellCallback;
/*  54:    */   
/*  55:    */   public ShellCallback getShellCallback()
/*  56:    */   {
/*  57: 90 */     return this.shellCallback;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void setShellCallback(ShellCallback shellCallback)
/*  61:    */   {
/*  62: 97 */     this.shellCallback = shellCallback;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public AbatorContext(String generatorSetType, ModelType defaultModelType)
/*  66:    */   {
/*  67:108 */     this.generatorSetType = generatorSetType;
/*  68:110 */     if (defaultModelType == null) {
/*  69:111 */       this.defaultModelType = ModelType.CONDITIONAL;
/*  70:    */     } else {
/*  71:114 */       this.defaultModelType = defaultModelType;
/*  72:    */     }
/*  73:117 */     if (generatorSetType == null) {
/*  74:118 */       this.generatorSet = new SimpleGeneratorSet();
/*  75:120 */     } else if ("Legacy".equalsIgnoreCase(generatorSetType)) {
/*  76:121 */       this.generatorSet = new LegacyGeneratorSet();
/*  77:123 */     } else if ("Java2".equalsIgnoreCase(generatorSetType)) {
/*  78:124 */       this.generatorSet = new Java2GeneratorSet();
/*  79:126 */     } else if ("Java5".equalsIgnoreCase(generatorSetType)) {
/*  80:127 */       this.generatorSet = new Java5GeneratorSet();
/*  81:    */     } else {
/*  82:130 */       this.generatorSet = ((GeneratorSet)AbatorObjectFactory.createObject(generatorSetType));
/*  83:    */     }
/*  84:133 */     this.tableConfigurations = new ArrayList();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void addTableConfiguration(TableConfiguration tc)
/*  88:    */   {
/*  89:137 */     this.tableConfigurations.add(tc);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public JDBCConnectionConfiguration getJdbcConnectionConfiguration()
/*  93:    */   {
/*  94:141 */     return this.jdbcConnectionConfiguration;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public DAOGeneratorConfiguration getDaoGeneratorConfiguration()
/*  98:    */   {
/*  99:145 */     return this.daoGeneratorConfiguration;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public JavaModelGeneratorConfiguration getJavaModelGeneratorConfiguration()
/* 103:    */   {
/* 104:149 */     return this.javaModelGeneratorConfiguration;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public JavaTypeResolverConfiguration getJavaTypeResolverConfiguration()
/* 108:    */   {
/* 109:153 */     return this.javaTypeResolverConfiguration;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public SqlMapGeneratorConfiguration getSqlMapGeneratorConfiguration()
/* 113:    */   {
/* 114:157 */     return this.sqlMapGeneratorConfiguration;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void validate(List errors)
/* 118:    */   {
/* 119:168 */     validateJdbcConnectionConfiguration(errors);
/* 120:170 */     if (this.javaModelGeneratorConfiguration == null)
/* 121:    */     {
/* 122:171 */       errors.add(Messages.getString("ValidationError.8"));
/* 123:    */     }
/* 124:    */     else
/* 125:    */     {
/* 126:174 */       if (!StringUtility.stringHasValue(this.javaModelGeneratorConfiguration.getTargetProject())) {
/* 127:175 */         errors.add(Messages.getString("ValidationError.0", this.id));
/* 128:    */       }
/* 129:178 */       if (!StringUtility.stringHasValue(this.javaModelGeneratorConfiguration.getTargetPackage())) {
/* 130:179 */         errors.add(Messages.getString("ValidationError.12", 
/* 131:180 */           "JavaModelGenerator", this.id));
/* 132:    */       }
/* 133:    */     }
/* 134:184 */     if (this.sqlMapGeneratorConfiguration == null)
/* 135:    */     {
/* 136:185 */       errors.add(Messages.getString("ValidationError.9"));
/* 137:    */     }
/* 138:    */     else
/* 139:    */     {
/* 140:188 */       if (!StringUtility.stringHasValue(this.sqlMapGeneratorConfiguration.getTargetProject())) {
/* 141:189 */         errors.add(Messages.getString("ValidationError.1", this.id));
/* 142:    */       }
/* 143:192 */       if (!StringUtility.stringHasValue(this.sqlMapGeneratorConfiguration.getTargetPackage())) {
/* 144:193 */         errors.add(Messages.getString("ValidationError.12", 
/* 145:194 */           "SQLMapGenerator", this.id));
/* 146:    */       }
/* 147:    */     }
/* 148:198 */     if (this.daoGeneratorConfiguration != null)
/* 149:    */     {
/* 150:199 */       if (!StringUtility.stringHasValue(this.daoGeneratorConfiguration.getTargetProject())) {
/* 151:200 */         errors.add(Messages.getString("ValidationError.2", "DAOGenerator", this.id));
/* 152:    */       }
/* 153:203 */       if (!StringUtility.stringHasValue(this.daoGeneratorConfiguration.getTargetPackage())) {
/* 154:204 */         errors.add(Messages.getString("ValidationError.12", 
/* 155:205 */           "DAOGenerator", this.id));
/* 156:    */       }
/* 157:    */     }
/* 158:209 */     if (this.serviceGeneratorConfiguration != null)
/* 159:    */     {
/* 160:210 */       if (!StringUtility.stringHasValue(this.serviceGeneratorConfiguration.getTargetProject())) {
/* 161:211 */         errors.add(Messages.getString("ValidationError.2", "ServiceGenerator", this.id));
/* 162:    */       }
/* 163:214 */       if (!StringUtility.stringHasValue(this.serviceGeneratorConfiguration.getTargetPackage())) {
/* 164:215 */         errors.add(Messages.getString("ValidationError.12", 
/* 165:216 */           "ServiceGenerator", this.id));
/* 166:    */       }
/* 167:    */     }
/* 168:220 */     if (this.aopGeneratorConfiguration != null)
/* 169:    */     {
/* 170:221 */       if (!StringUtility.stringHasValue(this.aopGeneratorConfiguration.getTargetProject())) {
/* 171:222 */         errors.add(Messages.getString("ValidationError.2", "AopGenerator", this.id));
/* 172:    */       }
/* 173:225 */       if (!StringUtility.stringHasValue(this.aopGeneratorConfiguration.getTargetPackage())) {
/* 174:226 */         errors.add(Messages.getString("ValidationError.12", 
/* 175:227 */           "AopGenerator", this.id));
/* 176:    */       }
/* 177:    */     }
/* 178:231 */     if (this.controllerGeneratorConfiguration != null)
/* 179:    */     {
/* 180:232 */       if (!StringUtility.stringHasValue(this.controllerGeneratorConfiguration.getTargetProject())) {
/* 181:233 */         errors.add(Messages.getString("ValidationError.2", "ControllerGenerator", this.id));
/* 182:    */       }
/* 183:236 */       if (!StringUtility.stringHasValue(this.controllerGeneratorConfiguration.getTargetPackage())) {
/* 184:237 */         errors.add(Messages.getString("ValidationError.12", 
/* 185:238 */           "ControllerGenerator", this.id));
/* 186:    */       }
/* 187:    */     }
/* 188:242 */     if (this.jspGeneratorConfiguration != null)
/* 189:    */     {
/* 190:243 */       if (!StringUtility.stringHasValue(this.jspGeneratorConfiguration.getTargetProject())) {
/* 191:244 */         errors.add(Messages.getString("ValidationError.2", "JspGenerator", this.id));
/* 192:    */       }
/* 193:247 */       if (!StringUtility.stringHasValue(this.jspGeneratorConfiguration.getTargetPackage())) {
/* 194:248 */         errors.add(Messages.getString("ValidationError.12", 
/* 195:249 */           "JspGenerator", this.id));
/* 196:    */       }
/* 197:    */     }
/* 198:253 */     if (this.tableConfigurations.size() == 0) {
/* 199:254 */       errors.add(Messages.getString("ValidationError.3"));
/* 200:    */     } else {
/* 201:257 */       for (int i = 0; i < this.tableConfigurations.size(); i++)
/* 202:    */       {
/* 203:258 */         TableConfiguration tc = (TableConfiguration)this.tableConfigurations.get(i);
/* 204:    */         
/* 205:260 */         validateTableConfiguration(tc, errors, i);
/* 206:    */       }
/* 207:    */     }
/* 208:    */   }
/* 209:    */   
/* 210:    */   private void validateJdbcConnectionConfiguration(List errors)
/* 211:    */   {
/* 212:266 */     if (this.jdbcConnectionConfiguration == null)
/* 213:    */     {
/* 214:267 */       errors.add(Messages.getString("ValidationError.10"));
/* 215:268 */       return;
/* 216:    */     }
/* 217:271 */     if (!StringUtility.stringHasValue(this.jdbcConnectionConfiguration.getDriverClass())) {
/* 218:272 */       errors.add(Messages.getString("ValidationError.4"));
/* 219:    */     }
/* 220:275 */     if (!StringUtility.stringHasValue(this.jdbcConnectionConfiguration.getConnectionURL())) {
/* 221:276 */       errors.add(Messages.getString("ValidationError.5"));
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   private void validateTableConfiguration(TableConfiguration tc, List errors, int listPosition)
/* 226:    */   {
/* 227:281 */     if (!StringUtility.stringHasValue(tc.getTableName())) {
/* 228:282 */       errors.add(Messages.getString("ValidationError.6", Integer.toString(listPosition)));
/* 229:    */     }
/* 230:285 */     if ((tc.getGeneratedKey() != null) && (!StringUtility.stringHasValue(tc.getGeneratedKey().getSqlStatement())))
/* 231:    */     {
/* 232:286 */       String tableName = StringUtility.composeFullyQualifiedTableName(tc.getCatalog(), tc.getSchema(), tc.getTableName());
/* 233:287 */       errors.add(Messages.getString("ValidationError.7", 
/* 234:288 */         tableName));
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   public void generateFiles(ProgressCallback callback, List generatedJavaFiles, List generatedXmlFiles, List generatedJspFiles, List warnings)
/* 239:    */     throws InvalidConfigurationException, SQLException, InterruptedException, IOException
/* 240:    */   {
/* 241:317 */     if (callback == null) {
/* 242:318 */       callback = new NullProgressCallback();
/* 243:    */     }
/* 244:321 */     JavaTypeResolver javaTypeResolver = AbatorObjectFactory.createJavaTypeResolver(this, warnings);
/* 245:322 */     JavaModelGenerator javaModelGenerator = AbatorObjectFactory.createJavaModelGenerator(this, warnings);
/* 246:323 */     SqlMapGenerator sqlMapGenerator = AbatorObjectFactory.createSqlMapGenerator(this, javaModelGenerator, warnings);
/* 247:324 */     DAOGenerator daoGenerator = AbatorObjectFactory.createDAOGenerator(this, javaModelGenerator, sqlMapGenerator, warnings);
/* 248:    */     
/* 249:326 */     ServiceGenerator serviceGenerator = null;
/* 250:327 */     if (daoGenerator != null) {
/* 251:328 */       serviceGenerator = AbatorObjectFactory.createServiceGenerator(this, javaModelGenerator, daoGenerator, warnings);
/* 252:    */     }
/* 253:330 */     AopGenerator aopGenerator = null;
/* 254:331 */     if (daoGenerator != null) {
/* 255:332 */       aopGenerator = AbatorObjectFactory.createAopGenerator(this, javaModelGenerator, daoGenerator, warnings);
/* 256:    */     }
/* 257:334 */     ControllerGenerator controllerGenerator = null;
/* 258:335 */     if (serviceGenerator != null) {
/* 259:336 */       controllerGenerator = AbatorObjectFactory.createControllerGenerator(this, javaModelGenerator, serviceGenerator, 
/* 260:337 */         warnings);
/* 261:    */     }
/* 262:339 */     JspGenerator jspGenerator = null;
/* 263:340 */     if (controllerGenerator != null) {
/* 264:341 */       jspGenerator = AbatorObjectFactory.createJspGenerator(this, this.shellCallback, javaModelGenerator, controllerGenerator, 
/* 265:342 */         warnings);
/* 266:    */     }
/* 267:345 */     boolean makeAbatorConfigFile = false;
/* 268:346 */     XmlElement contextXml = null;
/* 269:    */     
/* 270:348 */     String abatorConfigFileName = (String)this.sqlMapGeneratorConfiguration.getProperties().get("abatorConfigFile");
/* 271:349 */     if (StringUtility.stringHasValue(abatorConfigFileName))
/* 272:    */     {
/* 273:350 */       File abatorConfigFile = new File(abatorConfigFileName);
/* 274:351 */       if (!abatorConfigFile.exists())
/* 275:    */       {
/* 276:352 */         makeAbatorConfigFile = true;
/* 277:353 */         contextXml = toXml();
/* 278:    */       }
/* 279:    */     }
/* 280:357 */     Connection connection = null;
/* 281:    */     try
/* 282:    */     {
/* 283:359 */       callback.startSubTask(Messages.getString("Progress.0"));
/* 284:360 */       connection = getConnection();
/* 285:    */       
/* 286:362 */       Iterator iter = this.tableConfigurations.iterator();
/* 287:363 */       while (iter.hasNext())
/* 288:    */       {
/* 289:364 */         TableConfiguration tc = (TableConfiguration)iter.next();
/* 290:365 */         String tableName = 
/* 291:366 */           StringUtility.composeFullyQualifiedTableName(tc.getCatalog(), tc.getSchema(), tc.getTableName());
/* 292:368 */         if (!tc.areAnyStatementsEnabled())
/* 293:    */         {
/* 294:369 */           warnings.add(Messages.getString("Warning.0", tableName));
/* 295:    */         }
/* 296:    */         else
/* 297:    */         {
/* 298:374 */           callback.startSubTask(Messages.getString("Progress.1", tableName));
/* 299:    */           
/* 300:376 */           Collection introspectedTables = DatabaseIntrospector.introspectTables(connection, tc, javaTypeResolver, warnings);
/* 301:377 */           callback.checkCancel();
/* 302:    */           
/* 303:379 */           Iterator iter2 = introspectedTables.iterator();
/* 304:380 */           while (iter2.hasNext())
/* 305:    */           {
/* 306:381 */             callback.checkCancel();
/* 307:382 */             IntrospectedTable introspectedTable = (IntrospectedTable)iter2.next();
/* 308:384 */             if (makeAbatorConfigFile)
/* 309:    */             {
/* 310:385 */               contextXml.addElement(sqlMapGenerator.getAbatorTableConfigure(introspectedTable, tc));
/* 311:    */             }
/* 312:    */             else
/* 313:    */             {
/* 314:389 */               if (daoGenerator != null) {
/* 315:390 */                 generatedJavaFiles.addAll(daoGenerator.getGeneratedJavaFiles(introspectedTable, callback));
/* 316:    */               }
/* 317:392 */               if (serviceGenerator != null) {
/* 318:393 */                 generatedJavaFiles.addAll(serviceGenerator.getGeneratedJavaFiles(introspectedTable, callback));
/* 319:    */               }
/* 320:395 */               if ((aopGenerator != null) && (tableName.indexOf("_log") == -1)) {
/* 321:396 */                 generatedJavaFiles.addAll(aopGenerator.getGeneratedJavaFiles(introspectedTable, callback));
/* 322:    */               }
/* 323:398 */               if ((controllerGenerator != null) && (tableName.indexOf("_log") == -1)) {
/* 324:399 */                 generatedJavaFiles.addAll(controllerGenerator.getGeneratedJavaFiles(introspectedTable, callback));
/* 325:    */               }
/* 326:401 */               if ((jspGenerator != null) && (tableName.indexOf("_log") == -1)) {
/* 327:402 */                 generatedJspFiles.addAll(jspGenerator.getGeneratedJspFiles(introspectedTable, callback));
/* 328:    */               }
/* 329:404 */               generatedJavaFiles.addAll(javaModelGenerator.getGeneratedJavaFiles(introspectedTable, callback));
/* 330:405 */               generatedXmlFiles.addAll(sqlMapGenerator.getGeneratedXMLFiles(introspectedTable, callback));
/* 331:    */             }
/* 332:    */           }
/* 333:    */         }
/* 334:    */       }
/* 335:    */     }
/* 336:    */     finally
/* 337:    */     {
/* 338:410 */       closeConnection(connection);
/* 339:411 */       callback.finished();
/* 340:    */     }
/* 341:413 */     if (makeAbatorConfigFile) {
/* 342:414 */       generateAbatorConfig(abatorConfigFileName, contextXml);
/* 343:    */     }
/* 344:    */   }
/* 345:    */   
/* 346:    */   public int getTotalSteps()
/* 347:    */   {
/* 348:419 */     int steps = 0;
/* 349:    */     
/* 350:421 */     steps++;
/* 351:422 */     steps += this.tableConfigurations.size() * 8;
/* 352:    */     
/* 353:424 */     return steps;
/* 354:    */   }
/* 355:    */   
/* 356:    */   private Connection getConnection()
/* 357:    */     throws SQLException
/* 358:    */   {
/* 359:428 */     Connection connection = ConnectionFactory.getInstance().getConnection(this.jdbcConnectionConfiguration);
/* 360:    */     
/* 361:430 */     return connection;
/* 362:    */   }
/* 363:    */   
/* 364:    */   private void closeConnection(Connection connection)
/* 365:    */   {
/* 366:434 */     if (connection != null) {
/* 367:    */       try
/* 368:    */       {
/* 369:436 */         connection.close();
/* 370:    */       }
/* 371:    */       catch (SQLException localSQLException) {}
/* 372:    */     }
/* 373:    */   }
/* 374:    */   
/* 375:    */   public String getId()
/* 376:    */   {
/* 377:446 */     return this.id;
/* 378:    */   }
/* 379:    */   
/* 380:    */   public void setId(String id)
/* 381:    */   {
/* 382:450 */     this.id = id;
/* 383:    */   }
/* 384:    */   
/* 385:    */   public GeneratorSet getGeneratorSet()
/* 386:    */   {
/* 387:454 */     return this.generatorSet;
/* 388:    */   }
/* 389:    */   
/* 390:    */   public void setDaoGeneratorConfiguration(DAOGeneratorConfiguration daoGeneratorConfiguration)
/* 391:    */   {
/* 392:458 */     this.daoGeneratorConfiguration = daoGeneratorConfiguration;
/* 393:    */   }
/* 394:    */   
/* 395:    */   public void setJavaModelGeneratorConfiguration(JavaModelGeneratorConfiguration javaModelGeneratorConfiguration)
/* 396:    */   {
/* 397:462 */     this.javaModelGeneratorConfiguration = javaModelGeneratorConfiguration;
/* 398:    */   }
/* 399:    */   
/* 400:    */   public void setJavaTypeResolverConfiguration(JavaTypeResolverConfiguration javaTypeResolverConfiguration)
/* 401:    */   {
/* 402:466 */     this.javaTypeResolverConfiguration = javaTypeResolverConfiguration;
/* 403:    */   }
/* 404:    */   
/* 405:    */   public void setJdbcConnectionConfiguration(JDBCConnectionConfiguration jdbcConnectionConfiguration)
/* 406:    */   {
/* 407:470 */     this.jdbcConnectionConfiguration = jdbcConnectionConfiguration;
/* 408:    */   }
/* 409:    */   
/* 410:    */   public void setSqlMapGeneratorConfiguration(SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration)
/* 411:    */   {
/* 412:474 */     this.sqlMapGeneratorConfiguration = sqlMapGeneratorConfiguration;
/* 413:    */   }
/* 414:    */   
/* 415:    */   public ModelType getDefaultModelType()
/* 416:    */   {
/* 417:478 */     return this.defaultModelType;
/* 418:    */   }
/* 419:    */   
/* 420:    */   public AopGeneratorConfiguration getAopGeneratorConfiguration()
/* 421:    */   {
/* 422:482 */     return this.aopGeneratorConfiguration;
/* 423:    */   }
/* 424:    */   
/* 425:    */   public void setAopGeneratorConfiguration(AopGeneratorConfiguration aopGeneratorConfiguration)
/* 426:    */   {
/* 427:486 */     this.aopGeneratorConfiguration = aopGeneratorConfiguration;
/* 428:    */   }
/* 429:    */   
/* 430:    */   public ServiceGeneratorConfiguration getServiceGeneratorConfiguration()
/* 431:    */   {
/* 432:490 */     return this.serviceGeneratorConfiguration;
/* 433:    */   }
/* 434:    */   
/* 435:    */   public void setServiceGeneratorConfiguration(ServiceGeneratorConfiguration serviceGeneratorConfiguration)
/* 436:    */   {
/* 437:494 */     this.serviceGeneratorConfiguration = serviceGeneratorConfiguration;
/* 438:    */   }
/* 439:    */   
/* 440:    */   public ControllerGeneratorConfiguration getControllerGeneratorConfiguration()
/* 441:    */   {
/* 442:501 */     return this.controllerGeneratorConfiguration;
/* 443:    */   }
/* 444:    */   
/* 445:    */   public void setControllerGeneratorConfiguration(ControllerGeneratorConfiguration controllerGeneratorConfiguration)
/* 446:    */   {
/* 447:509 */     this.controllerGeneratorConfiguration = controllerGeneratorConfiguration;
/* 448:    */   }
/* 449:    */   
/* 450:    */   public JspGeneratorConfiguration getJspGeneratorConfiguration()
/* 451:    */   {
/* 452:516 */     return this.jspGeneratorConfiguration;
/* 453:    */   }
/* 454:    */   
/* 455:    */   public void setJspGeneratorConfiguration(JspGeneratorConfiguration jspGeneratorConfiguration)
/* 456:    */   {
/* 457:523 */     this.jspGeneratorConfiguration = jspGeneratorConfiguration;
/* 458:    */   }
/* 459:    */   
/* 460:    */   public XmlElement toXml()
/* 461:    */   {
/* 462:527 */     XmlElement answer = new XmlElement("abatorContext");
/* 463:528 */     if (StringUtility.stringHasValue(this.id)) {
/* 464:529 */       answer.addAttribute(new Attribute("id", this.id));
/* 465:    */     }
/* 466:530 */     if (StringUtility.stringHasValue(this.generatorSetType)) {
/* 467:531 */       answer.addAttribute(new Attribute("generatorSet", this.generatorSetType));
/* 468:    */     }
/* 469:532 */     if (this.defaultModelType != null) {
/* 470:533 */       answer.addAttribute(new Attribute("defaultModelType", this.defaultModelType.getModelType()));
/* 471:    */     }
/* 472:535 */     if (this.jdbcConnectionConfiguration != null) {
/* 473:536 */       answer.addElement(this.jdbcConnectionConfiguration.toXml());
/* 474:    */     }
/* 475:537 */     if (this.javaTypeResolverConfiguration != null) {
/* 476:538 */       answer.addElement(this.javaTypeResolverConfiguration.toXml());
/* 477:    */     }
/* 478:539 */     if (this.javaModelGeneratorConfiguration != null) {
/* 479:540 */       answer.addElement(this.javaModelGeneratorConfiguration.toXml());
/* 480:    */     }
/* 481:541 */     if (this.sqlMapGeneratorConfiguration != null) {
/* 482:542 */       answer.addElement(this.sqlMapGeneratorConfiguration.toXml());
/* 483:    */     }
/* 484:543 */     if (this.daoGeneratorConfiguration != null) {
/* 485:544 */       answer.addElement(this.daoGeneratorConfiguration.toXml());
/* 486:    */     }
/* 487:545 */     if (this.serviceGeneratorConfiguration != null) {
/* 488:546 */       answer.addElement(this.serviceGeneratorConfiguration.toXml());
/* 489:    */     }
/* 490:547 */     if (this.aopGeneratorConfiguration != null) {
/* 491:548 */       answer.addElement(this.aopGeneratorConfiguration.toXml());
/* 492:    */     }
/* 493:549 */     if (this.controllerGeneratorConfiguration != null) {
/* 494:550 */       answer.addElement(this.controllerGeneratorConfiguration.toXml());
/* 495:    */     }
/* 496:551 */     if (this.jspGeneratorConfiguration != null) {
/* 497:552 */       answer.addElement(this.jspGeneratorConfiguration.toXml());
/* 498:    */     }
/* 499:554 */     toXml(answer);
/* 500:555 */     return answer;
/* 501:    */   }
/* 502:    */   
/* 503:    */   private static void generateAbatorConfig(String fileName, XmlElement context)
/* 504:    */     throws IOException
/* 505:    */   {
/* 506:559 */     Document document = new Document("-//Apache Software Foundation//DTD Abator for iBATIS Configuration 1.0//EN", "http://abator.com/dtd/abator-config_1_0.dtd");
/* 507:560 */     XmlElement root = new XmlElement("abatorConfiguration");
/* 508:561 */     root.addElement(context);
/* 509:562 */     document.setRootElement(root);
/* 510:563 */     BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, false));
/* 511:564 */     bw.write(document.getFormattedContent("GBK"));
/* 512:565 */     bw.close();
/* 513:    */   }
/* 514:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.AbatorContext
 * JD-Core Version:    0.7.0.1
 */