/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.internal.java.dao.GenericCIJava5DAOGenerator;
/*  4:   */ import org.apache.ibatis.abator.internal.java.dao.GenericSIJava5DAOGenerator;
/*  5:   */ import org.apache.ibatis.abator.internal.java.dao.IbatisJava5DAOGenerator;
/*  6:   */ import org.apache.ibatis.abator.internal.java.dao.SpringAbatorJava5DAOGenerator;
/*  7:   */ import org.apache.ibatis.abator.internal.java.dao.SpringJava5DAOGenerator;
/*  8:   */ import org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorSimpleImpl;
/*  9:   */ import org.apache.ibatis.abator.internal.java.service.BaseServiceGenerator;
/* 10:   */ import org.apache.ibatis.abator.internal.java.service.SpringAbatorJava5ServiceGenerator;
/* 11:   */ import org.apache.ibatis.abator.internal.java.service.SpringAbatorVportalServiceGenerator;
/* 12:   */ import org.apache.ibatis.abator.internal.java.service.SpringE2xpertServiceGenerator;
/* 13:   */ import org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorJava5Impl;
/* 14:   */ import org.apache.ibatis.abator.internal.types.JavaTypeResolverDefaultImpl;
/* 15:   */ 
/* 16:   */ public class Java5GeneratorSet
/* 17:   */   extends GeneratorSet
/* 18:   */ {
/* 19:   */   public Java5GeneratorSet()
/* 20:   */   {
/* 21:46 */     this.javaModelGeneratorType = JavaModelGeneratorSimpleImpl.class.getName();
/* 22:47 */     this.javaTypeResolverType = JavaTypeResolverDefaultImpl.class.getName();
/* 23:48 */     this.sqlMapGeneratorType = SqlMapGeneratorJava5Impl.class.getName();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String translateDAOGeneratorType(String configurationType)
/* 27:   */   {
/* 28:52 */     String answer = null;
/* 29:54 */     if ("IBATIS".equalsIgnoreCase(configurationType)) {
/* 30:55 */       answer = IbatisJava5DAOGenerator.class.getName();
/* 31:56 */     } else if ("SPRING".equalsIgnoreCase(configurationType)) {
/* 32:57 */       answer = SpringJava5DAOGenerator.class.getName();
/* 33:58 */     } else if ("GENERIC-CI".equalsIgnoreCase(configurationType)) {
/* 34:59 */       answer = GenericCIJava5DAOGenerator.class.getName();
/* 35:60 */     } else if ("GENERIC-SI".equalsIgnoreCase(configurationType)) {
/* 36:61 */       answer = GenericSIJava5DAOGenerator.class.getName();
/* 37:62 */     } else if (!"E2XPERT".equalsIgnoreCase(configurationType)) {
/* 38:66 */       if ("BUILD".equalsIgnoreCase(configurationType)) {
/* 39:67 */         answer = SpringAbatorJava5DAOGenerator.class.getName();
/* 40:   */       } else {
/* 41:69 */         answer = configurationType;
/* 42:   */       }
/* 43:   */     }
/* 44:72 */     return answer;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public String translateServiceGeneratorType(String configurationType)
/* 48:   */   {
/* 49:   */     String answer;
/* 50:   */     String answer;
/* 51:78 */     if ("BASE".equalsIgnoreCase(configurationType))
/* 52:   */     {
/* 53:79 */       answer = BaseServiceGenerator.class.getName();
/* 54:   */     }
/* 55:   */     else
/* 56:   */     {
/* 57:   */       String answer;
/* 58:80 */       if ("BUILDVPORTAL".equalsIgnoreCase(configurationType))
/* 59:   */       {
/* 60:81 */         answer = SpringAbatorVportalServiceGenerator.class.getName();
/* 61:   */       }
/* 62:   */       else
/* 63:   */       {
/* 64:   */         String answer;
/* 65:82 */         if ("BUILD".equalsIgnoreCase(configurationType))
/* 66:   */         {
/* 67:83 */           answer = SpringAbatorJava5ServiceGenerator.class.getName();
/* 68:   */         }
/* 69:   */         else
/* 70:   */         {
/* 71:   */           String answer;
/* 72:84 */           if ("E2XPERT".equalsIgnoreCase(configurationType)) {
/* 73:85 */             answer = SpringE2xpertServiceGenerator.class.getName();
/* 74:   */           } else {
/* 75:87 */             answer = configurationType;
/* 76:   */           }
/* 77:   */         }
/* 78:   */       }
/* 79:   */     }
/* 80:90 */     return answer;
/* 81:   */   }
/* 82:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.Java5GeneratorSet
 * JD-Core Version:    0.7.0.1
 */