/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import java.util.LinkedHashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*  7:   */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  8:   */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  9:   */ 
/* 10:   */ public abstract class PropertyHolder
/* 11:   */ {
/* 12:   */   private Map<String, String> properties;
/* 13:   */   
/* 14:   */   public PropertyHolder()
/* 15:   */   {
/* 16:36 */     this.properties = new LinkedHashMap();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void addProperty(String name, String value)
/* 20:   */   {
/* 21:40 */     this.properties.put(name, value);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Map getProperties()
/* 25:   */   {
/* 26:44 */     return this.properties;
/* 27:   */   }
/* 28:   */   
/* 29:   */   protected XmlElement toXml(XmlElement parent)
/* 30:   */   {
/* 31:48 */     if (parent == null) {
/* 32:49 */       return parent;
/* 33:   */     }
/* 34:51 */     for (Map.Entry<String, String> entry : this.properties.entrySet())
/* 35:   */     {
/* 36:52 */       XmlElement element = new XmlElement("property");
/* 37:53 */       element.addAttribute(new Attribute("name", (String)entry.getKey()));
/* 38:54 */       if (StringUtility.stringHasValue((String)entry.getValue())) {
/* 39:55 */         if ((((String)entry.getValue()).indexOf('>') > -1) || (((String)entry.getValue()).indexOf('<') > -1) || 
/* 40:56 */           (((String)entry.getValue()).indexOf('&') > -1) || (((String)entry.getValue()).indexOf('\'') > -1) || 
/* 41:57 */           (((String)entry.getValue()).indexOf('"') > -1) || (((String)entry.getValue()).indexOf('\n') > -1) || 
/* 42:58 */           (((String)entry.getValue()).indexOf('\r') > -1))
/* 43:   */         {
/* 44:59 */           XmlElement value = new XmlElement("value", (String)entry.getValue());
/* 45:60 */           element.addElement(value);
/* 46:   */         }
/* 47:   */         else
/* 48:   */         {
/* 49:63 */           element.addAttribute(new Attribute("value", (String)entry.getValue()));
/* 50:   */         }
/* 51:   */       }
/* 52:67 */       parent.addElement(element);
/* 53:   */     }
/* 54:69 */     return parent;
/* 55:   */   }
/* 56:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.PropertyHolder
 * JD-Core Version:    0.7.0.1
 */