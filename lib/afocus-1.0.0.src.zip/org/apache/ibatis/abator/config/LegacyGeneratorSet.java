/*  1:   */ package org.apache.ibatis.abator.config;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.internal.java.dao.GenericCILegacyDAOGenerator;
/*  4:   */ import org.apache.ibatis.abator.internal.java.dao.GenericSILegacyDAOGenerator;
/*  5:   */ import org.apache.ibatis.abator.internal.java.dao.IbatisLegacyDAOGenerator;
/*  6:   */ import org.apache.ibatis.abator.internal.java.dao.SpringAbatorLegacyDAOGenerator;
/*  7:   */ import org.apache.ibatis.abator.internal.java.dao.SpringE2xpertLegacyDAOGenerator;
/*  8:   */ import org.apache.ibatis.abator.internal.java.dao.SpringLegacyDAOGenerator;
/*  9:   */ import org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorLegacyImpl;
/* 10:   */ import org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorLegacyImpl;
/* 11:   */ import org.apache.ibatis.abator.internal.types.JavaTypeResolverDefaultImpl;
/* 12:   */ 
/* 13:   */ public class LegacyGeneratorSet
/* 14:   */   extends GeneratorSet
/* 15:   */ {
/* 16:   */   public LegacyGeneratorSet()
/* 17:   */   {
/* 18:41 */     this.javaModelGeneratorType = JavaModelGeneratorLegacyImpl.class.getName();
/* 19:42 */     this.javaTypeResolverType = JavaTypeResolverDefaultImpl.class.getName();
/* 20:43 */     this.sqlMapGeneratorType = SqlMapGeneratorLegacyImpl.class.getName();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String translateDAOGeneratorType(String configurationType)
/* 24:   */   {
/* 25:   */     String answer;
/* 26:   */     String answer;
/* 27:49 */     if ("IBATIS".equalsIgnoreCase(configurationType))
/* 28:   */     {
/* 29:50 */       answer = IbatisLegacyDAOGenerator.class.getName();
/* 30:   */     }
/* 31:   */     else
/* 32:   */     {
/* 33:   */       String answer;
/* 34:51 */       if ("SPRING".equalsIgnoreCase(configurationType))
/* 35:   */       {
/* 36:52 */         answer = SpringLegacyDAOGenerator.class.getName();
/* 37:   */       }
/* 38:   */       else
/* 39:   */       {
/* 40:   */         String answer;
/* 41:53 */         if ("GENERIC-CI".equalsIgnoreCase(configurationType))
/* 42:   */         {
/* 43:54 */           answer = GenericCILegacyDAOGenerator.class.getName();
/* 44:   */         }
/* 45:   */         else
/* 46:   */         {
/* 47:   */           String answer;
/* 48:55 */           if ("GENERIC-SI".equalsIgnoreCase(configurationType))
/* 49:   */           {
/* 50:56 */             answer = GenericSILegacyDAOGenerator.class.getName();
/* 51:   */           }
/* 52:   */           else
/* 53:   */           {
/* 54:   */             String answer;
/* 55:57 */             if ("E2XPERT".equalsIgnoreCase(configurationType))
/* 56:   */             {
/* 57:58 */               answer = SpringE2xpertLegacyDAOGenerator.class.getName();
/* 58:   */             }
/* 59:   */             else
/* 60:   */             {
/* 61:   */               String answer;
/* 62:61 */               if ("BUILD".equalsIgnoreCase(configurationType)) {
/* 63:62 */                 answer = SpringAbatorLegacyDAOGenerator.class.getName();
/* 64:   */               } else {
/* 65:64 */                 answer = configurationType;
/* 66:   */               }
/* 67:   */             }
/* 68:   */           }
/* 69:   */         }
/* 70:   */       }
/* 71:   */     }
/* 72:67 */     return answer;
/* 73:   */   }
/* 74:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.LegacyGeneratorSet
 * JD-Core Version:    0.7.0.1
 */