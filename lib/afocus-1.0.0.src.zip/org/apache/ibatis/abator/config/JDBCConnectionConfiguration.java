/*   1:    */ package org.apache.ibatis.abator.config;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*   6:    */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*   7:    */ 
/*   8:    */ public class JDBCConnectionConfiguration
/*   9:    */   extends PropertyHolder
/*  10:    */ {
/*  11:    */   private String driverClass;
/*  12:    */   private String connectionURL;
/*  13:    */   private String userId;
/*  14:    */   private String password;
/*  15:    */   private List<String> classPathEntries;
/*  16:    */   
/*  17:    */   public JDBCConnectionConfiguration()
/*  18:    */   {
/*  19: 42 */     this.classPathEntries = new ArrayList();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public String getConnectionURL()
/*  23:    */   {
/*  24: 46 */     return this.connectionURL;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setConnectionURL(String connectionURL)
/*  28:    */   {
/*  29: 50 */     this.connectionURL = connectionURL;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getPassword()
/*  33:    */   {
/*  34: 54 */     return this.password;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setPassword(String password)
/*  38:    */   {
/*  39: 58 */     this.password = password;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public String getUserId()
/*  43:    */   {
/*  44: 62 */     return this.userId;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setUserId(String userId)
/*  48:    */   {
/*  49: 66 */     this.userId = userId;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void addClasspathEntry(String entry)
/*  53:    */   {
/*  54: 70 */     this.classPathEntries.add(entry);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public List getClassPathEntries()
/*  58:    */   {
/*  59: 77 */     return this.classPathEntries;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public String getDriverClass()
/*  63:    */   {
/*  64: 81 */     return this.driverClass;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setDriverClass(String driverClass)
/*  68:    */   {
/*  69: 85 */     this.driverClass = driverClass;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public XmlElement toXml()
/*  73:    */   {
/*  74: 89 */     XmlElement answer = new XmlElement("jdbcConnection");
/*  75: 90 */     answer.addAttribute(new Attribute("driverClass", this.driverClass));
/*  76: 91 */     answer.addAttribute(new Attribute("connectionURL", this.connectionURL));
/*  77: 92 */     answer.addAttribute(new Attribute("userId", this.userId));
/*  78: 93 */     answer.addAttribute(new Attribute("password", this.password));
/*  79: 94 */     for (String classPathEntry : this.classPathEntries)
/*  80:    */     {
/*  81: 95 */       XmlElement element = new XmlElement("classPathEntry");
/*  82: 96 */       element.addAttribute(new Attribute("location", classPathEntry));
/*  83: 97 */       answer.addElement(element);
/*  84:    */     }
/*  85: 99 */     toXml(answer);
/*  86:100 */     return answer;
/*  87:    */   }
/*  88:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.config.JDBCConnectionConfiguration
 * JD-Core Version:    0.7.0.1
 */