/*   1:    */ 
/*   2:    */ 
/*   3:    */ java.io.File
/*   4:    */ java.io.IOException
/*   5:    */ java.sql.SQLException
/*   6:    */ java.util.ArrayList
/*   7:    */ java.util.Arrays
/*   8:    */ java.util.Iterator
/*   9:    */ java.util.List
/*  10:    */ java.util.Properties
/*  11:    */ org.apache.ibatis.abator.api.Abator
/*  12:    */ org.apache.ibatis.abator.config.AbatorConfiguration
/*  13:    */ org.apache.ibatis.abator.config.xml.AbatorConfigurationParser
/*  14:    */ org.apache.ibatis.abator.exception.InvalidConfigurationException
/*  15:    */ org.apache.ibatis.abator.exception.XMLParserException
/*  16:    */ org.apache.ibatis.abator.internal.DefaultShellCallback
/*  17:    */ org.apache.ibatis.abator.internal.util.StringUtility
/*  18:    */ org.apache.ibatis.abator.internal.util.messages.Messages
/*  19:    */ org.apache.tools.ant.BuildException
/*  20:    */ org.apache.tools.ant.Task
/*  21:    */ org.apache.tools.ant.types.PropertySet
/*  22:    */ 
/*  23:    */ AbatorAntTask
/*  24:    */   
/*  25:    */ 
/*  26:    */   configfile
/*  27:    */   overwrite
/*  28:    */   propertyset
/*  29:    */   verbose
/*  30:    */   
/*  31:    */   execute
/*  32:    */     
/*  33:    */   
/*  34: 80 */      (stringHasValueconfigfile)) {
/*  35: 81 */       throw new BuildException(Messages.getString("RuntimeError.0"));
/*  36:    */     }
/*  37: 84 */     List warnings = new ArrayList();
/*  38:    */     
/*  39: 86 */     File configurationFile = new File(this.configfile);
/*  40: 87 */     if (!configurationFile.exists()) {
/*  41: 88 */       throw new BuildException(Messages.getString("RuntimeError.1", this.configfile));
/*  42:    */     }
/*  43:    */     try
/*  44:    */     {
/*  45: 92 */       Properties p = this.propertyset == null ? null : this.propertyset.getProperties();
/*  46:    */       
/*  47: 94 */       AbatorConfigurationParser cp = new AbatorConfigurationParser(p, 
/*  48: 95 */         warnings);
/*  49: 96 */       AbatorConfiguration config = cp.parseAbatorConfiguration(configurationFile);
/*  50:    */       
/*  51: 98 */       DefaultShellCallback callback = new DefaultShellCallback(this.overwrite);
/*  52:    */       
/*  53:100 */       Abator abator = new Abator(config, callback, warnings);
/*  54:    */       
/*  55:102 */       abator.generate(new AntProgressCallback(this, this.verbose));
/*  56:    */     }
/*  57:    */     catch (XMLParserException e)
/*  58:    */     {
/*  59:105 */       List errors = e.getErrors();
/*  60:106 */       Iterator iter = errors.iterator();
/*  61:107 */       while (iter.hasNext()) {
/*  62:108 */         log((String)iter.next(), 0);
/*  63:    */       }
/*  64:110 */       e.printStackTrace();
/*  65:111 */       throw new BuildException(Arrays.deepToString(e.getStackTrace()));
/*  66:    */     }
/*  67:    */     catch (SQLException e)
/*  68:    */     {
/*  69:113 */       e.printStackTrace();
/*  70:114 */       throw new BuildException(Arrays.deepToString(e.getStackTrace()));
/*  71:    */     }
/*  72:    */     catch (IOException e)
/*  73:    */     {
/*  74:116 */       e.printStackTrace();
/*  75:117 */       throw new BuildException(Arrays.deepToString(e.getStackTrace()));
/*  76:    */     }
/*  77:    */     catch (InvalidConfigurationException e)
/*  78:    */     {
/*  79:119 */       e.printStackTrace();
/*  80:120 */       throw new BuildException(Arrays.deepToString(e.getStackTrace()));
/*  81:    */     }
/*  82:    */     catch (InterruptedException e)
/*  83:    */     {
/*  84:122 */       e.printStackTrace();
/*  85:    */     }
/*  86:127 */     Iterator iter = warnings.iterator();
/*  87:128 */     while (iter.hasNext()) {
/*  88:129 */       log((String)iter.next(), 1);
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String getConfigfile()
/*  93:    */   {
/*  94:137 */     return this.configfile;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setConfigfile(String configfile)
/*  98:    */   {
/*  99:144 */     this.configfile = configfile;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean isOverwrite()
/* 103:    */   {
/* 104:151 */     return this.overwrite;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setOverwrite(boolean overwrite)
/* 108:    */   {
/* 109:158 */     this.overwrite = overwrite;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public PropertySet createPropertyset()
/* 113:    */   {
/* 114:162 */     if (this.propertyset == null) {
/* 115:163 */       this.propertyset = new PropertySet();
/* 116:    */     }
/* 117:166 */     return this.propertyset;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean isVerbose()
/* 121:    */   {
/* 122:170 */     return this.verbose;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setVerbose(boolean verbose)
/* 126:    */   {
/* 127:174 */     this.verbose = verbose;
/* 128:    */   }
/* 129:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.ant.AbatorAntTask
 * JD-Core Version:    0.7.0.1
 */