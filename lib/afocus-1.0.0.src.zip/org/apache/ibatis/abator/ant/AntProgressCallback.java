/*  1:   */ package org.apache.ibatis.abator.ant;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.ProgressCallback;
/*  4:   */ import org.apache.tools.ant.Task;
/*  5:   */ 
/*  6:   */ public class AntProgressCallback
/*  7:   */   implements ProgressCallback
/*  8:   */ {
/*  9:   */   private Task task;
/* 10:   */   private boolean verbose;
/* 11:   */   
/* 12:   */   public AntProgressCallback(Task task, boolean verbose)
/* 13:   */   {
/* 14:39 */     this.task = task;
/* 15:40 */     this.verbose = verbose;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setNumberOfSubTasks(int totalSubTasks) {}
/* 19:   */   
/* 20:   */   public void startSubTask(String subTaskName)
/* 21:   */   {
/* 22:53 */     if (this.verbose) {
/* 23:54 */       this.task.log(subTaskName, 3);
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void finished() {}
/* 28:   */   
/* 29:   */   public void checkCancel()
/* 30:   */     throws InterruptedException
/* 31:   */   {}
/* 32:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.ant.AntProgressCallback
 * JD-Core Version:    0.7.0.1
 */