/*  1:   */ package org.apache.ibatis.abator.exception;
/*  2:   */ 
/*  3:   */ public class ShellException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   static final long serialVersionUID = -2026841561754434544L;
/*  7:   */   
/*  8:   */   public ShellException() {}
/*  9:   */   
/* 10:   */   public ShellException(String arg0)
/* 11:   */   {
/* 12:37 */     super(arg0);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public ShellException(String arg0, Throwable arg1)
/* 16:   */   {
/* 17:44 */     super(arg0, arg1);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public ShellException(Throwable arg0)
/* 21:   */   {
/* 22:50 */     super(arg0);
/* 23:   */   }
/* 24:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.exception.ShellException
 * JD-Core Version:    0.7.0.1
 */