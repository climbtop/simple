/*  1:   */ package org.apache.ibatis.abator.exception;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class XMLParserException
/*  7:   */   extends Exception
/*  8:   */ {
/*  9:   */   private static final long serialVersionUID = 5172525430401340573L;
/* 10:   */   private List errors;
/* 11:   */   
/* 12:   */   public XMLParserException(List errors)
/* 13:   */   {
/* 14:35 */     this.errors = errors;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public XMLParserException(String error)
/* 18:   */   {
/* 19:39 */     super(error);
/* 20:40 */     this.errors = new ArrayList();
/* 21:41 */     this.errors.add(error);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public List getErrors()
/* 25:   */   {
/* 26:45 */     return this.errors;
/* 27:   */   }
/* 28:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.exception.XMLParserException
 * JD-Core Version:    0.7.0.1
 */