/*  1:   */ package org.apache.ibatis.abator.exception;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class InvalidConfigurationException
/*  6:   */   extends Exception
/*  7:   */ {
/*  8:   */   static final long serialVersionUID = 4902307610148543411L;
/*  9:   */   private List errors;
/* 10:   */   
/* 11:   */   public InvalidConfigurationException(List errors)
/* 12:   */   {
/* 13:33 */     this.errors = errors;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public List getErrors()
/* 17:   */   {
/* 18:37 */     return this.errors;
/* 19:   */   }
/* 20:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.exception.InvalidConfigurationException
 * JD-Core Version:    0.7.0.1
 */