package org.apache.ibatis.abator.exception;

public class UnsupportedDataTypeException
  extends Exception
{
  private static final long serialVersionUID = -1012729279827054627L;
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.exception.UnsupportedDataTypeException
 * JD-Core Version:    0.7.0.1
 */