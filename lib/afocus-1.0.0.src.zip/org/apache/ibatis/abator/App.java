/*  1:   */ package org.apache.ibatis.abator;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import org.apache.ibatis.abator.api.AbatorRunner;
/*  5:   */ import org.apache.maven.plugin.AbstractMojo;
/*  6:   */ import org.apache.maven.plugin.MojoExecutionException;
/*  7:   */ import org.apache.maven.plugin.MojoFailureException;
/*  8:   */ import org.apache.maven.plugins.annotations.LifecyclePhase;
/*  9:   */ import org.apache.maven.plugins.annotations.Mojo;
/* 10:   */ import org.apache.maven.plugins.annotations.Parameter;
/* 11:   */ 
/* 12:   */ @Mojo(name="app", defaultPhase=LifecyclePhase.COMPILE)
/* 13:   */ public class App
/* 14:   */   extends AbstractMojo
/* 15:   */ {
/* 16:   */   @Parameter
/* 17:14 */   private String path = "";
/* 18:   */   @Parameter
/* 19:17 */   private String override = "";
/* 20:   */   
/* 21:   */   public void execute()
/* 22:   */     throws MojoExecutionException, MojoFailureException
/* 23:   */   {
/* 24:21 */     String[] args = { this.path, this.override };
/* 25:22 */     System.out.println("path:" + this.path);
/* 26:23 */     System.out.println("override:" + this.override);
/* 27:24 */     AbatorRunner.main(args);
/* 28:   */   }
/* 29:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.App
 * JD-Core Version:    0.7.0.1
 */