/*   1:    */ package org.apache.ibatis.abator.api;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.internal.util.EqualsUtil;
/*   4:    */ import org.apache.ibatis.abator.internal.util.HashCodeUtil;
/*   5:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*   6:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   7:    */ 
/*   8:    */ public class FullyQualifiedTable
/*   9:    */ {
/*  10:    */   private String catalog;
/*  11:    */   private String schema;
/*  12:    */   private String tableName;
/*  13:    */   private String domainObjectName;
/*  14:    */   private String alias;
/*  15:    */   private String label;
/*  16:    */   private String memo;
/*  17:    */   
/*  18:    */   public FullyQualifiedTable(String catalog, String schema, String tableName, String domainObjectName, String alias)
/*  19:    */   {
/*  20: 48 */     this.catalog = catalog;
/*  21: 49 */     this.schema = schema;
/*  22: 50 */     this.tableName = tableName;
/*  23: 51 */     this.domainObjectName = domainObjectName;
/*  24: 53 */     if (alias == null) {
/*  25: 54 */       this.alias = null;
/*  26:    */     } else {
/*  27: 56 */       this.alias = alias.trim();
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   public String getCatalog()
/*  32:    */   {
/*  33: 61 */     return this.catalog;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getSchema()
/*  37:    */   {
/*  38: 65 */     return this.schema;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public String getTableName()
/*  42:    */   {
/*  43: 69 */     return this.tableName;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getFullyQualifiedTableName()
/*  47:    */   {
/*  48: 73 */     return StringUtility.composeFullyQualifiedTableName(this.catalog, this.schema, this.tableName);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String getAliasedFullyQualifiedTableName()
/*  52:    */   {
/*  53: 77 */     StringBuffer sb = new StringBuffer();
/*  54:    */     
/*  55: 79 */     sb.append(getFullyQualifiedTableName());
/*  56: 81 */     if (StringUtility.stringHasValue(this.alias))
/*  57:    */     {
/*  58: 82 */       sb.append(' ');
/*  59: 83 */       sb.append(this.alias);
/*  60:    */     }
/*  61: 86 */     return sb.toString();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getFullyQualifiedTableNameWithUnderscores()
/*  65:    */   {
/*  66: 90 */     StringBuffer sb = new StringBuffer();
/*  67: 92 */     if (StringUtility.stringHasValue(this.catalog))
/*  68:    */     {
/*  69: 93 */       sb.append(this.catalog);
/*  70: 94 */       sb.append('_');
/*  71:    */     }
/*  72: 97 */     if (StringUtility.stringHasValue(this.schema))
/*  73:    */     {
/*  74: 98 */       sb.append(this.schema);
/*  75: 99 */       sb.append('_');
/*  76:    */     }
/*  77:101 */     else if (sb.length() > 0)
/*  78:    */     {
/*  79:102 */       sb.append('_');
/*  80:    */     }
/*  81:106 */     sb.append(this.tableName);
/*  82:    */     
/*  83:108 */     return sb.toString();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getDomainObjectName()
/*  87:    */   {
/*  88:112 */     if (StringUtility.stringHasValue(this.domainObjectName)) {
/*  89:113 */       return this.domainObjectName;
/*  90:    */     }
/*  91:115 */     return JavaBeansUtil.getCamelCaseString(this.tableName, true);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean equals(Object obj)
/*  95:    */   {
/*  96:120 */     if (this == obj) {
/*  97:121 */       return true;
/*  98:    */     }
/*  99:124 */     if (!(obj instanceof FullyQualifiedTable)) {
/* 100:125 */       return false;
/* 101:    */     }
/* 102:128 */     FullyQualifiedTable other = (FullyQualifiedTable)obj;
/* 103:    */     
/* 104:130 */     return (EqualsUtil.areEqual(this.tableName, other.tableName)) && 
/* 105:131 */       (EqualsUtil.areEqual(this.catalog, other.catalog)) && 
/* 106:132 */       (EqualsUtil.areEqual(this.schema, other.schema));
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int hashCode()
/* 110:    */   {
/* 111:136 */     int result = 23;
/* 112:137 */     result = HashCodeUtil.hash(result, this.tableName);
/* 113:138 */     result = HashCodeUtil.hash(result, this.catalog);
/* 114:139 */     result = HashCodeUtil.hash(result, this.schema);
/* 115:    */     
/* 116:141 */     return result;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public String toString()
/* 120:    */   {
/* 121:145 */     return getFullyQualifiedTableName();
/* 122:    */   }
/* 123:    */   
/* 124:    */   public String getAlias()
/* 125:    */   {
/* 126:149 */     return this.alias;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public String getMemo()
/* 130:    */   {
/* 131:156 */     return this.memo;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setMemo(String memo)
/* 135:    */   {
/* 136:163 */     this.memo = memo;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getLabel()
/* 140:    */   {
/* 141:170 */     return this.label;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setLabel(String label)
/* 145:    */   {
/* 146:177 */     this.label = label;
/* 147:    */   }
/* 148:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.FullyQualifiedTable
 * JD-Core Version:    0.7.0.1
 */