package org.apache.ibatis.abator.api;

import java.util.Iterator;
import org.apache.ibatis.abator.config.GeneratedKey;
import org.apache.ibatis.abator.internal.db.ColumnDefinition;
import org.apache.ibatis.abator.internal.rules.AbatorRules;

public abstract interface IntrospectedTable
{
  public abstract FullyQualifiedTable getTable();
  
  public abstract String getSelectByExampleQueryId();
  
  public abstract String getSelectByPrimaryKeyQueryId();
  
  public abstract GeneratedKey getGeneratedKey();
  
  public abstract ColumnDefinition getColumn(String paramString);
  
  public abstract boolean hasJDBCDateColumns();
  
  public abstract boolean hasJDBCTimeColumns();
  
  public abstract Iterator getPrimaryKeyColumns();
  
  public abstract boolean hasPrimaryKeyColumns();
  
  public abstract boolean hasParentIdColumn();
  
  public abstract boolean hasStatusColumn();
  
  public abstract boolean hasMainFkColumns();
  
  public abstract Iterator getMainFkColumns();
  
  public abstract Iterator getBaseColumns();
  
  public abstract Iterator getAllColumns();
  
  public abstract Iterator getListColumns();
  
  public abstract Iterator getQueryColumns();
  
  public abstract String getListPropertyNames();
  
  public abstract int getListColumnSize();
  
  public abstract Iterator getNonBLOBColumns();
  
  public abstract Iterator getNonPrimaryKeyColumns();
  
  public abstract Iterator getBLOBColumns();
  
  public abstract boolean hasBLOBColumns();
  
  public abstract AbatorRules getRules();
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.IntrospectedTable
 * JD-Core Version:    0.7.0.1
 */