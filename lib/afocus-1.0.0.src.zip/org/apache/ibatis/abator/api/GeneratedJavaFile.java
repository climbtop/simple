/*  1:   */ package org.apache.ibatis.abator.api;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  6:   */ 
/*  7:   */ public class GeneratedJavaFile
/*  8:   */   extends GeneratedFile
/*  9:   */ {
/* 10:   */   private CompilationUnit compilationUnit;
/* 11:   */   
/* 12:   */   public GeneratedJavaFile(CompilationUnit compilationUnit, String targetProject)
/* 13:   */   {
/* 14:35 */     super(targetProject);
/* 15:36 */     this.compilationUnit = compilationUnit;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Set getImportedTypes()
/* 19:   */   {
/* 20:40 */     return this.compilationUnit.getImportedTypes();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getFormattedContent()
/* 24:   */   {
/* 25:48 */     return this.compilationUnit.getFormattedContent();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Set getSuperInterfaceTypes()
/* 29:   */   {
/* 30:52 */     return this.compilationUnit.getSuperInterfaceTypes();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public FullyQualifiedJavaType getSuperClass()
/* 34:   */   {
/* 35:59 */     return this.compilationUnit.getSuperClass();
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String getFileName()
/* 39:   */   {
/* 40:67 */     return this.compilationUnit.getType().getBaseShortName() + ".java";
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String getTargetPackage()
/* 44:   */   {
/* 45:75 */     return this.compilationUnit.getType().getPackageName();
/* 46:   */   }
/* 47:   */   
/* 48:   */   public boolean isJavaInterface()
/* 49:   */   {
/* 50:79 */     return this.compilationUnit.isJavaInterface();
/* 51:   */   }
/* 52:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.GeneratedJavaFile
 * JD-Core Version:    0.7.0.1
 */