package org.apache.ibatis.abator.api;

import java.io.File;
import java.util.List;
import org.apache.ibatis.abator.exception.ShellException;

public abstract interface ShellCallback
{
  public abstract File getDirectory(String paramString1, String paramString2, List paramList)
    throws ShellException;
  
  public abstract String mergeJavaFile(GeneratedJavaFile paramGeneratedJavaFile, String paramString, List paramList)
    throws ShellException;
  
  public abstract void refreshProject(String paramString);
  
  public abstract boolean mergeSupported();
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.ShellCallback
 * JD-Core Version:    0.7.0.1
 */