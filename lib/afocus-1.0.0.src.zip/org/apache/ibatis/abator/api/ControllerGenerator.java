package org.apache.ibatis.abator.api;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;

public abstract interface ControllerGenerator
{
  public abstract void addConfigurationProperties(Map paramMap);
  
  public abstract void addContextProperties(Map paramMap);
  
  public abstract void setWarnings(List paramList);
  
  public abstract void setTargetPackage(String paramString);
  
  public abstract void setTargetProject(String paramString);
  
  public abstract void setJavaModelGenerator(JavaModelGenerator paramJavaModelGenerator);
  
  public abstract void setServiceGenerator(ServiceGenerator paramServiceGenerator);
  
  public abstract List getGeneratedJavaFiles(IntrospectedTable paramIntrospectedTable, ProgressCallback paramProgressCallback);
  
  public abstract FullyQualifiedJavaType getControllerType(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract String getServicePropertyName(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract String getUrlPrefix(FullyQualifiedTable paramFullyQualifiedTable);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.ControllerGenerator
 * JD-Core Version:    0.7.0.1
 */