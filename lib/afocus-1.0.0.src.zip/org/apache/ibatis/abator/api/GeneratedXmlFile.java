/*  1:   */ package org.apache.ibatis.abator.api;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.xml.Document;
/*  4:   */ 
/*  5:   */ public class GeneratedXmlFile
/*  6:   */   extends GeneratedFile
/*  7:   */ {
/*  8:   */   private Document document;
/*  9:   */   private String fileName;
/* 10:   */   private String targetPackage;
/* 11:   */   
/* 12:   */   public GeneratedXmlFile(Document document, String fileName, String targetPackage, String targetProject)
/* 13:   */   {
/* 14:34 */     super(targetProject);
/* 15:35 */     this.document = document;
/* 16:36 */     this.fileName = fileName;
/* 17:37 */     this.targetPackage = targetPackage;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getFormattedContent()
/* 21:   */   {
/* 22:45 */     return this.document.getFormattedContent();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getFileName()
/* 26:   */   {
/* 27:52 */     return this.fileName;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getTargetPackage()
/* 31:   */   {
/* 32:59 */     return this.targetPackage;
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.GeneratedXmlFile
 * JD-Core Version:    0.7.0.1
 */