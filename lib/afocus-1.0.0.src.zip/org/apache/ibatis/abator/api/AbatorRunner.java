/*   1:    */ package org.apache.ibatis.abator.api;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.PrintStream;
/*   6:    */ import java.sql.SQLException;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ import org.apache.ibatis.abator.config.AbatorConfiguration;
/*  11:    */ import org.apache.ibatis.abator.config.xml.AbatorConfigurationParser;
/*  12:    */ import org.apache.ibatis.abator.exception.InvalidConfigurationException;
/*  13:    */ import org.apache.ibatis.abator.exception.XMLParserException;
/*  14:    */ import org.apache.ibatis.abator.internal.DefaultShellCallback;
/*  15:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  16:    */ 
/*  17:    */ public class AbatorRunner
/*  18:    */ {
/*  19:    */   public static void main(String[] args)
/*  20:    */   {
/*  21: 40 */     if (args.length != 2)
/*  22:    */     {
/*  23: 41 */       usage();
/*  24: 42 */       return;
/*  25:    */     }
/*  26: 45 */     String configfile = args[0];
/*  27: 46 */     boolean overwrite = "true".equalsIgnoreCase(args[1]);
/*  28:    */     
/*  29: 48 */     List warnings = new ArrayList();
/*  30:    */     
/*  31: 50 */     File configurationFile = new File(configfile);
/*  32: 51 */     if (!configurationFile.exists())
/*  33:    */     {
/*  34: 52 */       writeLine(Messages.getString("RuntimeError.1", configfile));
/*  35: 53 */       return;
/*  36:    */     }
/*  37:    */     try
/*  38:    */     {
/*  39: 57 */       AbatorConfigurationParser cp = new AbatorConfigurationParser(
/*  40: 58 */         warnings);
/*  41: 59 */       AbatorConfiguration config = cp.parseAbatorConfiguration(configurationFile);
/*  42:    */       
/*  43: 61 */       DefaultShellCallback callback = new DefaultShellCallback(overwrite);
/*  44:    */       
/*  45: 63 */       Abator abator = new Abator(config, callback, warnings);
/*  46:    */       
/*  47: 65 */       abator.generate(null);
/*  48:    */     }
/*  49:    */     catch (XMLParserException e)
/*  50:    */     {
/*  51: 68 */       writeLine(Messages.getString("Progress.3"));
/*  52: 69 */       writeLine();
/*  53: 70 */       List errors = e.getErrors();
/*  54: 71 */       Iterator iter = errors.iterator();
/*  55: 72 */       while (iter.hasNext()) {
/*  56: 73 */         writeLine((String)iter.next());
/*  57:    */       }
/*  58: 76 */       return;
/*  59:    */     }
/*  60:    */     catch (SQLException e)
/*  61:    */     {
/*  62: 78 */       e.printStackTrace();
/*  63: 79 */       return;
/*  64:    */     }
/*  65:    */     catch (IOException e)
/*  66:    */     {
/*  67: 81 */       e.printStackTrace();
/*  68: 82 */       return;
/*  69:    */     }
/*  70:    */     catch (InvalidConfigurationException e)
/*  71:    */     {
/*  72: 84 */       e.printStackTrace();
/*  73: 85 */       return;
/*  74:    */     }
/*  75:    */     catch (InterruptedException localInterruptedException) {}
/*  76: 91 */     Iterator iter = warnings.iterator();
/*  77: 92 */     while (iter.hasNext()) {
/*  78: 93 */       writeLine((String)iter.next());
/*  79:    */     }
/*  80: 96 */     if (warnings.size() == 0)
/*  81:    */     {
/*  82: 97 */       writeLine(Messages.getString("Progress.4"));
/*  83:    */     }
/*  84:    */     else
/*  85:    */     {
/*  86: 99 */       writeLine();
/*  87:100 */       writeLine(Messages.getString("Progress.5"));
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static void usage()
/*  92:    */   {
/*  93:105 */     writeLine(Messages.getString("Usage.0"));
/*  94:106 */     writeLine(Messages.getString("Usage.1"));
/*  95:107 */     writeLine(Messages.getString("Usage.2"));
/*  96:108 */     writeLine(Messages.getString("Usage.3"));
/*  97:109 */     writeLine(Messages.getString("Usage.4"));
/*  98:110 */     writeLine(Messages.getString("Usage.5"));
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static void writeLine(String message)
/* 102:    */   {
/* 103:114 */     System.out.println(message);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static void writeLine()
/* 107:    */   {
/* 108:118 */     System.out.println();
/* 109:    */   }
/* 110:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.AbatorRunner
 * JD-Core Version:    0.7.0.1
 */