/*  1:   */ package org.apache.ibatis.abator.api;
/*  2:   */ 
/*  3:   */ public abstract class GeneratedFile
/*  4:   */ {
/*  5:   */   private String targetProject;
/*  6:   */   
/*  7:   */   public GeneratedFile(String targetProject)
/*  8:   */   {
/*  9:31 */     this.targetProject = targetProject;
/* 10:   */   }
/* 11:   */   
/* 12:   */   public abstract String getFormattedContent();
/* 13:   */   
/* 14:   */   public abstract String getFileName();
/* 15:   */   
/* 16:   */   public String getTargetProject()
/* 17:   */   {
/* 18:60 */     return this.targetProject;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public abstract String getTargetPackage();
/* 22:   */   
/* 23:   */   public String toString()
/* 24:   */   {
/* 25:72 */     return getFormattedContent();
/* 26:   */   }
/* 27:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.GeneratedFile
 * JD-Core Version:    0.7.0.1
 */