/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.TreeSet;
/*   9:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  10:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  11:    */ 
/*  12:    */ public class TopLevelEnumeration
/*  13:    */   extends InnerEnum
/*  14:    */   implements CompilationUnit
/*  15:    */ {
/*  16:    */   private Set importedTypes;
/*  17:    */   private List fileCommentLines;
/*  18:    */   
/*  19:    */   public TopLevelEnumeration(FullyQualifiedJavaType type)
/*  20:    */   {
/*  21: 42 */     super(type);
/*  22: 43 */     this.importedTypes = new TreeSet();
/*  23: 44 */     this.fileCommentLines = new ArrayList();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public String getFormattedContent()
/*  27:    */   {
/*  28: 51 */     StringBuffer sb = new StringBuffer();
/*  29:    */     
/*  30: 53 */     Iterator iter = this.fileCommentLines.iterator();
/*  31: 54 */     while (iter.hasNext())
/*  32:    */     {
/*  33: 55 */       sb.append(iter.next());
/*  34: 56 */       OutputUtilities.newLine(sb);
/*  35:    */     }
/*  36: 59 */     if ((getType().getPackageName() != null) && 
/*  37: 60 */       (getType().getPackageName().length() > 0))
/*  38:    */     {
/*  39: 61 */       sb.append("package ");
/*  40: 62 */       sb.append(getType().getPackageName());
/*  41: 63 */       sb.append(';');
/*  42: 64 */       OutputUtilities.newLine(sb);
/*  43: 65 */       OutputUtilities.newLine(sb);
/*  44:    */     }
/*  45: 68 */     iter = this.importedTypes.iterator();
/*  46: 69 */     while (iter.hasNext())
/*  47:    */     {
/*  48: 70 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  49: 71 */       if (fqjt.isExplicitlyImported())
/*  50:    */       {
/*  51: 72 */         sb.append("import ");
/*  52: 73 */         sb.append(fqjt.getFullyQualifiedName());
/*  53: 74 */         sb.append(';');
/*  54: 75 */         OutputUtilities.newLine(sb);
/*  55:    */       }
/*  56:    */     }
/*  57: 79 */     if (this.importedTypes.size() > 0) {
/*  58: 80 */       OutputUtilities.newLine(sb);
/*  59:    */     }
/*  60: 83 */     sb.append(super.getFormattedContent(0));
/*  61:    */     
/*  62: 85 */     return sb.toString();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Set getImportedTypes()
/*  66:    */   {
/*  67: 92 */     return Collections.unmodifiableSet(this.importedTypes);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public FullyQualifiedJavaType getSuperClass()
/*  71:    */   {
/*  72: 99 */     throw new UnsupportedOperationException(Messages.getString("RuntimeError.11"));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean isJavaInterface()
/*  76:    */   {
/*  77:106 */     return false;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isJavaEnumeration()
/*  81:    */   {
/*  82:113 */     return true;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void addImportedType(FullyQualifiedJavaType importedType)
/*  86:    */   {
/*  87:120 */     if ((importedType.isExplicitlyImported()) && 
/*  88:121 */       (!importedType.getPackageName().equals(getType().getPackageName()))) {
/*  89:122 */       this.importedTypes.add(importedType);
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void addFileCommentLine(String commentLine)
/*  94:    */   {
/*  95:127 */     this.fileCommentLines.add(commentLine);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public List getFileCommentLines()
/*  99:    */   {
/* 100:131 */     return this.fileCommentLines;
/* 101:    */   }
/* 102:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.TopLevelEnumeration
 * JD-Core Version:    0.7.0.1
 */