/*  1:   */ package org.apache.ibatis.abator.api.dom.java;
/*  2:   */ 
/*  3:   */ public class JavaWildcardType
/*  4:   */   extends FullyQualifiedJavaType
/*  5:   */ {
/*  6:   */   private boolean extendsType;
/*  7:   */   
/*  8:   */   public JavaWildcardType(String fullyQualifiedName, boolean extendsType)
/*  9:   */   {
/* 10:34 */     super(fullyQualifiedName);
/* 11:35 */     this.extendsType = extendsType;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getShortName()
/* 15:   */   {
/* 16:39 */     StringBuffer sb = new StringBuffer();
/* 17:40 */     if (this.extendsType) {
/* 18:41 */       sb.append("? extends ");
/* 19:   */     } else {
/* 20:43 */       sb.append("? super ");
/* 21:   */     }
/* 22:45 */     sb.append(super.getShortName());
/* 23:   */     
/* 24:47 */     return sb.toString();
/* 25:   */   }
/* 26:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.JavaWildcardType
 * JD-Core Version:    0.7.0.1
 */