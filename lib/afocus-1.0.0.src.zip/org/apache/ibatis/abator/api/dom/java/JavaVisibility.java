/*  1:   */ package org.apache.ibatis.abator.api.dom.java;
/*  2:   */ 
/*  3:   */ public class JavaVisibility
/*  4:   */ {
/*  5:24 */   public static final JavaVisibility PUBLIC = new JavaVisibility();
/*  6:25 */   public static final JavaVisibility PRIVATE = new JavaVisibility();
/*  7:26 */   public static final JavaVisibility PROTECTED = new JavaVisibility();
/*  8:27 */   public static final JavaVisibility DEFAULT = new JavaVisibility();
/*  9:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.JavaVisibility
 * JD-Core Version:    0.7.0.1
 */