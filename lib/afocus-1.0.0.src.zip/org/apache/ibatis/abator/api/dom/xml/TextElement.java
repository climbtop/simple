/*   1:    */ package org.apache.ibatis.abator.api.dom.xml;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.StringTokenizer;
/*   6:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*   7:    */ 
/*   8:    */ public class TextElement
/*   9:    */   extends Element
/*  10:    */ {
/*  11:    */   private String content;
/*  12:    */   
/*  13:    */   public TextElement(String content)
/*  14:    */   {
/*  15: 35 */     this.content = content;
/*  16:    */   }
/*  17:    */   
/*  18:    */   public String getFormattedContent(int indentLevel)
/*  19:    */   {
/*  20: 44 */     return formatLongString(this.content, 100, indentLevel);
/*  21:    */   }
/*  22:    */   
/*  23:    */   private static String formatLongString(String s, int maxLineLength, int indentLevel)
/*  24:    */   {
/*  25: 62 */     StringBuffer sb = new StringBuffer();
/*  26: 63 */     OutputUtilities.xmlIndent(sb, indentLevel);
/*  27: 64 */     sb.append(s);
/*  28: 65 */     if ((sb.length() <= maxLineLength) || (s.indexOf(' ') == -1)) {
/*  29: 67 */       return sb.toString();
/*  30:    */     }
/*  31: 70 */     ArrayList lines = new ArrayList();
/*  32: 71 */     StringTokenizer st = new StringTokenizer(s, " ");
/*  33:    */     
/*  34: 73 */     sb.setLength(0);
/*  35: 74 */     OutputUtilities.xmlIndent(sb, indentLevel);
/*  36: 75 */     sb.append(st.nextToken());
/*  37: 76 */     while (st.hasMoreTokens())
/*  38:    */     {
/*  39: 77 */       String token = st.nextToken();
/*  40: 79 */       if (sb.length() + token.length() + 1 > maxLineLength)
/*  41:    */       {
/*  42: 80 */         lines.add(sb.toString());
/*  43: 81 */         sb.setLength(0);
/*  44: 82 */         OutputUtilities.xmlIndent(sb, indentLevel + 1);
/*  45: 83 */         sb.append(token);
/*  46:    */       }
/*  47:    */       else
/*  48:    */       {
/*  49: 85 */         sb.append(' ');
/*  50: 86 */         sb.append(token);
/*  51:    */       }
/*  52:    */     }
/*  53: 90 */     if (sb.toString().trim().length() > 0) {
/*  54: 91 */       lines.add(sb.toString());
/*  55:    */     }
/*  56: 94 */     sb.setLength(0);
/*  57: 95 */     Iterator iter = lines.iterator();
/*  58: 96 */     while (iter.hasNext())
/*  59:    */     {
/*  60: 97 */       sb.append(iter.next());
/*  61: 98 */       if (iter.hasNext()) {
/*  62: 99 */         OutputUtilities.newLine(sb);
/*  63:    */       }
/*  64:    */     }
/*  65:103 */     return sb.toString();
/*  66:    */   }
/*  67:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.xml.TextElement
 * JD-Core Version:    0.7.0.1
 */