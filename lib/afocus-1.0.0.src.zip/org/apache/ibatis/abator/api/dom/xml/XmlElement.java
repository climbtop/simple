/*   1:    */ package org.apache.ibatis.abator.api.dom.xml;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*   7:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   8:    */ 
/*   9:    */ public class XmlElement
/*  10:    */   extends Element
/*  11:    */ {
/*  12:    */   private List attributes;
/*  13:    */   private List elements;
/*  14:    */   private String name;
/*  15: 36 */   private String pcdata = null;
/*  16:    */   
/*  17:    */   public XmlElement(String name, String pcdata)
/*  18:    */   {
/*  19: 43 */     this.attributes = new ArrayList();
/*  20: 44 */     this.elements = new ArrayList();
/*  21: 45 */     this.name = name;
/*  22: 46 */     this.pcdata = pcdata;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public XmlElement(String name)
/*  26:    */   {
/*  27: 50 */     this(name, null);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setPcdata(String pcdata)
/*  31:    */   {
/*  32: 54 */     this.pcdata = pcdata;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public List getAttributes()
/*  36:    */   {
/*  37: 61 */     return this.attributes;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void addAttribute(Attribute attribute)
/*  41:    */   {
/*  42: 65 */     this.attributes.add(attribute);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public List getElements()
/*  46:    */   {
/*  47: 72 */     return this.elements;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void addElement(Element element)
/*  51:    */   {
/*  52: 76 */     this.elements.add(element);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public String getName()
/*  56:    */   {
/*  57: 83 */     return this.name;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void addComment() {}
/*  61:    */   
/*  62:    */   public String getFormattedContent(int indentLevel)
/*  63:    */   {
/*  64:111 */     StringBuffer sb = new StringBuffer();
/*  65:    */     
/*  66:113 */     OutputUtilities.xmlIndent(sb, indentLevel);
/*  67:114 */     sb.append('<');
/*  68:115 */     sb.append(this.name);
/*  69:    */     
/*  70:117 */     Iterator iter = this.attributes.iterator();
/*  71:118 */     while (iter.hasNext())
/*  72:    */     {
/*  73:119 */       Attribute att = (Attribute)iter.next();
/*  74:120 */       sb.append(' ');
/*  75:121 */       sb.append(att.getFormattedContent());
/*  76:    */     }
/*  77:124 */     if (StringUtility.stringHasValue(this.pcdata))
/*  78:    */     {
/*  79:125 */       sb.append(" ><![CDATA[").append(this.pcdata).append("]]>");
/*  80:126 */       sb.append("</").append(this.name).append('>');
/*  81:    */     }
/*  82:129 */     else if (this.elements.size() > 0)
/*  83:    */     {
/*  84:130 */       sb.append(" >");
/*  85:131 */       iter = this.elements.iterator();
/*  86:132 */       while (iter.hasNext())
/*  87:    */       {
/*  88:133 */         Element element = (Element)iter.next();
/*  89:134 */         OutputUtilities.newLine(sb);
/*  90:135 */         sb.append(element.getFormattedContent(indentLevel + 1));
/*  91:    */       }
/*  92:137 */       OutputUtilities.newLine(sb);
/*  93:138 */       OutputUtilities.xmlIndent(sb, indentLevel);
/*  94:139 */       sb.append("</").append(this.name).append('>');
/*  95:    */     }
/*  96:    */     else
/*  97:    */     {
/*  98:142 */       sb.append(" />");
/*  99:    */     }
/* 100:145 */     return sb.toString();
/* 101:    */   }
/* 102:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.xml.XmlElement
 * JD-Core Version:    0.7.0.1
 */