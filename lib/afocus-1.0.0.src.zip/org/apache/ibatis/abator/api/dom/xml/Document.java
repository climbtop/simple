/*  1:   */ package org.apache.ibatis.abator.api.dom.xml;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  4:   */ 
/*  5:   */ public class Document
/*  6:   */ {
/*  7:   */   private String publicId;
/*  8:   */   private String systemId;
/*  9:   */   private XmlElement rootElement;
/* 10:   */   
/* 11:   */   public Document(String publicId, String systemId)
/* 12:   */   {
/* 13:35 */     this.publicId = publicId;
/* 14:36 */     this.systemId = systemId;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public XmlElement getRootElement()
/* 18:   */   {
/* 19:43 */     return this.rootElement;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void setRootElement(XmlElement rootElement)
/* 23:   */   {
/* 24:51 */     this.rootElement = rootElement;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getPublicId()
/* 28:   */   {
/* 29:58 */     return this.publicId;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getSystemId()
/* 33:   */   {
/* 34:65 */     return this.systemId;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getFormattedContent()
/* 38:   */   {
/* 39:69 */     return getFormattedContent("UTF-8");
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getFormattedContent(String encode)
/* 43:   */   {
/* 44:73 */     StringBuffer sb = new StringBuffer();
/* 45:   */     
/* 46:75 */     sb.append("<?xml version=\"1.0\" encoding=\"" + encode + "\" ?>");
/* 47:   */     
/* 48:77 */     OutputUtilities.newLine(sb);
/* 49:78 */     sb.append("<!DOCTYPE ");
/* 50:79 */     sb.append(this.rootElement.getName());
/* 51:80 */     sb.append(" PUBLIC \"");
/* 52:81 */     sb.append(this.publicId);
/* 53:82 */     sb.append("\" \"");
/* 54:83 */     sb.append(this.systemId);
/* 55:84 */     sb.append("\" >");
/* 56:   */     
/* 57:86 */     OutputUtilities.newLine(sb);
/* 58:87 */     sb.append(this.rootElement.getFormattedContent(0));
/* 59:   */     
/* 60:89 */     return sb.toString();
/* 61:   */   }
/* 62:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.xml.Document
 * JD-Core Version:    0.7.0.1
 */