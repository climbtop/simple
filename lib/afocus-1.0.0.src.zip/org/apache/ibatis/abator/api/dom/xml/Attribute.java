/*  1:   */ package org.apache.ibatis.abator.api.dom.xml;
/*  2:   */ 
/*  3:   */ public class Attribute
/*  4:   */ {
/*  5:   */   private String name;
/*  6:   */   private String value;
/*  7:   */   
/*  8:   */   public Attribute(String name, String value)
/*  9:   */   {
/* 10:30 */     this.name = name;
/* 11:31 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getName()
/* 15:   */   {
/* 16:38 */     return this.name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getValue()
/* 20:   */   {
/* 21:44 */     return this.value;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getFormattedContent()
/* 25:   */   {
/* 26:48 */     StringBuffer sb = new StringBuffer();
/* 27:49 */     sb.append(this.name);
/* 28:50 */     sb.append("=\"");
/* 29:51 */     sb.append(this.value);
/* 30:52 */     sb.append('"');
/* 31:   */     
/* 32:54 */     return sb.toString();
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.xml.Attribute
 * JD-Core Version:    0.7.0.1
 */