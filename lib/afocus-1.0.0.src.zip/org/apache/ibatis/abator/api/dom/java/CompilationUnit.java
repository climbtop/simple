package org.apache.ibatis.abator.api.dom.java;

import java.util.List;
import java.util.Set;

public abstract interface CompilationUnit
{
  public abstract String getFormattedContent();
  
  public abstract Set getImportedTypes();
  
  public abstract FullyQualifiedJavaType getSuperClass();
  
  public abstract boolean isJavaInterface();
  
  public abstract boolean isJavaEnumeration();
  
  public abstract Set getSuperInterfaceTypes();
  
  public abstract FullyQualifiedJavaType getType();
  
  public abstract void addImportedType(FullyQualifiedJavaType paramFullyQualifiedJavaType);
  
  public abstract void addFileCommentLine(String paramString);
  
  public abstract List getFileCommentLines();
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.CompilationUnit
 * JD-Core Version:    0.7.0.1
 */