/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ 
/*   7:    */ public class FullyQualifiedJavaType
/*   8:    */   implements Comparable
/*   9:    */ {
/*  10: 26 */   private static FullyQualifiedJavaType intInstance = null;
/*  11: 27 */   private static FullyQualifiedJavaType longPrimitiveInstance = null;
/*  12: 28 */   private static FullyQualifiedJavaType stringInstance = null;
/*  13: 29 */   private static FullyQualifiedJavaType booleanPrimitiveInstance = null;
/*  14: 30 */   private static FullyQualifiedJavaType objectInstance = null;
/*  15: 31 */   private static FullyQualifiedJavaType dateInstance = null;
/*  16: 32 */   private static FullyQualifiedJavaType criteriaInstance = null;
/*  17: 33 */   private static FullyQualifiedJavaType serializableInstance = null;
/*  18:    */   private String baseShortName;
/*  19:    */   private String calculatedShortName;
/*  20:    */   private String fullyQualifiedName;
/*  21:    */   private boolean explicitlyImported;
/*  22:    */   private String packageName;
/*  23:    */   private boolean primitive;
/*  24:    */   private PrimitiveTypeWrapper primitiveTypeWrapper;
/*  25:    */   private List typeArguments;
/*  26:    */   
/*  27:    */   public FullyQualifiedJavaType(String fullyQualifiedName)
/*  28:    */   {
/*  29: 55 */     this.typeArguments = new ArrayList();
/*  30: 56 */     this.fullyQualifiedName = fullyQualifiedName;
/*  31:    */     
/*  32: 58 */     int lastIndex = fullyQualifiedName.lastIndexOf('.');
/*  33: 59 */     if (lastIndex == -1)
/*  34:    */     {
/*  35: 60 */       this.baseShortName = fullyQualifiedName;
/*  36: 61 */       this.explicitlyImported = false;
/*  37: 62 */       this.packageName = "";
/*  38: 64 */       if ("byte".equals(fullyQualifiedName))
/*  39:    */       {
/*  40: 65 */         this.primitive = true;
/*  41: 66 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getByteInstance();
/*  42:    */       }
/*  43: 67 */       else if ("short".equals(fullyQualifiedName))
/*  44:    */       {
/*  45: 68 */         this.primitive = true;
/*  46: 69 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getShortInstance();
/*  47:    */       }
/*  48: 70 */       else if ("int".equals(fullyQualifiedName))
/*  49:    */       {
/*  50: 71 */         this.primitive = true;
/*  51: 72 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getIntegerInstance();
/*  52:    */       }
/*  53: 73 */       else if ("long".equals(fullyQualifiedName))
/*  54:    */       {
/*  55: 74 */         this.primitive = true;
/*  56: 75 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getLongInstance();
/*  57:    */       }
/*  58: 76 */       else if ("char".equals(fullyQualifiedName))
/*  59:    */       {
/*  60: 77 */         this.primitive = true;
/*  61: 78 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getCharacterInstance();
/*  62:    */       }
/*  63: 79 */       else if ("float".equals(fullyQualifiedName))
/*  64:    */       {
/*  65: 80 */         this.primitive = true;
/*  66: 81 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getFloatInstance();
/*  67:    */       }
/*  68: 82 */       else if ("double".equals(fullyQualifiedName))
/*  69:    */       {
/*  70: 83 */         this.primitive = true;
/*  71: 84 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getDoubleInstance();
/*  72:    */       }
/*  73: 85 */       else if ("boolean".equals(fullyQualifiedName))
/*  74:    */       {
/*  75: 86 */         this.primitive = true;
/*  76: 87 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getBooleanInstance();
/*  77:    */       }
/*  78:    */       else
/*  79:    */       {
/*  80: 89 */         this.primitive = false;
/*  81: 90 */         this.primitiveTypeWrapper = null;
/*  82:    */       }
/*  83:    */     }
/*  84:    */     else
/*  85:    */     {
/*  86: 93 */       this.baseShortName = fullyQualifiedName.substring(lastIndex + 1);
/*  87: 94 */       this.packageName = fullyQualifiedName.substring(0, lastIndex);
/*  88: 95 */       if ("java.lang".equals(this.packageName)) {
/*  89: 96 */         this.explicitlyImported = false;
/*  90:    */       } else {
/*  91: 98 */         this.explicitlyImported = true;
/*  92:    */       }
/*  93:    */     }
/*  94:102 */     this.calculatedShortName = this.baseShortName;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean isExplicitlyImported()
/*  98:    */   {
/*  99:109 */     return this.explicitlyImported;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String getFullyQualifiedName()
/* 103:    */   {
/* 104:118 */     return this.fullyQualifiedName;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public String getPackageName()
/* 108:    */   {
/* 109:124 */     return this.packageName;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String getShortName()
/* 113:    */   {
/* 114:130 */     return this.calculatedShortName;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public String getBaseShortName()
/* 118:    */   {
/* 119:134 */     return this.baseShortName;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean equals(Object obj)
/* 123:    */   {
/* 124:141 */     if (this == obj) {
/* 125:142 */       return true;
/* 126:    */     }
/* 127:145 */     if (!(obj instanceof FullyQualifiedJavaType)) {
/* 128:146 */       return false;
/* 129:    */     }
/* 130:149 */     FullyQualifiedJavaType other = (FullyQualifiedJavaType)obj;
/* 131:    */     
/* 132:151 */     return this.fullyQualifiedName.equals(other.fullyQualifiedName);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public int hashCode()
/* 136:    */   {
/* 137:158 */     return this.fullyQualifiedName.hashCode();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String toString()
/* 141:    */   {
/* 142:165 */     return this.fullyQualifiedName;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean isPrimitive()
/* 146:    */   {
/* 147:172 */     return this.primitive;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public PrimitiveTypeWrapper getPrimitiveTypeWrapper()
/* 151:    */   {
/* 152:179 */     return this.primitiveTypeWrapper;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static final FullyQualifiedJavaType getIntInstance()
/* 156:    */   {
/* 157:183 */     if (intInstance == null) {
/* 158:184 */       intInstance = new FullyQualifiedJavaType("int");
/* 159:    */     }
/* 160:186 */     return intInstance;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static final FullyQualifiedJavaType getLongPrimitiveInstance()
/* 164:    */   {
/* 165:190 */     if (longPrimitiveInstance == null) {
/* 166:191 */       longPrimitiveInstance = new FullyQualifiedJavaType("long");
/* 167:    */     }
/* 168:193 */     return longPrimitiveInstance;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static final FullyQualifiedJavaType getNewMapInstance()
/* 172:    */   {
/* 173:198 */     return new FullyQualifiedJavaType("java.util.Map");
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static final FullyQualifiedJavaType getNewListInstance()
/* 177:    */   {
/* 178:203 */     return new FullyQualifiedJavaType("java.util.List");
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static final FullyQualifiedJavaType getNewHashMapInstance()
/* 182:    */   {
/* 183:208 */     return new FullyQualifiedJavaType("java.util.HashMap");
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static final FullyQualifiedJavaType getNewArrayListInstance()
/* 187:    */   {
/* 188:213 */     return new FullyQualifiedJavaType("java.util.ArrayList");
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static final FullyQualifiedJavaType getNewIteratorInstance()
/* 192:    */   {
/* 193:218 */     return new FullyQualifiedJavaType("java.util.Iterator");
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static final FullyQualifiedJavaType getStringInstance()
/* 197:    */   {
/* 198:222 */     if (stringInstance == null) {
/* 199:223 */       stringInstance = new FullyQualifiedJavaType("java.lang.String");
/* 200:    */     }
/* 201:226 */     return stringInstance;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public static final FullyQualifiedJavaType getBooleanPrimitiveInstance()
/* 205:    */   {
/* 206:230 */     if (booleanPrimitiveInstance == null) {
/* 207:231 */       booleanPrimitiveInstance = new FullyQualifiedJavaType("boolean");
/* 208:    */     }
/* 209:234 */     return booleanPrimitiveInstance;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public static final FullyQualifiedJavaType getObjectInstance()
/* 213:    */   {
/* 214:238 */     if (objectInstance == null) {
/* 215:239 */       objectInstance = new FullyQualifiedJavaType("java.lang.Object");
/* 216:    */     }
/* 217:242 */     return objectInstance;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static final FullyQualifiedJavaType getDateInstance()
/* 221:    */   {
/* 222:246 */     if (dateInstance == null) {
/* 223:247 */       dateInstance = new FullyQualifiedJavaType("java.util.Date");
/* 224:    */     }
/* 225:250 */     return dateInstance;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static final FullyQualifiedJavaType getCriteriaInstance()
/* 229:    */   {
/* 230:254 */     if (criteriaInstance == null) {
/* 231:255 */       criteriaInstance = new FullyQualifiedJavaType("Criteria");
/* 232:    */     }
/* 233:258 */     return criteriaInstance;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public static final FullyQualifiedJavaType getSerializableInstance()
/* 237:    */   {
/* 238:262 */     if (serializableInstance == null) {
/* 239:263 */       serializableInstance = new FullyQualifiedJavaType("java.io.Serializable");
/* 240:    */     }
/* 241:265 */     return serializableInstance;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public int compareTo(Object o)
/* 245:    */   {
/* 246:272 */     return this.fullyQualifiedName.compareTo(((FullyQualifiedJavaType)o).fullyQualifiedName);
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void clearArguments()
/* 250:    */   {
/* 251:276 */     this.typeArguments.clear();
/* 252:    */   }
/* 253:    */   
/* 254:    */   public void addTypeArgument(FullyQualifiedJavaType type)
/* 255:    */   {
/* 256:280 */     this.typeArguments.add(type);
/* 257:    */     
/* 258:282 */     StringBuffer sb = new StringBuffer();
/* 259:283 */     sb.append(this.baseShortName);
/* 260:284 */     sb.append('<');
/* 261:    */     
/* 262:286 */     boolean comma = false;
/* 263:287 */     Iterator iter = this.typeArguments.iterator();
/* 264:288 */     while (iter.hasNext())
/* 265:    */     {
/* 266:289 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 267:290 */       if (comma) {
/* 268:291 */         sb.append(", ");
/* 269:    */       } else {
/* 270:293 */         comma = true;
/* 271:    */       }
/* 272:295 */       sb.append(fqjt.getShortName());
/* 273:    */     }
/* 274:297 */     sb.append('>');
/* 275:298 */     this.calculatedShortName = sb.toString();
/* 276:    */   }
/* 277:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType
 * JD-Core Version:    0.7.0.1
 */