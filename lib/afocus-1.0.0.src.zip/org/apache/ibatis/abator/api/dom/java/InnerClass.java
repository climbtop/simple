/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   9:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  10:    */ 
/*  11:    */ public class InnerClass
/*  12:    */   extends JavaElement
/*  13:    */ {
/*  14:    */   private List fields;
/*  15:    */   private List innerClasses;
/*  16:    */   private List innerEnums;
/*  17:    */   private FullyQualifiedJavaType superClass;
/*  18:    */   private FullyQualifiedJavaType type;
/*  19:    */   private Set superInterfaceTypes;
/*  20:    */   private List methods;
/*  21:    */   
/*  22:    */   public InnerClass(FullyQualifiedJavaType type)
/*  23:    */   {
/*  24: 53 */     this.type = type;
/*  25: 54 */     this.fields = new ArrayList();
/*  26: 55 */     this.innerClasses = new ArrayList();
/*  27: 56 */     this.innerEnums = new ArrayList();
/*  28: 57 */     this.superInterfaceTypes = new HashSet();
/*  29: 58 */     this.methods = new ArrayList();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public List getFields()
/*  33:    */   {
/*  34: 65 */     return this.fields;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void addField(Field field)
/*  38:    */   {
/*  39: 69 */     this.fields.add(field);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public FullyQualifiedJavaType getSuperClass()
/*  43:    */   {
/*  44: 76 */     return this.superClass;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setSuperClass(FullyQualifiedJavaType superClass)
/*  48:    */   {
/*  49: 84 */     this.superClass = superClass;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public List getInnerClasses()
/*  53:    */   {
/*  54: 90 */     return this.innerClasses;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void addInnerClass(InnerClass innerClass)
/*  58:    */   {
/*  59: 94 */     this.innerClasses.add(innerClass);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public List getInnerEnums()
/*  63:    */   {
/*  64: 98 */     return this.innerEnums;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void addInnerEnum(InnerEnum innerEnum)
/*  68:    */   {
/*  69:102 */     this.innerEnums.add(innerEnum);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String getFormattedContent(int indentLevel)
/*  73:    */   {
/*  74:106 */     StringBuffer sb = new StringBuffer();
/*  75:    */     
/*  76:108 */     Iterator iter = getJavaDocLines().iterator();
/*  77:109 */     while (iter.hasNext())
/*  78:    */     {
/*  79:110 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  80:111 */       sb.append(iter.next());
/*  81:112 */       OutputUtilities.newLine(sb);
/*  82:    */     }
/*  83:115 */     iter = getAnnotations().iterator();
/*  84:116 */     while (iter.hasNext())
/*  85:    */     {
/*  86:117 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  87:118 */       sb.append(iter.next());
/*  88:119 */       OutputUtilities.newLine(sb);
/*  89:    */     }
/*  90:122 */     OutputUtilities.javaIndent(sb, indentLevel);
/*  91:123 */     if (getVisibility() == JavaVisibility.PRIVATE) {
/*  92:124 */       sb.append("private ");
/*  93:125 */     } else if (getVisibility() == JavaVisibility.PROTECTED) {
/*  94:126 */       sb.append("protected ");
/*  95:127 */     } else if (getVisibility() == JavaVisibility.PUBLIC) {
/*  96:128 */       sb.append("public ");
/*  97:    */     }
/*  98:131 */     if (isModifierStatic()) {
/*  99:132 */       sb.append("static ");
/* 100:    */     }
/* 101:135 */     if (isModifierFinal()) {
/* 102:136 */       sb.append("final ");
/* 103:    */     }
/* 104:139 */     sb.append("class ");
/* 105:140 */     sb.append(getType().getShortName());
/* 106:142 */     if (this.superClass != null)
/* 107:    */     {
/* 108:143 */       sb.append(" extends ");
/* 109:144 */       sb.append(this.superClass.getShortName());
/* 110:    */     }
/* 111:147 */     if (this.superInterfaceTypes.size() > 0)
/* 112:    */     {
/* 113:148 */       sb.append(" implements ");
/* 114:    */       
/* 115:150 */       iter = this.superInterfaceTypes.iterator();
/* 116:151 */       boolean comma = false;
/* 117:152 */       while (iter.hasNext())
/* 118:    */       {
/* 119:153 */         if (comma) {
/* 120:154 */           sb.append(", ");
/* 121:    */         } else {
/* 122:156 */           comma = true;
/* 123:    */         }
/* 124:159 */         FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 125:160 */         sb.append(fqjt.getShortName());
/* 126:    */       }
/* 127:    */     }
/* 128:164 */     sb.append(" {");
/* 129:165 */     indentLevel++;
/* 130:    */     
/* 131:167 */     iter = this.fields.iterator();
/* 132:168 */     while (iter.hasNext())
/* 133:    */     {
/* 134:169 */       OutputUtilities.newLine(sb);
/* 135:170 */       Field field = (Field)iter.next();
/* 136:171 */       sb.append(field.getFormattedContent(indentLevel));
/* 137:172 */       if (iter.hasNext()) {
/* 138:173 */         OutputUtilities.newLine(sb);
/* 139:    */       }
/* 140:    */     }
/* 141:177 */     if (this.methods.size() > 0) {
/* 142:178 */       OutputUtilities.newLine(sb);
/* 143:    */     }
/* 144:180 */     iter = this.methods.iterator();
/* 145:181 */     while (iter.hasNext())
/* 146:    */     {
/* 147:182 */       OutputUtilities.newLine(sb);
/* 148:183 */       Method method = (Method)iter.next();
/* 149:184 */       sb.append(method.getFormattedContent(indentLevel, false));
/* 150:185 */       if (iter.hasNext()) {
/* 151:186 */         OutputUtilities.newLine(sb);
/* 152:    */       }
/* 153:    */     }
/* 154:190 */     if (this.innerClasses.size() > 0) {
/* 155:191 */       OutputUtilities.newLine(sb);
/* 156:    */     }
/* 157:193 */     iter = this.innerClasses.iterator();
/* 158:194 */     while (iter.hasNext())
/* 159:    */     {
/* 160:195 */       OutputUtilities.newLine(sb);
/* 161:196 */       InnerClass innerClass = (InnerClass)iter.next();
/* 162:197 */       sb.append(innerClass.getFormattedContent(indentLevel));
/* 163:198 */       if (iter.hasNext()) {
/* 164:199 */         OutputUtilities.newLine(sb);
/* 165:    */       }
/* 166:    */     }
/* 167:203 */     if (this.innerEnums.size() > 0) {
/* 168:204 */       OutputUtilities.newLine(sb);
/* 169:    */     }
/* 170:206 */     iter = this.innerEnums.iterator();
/* 171:207 */     while (iter.hasNext())
/* 172:    */     {
/* 173:208 */       OutputUtilities.newLine(sb);
/* 174:209 */       InnerEnum innerEnum = (InnerEnum)iter.next();
/* 175:210 */       sb.append(innerEnum.getFormattedContent(indentLevel));
/* 176:211 */       if (iter.hasNext()) {
/* 177:212 */         OutputUtilities.newLine(sb);
/* 178:    */       }
/* 179:    */     }
/* 180:216 */     indentLevel--;
/* 181:217 */     OutputUtilities.newLine(sb);
/* 182:218 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 183:219 */     sb.append('}');
/* 184:    */     
/* 185:221 */     return sb.toString();
/* 186:    */   }
/* 187:    */   
/* 188:    */   public Set getSuperInterfaceTypes()
/* 189:    */   {
/* 190:228 */     return this.superInterfaceTypes;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void addSuperInterface(FullyQualifiedJavaType superInterface)
/* 194:    */   {
/* 195:232 */     this.superInterfaceTypes.add(superInterface);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public List getMethods()
/* 199:    */   {
/* 200:239 */     return this.methods;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void addMethod(Method method)
/* 204:    */   {
/* 205:243 */     this.methods.add(method);
/* 206:    */   }
/* 207:    */   
/* 208:    */   public FullyQualifiedJavaType getType()
/* 209:    */   {
/* 210:250 */     return this.type;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public void addComment(FullyQualifiedTable table)
/* 214:    */   {
/* 215:254 */     StringBuffer sb = new StringBuffer();
/* 216:    */     
/* 217:256 */     addJavaDocLine("/**");
/* 218:    */     
/* 219:    */ 
/* 220:259 */     sb.append(" * This class corresponds to the database table ");
/* 221:260 */     sb.append(table.getFullyQualifiedTableName());
/* 222:261 */     addJavaDocLine(sb.toString());
/* 223:    */     
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:270 */     addJavaDocLine(" */");
/* 232:    */   }
/* 233:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.InnerClass
 * JD-Core Version:    0.7.0.1
 */