package org.apache.ibatis.abator.api.dom.xml;

public abstract class Element
{
  public abstract String getFormattedContent(int paramInt);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.xml.Element
 * JD-Core Version:    0.7.0.1
 */