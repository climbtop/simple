/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.TreeSet;
/*   9:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  10:    */ 
/*  11:    */ public class TopLevelClass
/*  12:    */   extends InnerClass
/*  13:    */   implements CompilationUnit
/*  14:    */ {
/*  15:    */   private Set importedTypes;
/*  16:    */   private List fileCommentLines;
/*  17:    */   
/*  18:    */   public TopLevelClass(FullyQualifiedJavaType type)
/*  19:    */   {
/*  20: 39 */     super(type);
/*  21: 40 */     this.importedTypes = new TreeSet();
/*  22: 41 */     this.fileCommentLines = new ArrayList();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public Set getImportedTypes()
/*  26:    */   {
/*  27: 48 */     return Collections.unmodifiableSet(this.importedTypes);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void addImportedType(FullyQualifiedJavaType importedType)
/*  31:    */   {
/*  32: 52 */     if ((importedType != null) && (importedType.isExplicitlyImported()) && 
/*  33: 53 */       (!importedType.getPackageName().equals(getType().getPackageName()))) {
/*  34: 54 */       this.importedTypes.add(importedType);
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public String getFormattedContent()
/*  39:    */   {
/*  40: 59 */     StringBuffer sb = new StringBuffer();
/*  41:    */     
/*  42: 61 */     Iterator iter = this.fileCommentLines.iterator();
/*  43: 62 */     while (iter.hasNext())
/*  44:    */     {
/*  45: 63 */       sb.append(iter.next());
/*  46: 64 */       OutputUtilities.newLine(sb);
/*  47:    */     }
/*  48: 67 */     if ((getType().getPackageName() != null) && 
/*  49: 68 */       (getType().getPackageName().length() > 0))
/*  50:    */     {
/*  51: 69 */       sb.append("package ");
/*  52: 70 */       sb.append(getType().getPackageName());
/*  53: 71 */       sb.append(';');
/*  54: 72 */       OutputUtilities.newLine(sb);
/*  55: 73 */       OutputUtilities.newLine(sb);
/*  56:    */     }
/*  57: 76 */     iter = this.importedTypes.iterator();
/*  58: 77 */     String packagePrefix = "";
/*  59: 78 */     while (iter.hasNext())
/*  60:    */     {
/*  61: 79 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  62: 80 */       if (fqjt.isExplicitlyImported())
/*  63:    */       {
/*  64: 81 */         String name = fqjt.getFullyQualifiedName();
/*  65: 82 */         if (packagePrefix.length() == 0) {
/*  66: 83 */           packagePrefix = name.substring(0, name.indexOf('.', name.indexOf(46)));
/*  67:    */         }
/*  68: 85 */         if (!name.startsWith(packagePrefix))
/*  69:    */         {
/*  70: 86 */           packagePrefix = name.substring(0, name.indexOf('.', name.indexOf(46)));
/*  71: 87 */           OutputUtilities.newLine(sb);
/*  72:    */         }
/*  73: 90 */         sb.append("import ");
/*  74: 91 */         sb.append(name);
/*  75: 92 */         sb.append(';');
/*  76: 93 */         OutputUtilities.newLine(sb);
/*  77:    */       }
/*  78:    */     }
/*  79: 97 */     if (this.importedTypes.size() > 0) {
/*  80: 98 */       OutputUtilities.newLine(sb);
/*  81:    */     }
/*  82:101 */     sb.append(super.getFormattedContent(0));
/*  83:    */     
/*  84:103 */     return sb.toString();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean isJavaInterface()
/*  88:    */   {
/*  89:112 */     return false;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isJavaEnumeration()
/*  93:    */   {
/*  94:116 */     return false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void addFileCommentLine(String commentLine)
/*  98:    */   {
/*  99:120 */     this.fileCommentLines.add(commentLine);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public List getFileCommentLines()
/* 103:    */   {
/* 104:124 */     return this.fileCommentLines;
/* 105:    */   }
/* 106:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.TopLevelClass
 * JD-Core Version:    0.7.0.1
 */