/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ public class PrimitiveTypeWrapper
/*   4:    */   extends FullyQualifiedJavaType
/*   5:    */ {
/*   6:    */   private static PrimitiveTypeWrapper booleanInstance;
/*   7:    */   private static PrimitiveTypeWrapper byteInstance;
/*   8:    */   private static PrimitiveTypeWrapper characterInstance;
/*   9:    */   private static PrimitiveTypeWrapper doubleInstance;
/*  10:    */   private static PrimitiveTypeWrapper floatInstance;
/*  11:    */   private static PrimitiveTypeWrapper integerInstance;
/*  12:    */   private static PrimitiveTypeWrapper longInstance;
/*  13:    */   private static PrimitiveTypeWrapper shortInstance;
/*  14:    */   private String toPrimitiveMethod;
/*  15:    */   
/*  16:    */   private PrimitiveTypeWrapper(String fullyQualifiedName, String toPrimitiveMethod)
/*  17:    */   {
/*  18: 43 */     super(fullyQualifiedName);
/*  19: 44 */     this.toPrimitiveMethod = toPrimitiveMethod;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public String getToPrimitiveMethod()
/*  23:    */   {
/*  24: 48 */     return this.toPrimitiveMethod;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static PrimitiveTypeWrapper getBooleanInstance()
/*  28:    */   {
/*  29: 52 */     if (booleanInstance == null) {
/*  30: 53 */       booleanInstance = new PrimitiveTypeWrapper("java.lang.Boolean", 
/*  31: 54 */         "booleanValue()");
/*  32:    */     }
/*  33: 57 */     return booleanInstance;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static PrimitiveTypeWrapper getByteInstance()
/*  37:    */   {
/*  38: 61 */     if (byteInstance == null) {
/*  39: 62 */       byteInstance = new PrimitiveTypeWrapper("java.lang.Byte", 
/*  40: 63 */         "byteValue()");
/*  41:    */     }
/*  42: 66 */     return byteInstance;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static PrimitiveTypeWrapper getCharacterInstance()
/*  46:    */   {
/*  47: 70 */     if (characterInstance == null) {
/*  48: 71 */       characterInstance = new PrimitiveTypeWrapper("java.lang.Character", 
/*  49: 72 */         "charValue()");
/*  50:    */     }
/*  51: 75 */     return characterInstance;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static PrimitiveTypeWrapper getDoubleInstance()
/*  55:    */   {
/*  56: 79 */     if (doubleInstance == null) {
/*  57: 80 */       doubleInstance = new PrimitiveTypeWrapper("java.lang.Double", 
/*  58: 81 */         "doubleValue()");
/*  59:    */     }
/*  60: 84 */     return doubleInstance;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static PrimitiveTypeWrapper getFloatInstance()
/*  64:    */   {
/*  65: 88 */     if (floatInstance == null) {
/*  66: 89 */       floatInstance = new PrimitiveTypeWrapper("java.lang.Float", 
/*  67: 90 */         "floatValue()");
/*  68:    */     }
/*  69: 93 */     return floatInstance;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static PrimitiveTypeWrapper getIntegerInstance()
/*  73:    */   {
/*  74: 97 */     if (integerInstance == null) {
/*  75: 98 */       integerInstance = new PrimitiveTypeWrapper("java.lang.Integer", 
/*  76: 99 */         "intValue()");
/*  77:    */     }
/*  78:102 */     return integerInstance;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static PrimitiveTypeWrapper getLongInstance()
/*  82:    */   {
/*  83:106 */     if (longInstance == null) {
/*  84:107 */       longInstance = new PrimitiveTypeWrapper("java.lang.Long", 
/*  85:108 */         "longValue()");
/*  86:    */     }
/*  87:111 */     return longInstance;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static PrimitiveTypeWrapper getShortInstance()
/*  91:    */   {
/*  92:115 */     if (shortInstance == null) {
/*  93:116 */       shortInstance = new PrimitiveTypeWrapper("java.lang.Short", 
/*  94:117 */         "shortValue()");
/*  95:    */     }
/*  96:120 */     return shortInstance;
/*  97:    */   }
/*  98:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.PrimitiveTypeWrapper
 * JD-Core Version:    0.7.0.1
 */