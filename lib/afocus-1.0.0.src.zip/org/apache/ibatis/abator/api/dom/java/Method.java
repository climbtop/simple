/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.ListIterator;
/*   7:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   8:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*   9:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  10:    */ 
/*  11:    */ public class Method
/*  12:    */   extends JavaElement
/*  13:    */ {
/*  14:    */   private List bodyLines;
/*  15:    */   private boolean constructor;
/*  16:    */   private FullyQualifiedJavaType returnType;
/*  17:    */   private String name;
/*  18:    */   private List parameters;
/*  19:    */   private List exceptions;
/*  20:    */   
/*  21:    */   public Method()
/*  22:    */   {
/*  23: 49 */     this.bodyLines = new ArrayList();
/*  24: 50 */     this.parameters = new ArrayList();
/*  25: 51 */     this.exceptions = new ArrayList();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public List getBodyLines()
/*  29:    */   {
/*  30: 58 */     return this.bodyLines;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void addBodyLine(String line)
/*  34:    */   {
/*  35: 62 */     this.bodyLines.add(line);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public String getFormattedContent(int indentLevel, boolean interfaceMethod)
/*  39:    */   {
/*  40: 66 */     StringBuffer sb = new StringBuffer();
/*  41:    */     
/*  42: 68 */     Iterator iter = getJavaDocLines().iterator();
/*  43: 69 */     while (iter.hasNext())
/*  44:    */     {
/*  45: 70 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  46: 71 */       sb.append(iter.next());
/*  47: 72 */       OutputUtilities.newLine(sb);
/*  48:    */     }
/*  49: 75 */     iter = getAnnotations().iterator();
/*  50: 76 */     while (iter.hasNext())
/*  51:    */     {
/*  52: 77 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  53: 78 */       sb.append(iter.next());
/*  54: 79 */       OutputUtilities.newLine(sb);
/*  55:    */     }
/*  56: 82 */     OutputUtilities.javaIndent(sb, indentLevel);
/*  57: 84 */     if (!interfaceMethod)
/*  58:    */     {
/*  59: 85 */       if (getVisibility() == JavaVisibility.PRIVATE) {
/*  60: 86 */         sb.append("private ");
/*  61: 87 */       } else if (getVisibility() == JavaVisibility.PROTECTED) {
/*  62: 88 */         sb.append("protected ");
/*  63: 89 */       } else if (getVisibility() == JavaVisibility.PUBLIC) {
/*  64: 90 */         sb.append("public ");
/*  65:    */       }
/*  66: 93 */       if (isModifierStatic()) {
/*  67: 94 */         sb.append("static ");
/*  68:    */       }
/*  69: 97 */       if (isModifierFinal()) {
/*  70: 98 */         sb.append("final ");
/*  71:    */       }
/*  72:101 */       if (this.bodyLines.size() == 0) {
/*  73:102 */         sb.append("abstract ");
/*  74:    */       }
/*  75:    */     }
/*  76:106 */     if (!this.constructor)
/*  77:    */     {
/*  78:107 */       if (getReturnType() == null) {
/*  79:108 */         sb.append("void");
/*  80:    */       } else {
/*  81:110 */         sb.append(getReturnType().getShortName());
/*  82:    */       }
/*  83:112 */       sb.append(' ');
/*  84:    */     }
/*  85:115 */     sb.append(getName());
/*  86:116 */     sb.append('(');
/*  87:    */     
/*  88:118 */     iter = getParameters().iterator();
/*  89:119 */     boolean comma = false;
/*  90:120 */     while (iter.hasNext())
/*  91:    */     {
/*  92:121 */       if (comma) {
/*  93:122 */         sb.append(", ");
/*  94:    */       } else {
/*  95:124 */         comma = true;
/*  96:    */       }
/*  97:127 */       Parameter parameter = (Parameter)iter.next();
/*  98:128 */       for (String annotation : parameter.getAnnotations()) {
/*  99:129 */         sb.append(annotation).append(' ');
/* 100:    */       }
/* 101:131 */       sb.append(parameter.getType().getShortName());
/* 102:132 */       sb.append(' ');
/* 103:133 */       sb.append(parameter.getName());
/* 104:    */     }
/* 105:136 */     sb.append(')');
/* 106:138 */     if (getExceptions().size() > 0)
/* 107:    */     {
/* 108:139 */       sb.append(" throws ");
/* 109:140 */       iter = getExceptions().iterator();
/* 110:141 */       comma = false;
/* 111:142 */       while (iter.hasNext())
/* 112:    */       {
/* 113:143 */         if (comma) {
/* 114:144 */           sb.append(", ");
/* 115:    */         } else {
/* 116:146 */           comma = true;
/* 117:    */         }
/* 118:149 */         FullyQualifiedJavaType fqjt = 
/* 119:150 */           (FullyQualifiedJavaType)iter.next();
/* 120:151 */         sb.append(fqjt.getShortName());
/* 121:    */       }
/* 122:    */     }
/* 123:156 */     if (this.bodyLines.size() == 0)
/* 124:    */     {
/* 125:157 */       sb.append(';');
/* 126:    */     }
/* 127:    */     else
/* 128:    */     {
/* 129:159 */       sb.append(" {");
/* 130:160 */       indentLevel++;
/* 131:    */       
/* 132:162 */       ListIterator listIter = this.bodyLines.listIterator();
/* 133:163 */       while (listIter.hasNext())
/* 134:    */       {
/* 135:164 */         String line = (String)listIter.next();
/* 136:165 */         if (line.startsWith("}")) {
/* 137:166 */           indentLevel--;
/* 138:    */         }
/* 139:169 */         OutputUtilities.newLine(sb);
/* 140:170 */         OutputUtilities.javaIndent(sb, indentLevel);
/* 141:171 */         sb.append(line);
/* 142:173 */         if (((line.endsWith("{")) && (!line.startsWith("switch"))) || 
/* 143:174 */           (line.endsWith(":"))) {
/* 144:175 */           indentLevel++;
/* 145:    */         }
/* 146:178 */         if (line.startsWith("break"))
/* 147:    */         {
/* 148:180 */           if (listIter.hasNext())
/* 149:    */           {
/* 150:181 */             String nextLine = (String)listIter.next();
/* 151:182 */             if (nextLine.startsWith("}")) {
/* 152:183 */               indentLevel++;
/* 153:    */             }
/* 154:187 */             listIter.previous();
/* 155:    */           }
/* 156:189 */           indentLevel--;
/* 157:    */         }
/* 158:    */       }
/* 159:193 */       indentLevel--;
/* 160:194 */       OutputUtilities.newLine(sb);
/* 161:195 */       OutputUtilities.javaIndent(sb, indentLevel);
/* 162:196 */       sb.append('}');
/* 163:    */     }
/* 164:199 */     return sb.toString();
/* 165:    */   }
/* 166:    */   
/* 167:    */   public boolean isConstructor()
/* 168:    */   {
/* 169:206 */     return this.constructor;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setConstructor(boolean constructor)
/* 173:    */   {
/* 174:214 */     this.constructor = constructor;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public String getName()
/* 178:    */   {
/* 179:221 */     return this.name;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setName(String name)
/* 183:    */   {
/* 184:229 */     this.name = name;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public List getParameters()
/* 188:    */   {
/* 189:233 */     return this.parameters;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void addParameter(Parameter parameter)
/* 193:    */   {
/* 194:237 */     this.parameters.add(parameter);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public FullyQualifiedJavaType getReturnType()
/* 198:    */   {
/* 199:244 */     return this.returnType;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setReturnType(FullyQualifiedJavaType returnType)
/* 203:    */   {
/* 204:252 */     this.returnType = returnType;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public List getExceptions()
/* 208:    */   {
/* 209:259 */     return this.exceptions;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void addException(FullyQualifiedJavaType exception)
/* 213:    */   {
/* 214:263 */     this.exceptions.add(exception);
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void addGetterComment(FullyQualifiedTable table, ColumnDefinition columnDefinition)
/* 218:    */   {
/* 219:267 */     StringBuffer sb = new StringBuffer();
/* 220:    */     
/* 221:269 */     addJavaDocLine("/**");
/* 222:    */     
/* 223:    */ 
/* 224:272 */     sb.append(" * This method returns the value of the database column ");
/* 225:273 */     sb.append(table.getFullyQualifiedTableName());
/* 226:274 */     sb.append('.');
/* 227:275 */     sb.append(columnDefinition.getColumnName());
/* 228:276 */     addJavaDocLine(sb.toString());
/* 229:    */     
/* 230:278 */     addJavaDocLine(" *");
/* 231:    */     
/* 232:280 */     sb.setLength(0);
/* 233:281 */     sb.append(" * @return the value of ");
/* 234:282 */     sb.append(table.getFullyQualifiedTableName());
/* 235:283 */     sb.append('.');
/* 236:284 */     sb.append(columnDefinition.getColumnName());
/* 237:285 */     addJavaDocLine(sb.toString());
/* 238:    */     
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:294 */     addJavaDocLine(" */");
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void addSetterComment(FullyQualifiedTable table, ColumnDefinition columnDefinition)
/* 250:    */   {
/* 251:298 */     StringBuffer sb = new StringBuffer();
/* 252:    */     
/* 253:300 */     addJavaDocLine("/**");
/* 254:    */     
/* 255:    */ 
/* 256:303 */     sb.append(" * This method sets the value of the database column ");
/* 257:304 */     sb.append(table.getFullyQualifiedTableName());
/* 258:305 */     sb.append('.');
/* 259:306 */     sb.append(columnDefinition.getColumnName());
/* 260:307 */     addJavaDocLine(sb.toString());
/* 261:    */     
/* 262:309 */     addJavaDocLine(" *");
/* 263:    */     
/* 264:311 */     sb.setLength(0);
/* 265:312 */     sb.append(" * @param ");
/* 266:313 */     sb.append(columnDefinition.getJavaProperty());
/* 267:314 */     sb.append(" the value for ");
/* 268:315 */     sb.append(table.getFullyQualifiedTableName());
/* 269:316 */     sb.append('.');
/* 270:317 */     sb.append(columnDefinition.getColumnName());
/* 271:318 */     addJavaDocLine(sb.toString());
/* 272:    */     
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:327 */     addJavaDocLine(" */");
/* 281:    */   }
/* 282:    */   
/* 283:    */   public void addComment(FullyQualifiedTable table) {}
/* 284:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.Method
 * JD-Core Version:    0.7.0.1
 */