/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public abstract class JavaElement
/*   7:    */ {
/*   8:    */   private List javaDocLines;
/*   9:    */   private JavaVisibility visibility;
/*  10:    */   private boolean modifierStatic;
/*  11:    */   private boolean modifierFinal;
/*  12:    */   private List annotations;
/*  13:    */   
/*  14:    */   public JavaElement()
/*  15:    */   {
/*  16: 40 */     this.javaDocLines = new ArrayList();
/*  17: 41 */     this.annotations = new ArrayList();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public List getJavaDocLines()
/*  21:    */   {
/*  22: 48 */     return this.javaDocLines;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void addJavaDocLine(String javaDocLine)
/*  26:    */   {
/*  27: 52 */     this.javaDocLines.add(javaDocLine);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public List getAnnotations()
/*  31:    */   {
/*  32: 56 */     return this.annotations;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void addAnnotation(String annotation)
/*  36:    */   {
/*  37: 60 */     this.annotations.add(annotation);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isModifierFinal()
/*  41:    */   {
/*  42: 67 */     return this.modifierFinal;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setModifierFinal(boolean modifierFinal)
/*  46:    */   {
/*  47: 75 */     this.modifierFinal = modifierFinal;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean isModifierStatic()
/*  51:    */   {
/*  52: 82 */     return this.modifierStatic;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setModifierStatic(boolean modifierStatic)
/*  56:    */   {
/*  57: 90 */     this.modifierStatic = modifierStatic;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public JavaVisibility getVisibility()
/*  61:    */   {
/*  62: 97 */     return this.visibility;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setVisibility(JavaVisibility visibility)
/*  66:    */   {
/*  67:105 */     this.visibility = visibility;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void addSuppressTypeWarningsAnnotation()
/*  71:    */   {
/*  72:109 */     addAnnotation("@SuppressWarnings(\"unchecked\")");
/*  73:    */   }
/*  74:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.JavaElement
 * JD-Core Version:    0.7.0.1
 */