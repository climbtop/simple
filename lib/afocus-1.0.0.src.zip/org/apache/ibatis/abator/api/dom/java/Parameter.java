/*  1:   */ package org.apache.ibatis.abator.api.dom.java;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class Parameter
/*  7:   */ {
/*  8:   */   private String name;
/*  9:   */   private FullyQualifiedJavaType type;
/* 10:   */   private List<String> annotations;
/* 11:   */   
/* 12:   */   public Parameter(FullyQualifiedJavaType type, String name)
/* 13:   */   {
/* 14:33 */     this.name = name;
/* 15:34 */     this.type = type;
/* 16:35 */     this.annotations = new ArrayList();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Parameter(String annotation, FullyQualifiedJavaType type, String name)
/* 20:   */   {
/* 21:39 */     this(type, name);
/* 22:40 */     addAnnotation(annotation);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public List<String> getAnnotations()
/* 26:   */   {
/* 27:44 */     return this.annotations;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void addAnnotation(String annotation)
/* 31:   */   {
/* 32:48 */     this.annotations.add(annotation);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getName()
/* 36:   */   {
/* 37:55 */     return this.name;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public FullyQualifiedJavaType getType()
/* 41:   */   {
/* 42:62 */     return this.type;
/* 43:   */   }
/* 44:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.Parameter
 * JD-Core Version:    0.7.0.1
 */