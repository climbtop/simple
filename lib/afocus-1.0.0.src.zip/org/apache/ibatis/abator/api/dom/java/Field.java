/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   6:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*   7:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   8:    */ 
/*   9:    */ public class Field
/*  10:    */   extends JavaElement
/*  11:    */ {
/*  12:    */   private FullyQualifiedJavaType type;
/*  13:    */   private String name;
/*  14:    */   private String initializationString;
/*  15:    */   
/*  16:    */   public String getName()
/*  17:    */   {
/*  18: 44 */     return this.name;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setName(String name)
/*  22:    */   {
/*  23: 52 */     this.name = name;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public FullyQualifiedJavaType getType()
/*  27:    */   {
/*  28: 59 */     return this.type;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setType(FullyQualifiedJavaType type)
/*  32:    */   {
/*  33: 67 */     this.type = type;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getInitializationString()
/*  37:    */   {
/*  38: 73 */     return this.initializationString;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setInitializationString(String initializationString)
/*  42:    */   {
/*  43: 79 */     this.initializationString = initializationString;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getFormattedContent(int indentLevel)
/*  47:    */   {
/*  48: 83 */     StringBuffer sb = new StringBuffer();
/*  49:    */     
/*  50: 85 */     Iterator iter = getJavaDocLines().iterator();
/*  51: 86 */     while (iter.hasNext())
/*  52:    */     {
/*  53: 87 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  54: 88 */       sb.append(iter.next());
/*  55: 89 */       OutputUtilities.newLine(sb);
/*  56:    */     }
/*  57: 92 */     iter = getAnnotations().iterator();
/*  58: 93 */     while (iter.hasNext())
/*  59:    */     {
/*  60: 94 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  61: 95 */       sb.append(iter.next());
/*  62: 96 */       OutputUtilities.newLine(sb);
/*  63:    */     }
/*  64: 99 */     OutputUtilities.javaIndent(sb, indentLevel);
/*  65:100 */     if (getVisibility() == JavaVisibility.PRIVATE) {
/*  66:101 */       sb.append("private ");
/*  67:102 */     } else if (getVisibility() == JavaVisibility.PROTECTED) {
/*  68:103 */       sb.append("protected ");
/*  69:104 */     } else if (getVisibility() == JavaVisibility.PUBLIC) {
/*  70:105 */       sb.append("public ");
/*  71:    */     }
/*  72:108 */     if (isModifierStatic()) {
/*  73:109 */       sb.append("static ");
/*  74:    */     }
/*  75:112 */     if (isModifierFinal()) {
/*  76:113 */       sb.append("final ");
/*  77:    */     }
/*  78:116 */     sb.append(this.type.getShortName());
/*  79:    */     
/*  80:118 */     sb.append(' ');
/*  81:119 */     sb.append(this.name);
/*  82:121 */     if ((this.initializationString != null) && (this.initializationString.length() > 0))
/*  83:    */     {
/*  84:122 */       sb.append(" = ");
/*  85:123 */       if (this.type.getBaseShortName().equalsIgnoreCase("String")) {
/*  86:124 */         sb.append("\"").append(this.initializationString.replace("\"", "\\\"")).append("\"");
/*  87:    */       } else {
/*  88:127 */         sb.append(this.initializationString);
/*  89:    */       }
/*  90:    */     }
/*  91:130 */     sb.append(';');
/*  92:    */     
/*  93:132 */     return sb.toString();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void addComment(FullyQualifiedTable table, String columnName, String label, String columnMemo)
/*  97:    */   {
/*  98:136 */     StringBuffer sb = new StringBuffer();
/*  99:    */     
/* 100:138 */     addJavaDocLine("/**");
/* 101:    */     
/* 102:    */ 
/* 103:141 */     sb.append(" * This field corresponds to the database column ");
/* 104:142 */     sb.append(table.getFullyQualifiedTableName());
/* 105:143 */     sb.append('.');
/* 106:144 */     sb.append(columnName);
/* 107:145 */     addJavaDocLine(sb.toString());
/* 108:146 */     sb.setLength(0);
/* 109:147 */     if (!this.name.equalsIgnoreCase(label)) {
/* 110:148 */       sb.append(" * ").append(label);
/* 111:    */     }
/* 112:149 */     if (StringUtility.stringHasValue(columnMemo)) {
/* 113:150 */       sb.append(sb.length() > 0 ? ", " : " * ").append(columnMemo);
/* 114:    */     }
/* 115:152 */     if (sb.length() > 0) {
/* 116:153 */       addJavaDocLine(sb.toString());
/* 117:    */     }
/* 118:161 */     addJavaDocLine(" */");
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void addComment(FullyQualifiedTable table) {}
/* 122:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.Field
 * JD-Core Version:    0.7.0.1
 */