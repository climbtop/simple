/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.LinkedHashSet;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Set;
/*   9:    */ import java.util.TreeSet;
/*  10:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  11:    */ 
/*  12:    */ public class Interface
/*  13:    */   extends JavaElement
/*  14:    */   implements CompilationUnit
/*  15:    */ {
/*  16:    */   private Set importedTypes;
/*  17:    */   private FullyQualifiedJavaType type;
/*  18:    */   private Set superInterfaceTypes;
/*  19:    */   private List methods;
/*  20:    */   private List fileCommentLines;
/*  21:    */   
/*  22:    */   public Interface(FullyQualifiedJavaType type)
/*  23:    */   {
/*  24: 47 */     this.type = type;
/*  25: 48 */     this.superInterfaceTypes = new LinkedHashSet();
/*  26: 49 */     this.methods = new ArrayList();
/*  27: 50 */     this.importedTypes = new TreeSet();
/*  28: 51 */     this.fileCommentLines = new ArrayList();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Set getImportedTypes()
/*  32:    */   {
/*  33: 55 */     return Collections.unmodifiableSet(this.importedTypes);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void addImportedType(FullyQualifiedJavaType importedType)
/*  37:    */   {
/*  38: 59 */     if ((importedType.isExplicitlyImported()) && 
/*  39: 60 */       (!importedType.getPackageName().equals(this.type.getPackageName()))) {
/*  40: 61 */       this.importedTypes.add(importedType);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String getFormattedContent()
/*  45:    */   {
/*  46: 66 */     StringBuffer sb = new StringBuffer();
/*  47:    */     
/*  48: 68 */     Iterator iter = this.fileCommentLines.iterator();
/*  49: 69 */     while (iter.hasNext())
/*  50:    */     {
/*  51: 70 */       sb.append(iter.next());
/*  52: 71 */       OutputUtilities.newLine(sb);
/*  53:    */     }
/*  54: 74 */     if ((getType().getPackageName() != null) && 
/*  55: 75 */       (getType().getPackageName().length() > 0))
/*  56:    */     {
/*  57: 76 */       sb.append("package ");
/*  58: 77 */       sb.append(getType().getPackageName());
/*  59: 78 */       sb.append(';');
/*  60: 79 */       OutputUtilities.newLine(sb);
/*  61: 80 */       OutputUtilities.newLine(sb);
/*  62:    */     }
/*  63: 83 */     iter = this.importedTypes.iterator();
/*  64: 84 */     while (iter.hasNext())
/*  65:    */     {
/*  66: 85 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  67: 86 */       if (fqjt.isExplicitlyImported())
/*  68:    */       {
/*  69: 87 */         sb.append("import ");
/*  70: 88 */         sb.append(fqjt.getFullyQualifiedName());
/*  71: 89 */         sb.append(';');
/*  72: 90 */         OutputUtilities.newLine(sb);
/*  73:    */       }
/*  74:    */     }
/*  75: 94 */     if (this.importedTypes.size() > 0) {
/*  76: 95 */       OutputUtilities.newLine(sb);
/*  77:    */     }
/*  78: 98 */     int indentLevel = 0;
/*  79:    */     
/*  80:100 */     iter = getJavaDocLines().iterator();
/*  81:101 */     while (iter.hasNext())
/*  82:    */     {
/*  83:102 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  84:103 */       sb.append(iter.next());
/*  85:104 */       OutputUtilities.newLine(sb);
/*  86:    */     }
/*  87:107 */     iter = getAnnotations().iterator();
/*  88:108 */     while (iter.hasNext())
/*  89:    */     {
/*  90:109 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  91:110 */       sb.append(iter.next());
/*  92:111 */       OutputUtilities.newLine(sb);
/*  93:    */     }
/*  94:114 */     OutputUtilities.javaIndent(sb, indentLevel);
/*  95:115 */     if (getVisibility() == JavaVisibility.PRIVATE) {
/*  96:116 */       sb.append("private ");
/*  97:117 */     } else if (getVisibility() == JavaVisibility.PROTECTED) {
/*  98:118 */       sb.append("protected ");
/*  99:119 */     } else if (getVisibility() == JavaVisibility.PUBLIC) {
/* 100:120 */       sb.append("public ");
/* 101:    */     }
/* 102:123 */     if (isModifierStatic()) {
/* 103:124 */       sb.append("static ");
/* 104:    */     }
/* 105:127 */     if (isModifierFinal()) {
/* 106:128 */       sb.append("final ");
/* 107:    */     }
/* 108:131 */     sb.append("interface ");
/* 109:132 */     sb.append(getType().getShortName());
/* 110:134 */     if (getSuperInterfaceTypes().size() > 0)
/* 111:    */     {
/* 112:135 */       sb.append(" extends ");
/* 113:    */       
/* 114:137 */       iter = getSuperInterfaceTypes().iterator();
/* 115:138 */       boolean comma = false;
/* 116:139 */       while (iter.hasNext())
/* 117:    */       {
/* 118:140 */         if (comma) {
/* 119:141 */           sb.append(", ");
/* 120:    */         } else {
/* 121:143 */           comma = true;
/* 122:    */         }
/* 123:146 */         FullyQualifiedJavaType fqjt = 
/* 124:147 */           (FullyQualifiedJavaType)iter.next();
/* 125:148 */         sb.append(fqjt.getShortName());
/* 126:    */       }
/* 127:    */     }
/* 128:152 */     sb.append(" {");
/* 129:153 */     indentLevel++;
/* 130:    */     
/* 131:155 */     iter = getMethods().iterator();
/* 132:156 */     while (iter.hasNext())
/* 133:    */     {
/* 134:157 */       OutputUtilities.newLine(sb);
/* 135:158 */       Method method = (Method)iter.next();
/* 136:159 */       sb.append(method.getFormattedContent(indentLevel, true));
/* 137:160 */       if (iter.hasNext()) {
/* 138:161 */         OutputUtilities.newLine(sb);
/* 139:    */       }
/* 140:    */     }
/* 141:165 */     indentLevel--;
/* 142:166 */     OutputUtilities.newLine(sb);
/* 143:167 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 144:168 */     sb.append('}');
/* 145:    */     
/* 146:170 */     return sb.toString();
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void addSuperInterface(FullyQualifiedJavaType superInterface)
/* 150:    */   {
/* 151:174 */     this.superInterfaceTypes.add(superInterface);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public List getMethods()
/* 155:    */   {
/* 156:181 */     return this.methods;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void addMethod(Method method)
/* 160:    */   {
/* 161:185 */     this.methods.add(method);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public FullyQualifiedJavaType getType()
/* 165:    */   {
/* 166:192 */     return this.type;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public FullyQualifiedJavaType getSuperClass()
/* 170:    */   {
/* 171:202 */     return null;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public Set getSuperInterfaceTypes()
/* 175:    */   {
/* 176:211 */     return this.superInterfaceTypes;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public boolean isJavaInterface()
/* 180:    */   {
/* 181:220 */     return true;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public boolean isJavaEnumeration()
/* 185:    */   {
/* 186:224 */     return false;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void addFileCommentLine(String commentLine)
/* 190:    */   {
/* 191:228 */     this.fileCommentLines.add(commentLine);
/* 192:    */   }
/* 193:    */   
/* 194:    */   public List getFileCommentLines()
/* 195:    */   {
/* 196:232 */     return this.fileCommentLines;
/* 197:    */   }
/* 198:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.Interface
 * JD-Core Version:    0.7.0.1
 */