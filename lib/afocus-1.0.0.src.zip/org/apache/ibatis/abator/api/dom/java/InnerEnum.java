/*   1:    */ package org.apache.ibatis.abator.api.dom.java;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   9:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  10:    */ 
/*  11:    */ public class InnerEnum
/*  12:    */   extends JavaElement
/*  13:    */ {
/*  14:    */   private List fields;
/*  15:    */   private List innerClasses;
/*  16:    */   private List innerEnums;
/*  17:    */   private FullyQualifiedJavaType type;
/*  18:    */   private Set superInterfaceTypes;
/*  19:    */   private List methods;
/*  20:    */   private List enumConstants;
/*  21:    */   
/*  22:    */   public InnerEnum(FullyQualifiedJavaType type)
/*  23:    */   {
/*  24: 55 */     this.type = type;
/*  25: 56 */     this.fields = new ArrayList();
/*  26: 57 */     this.innerClasses = new ArrayList();
/*  27: 58 */     this.innerEnums = new ArrayList();
/*  28: 59 */     this.superInterfaceTypes = new HashSet();
/*  29: 60 */     this.methods = new ArrayList();
/*  30: 61 */     this.enumConstants = new ArrayList();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public List getFields()
/*  34:    */   {
/*  35: 68 */     return this.fields;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void addField(Field field)
/*  39:    */   {
/*  40: 72 */     this.fields.add(field);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public List getInnerClasses()
/*  44:    */   {
/*  45: 79 */     return this.innerClasses;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void addInnerClass(InnerClass innerClass)
/*  49:    */   {
/*  50: 83 */     this.innerClasses.add(innerClass);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public List getInnerEnums()
/*  54:    */   {
/*  55: 87 */     return this.innerEnums;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void addInnerEnum(InnerEnum innerEnum)
/*  59:    */   {
/*  60: 91 */     this.innerEnums.add(innerEnum);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public List getEnumConstants()
/*  64:    */   {
/*  65: 95 */     return this.enumConstants;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void addEnumConstant(String enumConstant)
/*  69:    */   {
/*  70: 99 */     this.enumConstants.add(enumConstant);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public String getFormattedContent(int indentLevel)
/*  74:    */   {
/*  75:103 */     StringBuffer sb = new StringBuffer();
/*  76:    */     
/*  77:105 */     Iterator iter = getJavaDocLines().iterator();
/*  78:106 */     while (iter.hasNext())
/*  79:    */     {
/*  80:107 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  81:108 */       sb.append(iter.next());
/*  82:109 */       OutputUtilities.newLine(sb);
/*  83:    */     }
/*  84:112 */     iter = getAnnotations().iterator();
/*  85:113 */     while (iter.hasNext())
/*  86:    */     {
/*  87:114 */       OutputUtilities.javaIndent(sb, indentLevel);
/*  88:115 */       sb.append(iter.next());
/*  89:116 */       OutputUtilities.newLine(sb);
/*  90:    */     }
/*  91:119 */     OutputUtilities.javaIndent(sb, indentLevel);
/*  92:120 */     if (getVisibility() == JavaVisibility.PUBLIC) {
/*  93:121 */       sb.append("public ");
/*  94:    */     }
/*  95:124 */     sb.append("enum ");
/*  96:125 */     sb.append(getType().getShortName());
/*  97:127 */     if (this.superInterfaceTypes.size() > 0)
/*  98:    */     {
/*  99:128 */       sb.append(" implements ");
/* 100:    */       
/* 101:130 */       iter = this.superInterfaceTypes.iterator();
/* 102:131 */       boolean comma = false;
/* 103:132 */       while (iter.hasNext())
/* 104:    */       {
/* 105:133 */         if (comma) {
/* 106:134 */           sb.append(", ");
/* 107:    */         } else {
/* 108:136 */           comma = true;
/* 109:    */         }
/* 110:139 */         FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 111:140 */         sb.append(fqjt.getShortName());
/* 112:    */       }
/* 113:    */     }
/* 114:144 */     sb.append(" {");
/* 115:145 */     indentLevel++;
/* 116:    */     
/* 117:147 */     iter = this.enumConstants.iterator();
/* 118:148 */     while (iter.hasNext())
/* 119:    */     {
/* 120:149 */       OutputUtilities.newLine(sb);
/* 121:150 */       OutputUtilities.javaIndent(sb, indentLevel);
/* 122:151 */       String enumConstant = (String)iter.next();
/* 123:152 */       sb.append(enumConstant);
/* 124:154 */       if (iter.hasNext()) {
/* 125:155 */         sb.append(',');
/* 126:    */       } else {
/* 127:157 */         sb.append(';');
/* 128:    */       }
/* 129:    */     }
/* 130:161 */     if (this.fields.size() > 0) {
/* 131:162 */       OutputUtilities.newLine(sb);
/* 132:    */     }
/* 133:164 */     iter = this.fields.iterator();
/* 134:165 */     while (iter.hasNext())
/* 135:    */     {
/* 136:166 */       OutputUtilities.newLine(sb);
/* 137:167 */       Field field = (Field)iter.next();
/* 138:168 */       sb.append(field.getFormattedContent(indentLevel));
/* 139:169 */       if (iter.hasNext()) {
/* 140:170 */         OutputUtilities.newLine(sb);
/* 141:    */       }
/* 142:    */     }
/* 143:174 */     if (this.methods.size() > 0) {
/* 144:175 */       OutputUtilities.newLine(sb);
/* 145:    */     }
/* 146:177 */     iter = this.methods.iterator();
/* 147:178 */     while (iter.hasNext())
/* 148:    */     {
/* 149:179 */       OutputUtilities.newLine(sb);
/* 150:180 */       Method method = (Method)iter.next();
/* 151:181 */       sb.append(method.getFormattedContent(indentLevel, false));
/* 152:182 */       if (iter.hasNext()) {
/* 153:183 */         OutputUtilities.newLine(sb);
/* 154:    */       }
/* 155:    */     }
/* 156:187 */     if (this.innerClasses.size() > 0) {
/* 157:188 */       OutputUtilities.newLine(sb);
/* 158:    */     }
/* 159:190 */     iter = this.innerClasses.iterator();
/* 160:191 */     while (iter.hasNext())
/* 161:    */     {
/* 162:192 */       OutputUtilities.newLine(sb);
/* 163:193 */       InnerClass innerClass = (InnerClass)iter.next();
/* 164:194 */       sb.append(innerClass.getFormattedContent(indentLevel));
/* 165:195 */       if (iter.hasNext()) {
/* 166:196 */         OutputUtilities.newLine(sb);
/* 167:    */       }
/* 168:    */     }
/* 169:200 */     if (this.innerEnums.size() > 0) {
/* 170:201 */       OutputUtilities.newLine(sb);
/* 171:    */     }
/* 172:203 */     iter = this.innerEnums.iterator();
/* 173:204 */     while (iter.hasNext())
/* 174:    */     {
/* 175:205 */       OutputUtilities.newLine(sb);
/* 176:206 */       InnerEnum innerEnum = (InnerEnum)iter.next();
/* 177:207 */       sb.append(innerEnum.getFormattedContent(indentLevel));
/* 178:208 */       if (iter.hasNext()) {
/* 179:209 */         OutputUtilities.newLine(sb);
/* 180:    */       }
/* 181:    */     }
/* 182:213 */     indentLevel--;
/* 183:214 */     OutputUtilities.newLine(sb);
/* 184:215 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 185:216 */     sb.append('}');
/* 186:    */     
/* 187:218 */     return sb.toString();
/* 188:    */   }
/* 189:    */   
/* 190:    */   public Set getSuperInterfaceTypes()
/* 191:    */   {
/* 192:225 */     return this.superInterfaceTypes;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void addSuperInterface(FullyQualifiedJavaType superInterface)
/* 196:    */   {
/* 197:229 */     this.superInterfaceTypes.add(superInterface);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public List getMethods()
/* 201:    */   {
/* 202:236 */     return this.methods;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void addMethod(Method method)
/* 206:    */   {
/* 207:240 */     this.methods.add(method);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public FullyQualifiedJavaType getType()
/* 211:    */   {
/* 212:247 */     return this.type;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void addComment(FullyQualifiedTable table)
/* 216:    */   {
/* 217:251 */     StringBuffer sb = new StringBuffer();
/* 218:    */     
/* 219:253 */     addJavaDocLine("/**");
/* 220:    */     
/* 221:    */ 
/* 222:256 */     sb.append(" * This enum corresponds to the database table ");
/* 223:257 */     sb.append(table.getFullyQualifiedTableName());
/* 224:258 */     addJavaDocLine(sb.toString());
/* 225:    */     
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:267 */     addJavaDocLine(" */");
/* 234:    */   }
/* 235:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.java.InnerEnum
 * JD-Core Version:    0.7.0.1
 */