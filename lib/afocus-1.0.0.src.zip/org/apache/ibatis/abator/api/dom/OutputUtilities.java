/*  1:   */ package org.apache.ibatis.abator.api.dom;
/*  2:   */ 
/*  3:   */ public class OutputUtilities
/*  4:   */ {
/*  5:   */   private static final String lineSeparator;
/*  6:   */   
/*  7:   */   static
/*  8:   */   {
/*  9:25 */     String ls = System.getProperty("line.separator");
/* 10:26 */     if (ls == null) {
/* 11:27 */       ls = "\n";
/* 12:   */     }
/* 13:29 */     lineSeparator = ls;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static void javaIndent(StringBuffer sb, int indentLevel)
/* 17:   */   {
/* 18:49 */     for (int i = 0; i < indentLevel; i++) {
/* 19:50 */       sb.append("    ");
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static void javaIndent(StringBuilder sb, int indentLevel)
/* 24:   */   {
/* 25:54 */     for (int i = 0; i < indentLevel; i++) {
/* 26:55 */       sb.append("    ");
/* 27:   */     }
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static void xmlIndent(StringBuffer sb, int indentLevel)
/* 31:   */   {
/* 32:69 */     for (int i = 0; i < indentLevel; i++) {
/* 33:70 */       sb.append("  ");
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static void xmlIndent(StringBuilder sb, int indentLevel)
/* 38:   */   {
/* 39:74 */     for (int i = 0; i < indentLevel; i++) {
/* 40:75 */       sb.append("  ");
/* 41:   */     }
/* 42:   */   }
/* 43:   */   
/* 44:   */   public static void newLine(StringBuffer sb)
/* 45:   */   {
/* 46:86 */     sb.append(lineSeparator);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public static void newLine(StringBuilder sb)
/* 50:   */   {
/* 51:89 */     sb.append(lineSeparator);
/* 52:   */   }
/* 53:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.dom.OutputUtilities
 * JD-Core Version:    0.7.0.1
 */