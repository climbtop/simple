package org.apache.ibatis.abator.api;

public abstract interface DAOMethodNameCalculator
{
  public abstract String getInsertMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getUpdateByPrimaryKeyWithoutBLOBsMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getUpdateByPrimaryKeyWithBLOBsMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getUpdateByPrimaryKeySelectiveMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getSelectByPrimaryKeyMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getSelectCountByExampleMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getSelectByExampleWithoutBLOBsMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getSelectByExampleWithBLOBsMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getDeleteByPrimaryKeyMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getDeleteByExampleMethodName(IntrospectedTable paramIntrospectedTable);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.DAOMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */