package org.apache.ibatis.abator.api;

public abstract interface AopMethodNameCalculator
{
  public abstract String getBeforeMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getAfterMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getAroundMethodName(IntrospectedTable paramIntrospectedTable);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.AopMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */