package org.apache.ibatis.abator.api;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.abator.exception.UnsupportedDataTypeException;
import org.apache.ibatis.abator.internal.db.ColumnDefinition;

public abstract interface JavaTypeResolver
{
  public abstract void addConfigurationProperties(Map paramMap);
  
  public abstract void addContextProperties(Map paramMap);
  
  public abstract void setWarnings(List paramList);
  
  public abstract void initializeResolvedJavaType(ColumnDefinition paramColumnDefinition)
    throws UnsupportedDataTypeException;
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.JavaTypeResolver
 * JD-Core Version:    0.7.0.1
 */