package org.apache.ibatis.abator.api;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.abator.api.dom.xml.XmlElement;
import org.apache.ibatis.abator.config.TableConfiguration;

public abstract interface SqlMapGenerator
{
  public abstract void setWarnings(List paramList);
  
  public abstract void addConfigurationProperties(Map paramMap);
  
  public abstract void addContextProperties(Map paramMap);
  
  public abstract void setTargetPackage(String paramString);
  
  public abstract void setTargetProject(String paramString);
  
  public abstract void setJavaModelGenerator(JavaModelGenerator paramJavaModelGenerator);
  
  public abstract String getSqlMapNamespace(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract String getInsertStatementId();
  
  public abstract String getUpdateByPrimaryKeyWithBLOBsStatementId();
  
  public abstract String getUpdateByPrimaryKeySelectiveStatementId();
  
  public abstract String getUpdateByPrimaryKeyStatementId();
  
  public abstract String getDeleteByPrimaryKeyStatementId();
  
  public abstract String getDeleteByExampleStatementId();
  
  public abstract String getSelectByPrimaryKeyStatementId();
  
  public abstract String getSelectByExampleStatementId();
  
  public abstract String getSelectByExampleWithBLOBsStatementId();
  
  public abstract XmlElement getAbatorTableConfigure(IntrospectedTable paramIntrospectedTable, TableConfiguration paramTableConfiguration);
  
  public abstract List getGeneratedXMLFiles(IntrospectedTable paramIntrospectedTable, ProgressCallback paramProgressCallback);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.SqlMapGenerator
 * JD-Core Version:    0.7.0.1
 */