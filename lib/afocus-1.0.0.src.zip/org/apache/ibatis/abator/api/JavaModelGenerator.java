package org.apache.ibatis.abator.api;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;

public abstract interface JavaModelGenerator
{
  public abstract void addConfigurationProperties(Map paramMap);
  
  public abstract void addContextProperties(Map paramMap);
  
  public abstract void setWarnings(List paramList);
  
  public abstract void setTargetPackage(String paramString);
  
  public abstract void setTargetProject(String paramString);
  
  public abstract FullyQualifiedJavaType getPrimaryKeyType(IntrospectedTable paramIntrospectedTable);
  
  public abstract FullyQualifiedJavaType getBaseRecordType(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract FullyQualifiedJavaType getExampleType(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract FullyQualifiedJavaType getRecordWithBLOBsType(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract List getGeneratedJavaFiles(IntrospectedTable paramIntrospectedTable, ProgressCallback paramProgressCallback);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.JavaModelGenerator
 * JD-Core Version:    0.7.0.1
 */