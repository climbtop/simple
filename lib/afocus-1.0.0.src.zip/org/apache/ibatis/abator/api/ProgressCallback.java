package org.apache.ibatis.abator.api;

public abstract interface ProgressCallback
{
  public abstract void setNumberOfSubTasks(int paramInt);
  
  public abstract void startSubTask(String paramString);
  
  public abstract void finished();
  
  public abstract void checkCancel()
    throws InterruptedException;
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.ProgressCallback
 * JD-Core Version:    0.7.0.1
 */