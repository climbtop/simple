package org.apache.ibatis.abator.api;

import java.util.List;
import java.util.Map;

public abstract interface JspGenerator
{
  public abstract void addConfigurationProperties(Map paramMap);
  
  public abstract void addContextProperties(Map paramMap);
  
  public abstract void setWarnings(List paramList);
  
  public abstract void setTargetPackage(String paramString);
  
  public abstract void setTargetProject(String paramString);
  
  public abstract void setJavaModelGenerator(JavaModelGenerator paramJavaModelGenerator);
  
  public abstract void setControllerGenerator(ControllerGenerator paramControllerGenerator);
  
  public abstract List getGeneratedJspFiles(IntrospectedTable paramIntrospectedTable, ProgressCallback paramProgressCallback);
  
  public abstract void setShellCallback(ShellCallback paramShellCallback);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.JspGenerator
 * JD-Core Version:    0.7.0.1
 */