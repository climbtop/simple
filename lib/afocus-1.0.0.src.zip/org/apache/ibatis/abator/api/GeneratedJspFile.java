/*  1:   */ package org.apache.ibatis.abator.api;
/*  2:   */ 
/*  3:   */ public class GeneratedJspFile
/*  4:   */   extends GeneratedFile
/*  5:   */ {
/*  6:   */   private String content;
/*  7:   */   private String fileName;
/*  8:   */   private String targetPackage;
/*  9:   */   
/* 10:   */   public GeneratedJspFile(String content, String fileName, String targetPackage, String targetProject)
/* 11:   */   {
/* 12:33 */     super(targetProject);
/* 13:34 */     this.content = content;
/* 14:35 */     this.fileName = fileName;
/* 15:36 */     this.targetPackage = targetPackage;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public String getFormattedContent()
/* 19:   */   {
/* 20:44 */     return this.content;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getFileName()
/* 24:   */   {
/* 25:51 */     return this.fileName;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getTargetPackage()
/* 29:   */   {
/* 30:58 */     return this.targetPackage;
/* 31:   */   }
/* 32:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.GeneratedJspFile
 * JD-Core Version:    0.7.0.1
 */