/*   1:    */ package org.apache.ibatis.abator.api;
/*   2:    */ 
/*   3:    */ import java.io.BufferedWriter;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.FileWriter;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.PrintStream;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.HashSet;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Set;
/*  15:    */ import org.apache.ibatis.abator.config.AbatorConfiguration;
/*  16:    */ import org.apache.ibatis.abator.config.AbatorContext;
/*  17:    */ import org.apache.ibatis.abator.exception.InvalidConfigurationException;
/*  18:    */ import org.apache.ibatis.abator.exception.ShellException;
/*  19:    */ import org.apache.ibatis.abator.internal.DefaultShellCallback;
/*  20:    */ import org.apache.ibatis.abator.internal.NullProgressCallback;
/*  21:    */ import org.apache.ibatis.abator.internal.XmlFileMergerJaxp;
/*  22:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  23:    */ 
/*  24:    */ public class Abator
/*  25:    */ {
/*  26:    */   private AbatorConfiguration abatorConfiguration;
/*  27:    */   private ShellCallback shellCallback;
/*  28:    */   private List generatedJavaFiles;
/*  29:    */   private List generatedXmlFiles;
/*  30:    */   private List generatedJspFiles;
/*  31:    */   private List warnings;
/*  32:    */   private Set projects;
/*  33:    */   
/*  34:    */   public Abator(AbatorConfiguration abatorConfiguration, ShellCallback shellCallback, List warnings)
/*  35:    */   {
/*  36: 88 */     if (abatorConfiguration == null) {
/*  37: 89 */       throw new IllegalArgumentException(Messages.getString("RuntimeError.2"));
/*  38:    */     }
/*  39: 91 */     this.abatorConfiguration = abatorConfiguration;
/*  40: 94 */     if (shellCallback == null) {
/*  41: 95 */       this.shellCallback = new DefaultShellCallback(false);
/*  42:    */     } else {
/*  43: 97 */       this.shellCallback = shellCallback;
/*  44:    */     }
/*  45:100 */     if (warnings == null) {
/*  46:101 */       this.warnings = new ArrayList();
/*  47:    */     } else {
/*  48:103 */       this.warnings = warnings;
/*  49:    */     }
/*  50:105 */     this.generatedJavaFiles = new ArrayList();
/*  51:106 */     this.generatedXmlFiles = new ArrayList();
/*  52:107 */     this.generatedJspFiles = new ArrayList();
/*  53:108 */     this.projects = new HashSet();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void generate(ProgressCallback callback)
/*  57:    */     throws InvalidConfigurationException, SQLException, IOException, InterruptedException
/*  58:    */   {
/*  59:127 */     if (callback == null) {
/*  60:128 */       callback = new NullProgressCallback();
/*  61:    */     }
/*  62:131 */     this.generatedJavaFiles.clear();
/*  63:132 */     this.generatedXmlFiles.clear();
/*  64:133 */     this.generatedJspFiles.clear();
/*  65:    */     
/*  66:135 */     int totalSteps = 0;
/*  67:136 */     totalSteps++;
/*  68:    */     
/*  69:138 */     Iterator iter = this.abatorConfiguration.getAbatorContexts().iterator();
/*  70:139 */     while (iter.hasNext())
/*  71:    */     {
/*  72:140 */       AbatorContext abatorContext = (AbatorContext)iter.next();
/*  73:    */       
/*  74:142 */       totalSteps += abatorContext.getTotalSteps();
/*  75:    */     }
/*  76:145 */     callback.setNumberOfSubTasks(totalSteps);
/*  77:    */     
/*  78:147 */     callback.startSubTask(Messages.getString("Progress.2"));
/*  79:148 */     this.abatorConfiguration.validate();
/*  80:    */     
/*  81:150 */     iter = this.abatorConfiguration.getAbatorContexts().iterator();
/*  82:151 */     while (iter.hasNext())
/*  83:    */     {
/*  84:152 */       AbatorContext abatorContext = (AbatorContext)iter.next();
/*  85:153 */       abatorContext.setShellCallback(this.shellCallback);
/*  86:    */       
/*  87:155 */       abatorContext.generateFiles(callback, this.generatedJavaFiles, 
/*  88:156 */         this.generatedXmlFiles, this.generatedJspFiles, this.warnings);
/*  89:    */     }
/*  90:158 */     System.out.println("generated jsp files");
/*  91:159 */     iter = this.generatedJspFiles.iterator();
/*  92:160 */     while (iter.hasNext())
/*  93:    */     {
/*  94:161 */       GeneratedJspFile gxf = (GeneratedJspFile)iter.next();
/*  95:162 */       this.projects.add(gxf.getTargetProject());
/*  96:    */       try
/*  97:    */       {
/*  98:168 */         File directory = this.shellCallback.getDirectory(gxf
/*  99:169 */           .getTargetProject(), gxf.getTargetPackage(), this.warnings);
/* 100:170 */         File targetFile = new File(directory, gxf.getFileName());
/* 101:    */         
/* 102:172 */         source = gxf.getFormattedContent();
/* 103:    */       }
/* 104:    */       catch (ShellException e)
/* 105:    */       {
/* 106:    */         String source;
/* 107:175 */         this.warnings.add(Arrays.deepToString(e.getStackTrace()));
/* 108:176 */         continue;
/* 109:    */       }
/* 110:    */       String source;
/* 111:    */       File targetFile;
/* 112:179 */       writeFile(targetFile, source);
/* 113:    */     }
/* 114:182 */     System.out.println("generated xml files");
/* 115:183 */     iter = this.generatedXmlFiles.iterator();
/* 116:184 */     while (iter.hasNext())
/* 117:    */     {
/* 118:185 */       GeneratedXmlFile gxf = (GeneratedXmlFile)iter.next();
/* 119:186 */       this.projects.add(gxf.getTargetProject());
/* 120:    */       try
/* 121:    */       {
/* 122:191 */         File directory = this.shellCallback.getDirectory(gxf
/* 123:192 */           .getTargetProject(), gxf.getTargetPackage(), this.warnings);
/* 124:193 */         File targetFile = new File(directory, gxf.getFileName());
/* 125:    */         String source;
/* 126:194 */         if (targetFile.exists()) {
/* 127:195 */           source = XmlFileMergerJaxp.getMergedSource(gxf, targetFile);
/* 128:    */         } else {
/* 129:197 */           source = gxf.getFormattedContent();
/* 130:    */         }
/* 131:    */       }
/* 132:    */       catch (ShellException e)
/* 133:    */       {
/* 134:    */         String source;
/* 135:200 */         this.warnings.add(Arrays.deepToString(e.getStackTrace()));
/* 136:201 */         continue;
/* 137:    */       }
/* 138:    */       String source;
/* 139:    */       File targetFile;
/* 140:204 */       writeFile(targetFile, source);
/* 141:    */     }
/* 142:206 */     System.out.println("generated java files");
/* 143:207 */     iter = this.generatedJavaFiles.iterator();
/* 144:208 */     while (iter.hasNext())
/* 145:    */     {
/* 146:209 */       GeneratedJavaFile gjf = (GeneratedJavaFile)iter.next();
/* 147:210 */       this.projects.add(gjf.getTargetProject());
/* 148:    */       try
/* 149:    */       {
/* 150:215 */         File directory = this.shellCallback.getDirectory(gjf
/* 151:216 */           .getTargetProject(), gjf.getTargetPackage(), this.warnings);
/* 152:217 */         File targetFile = new File(directory, gjf.getFileName());
/* 153:    */         String source;
/* 154:218 */         if (targetFile.exists())
/* 155:    */         {
/* 156:    */           String source;
/* 157:219 */           if (this.shellCallback.mergeSupported())
/* 158:    */           {
/* 159:220 */             source = this.shellCallback.mergeJavaFile(gjf, 
/* 160:221 */               "@abatorgenerated", this.warnings);
/* 161:    */           }
/* 162:    */           else
/* 163:    */           {
/* 164:223 */             String source = gjf.getFormattedContent();
/* 165:224 */             targetFile = getUniqueFileName(directory, gjf);
/* 166:225 */             this.warnings.add(Messages.getString("Warning.2", targetFile.getAbsolutePath()));
/* 167:    */           }
/* 168:    */         }
/* 169:    */         else
/* 170:    */         {
/* 171:228 */           source = gjf.getFormattedContent();
/* 172:    */         }
/* 173:231 */         writeFile(targetFile, source);
/* 174:    */       }
/* 175:    */       catch (ShellException e)
/* 176:    */       {
/* 177:233 */         e.printStackTrace();
/* 178:234 */         this.warnings.add(Arrays.deepToString(e.getStackTrace()));
/* 179:    */       }
/* 180:    */     }
/* 181:238 */     iter = this.projects.iterator();
/* 182:239 */     while (iter.hasNext()) {
/* 183:240 */       this.shellCallback.refreshProject((String)iter.next());
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   private void writeFile(File file, String content)
/* 188:    */     throws IOException
/* 189:    */   {
/* 190:251 */     BufferedWriter bw = new BufferedWriter(new FileWriter(file, false));
/* 191:252 */     bw.write(content);
/* 192:253 */     bw.close();
/* 193:    */   }
/* 194:    */   
/* 195:    */   private File getUniqueFileName(File directory, GeneratedJavaFile gjf)
/* 196:    */   {
/* 197:257 */     File answer = null;
/* 198:    */     
/* 199:    */ 
/* 200:260 */     StringBuffer sb = new StringBuffer();
/* 201:261 */     for (int i = 1; i < 10000; i++)
/* 202:    */     {
/* 203:262 */       sb.setLength(0);
/* 204:263 */       sb.append(gjf.getFileName());
/* 205:264 */       sb.append('.');
/* 206:265 */       sb.append(i);
/* 207:    */       
/* 208:267 */       File testFile = new File(directory, sb.toString());
/* 209:268 */       if (!testFile.exists())
/* 210:    */       {
/* 211:269 */         answer = testFile;
/* 212:270 */         break;
/* 213:    */       }
/* 214:    */     }
/* 215:274 */     if (answer == null) {
/* 216:275 */       throw new RuntimeException(Messages.getString("RuntimeError.3", directory.getAbsolutePath()));
/* 217:    */     }
/* 218:278 */     return answer;
/* 219:    */   }
/* 220:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.Abator
 * JD-Core Version:    0.7.0.1
 */