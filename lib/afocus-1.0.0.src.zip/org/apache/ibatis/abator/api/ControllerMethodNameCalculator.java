package org.apache.ibatis.abator.api;

public abstract interface ControllerMethodNameCalculator
{
  public abstract String getAddMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getEditMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getDetailMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getListMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getSearchMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getUpdateMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getUpdateStatusMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getAuditMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getMoveMethodName(IntrospectedTable paramIntrospectedTable);
  
  public abstract String getDeleteMethodName(IntrospectedTable paramIntrospectedTable);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.ControllerMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */