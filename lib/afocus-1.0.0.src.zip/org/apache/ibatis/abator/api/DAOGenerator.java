package org.apache.ibatis.abator.api;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;

public abstract interface DAOGenerator
{
  public abstract void addConfigurationProperties(Map paramMap);
  
  public abstract void addContextProperties(Map paramMap);
  
  public abstract void setWarnings(List paramList);
  
  public abstract void setTargetPackage(String paramString);
  
  public abstract void setTargetProject(String paramString);
  
  public abstract void setJavaModelGenerator(JavaModelGenerator paramJavaModelGenerator);
  
  public abstract void setSqlMapGenerator(SqlMapGenerator paramSqlMapGenerator);
  
  public abstract List getGeneratedJavaFiles(IntrospectedTable paramIntrospectedTable, ProgressCallback paramProgressCallback);
  
  public abstract DAOMethodNameCalculator getMethodNameCalculator();
  
  public abstract FullyQualifiedJavaType getDAOImplementationType(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract FullyQualifiedJavaType getDAOInterfaceType(FullyQualifiedTable paramFullyQualifiedTable);
  
  public abstract FullyQualifiedJavaType getBaseDAOInterfaceType(FullyQualifiedTable paramFullyQualifiedTable);
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.api.DAOGenerator
 * JD-Core Version:    0.7.0.1
 */