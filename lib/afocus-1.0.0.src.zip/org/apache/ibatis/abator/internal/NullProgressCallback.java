package org.apache.ibatis.abator.internal;

import org.apache.ibatis.abator.api.ProgressCallback;

public class NullProgressCallback
  implements ProgressCallback
{
  public void finished() {}
  
  public void checkCancel()
    throws InterruptedException
  {}
  
  public void setNumberOfSubTasks(int totalSubTasks) {}
  
  public void startSubTask(String subTaskName) {}
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.NullProgressCallback
 * JD-Core Version:    0.7.0.1
 */