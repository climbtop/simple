/*  1:   */ package org.apache.ibatis.abator.internal;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.ControllerMethodNameCalculator;
/*  4:   */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  5:   */ 
/*  6:   */ public class DefaultControllerMethodNameCalculator
/*  7:   */   implements ControllerMethodNameCalculator
/*  8:   */ {
/*  9:   */   public String getListMethodName(IntrospectedTable introspectedTable)
/* 10:   */   {
/* 11:37 */     return "list";
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getSearchMethodName(IntrospectedTable introspectedTable)
/* 15:   */   {
/* 16:41 */     return "search";
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getDeleteMethodName(IntrospectedTable introspectedTable)
/* 20:   */   {
/* 21:45 */     return "delete";
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getEditMethodName(IntrospectedTable introspectedTable)
/* 25:   */   {
/* 26:49 */     return "edit";
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getAddMethodName(IntrospectedTable introspectedTable)
/* 30:   */   {
/* 31:53 */     return "add";
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getDetailMethodName(IntrospectedTable introspectedTable)
/* 35:   */   {
/* 36:57 */     return "detail";
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String getUpdateMethodName(IntrospectedTable introspectedTable)
/* 40:   */   {
/* 41:61 */     return "update";
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getMoveMethodName(IntrospectedTable introspectedTable)
/* 45:   */   {
/* 46:66 */     return "move";
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String getAuditMethodName(IntrospectedTable introspectedTable)
/* 50:   */   {
/* 51:70 */     return "audit";
/* 52:   */   }
/* 53:   */   
/* 54:   */   public String getUpdateStatusMethodName(IntrospectedTable introspectedTable)
/* 55:   */   {
/* 56:74 */     return "updateStatus";
/* 57:   */   }
/* 58:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.DefaultControllerMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */