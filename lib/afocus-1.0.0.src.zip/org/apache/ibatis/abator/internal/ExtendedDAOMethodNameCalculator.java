/*   1:    */ package org.apache.ibatis.abator.internal;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   4:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   5:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   6:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   7:    */ 
/*   8:    */ public class ExtendedDAOMethodNameCalculator
/*   9:    */   implements DAOMethodNameCalculator
/*  10:    */ {
/*  11:    */   public String getInsertMethodName(IntrospectedTable introspectedTable)
/*  12:    */   {
/*  13: 37 */     StringBuffer sb = new StringBuffer();
/*  14: 38 */     sb.append("insert");
/*  15: 39 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  16:    */     
/*  17: 41 */     return sb.toString();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public String getUpdateByPrimaryKeyWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/*  21:    */   {
/*  22: 53 */     StringBuffer sb = new StringBuffer();
/*  23:    */     
/*  24: 55 */     sb.append("update");
/*  25: 56 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  26:    */     
/*  27: 58 */     AbatorRules rules = introspectedTable.getRules();
/*  28: 60 */     if (!rules.generateUpdateByPrimaryKeyWithBLOBs()) {
/*  29: 61 */       sb.append("ById");
/*  30: 62 */     } else if (rules.generateRecordWithBLOBsClass()) {
/*  31: 63 */       sb.append("ById");
/*  32:    */     } else {
/*  33: 65 */       sb.append("ByIdWithoutBLOBs");
/*  34:    */     }
/*  35: 68 */     return sb.toString();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public String getUpdateByPrimaryKeyWithBLOBsMethodName(IntrospectedTable introspectedTable)
/*  39:    */   {
/*  40: 80 */     StringBuffer sb = new StringBuffer();
/*  41: 81 */     sb.append("update");
/*  42: 82 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  43:    */     
/*  44: 84 */     AbatorRules rules = introspectedTable.getRules();
/*  45: 86 */     if (!rules.generateUpdateByPrimaryKeyWithoutBLOBs()) {
/*  46: 87 */       sb.append("ById");
/*  47: 88 */     } else if (rules.generateRecordWithBLOBsClass()) {
/*  48: 89 */       sb.append("ById");
/*  49:    */     } else {
/*  50: 91 */       sb.append("ByIdWithBLOBs");
/*  51:    */     }
/*  52: 94 */     return sb.toString();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public String getDeleteByExampleMethodName(IntrospectedTable introspectedTable)
/*  56:    */   {
/*  57: 98 */     StringBuffer sb = new StringBuffer();
/*  58: 99 */     sb.append("delete");
/*  59:100 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  60:101 */     sb.append("ByMap");
/*  61:    */     
/*  62:103 */     return sb.toString();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public String getDeleteByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/*  66:    */   {
/*  67:107 */     StringBuffer sb = new StringBuffer();
/*  68:108 */     sb.append("delete");
/*  69:109 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  70:110 */     sb.append("ById");
/*  71:    */     
/*  72:112 */     return sb.toString();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public String getSelectCountByExampleMethodName(IntrospectedTable introspectedTable)
/*  76:    */   {
/*  77:116 */     StringBuffer sb = new StringBuffer();
/*  78:117 */     sb.append("select");
/*  79:118 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  80:119 */     sb.append("CountByMap");
/*  81:    */     
/*  82:121 */     return sb.toString();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String getSelectByExampleWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/*  86:    */   {
/*  87:131 */     StringBuffer sb = new StringBuffer();
/*  88:132 */     sb.append("select");
/*  89:133 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/*  90:134 */     sb.append("ByMap");
/*  91:    */     
/*  92:136 */     AbatorRules rules = introspectedTable.getRules();
/*  93:138 */     if (rules.generateSelectByExampleWithBLOBs()) {
/*  94:139 */       sb.append("WithoutBLOBs");
/*  95:    */     }
/*  96:142 */     return sb.toString();
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getSelectByExampleWithBLOBsMethodName(IntrospectedTable introspectedTable)
/* 100:    */   {
/* 101:151 */     StringBuffer sb = new StringBuffer();
/* 102:152 */     sb.append("select");
/* 103:153 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/* 104:154 */     sb.append("ByMap");
/* 105:    */     
/* 106:156 */     AbatorRules rules = introspectedTable.getRules();
/* 107:158 */     if (rules.generateSelectByExampleWithoutBLOBs()) {
/* 108:159 */       sb.append("WithBLOBs");
/* 109:    */     }
/* 110:162 */     return sb.toString();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public String getSelectByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/* 114:    */   {
/* 115:166 */     StringBuffer sb = new StringBuffer();
/* 116:167 */     sb.append("select");
/* 117:168 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/* 118:169 */     sb.append("ById");
/* 119:    */     
/* 120:171 */     return sb.toString();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getUpdateByPrimaryKeySelectiveMethodName(IntrospectedTable introspectedTable)
/* 124:    */   {
/* 125:176 */     StringBuffer sb = new StringBuffer();
/* 126:177 */     sb.append("update");
/* 127:178 */     sb.append(introspectedTable.getTable().getDomainObjectName());
/* 128:179 */     sb.append("ByMap");
/* 129:    */     
/* 130:181 */     return sb.toString();
/* 131:    */   }
/* 132:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.ExtendedDAOMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */