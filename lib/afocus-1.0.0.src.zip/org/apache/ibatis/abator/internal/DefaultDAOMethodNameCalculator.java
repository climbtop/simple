/*   1:    */ package org.apache.ibatis.abator.internal;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   4:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   5:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   6:    */ 
/*   7:    */ public class DefaultDAOMethodNameCalculator
/*   8:    */   implements DAOMethodNameCalculator
/*   9:    */ {
/*  10:    */   public String getInsertMethodName(IntrospectedTable introspectedTable)
/*  11:    */   {
/*  12: 37 */     return "insert";
/*  13:    */   }
/*  14:    */   
/*  15:    */   public String getUpdateByPrimaryKeyWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/*  16:    */   {
/*  17: 49 */     AbatorRules rules = introspectedTable.getRules();
/*  18: 51 */     if (!rules.generateUpdateByPrimaryKeyWithBLOBs()) {
/*  19: 52 */       return "updateById";
/*  20:    */     }
/*  21: 53 */     if (rules.generateRecordWithBLOBsClass()) {
/*  22: 54 */       return "updateById";
/*  23:    */     }
/*  24: 56 */     return "updateByIdWithoutBLOBs";
/*  25:    */   }
/*  26:    */   
/*  27:    */   public String getUpdateByPrimaryKeyWithBLOBsMethodName(IntrospectedTable introspectedTable)
/*  28:    */   {
/*  29: 69 */     AbatorRules rules = introspectedTable.getRules();
/*  30: 71 */     if (!rules.generateUpdateByPrimaryKeyWithoutBLOBs()) {
/*  31: 72 */       return "updateById";
/*  32:    */     }
/*  33: 73 */     if (rules.generateRecordWithBLOBsClass()) {
/*  34: 74 */       return "updateById";
/*  35:    */     }
/*  36: 76 */     return "updateByIdWithBLOBs";
/*  37:    */   }
/*  38:    */   
/*  39:    */   public String getDeleteByExampleMethodName(IntrospectedTable introspectedTable)
/*  40:    */   {
/*  41: 81 */     return "deleteByMap";
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String getDeleteByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/*  45:    */   {
/*  46: 85 */     return "deleteById";
/*  47:    */   }
/*  48:    */   
/*  49:    */   public String getSelectCountByExampleMethodName(IntrospectedTable introspectedTable)
/*  50:    */   {
/*  51: 89 */     return "selectCountByMap";
/*  52:    */   }
/*  53:    */   
/*  54:    */   public String getSelectByExampleWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/*  55:    */   {
/*  56: 98 */     AbatorRules rules = introspectedTable.getRules();
/*  57:100 */     if (!rules.generateSelectByExampleWithBLOBs()) {
/*  58:101 */       return "selectByMap";
/*  59:    */     }
/*  60:103 */     return "selectByMapWithoutBLOBs";
/*  61:    */   }
/*  62:    */   
/*  63:    */   public String getSelectByExampleWithBLOBsMethodName(IntrospectedTable introspectedTable)
/*  64:    */   {
/*  65:113 */     AbatorRules rules = introspectedTable.getRules();
/*  66:115 */     if (!rules.generateSelectByExampleWithoutBLOBs()) {
/*  67:116 */       return "selectByMap";
/*  68:    */     }
/*  69:118 */     return "selectByMapWithBLOBs";
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String getSelectByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/*  73:    */   {
/*  74:123 */     return "selectById";
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getUpdateByPrimaryKeySelectiveMethodName(IntrospectedTable introspectedTable)
/*  78:    */   {
/*  79:127 */     return "updateByMap";
/*  80:    */   }
/*  81:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.DefaultDAOMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */