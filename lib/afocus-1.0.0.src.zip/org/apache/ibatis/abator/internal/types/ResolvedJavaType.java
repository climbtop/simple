/*  1:   */ package org.apache.ibatis.abator.internal.types;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  4:   */ 
/*  5:   */ public class ResolvedJavaType
/*  6:   */ {
/*  7:   */   private FullyQualifiedJavaType fullyQualifiedJavaType;
/*  8:   */   private String jdbcTypeName;
/*  9:   */   
/* 10:   */   public String getJdbcTypeName()
/* 11:   */   {
/* 12:34 */     return this.jdbcTypeName;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setJdbcTypeName(String jdbcTypeName)
/* 16:   */   {
/* 17:38 */     this.jdbcTypeName = jdbcTypeName;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public FullyQualifiedJavaType getFullyQualifiedJavaType()
/* 21:   */   {
/* 22:44 */     return this.fullyQualifiedJavaType;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setFullyQualifiedJavaType(FullyQualifiedJavaType fullyQualifiedJavaType)
/* 26:   */   {
/* 27:51 */     this.fullyQualifiedJavaType = fullyQualifiedJavaType;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean isJDBCDate()
/* 31:   */   {
/* 32:55 */     return (this.fullyQualifiedJavaType.equals(FullyQualifiedJavaType.getDateInstance())) && 
/* 33:56 */       ("DATE".equalsIgnoreCase(this.jdbcTypeName));
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean isJDBCTime()
/* 37:   */   {
/* 38:60 */     return (this.fullyQualifiedJavaType.equals(FullyQualifiedJavaType.getDateInstance())) && 
/* 39:61 */       ("TIME".equalsIgnoreCase(this.jdbcTypeName));
/* 40:   */   }
/* 41:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.types.ResolvedJavaType
 * JD-Core Version:    0.7.0.1
 */