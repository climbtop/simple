/*   1:    */ package org.apache.ibatis.abator.internal.types;
/*   2:    */ 
/*   3:    */ import java.math.BigDecimal;
/*   4:    */ import java.util.Date;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.apache.ibatis.abator.api.JavaTypeResolver;
/*   9:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  10:    */ import org.apache.ibatis.abator.exception.UnsupportedDataTypeException;
/*  11:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  12:    */ 
/*  13:    */ public class JavaTypeResolverDefaultImpl
/*  14:    */   implements JavaTypeResolver
/*  15:    */ {
/*  16:    */   protected List warnings;
/*  17:    */   protected Map properties;
/*  18:    */   
/*  19:    */   public JavaTypeResolverDefaultImpl()
/*  20:    */   {
/*  21: 42 */     this.properties = new HashMap();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void addConfigurationProperties(Map properties)
/*  25:    */   {
/*  26: 46 */     this.properties.putAll(properties);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void addContextProperties(Map properties)
/*  30:    */   {
/*  31: 50 */     this.properties.putAll(properties);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void initializeResolvedJavaType(ColumnDefinition cd)
/*  35:    */     throws UnsupportedDataTypeException
/*  36:    */   {
/*  37: 59 */     boolean forceBigDecimals = "true".equalsIgnoreCase(
/*  38: 60 */       (String)this.properties.get("forceBigDecimals"));
/*  39:    */     
/*  40: 62 */     ResolvedJavaType type = new ResolvedJavaType();
/*  41: 64 */     switch (cd.getJdbcType())
/*  42:    */     {
/*  43:    */     case 2003: 
/*  44: 66 */       type.setJdbcTypeName("ARRAY");
/*  45: 67 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/*  46: 68 */       break;
/*  47:    */     case -5: 
/*  48: 71 */       type.setJdbcTypeName("BIGINT");
/*  49: 72 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Long.class.getName()));
/*  50: 73 */       break;
/*  51:    */     case -2: 
/*  52: 76 */       type.setJdbcTypeName("BINARY");
/*  53: 77 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/*  54: 78 */       break;
/*  55:    */     case -7: 
/*  56: 81 */       type.setJdbcTypeName("BIT");
/*  57: 82 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/*  58: 83 */       break;
/*  59:    */     case 2004: 
/*  60: 86 */       type.setJdbcTypeName("BLOB");
/*  61: 87 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType("byte[]"));
/*  62: 88 */       break;
/*  63:    */     case 16: 
/*  64: 91 */       type.setJdbcTypeName("BOOLEAN");
/*  65: 92 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Boolean.class.getName()));
/*  66: 93 */       break;
/*  67:    */     case 1: 
/*  68: 96 */       type.setJdbcTypeName("CHAR");
/*  69: 97 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(String.class.getName()));
/*  70: 98 */       break;
/*  71:    */     case 2005: 
/*  72:101 */       type.setJdbcTypeName("CLOB");
/*  73:102 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(String.class.getName()));
/*  74:103 */       break;
/*  75:    */     case 70: 
/*  76:106 */       type.setJdbcTypeName("DATALINK");
/*  77:107 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/*  78:108 */       break;
/*  79:    */     case 91: 
/*  80:111 */       type.setJdbcTypeName("DATE");
/*  81:112 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Date.class.getName()));
/*  82:113 */       break;
/*  83:    */     case 3: 
/*  84:116 */       type.setJdbcTypeName("DECIMAL");
/*  85:117 */       if ((cd.getScale() > 0) || (cd.getLength() > 18) || (forceBigDecimals)) {
/*  86:118 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(BigDecimal.class.getName()));
/*  87:119 */       } else if (cd.getLength() > 9) {
/*  88:120 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Long.class.getName()));
/*  89:121 */       } else if (cd.getLength() > 4) {
/*  90:122 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Integer.class.getName()));
/*  91:    */       } else {
/*  92:124 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Short.class.getName()));
/*  93:    */       }
/*  94:126 */       break;
/*  95:    */     case 2001: 
/*  96:129 */       type.setJdbcTypeName("DISTINCT");
/*  97:130 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/*  98:131 */       break;
/*  99:    */     case 8: 
/* 100:134 */       type.setJdbcTypeName("DOUBLE");
/* 101:135 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Double.class.getName()));
/* 102:136 */       break;
/* 103:    */     case 6: 
/* 104:139 */       type.setJdbcTypeName("FLOAT");
/* 105:140 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Float.class.getName()));
/* 106:141 */       break;
/* 107:    */     case 4: 
/* 108:144 */       type.setJdbcTypeName("INTEGER");
/* 109:145 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Integer.class.getName()));
/* 110:146 */       break;
/* 111:    */     case 2000: 
/* 112:149 */       type.setJdbcTypeName("JAVA_OBJECT");
/* 113:150 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/* 114:151 */       break;
/* 115:    */     case -4: 
/* 116:154 */       type.setJdbcTypeName("LONGVARBINARY");
/* 117:155 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType("byte[]"));
/* 118:156 */       break;
/* 119:    */     case -1: 
/* 120:159 */       type.setJdbcTypeName("LONGVARCHAR");
/* 121:160 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(String.class.getName()));
/* 122:161 */       break;
/* 123:    */     case 0: 
/* 124:164 */       type.setJdbcTypeName("NULL");
/* 125:165 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/* 126:166 */       break;
/* 127:    */     case 2: 
/* 128:169 */       type.setJdbcTypeName("NUMERIC");
/* 129:170 */       if ((cd.getScale() > 0) || (cd.getLength() > 18) || (forceBigDecimals)) {
/* 130:171 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(BigDecimal.class.getName()));
/* 131:172 */       } else if (cd.getLength() > 9) {
/* 132:173 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Long.class.getName()));
/* 133:174 */       } else if (cd.getLength() > 4) {
/* 134:175 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Integer.class.getName()));
/* 135:    */       } else {
/* 136:177 */         type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Short.class.getName()));
/* 137:    */       }
/* 138:179 */       break;
/* 139:    */     case 1111: 
/* 140:182 */       type.setJdbcTypeName("OTHER");
/* 141:183 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/* 142:184 */       break;
/* 143:    */     case 7: 
/* 144:187 */       type.setJdbcTypeName("REAL");
/* 145:188 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Double.class.getName()));
/* 146:189 */       break;
/* 147:    */     case 2006: 
/* 148:192 */       type.setJdbcTypeName("REF");
/* 149:193 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/* 150:194 */       break;
/* 151:    */     case 5: 
/* 152:197 */       type.setJdbcTypeName("SMALLINT");
/* 153:198 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Short.class.getName()));
/* 154:199 */       break;
/* 155:    */     case 2002: 
/* 156:202 */       type.setJdbcTypeName("STRUCT");
/* 157:203 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/* 158:204 */       break;
/* 159:    */     case 92: 
/* 160:207 */       type.setJdbcTypeName("TIME");
/* 161:208 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Date.class.getName()));
/* 162:209 */       break;
/* 163:    */     case 93: 
/* 164:212 */       type.setJdbcTypeName("TIMESTAMP");
/* 165:213 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Date.class.getName()));
/* 166:214 */       break;
/* 167:    */     case -6: 
/* 168:217 */       type.setJdbcTypeName("TINYINT");
/* 169:218 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Byte.class.getName()));
/* 170:219 */       break;
/* 171:    */     case -3: 
/* 172:222 */       type.setJdbcTypeName("VARBINARY");
/* 173:223 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(Object.class.getName()));
/* 174:224 */       break;
/* 175:    */     case 12: 
/* 176:227 */       type.setJdbcTypeName("VARCHAR");
/* 177:228 */       type.setFullyQualifiedJavaType(new FullyQualifiedJavaType(String.class.getName()));
/* 178:229 */       break;
/* 179:    */     default: 
/* 180:232 */       throw new UnsupportedDataTypeException();
/* 181:    */     }
/* 182:235 */     cd.setResolvedJavaType(type);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setWarnings(List warnings)
/* 186:    */   {
/* 187:242 */     this.warnings = warnings;
/* 188:    */   }
/* 189:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.types.JavaTypeResolverDefaultImpl
 * JD-Core Version:    0.7.0.1
 */