/*   1:    */ package org.apache.ibatis.abator.internal;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.StringTokenizer;
/*   6:    */ import org.apache.ibatis.abator.api.GeneratedJavaFile;
/*   7:    */ import org.apache.ibatis.abator.api.ShellCallback;
/*   8:    */ import org.apache.ibatis.abator.exception.ShellException;
/*   9:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  10:    */ 
/*  11:    */ public class DefaultShellCallback
/*  12:    */   implements ShellCallback
/*  13:    */ {
/*  14:    */   private boolean overwrite;
/*  15:    */   
/*  16:    */   public DefaultShellCallback(boolean overwrite)
/*  17:    */   {
/*  18: 38 */     this.overwrite = overwrite;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public File getDirectory(String targetProject, String targetPackage, List warnings)
/*  22:    */     throws ShellException
/*  23:    */   {
/*  24: 53 */     File project = new File(targetProject);
/*  25: 54 */     if (!project.isDirectory()) {
/*  26: 55 */       throw new ShellException(Messages.getString("Warning.9", 
/*  27: 56 */         targetProject));
/*  28:    */     }
/*  29: 59 */     StringBuffer sb = new StringBuffer();
/*  30: 60 */     StringTokenizer st = new StringTokenizer(targetPackage, ".");
/*  31: 61 */     while (st.hasMoreTokens())
/*  32:    */     {
/*  33: 62 */       sb.append(st.nextToken());
/*  34: 63 */       sb.append(File.separatorChar);
/*  35:    */     }
/*  36: 66 */     File directory = new File(project, sb.toString());
/*  37: 67 */     if (!directory.isDirectory())
/*  38:    */     {
/*  39: 68 */       boolean rc = directory.mkdirs();
/*  40: 69 */       if (!rc) {
/*  41: 70 */         throw new ShellException(Messages.getString("Warning.10", 
/*  42: 71 */           directory.getAbsolutePath()));
/*  43:    */       }
/*  44:    */     }
/*  45: 75 */     return directory;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String mergeJavaFile(GeneratedJavaFile newFile, String javadocTag, List warnings)
/*  49:    */     throws ShellException
/*  50:    */   {
/*  51: 84 */     if (this.overwrite)
/*  52:    */     {
/*  53: 85 */       File directory = getDirectory(newFile.getTargetProject(), newFile.getTargetPackage(), warnings);
/*  54: 86 */       File file = new File(directory, newFile.getFileName());
/*  55: 87 */       warnings.add(Messages.getString("Warning.11", 
/*  56: 88 */         file.getAbsolutePath()));
/*  57:    */       
/*  58: 90 */       return newFile.getFormattedContent();
/*  59:    */     }
/*  60: 92 */     return null;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void refreshProject(String project) {}
/*  64:    */   
/*  65:    */   public boolean mergeSupported()
/*  66:    */   {
/*  67:108 */     return this.overwrite;
/*  68:    */   }
/*  69:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.DefaultShellCallback
 * JD-Core Version:    0.7.0.1
 */