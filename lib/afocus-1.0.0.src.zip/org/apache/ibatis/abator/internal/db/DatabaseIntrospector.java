/*   1:    */ package org.apache.ibatis.abator.internal.db;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.DatabaseMetaData;
/*   5:    */ import java.sql.ResultSet;
/*   6:    */ import java.sql.SQLException;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.HashMap;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Map.Entry;
/*  13:    */ import java.util.Set;
/*  14:    */ import java.util.StringTokenizer;
/*  15:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  16:    */ import org.apache.ibatis.abator.api.JavaTypeResolver;
/*  17:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  18:    */ import org.apache.ibatis.abator.config.ColumnOverride;
/*  19:    */ import org.apache.ibatis.abator.config.GeneratedKey;
/*  20:    */ import org.apache.ibatis.abator.config.TableConfiguration;
/*  21:    */ import org.apache.ibatis.abator.exception.UnsupportedDataTypeException;
/*  22:    */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*  23:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*  24:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  25:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  26:    */ 
/*  27:    */ public class DatabaseIntrospector
/*  28:    */ {
/*  29:    */   public static Collection introspectTables(Connection connection, TableConfiguration tc, JavaTypeResolver javaTypeResolver, List warnings)
/*  30:    */     throws SQLException
/*  31:    */   {
/*  32: 53 */     Map introspectedTables = new HashMap();
/*  33: 54 */     DatabaseMetaData dbmd = connection.getMetaData();
/*  34:    */     String localTableName;
/*  35:    */     String localCatalog;
/*  36:    */     String localSchema;
/*  37:    */     String localTableName;
/*  38: 60 */     if (dbmd.storesLowerCaseIdentifiers())
/*  39:    */     {
/*  40: 61 */       String localCatalog = tc.getCatalog() == null ? null : tc.getCatalog().toLowerCase();
/*  41: 62 */       String localSchema = tc.getSchema() == null ? null : tc.getSchema().toLowerCase();
/*  42: 63 */       localTableName = tc.getTableName() == null ? null : tc.getTableName().toLowerCase();
/*  43:    */     }
/*  44:    */     else
/*  45:    */     {
/*  46:    */       String localTableName;
/*  47: 65 */       if (dbmd.storesUpperCaseIdentifiers())
/*  48:    */       {
/*  49: 66 */         String localCatalog = tc.getCatalog() == null ? null : tc.getCatalog().toUpperCase();
/*  50: 67 */         String localSchema = tc.getSchema() == null ? null : tc.getSchema().toUpperCase();
/*  51: 68 */         localTableName = tc.getTableName() == null ? null : tc.getTableName().toUpperCase();
/*  52:    */       }
/*  53:    */       else
/*  54:    */       {
/*  55: 71 */         localCatalog = tc.getCatalog();
/*  56: 72 */         localSchema = tc.getSchema();
/*  57: 73 */         localTableName = tc.getTableName();
/*  58:    */       }
/*  59:    */     }
/*  60: 76 */     if (tc.isWildcardEscapingEnabled())
/*  61:    */     {
/*  62: 77 */       String escapeString = dbmd.getSearchStringEscape();
/*  63:    */       
/*  64: 79 */       StringBuffer sb = new StringBuffer();
/*  65: 81 */       if (localSchema != null)
/*  66:    */       {
/*  67: 82 */         StringTokenizer st = new StringTokenizer(localSchema, "_%", true);
/*  68: 83 */         while (st.hasMoreTokens())
/*  69:    */         {
/*  70: 84 */           String token = st.nextToken();
/*  71: 85 */           if ((token.equals("_")) || 
/*  72: 86 */             (token.equals("%"))) {
/*  73: 87 */             sb.append(escapeString);
/*  74:    */           }
/*  75: 89 */           sb.append(token);
/*  76:    */         }
/*  77: 91 */         localSchema = sb.toString();
/*  78:    */       }
/*  79: 94 */       sb.setLength(0);
/*  80: 95 */       StringTokenizer st = new StringTokenizer(localTableName, "_%", true);
/*  81: 96 */       while (st.hasMoreTokens())
/*  82:    */       {
/*  83: 97 */         String token = st.nextToken();
/*  84: 98 */         if ((token.equals("_")) || 
/*  85: 99 */           (token.equals("%"))) {
/*  86:100 */           sb.append(escapeString);
/*  87:    */         }
/*  88:102 */         sb.append(token);
/*  89:    */       }
/*  90:104 */       localTableName = sb.toString();
/*  91:    */     }
/*  92:107 */     ResultSet rs = dbmd.getColumns(localCatalog, localSchema, localTableName, null);
/*  93:    */     
/*  94:109 */     int returnedColumns = 0;
/*  95:110 */     while (rs.next())
/*  96:    */     {
/*  97:111 */       returnedColumns++;
/*  98:    */       
/*  99:113 */       ColumnDefinition cd = new ColumnDefinition(tc.getAlias());
/* 100:    */       
/* 101:115 */       cd.setJdbcType(rs.getInt("DATA_TYPE"));
/* 102:116 */       cd.setLength(rs.getInt("COLUMN_SIZE"));
/* 103:117 */       cd.setColumnName(rs.getString("COLUMN_NAME"));
/* 104:118 */       cd.setNullable(rs.getInt("NULLABLE") == 1);
/* 105:119 */       cd.setScale(rs.getInt("DECIMAL_DIGITS"));
/* 106:120 */       cd.setTypeName(rs.getString("TYPE_NAME"));
/* 107:121 */       cd.setMemo(rs.getString("REMARKS"));
/* 108:122 */       cd.setDefaultValue(rs.getString("COLUMN_DEF"));
/* 109:    */       
/* 110:124 */       String tableName = rs.getString("TABLE_NAME");
/* 111:125 */       String catalog = rs.getString("TABLE_CAT");
/* 112:126 */       String schema = rs.getString("TABLE_SCHEM");
/* 113:    */       
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:135 */       FullyQualifiedTable table = new FullyQualifiedTable(StringUtility.stringHasValue(tc.getCatalog()) ? catalog : null, 
/* 122:136 */         StringUtility.stringHasValue(tc.getSchema()) ? schema : null, tableName, tc.getDomainObjectName(), tc
/* 123:137 */         .getAlias());
/* 124:139 */       if (StringUtility.stringHasValue(tc.getLabel())) {
/* 125:140 */         table.setLabel(tc.getLabel());
/* 126:    */       } else {
/* 127:142 */         table.setLabel(tc.getDomainObjectName());
/* 128:    */       }
/* 129:144 */       ColumnOverride columnOverride = tc.getColumnOverride(cd.getColumnName());
/* 130:146 */       if ((columnOverride == null) || (!StringUtility.stringHasValue(columnOverride.getJavaProperty())))
/* 131:    */       {
/* 132:147 */         if ("true".equals(tc.getProperties().get("useActualColumnNames"))) {
/* 133:148 */           cd.setJavaProperty(JavaBeansUtil.getValidPropertyName(cd.getColumnName()));
/* 134:    */         } else {
/* 135:151 */           cd.setJavaProperty(JavaBeansUtil.getCamelCaseString(cd.getColumnName(), false));
/* 136:    */         }
/* 137:    */       }
/* 138:    */       else {
/* 139:155 */         cd.setJavaProperty(columnOverride.getJavaProperty());
/* 140:    */       }
/* 141:158 */       if (columnOverride != null)
/* 142:    */       {
/* 143:159 */         if (StringUtility.stringHasValue(columnOverride.getDefaultValue())) {
/* 144:160 */           cd.setDefaultValue(columnOverride.getDefaultValue());
/* 145:    */         }
/* 146:161 */         if (StringUtility.stringHasValue(columnOverride.getLabel())) {
/* 147:162 */           cd.setLabel(columnOverride.getLabel());
/* 148:    */         }
/* 149:163 */         if (StringUtility.stringHasValue(columnOverride.getHtmlEditor())) {
/* 150:164 */           cd.setHtmlEditor(columnOverride.getHtmlEditor());
/* 151:    */         }
/* 152:165 */         if (StringUtility.stringHasValue(columnOverride.getOptionValue())) {
/* 153:166 */           cd.setOptionValue(columnOverride.getOptionValue());
/* 154:    */         }
/* 155:167 */         if (StringUtility.stringHasValue(columnOverride.getValidator())) {
/* 156:168 */           cd.setValidator(columnOverride.getValidator());
/* 157:    */         }
/* 158:169 */         if (StringUtility.stringHasValue(columnOverride.getMemo())) {
/* 159:170 */           cd.setMemo(columnOverride.getMemo());
/* 160:    */         }
/* 161:171 */         cd.setListable(columnOverride.isListable());
/* 162:172 */         cd.setQueryable(columnOverride.isQueryable());
/* 163:173 */         cd.setMainFk(columnOverride.isMainFk());
/* 164:    */       }
/* 165:176 */       if (!StringUtility.stringHasValue(cd.getLabel())) {
/* 166:177 */         cd.setLabel(cd.getJavaProperty());
/* 167:    */       }
/* 168:    */       try
/* 169:    */       {
/* 170:181 */         javaTypeResolver.initializeResolvedJavaType(cd);
/* 171:    */       }
/* 172:    */       catch (UnsupportedDataTypeException e)
/* 173:    */       {
/* 174:186 */         warnings.add(Messages.getString("Warning.14", 
/* 175:187 */           table.getFullyQualifiedTableName(), cd.getColumnName()));
/* 176:188 */         continue;
/* 177:    */       }
/* 178:191 */       if ((columnOverride != null) && (StringUtility.stringHasValue(columnOverride.getJavaType()))) {
/* 179:192 */         cd.getResolvedJavaType().setFullyQualifiedJavaType(new FullyQualifiedJavaType(columnOverride.getJavaType()));
/* 180:    */       }
/* 181:195 */       if ((columnOverride != null) && (StringUtility.stringHasValue(columnOverride.getJdbcType()))) {
/* 182:196 */         cd.getResolvedJavaType().setJdbcTypeName(columnOverride.getJdbcType());
/* 183:    */       }
/* 184:199 */       if ((columnOverride != null) && (StringUtility.stringHasValue(columnOverride.getTypeHandler()))) {
/* 185:200 */         cd.setTypeHandler(columnOverride.getTypeHandler());
/* 186:    */       }
/* 187:203 */       if (("CLOB".equalsIgnoreCase(cd.getResolvedJavaType().getJdbcTypeName())) && (!StringUtility.stringHasValue(cd.getTypeHandler()))) {
/* 188:204 */         cd.setTypeHandler("org.springframework.orm.ibatis.support.ClobStringTypeHandler");
/* 189:    */       }
/* 190:207 */       if ((tc.getGeneratedKey() != null) && (tc.getGeneratedKey().isIdentity()) && 
/* 191:208 */         (cd.getColumnName().equalsIgnoreCase(tc.getGeneratedKey().getColumn()))) {
/* 192:209 */         cd.setIdentity(true);
/* 193:    */       } else {
/* 194:212 */         cd.setIdentity(false);
/* 195:    */       }
/* 196:215 */       if (!StringUtility.stringHasValue(cd.getValidator())) {
/* 197:216 */         cd.setValidator(cd.getDefaultJqueryValidator());
/* 198:    */       }
/* 199:219 */       if (!tc.isColumnIgnored(cd.getColumnName()))
/* 200:    */       {
/* 201:220 */         IntrospectedTableImpl introspectedTable = (IntrospectedTableImpl)introspectedTables.get(table
/* 202:221 */           .getFullyQualifiedTableName());
/* 203:222 */         if (introspectedTable == null)
/* 204:    */         {
/* 205:223 */           introspectedTable = new IntrospectedTableImpl(tc, new ColumnDefinitions(), table);
/* 206:224 */           introspectedTables.put(table.getFullyQualifiedTableName(), introspectedTable);
/* 207:    */         }
/* 208:227 */         introspectedTable.getColumnDefinitions().addColumn(cd);
/* 209:    */       }
/* 210:    */     }
/* 211:231 */     rs.close();
/* 212:233 */     if (returnedColumns == 0) {
/* 213:234 */       warnings.add(Messages.getString("Warning.19", tc.getCatalog(), 
/* 214:235 */         tc.getSchema(), tc.getTableName()));
/* 215:    */     }
/* 216:238 */     Iterator iter = introspectedTables.values().iterator();
/* 217:239 */     while (iter.hasNext())
/* 218:    */     {
/* 219:240 */       IntrospectedTableImpl it = (IntrospectedTableImpl)iter.next();
/* 220:241 */       calculatePrimaryKey(dbmd, it, warnings);
/* 221:    */     }
/* 222:247 */     iter = introspectedTables.entrySet().iterator();
/* 223:248 */     while (iter.hasNext())
/* 224:    */     {
/* 225:249 */       Map.Entry entry = (Map.Entry)iter.next();
/* 226:    */       
/* 227:251 */       IntrospectedTableImpl introspectedTable = (IntrospectedTableImpl)entry.getValue();
/* 228:    */       
/* 229:253 */       ColumnDefinitions cds = introspectedTable.getColumnDefinitions();
/* 230:255 */       if (!cds.hasAnyColumns())
/* 231:    */       {
/* 232:258 */         warnings.add(Messages.getString("Warning.1", introspectedTable.getTable().getFullyQualifiedTableName()));
/* 233:259 */         iter.remove();
/* 234:    */       }
/* 235:261 */       else if ((!cds.hasPrimaryKeyColumns()) && (!cds.hasBaseColumns()))
/* 236:    */       {
/* 237:264 */         warnings.add(Messages.getString("Warning.18", introspectedTable.getTable().getFullyQualifiedTableName()));
/* 238:265 */         iter.remove();
/* 239:    */       }
/* 240:    */       else
/* 241:    */       {
/* 242:271 */         reportIntrospectionWarnings(cds, tc, introspectedTable.getTable(), warnings);
/* 243:    */       }
/* 244:    */     }
/* 245:275 */     return introspectedTables.values();
/* 246:    */   }
/* 247:    */   
/* 248:    */   private static void calculatePrimaryKey(DatabaseMetaData dbmd, IntrospectedTableImpl introspectedTable, List warnings)
/* 249:    */   {
/* 250:279 */     ResultSet rs = null;
/* 251:    */     try
/* 252:    */     {
/* 253:282 */       rs = dbmd.getPrimaryKeys(introspectedTable.getTable().getCatalog(), introspectedTable.getTable().getSchema(), 
/* 254:283 */         introspectedTable.getTable().getTableName());
/* 255:    */     }
/* 256:    */     catch (SQLException e)
/* 257:    */     {
/* 258:286 */       closeResultSet(rs);
/* 259:287 */       warnings.add(Messages.getString("Warning.15"));
/* 260:288 */       return;
/* 261:    */     }
/* 262:    */     try
/* 263:    */     {
/* 264:    */       do
/* 265:    */       {
/* 266:293 */         String columnName = rs.getString("COLUMN_NAME");
/* 267:    */         
/* 268:295 */         introspectedTable.getColumnDefinitions().addPrimaryKeyColumn(columnName);
/* 269:292 */       } while (rs.next());
/* 270:    */     }
/* 271:    */     catch (SQLException localSQLException1) {}finally
/* 272:    */     {
/* 273:302 */       closeResultSet(rs);
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   private static void closeResultSet(ResultSet rs)
/* 278:    */   {
/* 279:307 */     if (rs != null) {
/* 280:    */       try
/* 281:    */       {
/* 282:309 */         rs.close();
/* 283:    */       }
/* 284:    */       catch (SQLException localSQLException) {}
/* 285:    */     }
/* 286:    */   }
/* 287:    */   
/* 288:    */   private static void reportIntrospectionWarnings(ColumnDefinitions columnDefinitions, TableConfiguration tableConfiguration, FullyQualifiedTable table, List warnings)
/* 289:    */   {
/* 290:322 */     Iterator iter = tableConfiguration.getColumnOverrides();
/* 291:323 */     while (iter.hasNext())
/* 292:    */     {
/* 293:324 */       ColumnOverride columnOverride = (ColumnOverride)iter.next();
/* 294:325 */       if (columnDefinitions.getColumn(columnOverride.getColumnName()) == null) {
/* 295:326 */         warnings.add(Messages.getString("Warning.3", 
/* 296:327 */           columnOverride.getColumnName(), table.toString()));
/* 297:    */       }
/* 298:    */     }
/* 299:333 */     iter = tableConfiguration.getIgnoredColumnsInError();
/* 300:334 */     while (iter.hasNext())
/* 301:    */     {
/* 302:335 */       String ignoredColumn = (String)iter.next();
/* 303:    */       
/* 304:337 */       warnings.add(Messages.getString("Warning.4", 
/* 305:338 */         ignoredColumn, table.toString()));
/* 306:    */     }
/* 307:341 */     GeneratedKey generatedKey = tableConfiguration.getGeneratedKey();
/* 308:342 */     if ((generatedKey != null) && (columnDefinitions.getColumn(generatedKey.getColumn().toUpperCase()) == null)) {
/* 309:343 */       if (generatedKey.isIdentity()) {
/* 310:344 */         warnings.add(Messages.getString("Warning.5", 
/* 311:345 */           generatedKey.getColumn(), table.toString()));
/* 312:    */       } else {
/* 313:348 */         warnings.add(Messages.getString("Warning.6", 
/* 314:349 */           generatedKey.getColumn(), table.toString()));
/* 315:    */       }
/* 316:    */     }
/* 317:    */   }
/* 318:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.db.DatabaseIntrospector
 * JD-Core Version:    0.7.0.1
 */