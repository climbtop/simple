/*   1:    */ package org.apache.ibatis.abator.internal.db;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*   4:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   5:    */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*   6:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*   7:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   8:    */ 
/*   9:    */ public class ColumnDefinition
/*  10:    */ {
/*  11:    */   private String columnName;
/*  12:    */   private int jdbcType;
/*  13:    */   private boolean nullable;
/*  14:    */   private int length;
/*  15:    */   private int scale;
/*  16:    */   private String typeName;
/*  17:    */   private boolean identity;
/*  18:    */   private String javaProperty;
/*  19:    */   private ResolvedJavaType resolvedJavaType;
/*  20:    */   private String tableAlias;
/*  21:    */   private String typeHandler;
/*  22:    */   private String memo;
/*  23: 57 */   private boolean listable = true;
/*  24: 59 */   private boolean queryable = true;
/*  25: 61 */   private boolean mainFk = false;
/*  26:    */   private String label;
/*  27: 65 */   private String htmlEditor = "text";
/*  28:    */   private String optionValue;
/*  29: 69 */   private String validator = "";
/*  30:    */   private String defaultValue;
/*  31:    */   private String aliasedColumnName;
/*  32:    */   private String renamedColumnName;
/*  33:    */   private String selectListPhrase;
/*  34:    */   
/*  35:    */   public ColumnDefinition(String tableAlias)
/*  36:    */   {
/*  37:102 */     this.tableAlias = tableAlias;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public int getJdbcType()
/*  41:    */   {
/*  42:106 */     return this.jdbcType;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setJdbcType(int jdbcType)
/*  46:    */   {
/*  47:110 */     this.jdbcType = jdbcType;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public int getLength()
/*  51:    */   {
/*  52:114 */     return this.length;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setLength(int length)
/*  56:    */   {
/*  57:118 */     this.length = length;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isNullable()
/*  61:    */   {
/*  62:122 */     return this.nullable;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setNullable(boolean nullable)
/*  66:    */   {
/*  67:126 */     this.nullable = nullable;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public int getScale()
/*  71:    */   {
/*  72:130 */     return this.scale;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setScale(int scale)
/*  76:    */   {
/*  77:134 */     this.scale = scale;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public String getTypeName()
/*  81:    */   {
/*  82:138 */     return this.typeName;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setTypeName(String typeName)
/*  86:    */   {
/*  87:142 */     this.typeName = typeName;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean isShortOrIntOrLong()
/*  91:    */   {
/*  92:146 */     String javaType = this.resolvedJavaType.getFullyQualifiedJavaType().getBaseShortName();
/*  93:147 */     return "long,Long,int,Integer,short,Short".indexOf(javaType) > -1;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean isDoubleOrFloat()
/*  97:    */   {
/*  98:150 */     String javaType = this.resolvedJavaType.getFullyQualifiedJavaType().getBaseShortName();
/*  99:151 */     return "Double,double,Float,float".indexOf(javaType) > -1;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean isDateOrTime()
/* 103:    */   {
/* 104:154 */     String javaType = this.resolvedJavaType.getFullyQualifiedJavaType().getBaseShortName();
/* 105:155 */     return (this.resolvedJavaType.isJDBCDate()) || (this.resolvedJavaType.isJDBCTime()) || ("Date".equalsIgnoreCase(javaType));
/* 106:    */   }
/* 107:    */   
/* 108:    */   public boolean isPhoneNumber()
/* 109:    */   {
/* 110:158 */     return this.javaProperty.toLowerCase().indexOf("phone") > -1;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public boolean isMobilePhone()
/* 114:    */   {
/* 115:161 */     return this.javaProperty.toLowerCase().indexOf("mobile") > -1;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean isEmail()
/* 119:    */   {
/* 120:164 */     return this.javaProperty.toLowerCase().indexOf("email") > -1;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public boolean isUrl()
/* 124:    */   {
/* 125:167 */     return this.javaProperty.toLowerCase().indexOf("url") > -1;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String getDefaultJqueryValidator()
/* 129:    */   {
/* 130:171 */     String editor = getHtmlEditor().toLowerCase();
/* 131:172 */     StringBuilder sb = new StringBuilder();
/* 132:173 */     if ((editor.startsWith("textarea")) || (editor.startsWith("text")) || (editor.startsWith("password")))
/* 133:    */     {
/* 134:174 */       boolean and = false;
/* 135:175 */       if (!isNullable())
/* 136:    */       {
/* 137:176 */         and = true;
/* 138:177 */         sb.append("validate[required");
/* 139:    */       }
/* 140:179 */       if (isDateOrTime())
/* 141:    */       {
/* 142:180 */         if (and)
/* 143:    */         {
/* 144:181 */           sb.append(",");
/* 145:    */         }
/* 146:    */         else
/* 147:    */         {
/* 148:184 */           sb.append("validate[");
/* 149:185 */           and = true;
/* 150:    */         }
/* 151:187 */         sb.append("custom[date]");
/* 152:    */       }
/* 153:189 */       else if ((isDoubleOrFloat()) || (isShortOrIntOrLong()))
/* 154:    */       {
/* 155:190 */         if (and)
/* 156:    */         {
/* 157:191 */           sb.append(",");
/* 158:    */         }
/* 159:    */         else
/* 160:    */         {
/* 161:194 */           sb.append("validate[");
/* 162:195 */           and = true;
/* 163:    */         }
/* 164:197 */         sb.append("custom[onlyNumber]");
/* 165:    */       }
/* 166:199 */       else if (isPhoneNumber())
/* 167:    */       {
/* 168:200 */         if (and)
/* 169:    */         {
/* 170:201 */           sb.append(",");
/* 171:    */         }
/* 172:    */         else
/* 173:    */         {
/* 174:204 */           sb.append("validate[");
/* 175:205 */           and = true;
/* 176:    */         }
/* 177:207 */         sb.append("custom[telephone]");
/* 178:    */       }
/* 179:209 */       else if (isMobilePhone())
/* 180:    */       {
/* 181:210 */         if (and)
/* 182:    */         {
/* 183:211 */           sb.append(",");
/* 184:    */         }
/* 185:    */         else
/* 186:    */         {
/* 187:214 */           sb.append("validate[");
/* 188:215 */           and = true;
/* 189:    */         }
/* 190:217 */         sb.append("custom[mobilephone]");
/* 191:    */       }
/* 192:219 */       else if (isEmail())
/* 193:    */       {
/* 194:220 */         if (and)
/* 195:    */         {
/* 196:221 */           sb.append(",");
/* 197:    */         }
/* 198:    */         else
/* 199:    */         {
/* 200:224 */           sb.append("validate[");
/* 201:225 */           and = true;
/* 202:    */         }
/* 203:227 */         sb.append("custom[email]");
/* 204:    */       }
/* 205:229 */       else if (isUrl())
/* 206:    */       {
/* 207:230 */         if (and)
/* 208:    */         {
/* 209:231 */           sb.append(",");
/* 210:    */         }
/* 211:    */         else
/* 212:    */         {
/* 213:234 */           sb.append("validate[");
/* 214:235 */           and = true;
/* 215:    */         }
/* 216:237 */         sb.append("custom[url]");
/* 217:    */       }
/* 218:239 */       if (getLength() > 0)
/* 219:    */       {
/* 220:240 */         if (and)
/* 221:    */         {
/* 222:241 */           sb.append(",");
/* 223:    */         }
/* 224:    */         else
/* 225:    */         {
/* 226:244 */           sb.append("validate[");
/* 227:245 */           and = true;
/* 228:    */         }
/* 229:247 */         sb.append("length[0,").append(getLength()).append("]");
/* 230:    */       }
/* 231:249 */       if (and) {
/* 232:250 */         sb.append("] ");
/* 233:    */       }
/* 234:251 */       sb.append("text-input");
/* 235:    */     }
/* 236:253 */     else if (editor.startsWith("radio"))
/* 237:    */     {
/* 238:254 */       if (!isNullable()) {
/* 239:255 */         sb.append("validate[required]");
/* 240:    */       }
/* 241:257 */       sb.append(" radio");
/* 242:    */     }
/* 243:259 */     else if (editor.startsWith("checkbox"))
/* 244:    */     {
/* 245:260 */       if (!isNullable()) {
/* 246:261 */         sb.append("validate[minCheckbox[1]]");
/* 247:    */       }
/* 248:263 */       sb.append(" checkbox");
/* 249:    */     }
/* 250:265 */     else if ((editor.startsWith("select")) && 
/* 251:266 */       (!isNullable()))
/* 252:    */     {
/* 253:267 */       sb.append("validate[required]");
/* 254:    */     }
/* 255:270 */     return sb.toString();
/* 256:    */   }
/* 257:    */   
/* 258:    */   private String getPropertyName(boolean query)
/* 259:    */   {
/* 260:274 */     if (query) {
/* 261:275 */       return JavaBeansUtil.getPrefixProperty("eq", this.javaProperty);
/* 262:    */     }
/* 263:276 */     return this.javaProperty;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public StringBuilder appendProperty(StringBuilder sb, String objName, boolean query)
/* 267:    */   {
/* 268:280 */     return appendProperty(sb, objName, query, null);
/* 269:    */   }
/* 270:    */   
/* 271:    */   public StringBuilder appendDateFormattedProperty(StringBuilder sb, String objName, boolean query)
/* 272:    */   {
/* 273:284 */     return appendFormattedProperty(sb, objName, query, false);
/* 274:    */   }
/* 275:    */   
/* 276:    */   public StringBuilder appendFormattedProperty(StringBuilder sb, String objName, boolean query, boolean formatNumber)
/* 277:    */   {
/* 278:287 */     if (isDateOrTime())
/* 279:    */     {
/* 280:288 */       sb.append("<fmt:formatDate value=\"");
/* 281:289 */       appendProperty(sb, objName, query);
/* 282:290 */       sb.append("\" pattern=\"yyyy-MM-dd hh:mm:ss\" />");
/* 283:291 */       return sb;
/* 284:    */     }
/* 285:294 */     if (!formatNumber) {
/* 286:295 */       return appendProperty(sb, objName, query);
/* 287:    */     }
/* 288:297 */     if (isDoubleOrFloat())
/* 289:    */     {
/* 290:298 */       sb.append("<fmt:formatNumber value=\"");
/* 291:299 */       appendProperty(sb, objName, query);
/* 292:300 */       sb.append("\" pattern=\"");
/* 293:301 */       StringBuilder temp = new StringBuilder();
/* 294:302 */       int i = 0;
/* 295:303 */       while (i < this.scale)
/* 296:    */       {
/* 297:304 */         temp.append('#');
/* 298:305 */         i++;
/* 299:    */       }
/* 300:307 */       temp.insert(0, ".");
/* 301:309 */       for (int j = 0; i < this.length; j++)
/* 302:    */       {
/* 303:310 */         temp.insert(0, "#");
/* 304:311 */         if ((j % 3 == 2) && (i < this.length - 1)) {
/* 305:312 */           temp.insert(0, ",");
/* 306:    */         }
/* 307:309 */         i++;
/* 308:    */       }
/* 309:314 */       sb.append(temp).append("\" />");
/* 310:315 */       return sb;
/* 311:    */     }
/* 312:317 */     if (("status".equalsIgnoreCase(this.javaProperty)) && (!query))
/* 313:    */     {
/* 314:318 */       sb.append("<span class=\"status");
/* 315:319 */       appendProperty(sb, objName, false).append("\">");
/* 316:320 */       appendProperty(sb, objName, false).append("</span>");
/* 317:321 */       return sb;
/* 318:    */     }
/* 319:324 */     return appendProperty(sb, objName, query);
/* 320:    */   }
/* 321:    */   
/* 322:    */   public StringBuilder appendProperty(StringBuilder sb, String objName, boolean query, String value)
/* 323:    */   {
/* 324:328 */     sb.append("${");
/* 325:329 */     if (query) {
/* 326:330 */       sb.append(JavaBeansUtil.getPrefixProperty("eq", this.javaProperty));
/* 327:    */     } else {
/* 328:332 */       sb.append(objName).append(".").append(this.javaProperty);
/* 329:    */     }
/* 330:334 */     if (StringUtility.stringHasValue(value))
/* 331:    */     {
/* 332:335 */       sb.append("==");
/* 333:336 */       if ("String".equalsIgnoreCase(this.resolvedJavaType.getFullyQualifiedJavaType().getBaseShortName())) {
/* 334:337 */         sb.append("'").append(value).append("'");
/* 335:    */       } else {
/* 336:339 */         sb.append(value);
/* 337:    */       }
/* 338:    */     }
/* 339:341 */     sb.append("}");
/* 340:342 */     return sb;
/* 341:    */   }
/* 342:    */   
/* 343:    */   public String toHtmlLabelString(boolean query)
/* 344:    */   {
/* 345:346 */     StringBuilder sb = new StringBuilder();
/* 346:347 */     sb.append("<label for=\"").append(getPropertyName(query)).append("\">").append(this.label).append(":</label>");
/* 347:348 */     if ((!isNullable()) && (!query) && (this.htmlEditor.toLowerCase().indexOf("hidden") < 0)) {
/* 348:349 */       sb.append(" <span style=\"color:red\">*</span>");
/* 349:    */     }
/* 350:350 */     return sb.toString();
/* 351:    */   }
/* 352:    */   
/* 353:    */   public String toHtmlEditorString(String objName, boolean query)
/* 354:    */   {
/* 355:354 */     StringBuilder sb = new StringBuilder();
/* 356:355 */     String[] editor = this.htmlEditor.split(":");
/* 357:357 */     if ("textArea".equalsIgnoreCase(editor[0]))
/* 358:    */     {
/* 359:358 */       OutputUtilities.newLine(sb);
/* 360:359 */       OutputUtilities.xmlIndent(sb, 4);
/* 361:360 */       sb.append("<textarea name=\"").append(getPropertyName(query)).append("\"");
/* 362:361 */       sb.append(" id=\"").append(getPropertyName(query)).append("\"");
/* 363:362 */       if (editor.length > 1) {
/* 364:363 */         sb.append(" rows=\"").append(editor[1]).append("\"");
/* 365:    */       } else {
/* 366:365 */         sb.append(" rows=\"3\"");
/* 367:    */       }
/* 368:366 */       if (editor.length > 2) {
/* 369:367 */         sb.append(" cols=\"").append(editor[2]).append("\"");
/* 370:    */       } else {
/* 371:369 */         sb.append(" cols=\"80\"");
/* 372:    */       }
/* 373:370 */       sb.append(" class=\"").append(this.validator).append("\">");
/* 374:371 */       appendProperty(sb, objName, query).append("</textarea>");
/* 375:372 */       OutputUtilities.newLine(sb);
/* 376:373 */       OutputUtilities.xmlIndent(sb, 3);
/* 377:    */     }
/* 378:375 */     else if ("select".equalsIgnoreCase(editor[0]))
/* 379:    */     {
/* 380:376 */       setSelectString(objName, editor, sb, query);
/* 381:    */     }
/* 382:378 */     else if ("hidden".equalsIgnoreCase(editor[0]))
/* 383:    */     {
/* 384:379 */       setInputString(objName, editor, sb, query);
/* 385:    */     }
/* 386:381 */     else if ("password".equalsIgnoreCase(editor[0]))
/* 387:    */     {
/* 388:382 */       setInputString(objName, editor, sb, query);
/* 389:    */     }
/* 390:384 */     else if ("text".equalsIgnoreCase(editor[0]))
/* 391:    */     {
/* 392:385 */       setInputString(objName, editor, sb, query);
/* 393:    */     }
/* 394:387 */     else if ("radio".equalsIgnoreCase(editor[0]))
/* 395:    */     {
/* 396:388 */       setCheckedInputString(objName, editor, sb, query);
/* 397:    */     }
/* 398:390 */     else if ("checkbox".equalsIgnoreCase(editor[0]))
/* 399:    */     {
/* 400:391 */       setCheckedInputString(objName, editor, sb, query);
/* 401:    */     }
/* 402:394 */     if (!query) {
/* 403:395 */       setValidatorErrorString(editor, sb);
/* 404:    */     }
/* 405:397 */     return sb.toString();
/* 406:    */   }
/* 407:    */   
/* 408:    */   private void setValidatorErrorString(String[] editor, StringBuilder sb)
/* 409:    */   {
/* 410:401 */     if ((editor[0].equalsIgnoreCase("text")) || (editor[0].equalsIgnoreCase("textarea")) || (editor[0].equalsIgnoreCase("password")))
/* 411:    */     {
/* 412:402 */       sb.append(" <span class='validateError'><form:errors path=\"").append(this.javaProperty).append("\" /></span>");
/* 413:403 */       OutputUtilities.newLine(sb);
/* 414:404 */       OutputUtilities.xmlIndent(sb, 3);
/* 415:    */     }
/* 416:    */   }
/* 417:    */   
/* 418:    */   private void setInputString(String objName, String[] editor, StringBuilder sb, boolean query)
/* 419:    */   {
/* 420:409 */     String type = query ? "text" : editor[0];
/* 421:410 */     OutputUtilities.newLine(sb);
/* 422:411 */     OutputUtilities.xmlIndent(sb, 4);
/* 423:    */     
/* 424:413 */     sb.append("<input type=\"").append(type).append("\" name=\"").append(getPropertyName(query)).append("\"");
/* 425:414 */     sb.append(" id=\"").append(getPropertyName(query)).append("\"");
/* 426:415 */     if (("text".equalsIgnoreCase(type)) || ("password".equalsIgnoreCase(type)))
/* 427:    */     {
/* 428:416 */       if (editor.length > 1)
/* 429:    */       {
/* 430:417 */         sb.append(" size=\"").append(editor[1]).append("\"");
/* 431:    */       }
/* 432:    */       else
/* 433:    */       {
/* 434:420 */         int size = this.length;
/* 435:421 */         if (query) {
/* 436:422 */           size = this.length > 14 ? 14 : isShortOrIntOrLong() ? 8 : this.length;
/* 437:    */         } else {
/* 438:424 */           size = this.length > 60 ? 60 : this.length;
/* 439:    */         }
/* 440:425 */         sb.append(" size=\"").append(size).append("\"");
/* 441:    */       }
/* 442:427 */       sb.append(" maxlength=\"").append(this.length).append("\" class=\"").append(this.validator).append("\"");
/* 443:    */     }
/* 444:429 */     sb.append(" value=\"");
/* 445:430 */     appendDateFormattedProperty(sb, objName, query).append("\"/>");
/* 446:431 */     if ("hidden".equalsIgnoreCase(type)) {
/* 447:432 */       appendDateFormattedProperty(sb, objName, query);
/* 448:    */     }
/* 449:434 */     OutputUtilities.newLine(sb);
/* 450:435 */     OutputUtilities.xmlIndent(sb, 3);
/* 451:    */   }
/* 452:    */   
/* 453:    */   private void setSelectString(String objName, String[] editor, StringBuilder sb, boolean query)
/* 454:    */   {
/* 455:439 */     OutputUtilities.newLine(sb);
/* 456:440 */     OutputUtilities.xmlIndent(sb, 4);
/* 457:441 */     sb.append("<select name=\"").append(getPropertyName(query)).append("\"");
/* 458:442 */     sb.append(" id=\"").append(getPropertyName(query)).append("\"");
/* 459:443 */     String size = editor.length > 1 ? editor[1] : "1";
/* 460:444 */     sb.append(" size=\"").append(size).append("\">");
/* 461:446 */     if (StringUtility.stringHasValue(this.optionValue))
/* 462:    */     {
/* 463:447 */       String[] options = this.optionValue.split(";");
/* 464:448 */       for (String option : options) {
/* 465:449 */         if (StringUtility.stringHasValue(option.trim()))
/* 466:    */         {
/* 467:451 */           String[] kv = option.trim().split(":");
/* 468:452 */           String value = kv[0].trim();
/* 469:453 */           String text = kv.length > 1 ? kv[1].trim() : value;
/* 470:454 */           setOptionStringInternal(objName, editor, sb, value, text, query);
/* 471:    */         }
/* 472:    */       }
/* 473:    */     }
/* 474:    */     else
/* 475:    */     {
/* 476:458 */       setOptionStringInternal(objName, editor, sb, "", "--请选择--", query);
/* 477:    */     }
/* 478:460 */     OutputUtilities.newLine(sb);
/* 479:461 */     OutputUtilities.xmlIndent(sb, 4);
/* 480:462 */     sb.append("</select>");
/* 481:463 */     OutputUtilities.newLine(sb);
/* 482:464 */     OutputUtilities.xmlIndent(sb, 3);
/* 483:    */   }
/* 484:    */   
/* 485:    */   private void setOptionStringInternal(String objName, String[] editor, StringBuilder sb, String value, String text, boolean query)
/* 486:    */   {
/* 487:468 */     OutputUtilities.newLine(sb);
/* 488:469 */     OutputUtilities.xmlIndent(sb, 5);
/* 489:470 */     sb.append("<option value=\"").append(value).append("\" ");
/* 490:471 */     sb.append(" <c:if test=\"");
/* 491:472 */     appendProperty(sb, objName, query, value).append("}\">selected</c:if> >");
/* 492:473 */     sb.append(text).append("</option>");
/* 493:    */   }
/* 494:    */   
/* 495:    */   private void setCheckedInputString(String objName, String[] editor, StringBuilder sb, boolean query)
/* 496:    */   {
/* 497:477 */     if (StringUtility.stringHasValue(this.optionValue))
/* 498:    */     {
/* 499:478 */       String[] options = this.optionValue.split(";");
/* 500:479 */       for (String option : options) {
/* 501:480 */         if (StringUtility.stringHasValue(option.trim()))
/* 502:    */         {
/* 503:482 */           String[] kv = option.trim().split(":");
/* 504:483 */           String value = kv[0].trim();
/* 505:484 */           String text = kv.length > 1 ? kv[1].trim() : value;
/* 506:485 */           setCheckedInputStringInternal(objName, editor, sb, value, text, query);
/* 507:    */         }
/* 508:    */       }
/* 509:    */     }
/* 510:    */     else
/* 511:    */     {
/* 512:489 */       setCheckedInputStringInternal(objName, editor, sb, "0", "0", query);
/* 513:    */     }
/* 514:491 */     OutputUtilities.newLine(sb);
/* 515:492 */     OutputUtilities.xmlIndent(sb, 3);
/* 516:    */   }
/* 517:    */   
/* 518:    */   private void setCheckedInputStringInternal(String objName, String[] editor, StringBuilder sb, String value, String text, boolean query)
/* 519:    */   {
/* 520:496 */     OutputUtilities.newLine(sb);
/* 521:497 */     OutputUtilities.xmlIndent(sb, 4);
/* 522:498 */     sb.append("<input type=\"").append(editor[0]).append("\" name=\"").append(getPropertyName(query)).append("\"");
/* 523:499 */     sb.append(" value=\"").append(value).append("\" ");
/* 524:500 */     sb.append(" <c:if test=\"");
/* 525:501 */     appendProperty(sb, objName, query, value).append("\">checked</c:if> />");
/* 526:502 */     sb.append(text);
/* 527:    */   }
/* 528:    */   
/* 529:    */   public String toString()
/* 530:    */   {
/* 531:509 */     StringBuffer sb = new StringBuffer();
/* 532:    */     
/* 533:511 */     sb.append("Column Name: ");
/* 534:512 */     sb.append(this.columnName);
/* 535:513 */     sb.append(", JDBC Type: ");
/* 536:514 */     sb.append(this.jdbcType);
/* 537:515 */     sb.append(", Type Name: ");
/* 538:516 */     sb.append(this.typeName);
/* 539:517 */     sb.append(", Nullable: ");
/* 540:518 */     sb.append(this.nullable);
/* 541:519 */     sb.append(", Length: ");
/* 542:520 */     sb.append(this.length);
/* 543:521 */     sb.append(", Scale: ");
/* 544:522 */     sb.append(this.scale);
/* 545:523 */     sb.append(", Identity: ");
/* 546:524 */     sb.append(this.identity);
/* 547:525 */     sb.append(", javaProperty: ");
/* 548:526 */     sb.append(this.javaProperty);
/* 549:527 */     sb.append(", Label: ");
/* 550:528 */     sb.append(this.label);
/* 551:529 */     sb.append(", listable: ");
/* 552:530 */     sb.append(this.listable);
/* 553:531 */     sb.append(", queryable: ");
/* 554:532 */     sb.append(this.queryable);
/* 555:533 */     sb.append(", mainFk: ");
/* 556:534 */     sb.append(this.mainFk);
/* 557:535 */     sb.append(", memo: ");
/* 558:536 */     sb.append(this.memo);
/* 559:537 */     sb.append(", htmlEditor: ");
/* 560:538 */     sb.append(this.htmlEditor);
/* 561:539 */     sb.append(", validator: ");
/* 562:540 */     sb.append(this.validator);
/* 563:541 */     sb.append(", defaultValue: ");
/* 564:542 */     sb.append(this.defaultValue);
/* 565:543 */     sb.append(", optionValue: ");
/* 566:544 */     sb.append(this.optionValue);
/* 567:    */     
/* 568:546 */     return sb.toString();
/* 569:    */   }
/* 570:    */   
/* 571:    */   public String getColumnName()
/* 572:    */   {
/* 573:550 */     return this.columnName;
/* 574:    */   }
/* 575:    */   
/* 576:    */   public void setColumnName(String columnName)
/* 577:    */   {
/* 578:554 */     this.columnName = columnName;
/* 579:556 */     if (StringUtility.stringHasValue(this.tableAlias))
/* 580:    */     {
/* 581:557 */       StringBuffer sb = new StringBuffer();
/* 582:    */       
/* 583:559 */       sb.append(this.tableAlias);
/* 584:560 */       sb.append('.');
/* 585:561 */       sb.append(columnName);
/* 586:562 */       this.aliasedColumnName = sb.toString();
/* 587:    */       
/* 588:564 */       sb.setLength(0);
/* 589:565 */       sb.append(this.tableAlias);
/* 590:566 */       sb.append('_');
/* 591:567 */       sb.append(columnName);
/* 592:568 */       this.renamedColumnName = sb.toString();
/* 593:    */       
/* 594:570 */       sb.setLength(0);
/* 595:571 */       sb.append(this.tableAlias);
/* 596:572 */       sb.append('.');
/* 597:573 */       sb.append(columnName);
/* 598:574 */       sb.append(" as ");
/* 599:575 */       sb.append(this.tableAlias);
/* 600:576 */       sb.append('_');
/* 601:577 */       sb.append(columnName);
/* 602:578 */       this.selectListPhrase = sb.toString();
/* 603:    */     }
/* 604:    */     else
/* 605:    */     {
/* 606:580 */       this.aliasedColumnName = columnName;
/* 607:581 */       this.renamedColumnName = columnName;
/* 608:582 */       this.selectListPhrase = columnName;
/* 609:    */     }
/* 610:    */   }
/* 611:    */   
/* 612:    */   public boolean isIdentity()
/* 613:    */   {
/* 614:590 */     return this.identity;
/* 615:    */   }
/* 616:    */   
/* 617:    */   public void setIdentity(boolean identity)
/* 618:    */   {
/* 619:598 */     this.identity = identity;
/* 620:    */   }
/* 621:    */   
/* 622:    */   public boolean isBLOBColumn()
/* 623:    */   {
/* 624:602 */     String typeName = this.resolvedJavaType.getJdbcTypeName();
/* 625:    */     
/* 626:604 */     return ("BLOB".equals(typeName)) || ("LONGVARBINARY".equals(typeName)) || 
/* 627:605 */       ("LONGVARCHAR".equals(typeName)) || ("CLOB".equals(typeName));
/* 628:    */   }
/* 629:    */   
/* 630:    */   public boolean isStringColumn()
/* 631:    */   {
/* 632:609 */     return this.resolvedJavaType.getFullyQualifiedJavaType() == 
/* 633:610 */       FullyQualifiedJavaType.getStringInstance();
/* 634:    */   }
/* 635:    */   
/* 636:    */   public boolean isJdbcCharacterColumn()
/* 637:    */   {
/* 638:614 */     return (this.jdbcType == 1) || 
/* 639:615 */       (this.jdbcType == 2005) || 
/* 640:616 */       (this.jdbcType == -1) || 
/* 641:617 */       (this.jdbcType == 12);
/* 642:    */   }
/* 643:    */   
/* 644:    */   public String getJavaProperty()
/* 645:    */   {
/* 646:621 */     return this.javaProperty;
/* 647:    */   }
/* 648:    */   
/* 649:    */   public void setJavaProperty(String javaProperty)
/* 650:    */   {
/* 651:625 */     this.javaProperty = javaProperty;
/* 652:    */   }
/* 653:    */   
/* 654:    */   public ResolvedJavaType getResolvedJavaType()
/* 655:    */   {
/* 656:629 */     return this.resolvedJavaType;
/* 657:    */   }
/* 658:    */   
/* 659:    */   public void setResolvedJavaType(ResolvedJavaType resolvedJavaType)
/* 660:    */   {
/* 661:633 */     this.resolvedJavaType = resolvedJavaType;
/* 662:    */   }
/* 663:    */   
/* 664:    */   public String getByExampleIndicatorProperty()
/* 665:    */   {
/* 666:637 */     return this.javaProperty + "_Indicator";
/* 667:    */   }
/* 668:    */   
/* 669:    */   public String getRenamedColumnName()
/* 670:    */   {
/* 671:641 */     return this.renamedColumnName;
/* 672:    */   }
/* 673:    */   
/* 674:    */   public String getAliasedColumnName()
/* 675:    */   {
/* 676:645 */     return this.aliasedColumnName;
/* 677:    */   }
/* 678:    */   
/* 679:    */   public String getSelectListPhrase()
/* 680:    */   {
/* 681:649 */     return this.selectListPhrase;
/* 682:    */   }
/* 683:    */   
/* 684:    */   public boolean isJDBCDateColumn()
/* 685:    */   {
/* 686:653 */     return (this.resolvedJavaType.isJDBCDate()) && 
/* 687:654 */       (!StringUtility.stringHasValue(this.typeHandler));
/* 688:    */   }
/* 689:    */   
/* 690:    */   public boolean isJDBCTimeColumn()
/* 691:    */   {
/* 692:658 */     return (this.resolvedJavaType.isJDBCTime()) && 
/* 693:659 */       (!StringUtility.stringHasValue(this.typeHandler));
/* 694:    */   }
/* 695:    */   
/* 696:    */   public String getIbatisFormattedParameterClause()
/* 697:    */   {
/* 698:663 */     return getIbatisFormattedParameterClauseInternal(getJavaProperty());
/* 699:    */   }
/* 700:    */   
/* 701:    */   public String getIbatisFormattedParameterClause(String propertyName)
/* 702:    */   {
/* 703:667 */     return getIbatisFormattedParameterClauseInternal(propertyName);
/* 704:    */   }
/* 705:    */   
/* 706:    */   public String getPrefixJavaProperty(String prefix)
/* 707:    */   {
/* 708:671 */     StringBuffer sb = new StringBuffer(this.javaProperty);
/* 709:673 */     if (Character.isLowerCase(sb.charAt(0))) {
/* 710:674 */       sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 711:    */     }
/* 712:677 */     if (StringUtility.stringHasValue(prefix)) {
/* 713:678 */       sb.insert(0, prefix);
/* 714:    */     }
/* 715:680 */     return sb.toString();
/* 716:    */   }
/* 717:    */   
/* 718:    */   public String getIbatisFormattedExampleParameterClause(String property, int databaseDialect)
/* 719:    */   {
/* 720:684 */     if (this.resolvedJavaType.getFullyQualifiedJavaType().getBaseShortName().equalsIgnoreCase("Date"))
/* 721:    */     {
/* 722:685 */       StringBuilder sb = new StringBuilder();
/* 723:686 */       if (DatabaseDialects.ORACLE.intValue() == databaseDialect)
/* 724:    */       {
/* 725:687 */         sb.append("TO_DATE( #");
/* 726:688 */         sb.append(property);
/* 727:689 */         sb.append(":VARCHAR#, 'yyyy-MM-dd  hh24:mi:ss' )");
/* 728:690 */         return sb.toString();
/* 729:    */       }
/* 730:    */     }
/* 731:693 */     return getIbatisFormattedParameterClauseInternal(property);
/* 732:    */   }
/* 733:    */   
/* 734:    */   private String getIbatisFormattedParameterClauseInternal(String property)
/* 735:    */   {
/* 736:697 */     StringBuffer sb = new StringBuffer();
/* 737:    */     
/* 738:699 */     sb.append('#');
/* 739:700 */     sb.append(property);
/* 740:702 */     if (StringUtility.stringHasValue(this.typeHandler))
/* 741:    */     {
/* 742:703 */       sb.append(",jdbcType=");
/* 743:704 */       sb.append(getResolvedJavaType().getJdbcTypeName());
/* 744:705 */       sb.append(",handler=");
/* 745:706 */       sb.append(this.typeHandler);
/* 746:    */     }
/* 747:    */     else
/* 748:    */     {
/* 749:708 */       sb.append(':');
/* 750:709 */       sb.append(getResolvedJavaType().getJdbcTypeName());
/* 751:    */     }
/* 752:712 */     sb.append('#');
/* 753:    */     
/* 754:714 */     return sb.toString();
/* 755:    */   }
/* 756:    */   
/* 757:    */   public String getTypeHandler()
/* 758:    */   {
/* 759:718 */     return this.typeHandler;
/* 760:    */   }
/* 761:    */   
/* 762:    */   public void setTypeHandler(String typeHandler)
/* 763:    */   {
/* 764:722 */     this.typeHandler = typeHandler;
/* 765:    */   }
/* 766:    */   
/* 767:    */   public String getMemo()
/* 768:    */   {
/* 769:729 */     return this.memo;
/* 770:    */   }
/* 771:    */   
/* 772:    */   public void setMemo(String memo)
/* 773:    */   {
/* 774:736 */     this.memo = memo;
/* 775:    */   }
/* 776:    */   
/* 777:    */   public boolean isListable()
/* 778:    */   {
/* 779:743 */     return this.listable;
/* 780:    */   }
/* 781:    */   
/* 782:    */   public void setListable(boolean listable)
/* 783:    */   {
/* 784:750 */     this.listable = listable;
/* 785:    */   }
/* 786:    */   
/* 787:    */   public boolean isQueryable()
/* 788:    */   {
/* 789:757 */     return this.queryable;
/* 790:    */   }
/* 791:    */   
/* 792:    */   public void setQueryable(boolean queryable)
/* 793:    */   {
/* 794:764 */     this.queryable = queryable;
/* 795:    */   }
/* 796:    */   
/* 797:    */   public boolean isMainFk()
/* 798:    */   {
/* 799:768 */     return this.mainFk;
/* 800:    */   }
/* 801:    */   
/* 802:    */   public void setMainFk(boolean mainFk)
/* 803:    */   {
/* 804:772 */     this.mainFk = mainFk;
/* 805:    */   }
/* 806:    */   
/* 807:    */   public String getLabel()
/* 808:    */   {
/* 809:779 */     return this.label;
/* 810:    */   }
/* 811:    */   
/* 812:    */   public void setLabel(String label)
/* 813:    */   {
/* 814:786 */     this.label = label;
/* 815:    */   }
/* 816:    */   
/* 817:    */   public String getHtmlEditor()
/* 818:    */   {
/* 819:793 */     return this.htmlEditor;
/* 820:    */   }
/* 821:    */   
/* 822:    */   public void setHtmlEditor(String htmlEditor)
/* 823:    */   {
/* 824:800 */     this.htmlEditor = htmlEditor;
/* 825:    */   }
/* 826:    */   
/* 827:    */   public String getOptionValue()
/* 828:    */   {
/* 829:807 */     return this.optionValue;
/* 830:    */   }
/* 831:    */   
/* 832:    */   public void setOptionValue(String optionValue)
/* 833:    */   {
/* 834:814 */     this.optionValue = optionValue;
/* 835:    */   }
/* 836:    */   
/* 837:    */   public String getDefaultValue()
/* 838:    */   {
/* 839:821 */     return this.defaultValue;
/* 840:    */   }
/* 841:    */   
/* 842:    */   public void setDefaultValue(String defaultValue)
/* 843:    */   {
/* 844:828 */     this.defaultValue = defaultValue;
/* 845:    */   }
/* 846:    */   
/* 847:    */   public String getValidator()
/* 848:    */   {
/* 849:835 */     return this.validator;
/* 850:    */   }
/* 851:    */   
/* 852:    */   public void setValidator(String validator)
/* 853:    */   {
/* 854:842 */     this.validator = validator;
/* 855:    */   }
/* 856:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.db.ColumnDefinition
 * JD-Core Version:    0.7.0.1
 */