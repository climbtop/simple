/*  1:   */ package org.apache.ibatis.abator.internal.db;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public class DatabaseDialects
/*  7:   */ {
/*  8:25 */   public static final Integer DB2 = new Integer(1);
/*  9:27 */   public static final Integer MYSQL = new Integer(2);
/* 10:29 */   public static final Integer SQLSERVER = new Integer(3);
/* 11:31 */   public static final Integer CLOUDSCAPE = new Integer(4);
/* 12:33 */   public static final Integer DERBY = new Integer(5);
/* 13:35 */   public static final Integer HSQLDB = new Integer(6);
/* 14:37 */   public static final Integer ORACLE = new Integer(7);
/* 15:44 */   private static final Map identityClauses = new HashMap();
/* 16:   */   private static final Map dateExmapleClauses;
/* 17:   */   private static final Map systemDates;
/* 18:   */   
/* 19:   */   static
/* 20:   */   {
/* 21:46 */     identityClauses.put(DB2, "VALUES IDENTITY_VAL_LOCAL()");
/* 22:47 */     identityClauses.put(MYSQL, "SELECT LAST_INSERT_ID()");
/* 23:48 */     identityClauses.put(SQLSERVER, "SELECT SCOPE_IDENTITY()");
/* 24:49 */     identityClauses.put(CLOUDSCAPE, "VALUES IDENTITY_VAL_LOCAL()");
/* 25:50 */     identityClauses.put(DERBY, "VALUES IDENTITY_VAL_LOCAL()");
/* 26:51 */     identityClauses.put(HSQLDB, "CALL IDENTITY()");
/* 27:   */     
/* 28:53 */     dateExmapleClauses = new HashMap();
/* 29:54 */     dateExmapleClauses.put(ORACLE, "TO_DATE( #{0}:VARCHAR#, 'yyyy-MM-dd  hh24:mi:ss' )");
/* 30:55 */     dateExmapleClauses.put(MYSQL, "#{0}:{1}#");
/* 31:   */     
/* 32:57 */     systemDates = new HashMap();
/* 33:58 */     systemDates.put(ORACLE, "SYSDATE");
/* 34:59 */     systemDates.put(MYSQL, "NOW()");
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static String getIdentityClause(Integer dialect)
/* 38:   */   {
/* 39:64 */     return (String)identityClauses.get(dialect);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static String getDateExmapleClause(Integer dialect)
/* 43:   */   {
/* 44:68 */     return (String)dateExmapleClauses.get(dialect);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public static String getSystemDate(Integer dialect)
/* 48:   */   {
/* 49:72 */     return (String)systemDates.get(dialect);
/* 50:   */   }
/* 51:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.db.DatabaseDialects
 * JD-Core Version:    0.7.0.1
 */