/*   1:    */ package org.apache.ibatis.abator.internal.db;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   6:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   7:    */ import org.apache.ibatis.abator.config.GeneratedKey;
/*   8:    */ import org.apache.ibatis.abator.config.ModelType;
/*   9:    */ import org.apache.ibatis.abator.config.TableConfiguration;
/*  10:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*  11:    */ import org.apache.ibatis.abator.internal.rules.ConditionalModelRules;
/*  12:    */ import org.apache.ibatis.abator.internal.rules.FlatModelRules;
/*  13:    */ import org.apache.ibatis.abator.internal.rules.HierarchicalModelRules;
/*  14:    */ import org.apache.ibatis.abator.internal.util.AggregatingIterator;
/*  15:    */ 
/*  16:    */ public class IntrospectedTableImpl
/*  17:    */   implements IntrospectedTable
/*  18:    */ {
/*  19:    */   private TableConfiguration tableConfiguration;
/*  20:    */   private ColumnDefinitions columnDefinitions;
/*  21:    */   private FullyQualifiedTable table;
/*  22:    */   private AbatorRules rules;
/*  23:    */   
/*  24:    */   public IntrospectedTableImpl(TableConfiguration tableConfiguration, ColumnDefinitions columnDefinitions, FullyQualifiedTable table)
/*  25:    */   {
/*  26: 49 */     this.columnDefinitions = columnDefinitions;
/*  27: 50 */     this.tableConfiguration = tableConfiguration;
/*  28: 51 */     this.table = table;
/*  29: 53 */     if (tableConfiguration.getModelType() == ModelType.HIERARCHICAL) {
/*  30: 54 */       this.rules = new HierarchicalModelRules(tableConfiguration, columnDefinitions);
/*  31: 55 */     } else if (tableConfiguration.getModelType() == ModelType.FLAT) {
/*  32: 56 */       this.rules = new FlatModelRules(tableConfiguration, columnDefinitions);
/*  33:    */     } else {
/*  34: 58 */       this.rules = new ConditionalModelRules(tableConfiguration, columnDefinitions);
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public FullyQualifiedTable getTable()
/*  39:    */   {
/*  40: 66 */     return this.table;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public String getSelectByExampleQueryId()
/*  44:    */   {
/*  45: 73 */     return this.tableConfiguration.getSelectByExampleQueryId();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String getSelectByPrimaryKeyQueryId()
/*  49:    */   {
/*  50: 80 */     return this.tableConfiguration.getSelectByPrimaryKeyQueryId();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public GeneratedKey getGeneratedKey()
/*  54:    */   {
/*  55: 87 */     return this.tableConfiguration.getGeneratedKey();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public ColumnDefinition getColumn(String columnName)
/*  59:    */   {
/*  60: 91 */     return this.columnDefinitions.getColumn(columnName);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean hasJDBCDateColumns()
/*  64:    */   {
/*  65: 95 */     return this.columnDefinitions.hasJDBCDateColumns();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean hasJDBCTimeColumns()
/*  69:    */   {
/*  70: 99 */     return this.columnDefinitions.hasJDBCTimeColumns();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean hasParentIdColumn()
/*  74:    */   {
/*  75:103 */     return this.columnDefinitions.hasParentIdColumn();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public boolean hasStatusColumn()
/*  79:    */   {
/*  80:107 */     return this.columnDefinitions.hasStatusColumn();
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean hasMainFkColumns()
/*  84:    */   {
/*  85:111 */     return this.columnDefinitions.hasMainFkColumns();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public ColumnDefinitions getColumnDefinitions()
/*  89:    */   {
/*  90:115 */     return this.columnDefinitions;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public AbatorRules getRules()
/*  94:    */   {
/*  95:119 */     return this.rules;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Iterator getAllColumns()
/*  99:    */   {
/* 100:123 */     return new AggregatingIterator(this.columnDefinitions.getPrimaryKeyColumns().iterator(), 
/* 101:124 */       this.columnDefinitions.getBaseColumns().iterator(), 
/* 102:125 */       this.columnDefinitions.getBLOBColumns().iterator());
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Iterator getNonBLOBColumns()
/* 106:    */   {
/* 107:129 */     return new AggregatingIterator(this.columnDefinitions.getPrimaryKeyColumns().iterator(), 
/* 108:130 */       this.columnDefinitions.getBaseColumns().iterator());
/* 109:    */   }
/* 110:    */   
/* 111:    */   public Iterator getPrimaryKeyColumns()
/* 112:    */   {
/* 113:134 */     return this.columnDefinitions.getPrimaryKeyColumns().iterator();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public Iterator getBaseColumns()
/* 117:    */   {
/* 118:138 */     return this.columnDefinitions.getBaseColumns().iterator();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Iterator getListColumns()
/* 122:    */   {
/* 123:142 */     return this.columnDefinitions.getListColumns().iterator();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public int getListColumnSize()
/* 127:    */   {
/* 128:146 */     return this.columnDefinitions.getListColumns().size();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public String getListPropertyNames()
/* 132:    */   {
/* 133:150 */     return this.columnDefinitions.getListPropertyNames();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public Iterator getQueryColumns()
/* 137:    */   {
/* 138:154 */     return this.columnDefinitions.getQueryColumns().iterator();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public Iterator getMainFkColumns()
/* 142:    */   {
/* 143:158 */     return this.columnDefinitions.getMainFkColumns().iterator();
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean hasPrimaryKeyColumns()
/* 147:    */   {
/* 148:162 */     return this.columnDefinitions.hasPrimaryKeyColumns();
/* 149:    */   }
/* 150:    */   
/* 151:    */   public Iterator getBLOBColumns()
/* 152:    */   {
/* 153:166 */     return this.columnDefinitions.getBLOBColumns().iterator();
/* 154:    */   }
/* 155:    */   
/* 156:    */   public boolean hasBLOBColumns()
/* 157:    */   {
/* 158:170 */     return this.columnDefinitions.hasBLOBColumns();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public Iterator getNonPrimaryKeyColumns()
/* 162:    */   {
/* 163:174 */     return new AggregatingIterator(this.columnDefinitions.getBaseColumns().iterator(), 
/* 164:175 */       this.columnDefinitions.getBLOBColumns().iterator());
/* 165:    */   }
/* 166:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.db.IntrospectedTableImpl
 * JD-Core Version:    0.7.0.1
 */