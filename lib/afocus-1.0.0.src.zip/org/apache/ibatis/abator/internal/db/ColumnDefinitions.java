/*   1:    */ package org.apache.ibatis.abator.internal.db;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.LinkedHashMap;
/*   5:    */ 
/*   6:    */ public class ColumnDefinitions
/*   7:    */ {
/*   8:    */   private LinkedHashMap<String, ColumnDefinition> primaryKeyColumns;
/*   9:    */   private LinkedHashMap<String, ColumnDefinition> baseColumns;
/*  10:    */   private LinkedHashMap<String, ColumnDefinition> blobColumns;
/*  11:    */   private LinkedHashMap<String, ColumnDefinition> listColumns;
/*  12:    */   private LinkedHashMap<String, ColumnDefinition> queryColumns;
/*  13:    */   private LinkedHashMap<String, ColumnDefinition> mainFkColumns;
/*  14:    */   private boolean hasJDBCDateColumns;
/*  15:    */   private boolean hasJDBCTimeColumns;
/*  16: 36 */   private boolean hasParentIdColumn = false;
/*  17: 37 */   private boolean hasStatusColumn = false;
/*  18:    */   
/*  19:    */   public ColumnDefinitions()
/*  20:    */   {
/*  21: 41 */     this.primaryKeyColumns = new LinkedHashMap();
/*  22: 42 */     this.baseColumns = new LinkedHashMap();
/*  23: 43 */     this.blobColumns = new LinkedHashMap();
/*  24: 44 */     this.listColumns = new LinkedHashMap();
/*  25: 45 */     this.queryColumns = new LinkedHashMap();
/*  26: 46 */     this.mainFkColumns = new LinkedHashMap();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public Collection getListColumns()
/*  30:    */   {
/*  31: 50 */     return this.listColumns.values();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public String getListPropertyNames()
/*  35:    */   {
/*  36: 54 */     StringBuilder sb = new StringBuilder();
/*  37: 55 */     boolean and = false;
/*  38: 56 */     for (ColumnDefinition cd : this.listColumns.values())
/*  39:    */     {
/*  40: 57 */       if (and) {
/*  41: 58 */         sb.append(",");
/*  42:    */       } else {
/*  43: 60 */         and = true;
/*  44:    */       }
/*  45: 61 */       sb.append(cd.getJavaProperty());
/*  46:    */     }
/*  47: 63 */     return sb.toString();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Collection<ColumnDefinition> getQueryColumns()
/*  51:    */   {
/*  52: 67 */     return this.queryColumns.values();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Collection<ColumnDefinition> getMainFkColumns()
/*  56:    */   {
/*  57: 70 */     return this.mainFkColumns.values();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Collection<ColumnDefinition> getBLOBColumns()
/*  61:    */   {
/*  62: 74 */     return this.blobColumns.values();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Collection<ColumnDefinition> getBaseColumns()
/*  66:    */   {
/*  67: 78 */     return this.baseColumns.values();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Collection<ColumnDefinition> getPrimaryKeyColumns()
/*  71:    */   {
/*  72: 82 */     return this.primaryKeyColumns.values();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void addColumn(ColumnDefinition cd)
/*  76:    */   {
/*  77: 86 */     if (cd.isBLOBColumn())
/*  78:    */     {
/*  79: 87 */       this.blobColumns.put(cd.getColumnName().toUpperCase(), cd);
/*  80:    */     }
/*  81:    */     else
/*  82:    */     {
/*  83: 89 */       this.baseColumns.put(cd.getColumnName().toUpperCase(), cd);
/*  84: 90 */       if (cd.isListable()) {
/*  85: 91 */         this.listColumns.put(cd.getColumnName().toUpperCase(), cd);
/*  86:    */       }
/*  87: 92 */       if (cd.isQueryable()) {
/*  88: 93 */         this.queryColumns.put(cd.getColumnName().toUpperCase(), cd);
/*  89:    */       }
/*  90: 94 */       if (cd.isMainFk()) {
/*  91: 95 */         this.mainFkColumns.put(cd.getColumnName().toUpperCase(), cd);
/*  92:    */       }
/*  93:    */     }
/*  94: 98 */     if (cd.isJDBCDateColumn()) {
/*  95: 99 */       this.hasJDBCDateColumns = true;
/*  96:    */     }
/*  97:102 */     if (cd.isJDBCTimeColumn()) {
/*  98:103 */       this.hasJDBCTimeColumns = true;
/*  99:    */     }
/* 100:106 */     if (cd.getJavaProperty().toLowerCase().equalsIgnoreCase("parentid")) {
/* 101:107 */       this.hasParentIdColumn = true;
/* 102:    */     }
/* 103:108 */     if (cd.getJavaProperty().toLowerCase().equalsIgnoreCase("status")) {
/* 104:109 */       this.hasStatusColumn = true;
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void addPrimaryKeyColumn(String columnName)
/* 109:    */   {
/* 110:113 */     String key = columnName.toUpperCase();
/* 111:114 */     if (this.baseColumns.containsKey(key)) {
/* 112:115 */       this.primaryKeyColumns.put(key, (ColumnDefinition)this.baseColumns.remove(key));
/* 113:116 */     } else if (this.blobColumns.containsKey(key)) {
/* 114:118 */       this.primaryKeyColumns.put(key, (ColumnDefinition)this.blobColumns.remove(key));
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean hasPrimaryKeyColumns()
/* 119:    */   {
/* 120:123 */     return this.primaryKeyColumns.size() > 0;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public boolean hasMainFkColumns()
/* 124:    */   {
/* 125:127 */     return this.mainFkColumns.size() > 0;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public boolean hasBLOBColumns()
/* 129:    */   {
/* 130:131 */     return this.blobColumns.size() > 0;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public boolean hasBaseColumns()
/* 134:    */   {
/* 135:135 */     return this.baseColumns.size() > 0;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public ColumnDefinition getColumn(String columnName)
/* 139:    */   {
/* 140:139 */     if (columnName == null) {
/* 141:140 */       return null;
/* 142:    */     }
/* 143:142 */     String key = columnName.toUpperCase();
/* 144:143 */     ColumnDefinition cd = (ColumnDefinition)this.primaryKeyColumns.get(key);
/* 145:145 */     if (cd == null) {
/* 146:146 */       cd = (ColumnDefinition)this.baseColumns.get(key);
/* 147:    */     }
/* 148:149 */     if (cd == null) {
/* 149:150 */       cd = (ColumnDefinition)this.blobColumns.get(key);
/* 150:    */     }
/* 151:153 */     return cd;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public boolean hasJDBCDateColumns()
/* 155:    */   {
/* 156:158 */     return this.hasJDBCDateColumns;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public boolean hasJDBCTimeColumns()
/* 160:    */   {
/* 161:162 */     return this.hasJDBCTimeColumns;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean hasParentIdColumn()
/* 165:    */   {
/* 166:166 */     return this.hasParentIdColumn;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public boolean hasStatusColumn()
/* 170:    */   {
/* 171:170 */     return this.hasStatusColumn;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public boolean hasAnyColumns()
/* 175:    */   {
/* 176:174 */     return (this.primaryKeyColumns.size() > 0) || 
/* 177:175 */       (this.baseColumns.size() > 0) || (
/* 178:176 */       this.blobColumns.size() > 0);
/* 179:    */   }
/* 180:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.db.ColumnDefinitions
 * JD-Core Version:    0.7.0.1
 */