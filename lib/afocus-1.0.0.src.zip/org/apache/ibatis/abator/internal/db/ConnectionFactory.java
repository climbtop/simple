/*   1:    */ package org.apache.ibatis.abator.internal.db;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.net.MalformedURLException;
/*   5:    */ import java.net.URL;
/*   6:    */ import java.net.URLClassLoader;
/*   7:    */ import java.sql.Connection;
/*   8:    */ import java.sql.Driver;
/*   9:    */ import java.sql.SQLException;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Properties;
/*  16:    */ import org.apache.ibatis.abator.config.JDBCConnectionConfiguration;
/*  17:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  18:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  19:    */ 
/*  20:    */ public class ConnectionFactory
/*  21:    */ {
/*  22: 44 */   private static ConnectionFactory instance = new ConnectionFactory();
/*  23:    */   private Map drivers;
/*  24:    */   
/*  25:    */   public static ConnectionFactory getInstance()
/*  26:    */   {
/*  27: 48 */     return instance;
/*  28:    */   }
/*  29:    */   
/*  30:    */   private ConnectionFactory()
/*  31:    */   {
/*  32: 56 */     this.drivers = new HashMap();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Connection getConnection(JDBCConnectionConfiguration config)
/*  36:    */     throws SQLException
/*  37:    */   {
/*  38: 61 */     Driver driver = getDriver(config);
/*  39:    */     
/*  40: 63 */     Properties props = new Properties();
/*  41: 65 */     if (StringUtility.stringHasValue(config.getUserId())) {
/*  42: 66 */       props.setProperty("user", config.getUserId());
/*  43:    */     }
/*  44: 69 */     if (StringUtility.stringHasValue(config.getPassword())) {
/*  45: 70 */       props.setProperty("password", config.getPassword());
/*  46:    */     }
/*  47: 73 */     props.putAll(config.getProperties());
/*  48:    */     
/*  49: 75 */     Connection conn = driver.connect(config.getConnectionURL(), props);
/*  50: 77 */     if (conn == null) {
/*  51: 78 */       throw new SQLException(Messages.getString("RuntimeError.7"));
/*  52:    */     }
/*  53: 81 */     return conn;
/*  54:    */   }
/*  55:    */   
/*  56:    */   private Driver getDriver(JDBCConnectionConfiguration connectionInformation)
/*  57:    */   {
/*  58: 86 */     String driverClass = connectionInformation.getDriverClass();
/*  59: 87 */     Driver driver = (Driver)this.drivers.get(driverClass);
/*  60: 89 */     if (driver == null) {
/*  61:    */       try
/*  62:    */       {
/*  63: 91 */         Class clazz = getCustomClassloader(connectionInformation)
/*  64: 92 */           .loadClass(driverClass);
/*  65: 93 */         driver = (Driver)clazz.newInstance();
/*  66: 94 */         this.drivers.put(driverClass, driver);
/*  67:    */       }
/*  68:    */       catch (Exception e)
/*  69:    */       {
/*  70: 96 */         throw new RuntimeException(
/*  71: 97 */           Messages.getString("RuntimeError.8"), e);
/*  72:    */       }
/*  73:    */     }
/*  74:101 */     return driver;
/*  75:    */   }
/*  76:    */   
/*  77:    */   private ClassLoader getCustomClassloader(JDBCConnectionConfiguration connectionInformation)
/*  78:    */   {
/*  79:106 */     ArrayList urls = new ArrayList();
/*  80:    */     
/*  81:    */ 
/*  82:109 */     Iterator iter = connectionInformation.getClassPathEntries().iterator();
/*  83:110 */     while (iter.hasNext())
/*  84:    */     {
/*  85:111 */       String classPathEntry = (String)iter.next();
/*  86:112 */       File file = new File(classPathEntry);
/*  87:113 */       if (!file.exists()) {
/*  88:114 */         throw new RuntimeException(
/*  89:115 */           Messages.getString("RuntimeError.9", classPathEntry));
/*  90:    */       }
/*  91:    */       try
/*  92:    */       {
/*  93:119 */         urls.add(file.toURL());
/*  94:    */       }
/*  95:    */       catch (MalformedURLException e)
/*  96:    */       {
/*  97:122 */         throw new RuntimeException(
/*  98:123 */           Messages.getString("RuntimeError.9", classPathEntry));
/*  99:    */       }
/* 100:    */     }
/* 101:127 */     ClassLoader parent = Thread.currentThread().getContextClassLoader();
/* 102:128 */     URLClassLoader ucl = new URLClassLoader(
/* 103:129 */       (URL[])urls.toArray(new URL[urls.size()]), parent);
/* 104:    */     
/* 105:131 */     return ucl;
/* 106:    */   }
/* 107:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.db.ConnectionFactory
 * JD-Core Version:    0.7.0.1
 */