/*  1:   */ package org.apache.ibatis.abator.internal;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.ControllerMethodNameCalculator;
/*  4:   */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  5:   */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  6:   */ 
/*  7:   */ public class ExtendedControllerMethodNameCalculator
/*  8:   */   implements ControllerMethodNameCalculator
/*  9:   */ {
/* 10:   */   public String getListMethodName(IntrospectedTable introspectedTable)
/* 11:   */   {
/* 12:37 */     return "list" + introspectedTable.getTable().getDomainObjectName();
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getSearchMethodName(IntrospectedTable introspectedTable)
/* 16:   */   {
/* 17:41 */     return "search" + introspectedTable.getTable().getDomainObjectName();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getDeleteMethodName(IntrospectedTable introspectedTable)
/* 21:   */   {
/* 22:45 */     return "delete" + introspectedTable.getTable().getDomainObjectName();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getEditMethodName(IntrospectedTable introspectedTable)
/* 26:   */   {
/* 27:49 */     return "edit" + introspectedTable.getTable().getDomainObjectName();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getAddMethodName(IntrospectedTable introspectedTable)
/* 31:   */   {
/* 32:53 */     return "add" + introspectedTable.getTable().getDomainObjectName();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getDetailMethodName(IntrospectedTable introspectedTable)
/* 36:   */   {
/* 37:57 */     return "detail" + introspectedTable.getTable().getDomainObjectName();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getUpdateMethodName(IntrospectedTable introspectedTable)
/* 41:   */   {
/* 42:61 */     return "update" + introspectedTable.getTable().getDomainObjectName();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String getMoveMethodName(IntrospectedTable introspectedTable)
/* 46:   */   {
/* 47:65 */     return "move" + introspectedTable.getTable().getDomainObjectName();
/* 48:   */   }
/* 49:   */   
/* 50:   */   public String getAuditMethodName(IntrospectedTable introspectedTable)
/* 51:   */   {
/* 52:69 */     return "audit" + introspectedTable.getTable().getDomainObjectName();
/* 53:   */   }
/* 54:   */   
/* 55:   */   public String getUpdateStatusMethodName(IntrospectedTable introspectedTable)
/* 56:   */   {
/* 57:73 */     return "update" + introspectedTable.getTable().getDomainObjectName() + "Status";
/* 58:   */   }
/* 59:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.ExtendedControllerMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */