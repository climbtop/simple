/*   1:    */ package org.apache.ibatis.abator.internal;
/*   2:    */ 
/*   3:    */ import java.io.ByteArrayOutputStream;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.StringReader;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ import javax.xml.parsers.DocumentBuilder;
/*  11:    */ import javax.xml.parsers.DocumentBuilderFactory;
/*  12:    */ import javax.xml.transform.Transformer;
/*  13:    */ import javax.xml.transform.TransformerException;
/*  14:    */ import javax.xml.transform.TransformerFactory;
/*  15:    */ import javax.xml.transform.dom.DOMSource;
/*  16:    */ import javax.xml.transform.stream.StreamResult;
/*  17:    */ import org.apache.ibatis.abator.api.GeneratedXmlFile;
/*  18:    */ import org.apache.ibatis.abator.exception.ShellException;
/*  19:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  20:    */ import org.w3c.dom.Document;
/*  21:    */ import org.w3c.dom.DocumentType;
/*  22:    */ import org.w3c.dom.Element;
/*  23:    */ import org.w3c.dom.Node;
/*  24:    */ import org.w3c.dom.NodeList;
/*  25:    */ import org.w3c.dom.Text;
/*  26:    */ import org.xml.sax.EntityResolver;
/*  27:    */ import org.xml.sax.InputSource;
/*  28:    */ import org.xml.sax.SAXException;
/*  29:    */ 
/*  30:    */ public class XmlFileMergerJaxp
/*  31:    */ {
/*  32:    */   private static class NullEntityResolver
/*  33:    */     implements EntityResolver
/*  34:    */   {
/*  35:    */     public InputSource resolveEntity(String publicId, String systemId)
/*  36:    */       throws SAXException, IOException
/*  37:    */     {
/*  38: 64 */       StringReader sr = new StringReader("");
/*  39:    */       
/*  40: 66 */       return new InputSource(sr);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static String getMergedSource(GeneratedXmlFile generatedXmlFile, File existingFile)
/*  45:    */     throws ShellException
/*  46:    */   {
/*  47:    */     try
/*  48:    */     {
/*  49: 80 */       DocumentBuilderFactory factory = 
/*  50: 81 */         DocumentBuilderFactory.newInstance();
/*  51: 82 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*  52: 83 */       builder.setEntityResolver(new NullEntityResolver(null));
/*  53:    */       
/*  54: 85 */       Document existingDocument = builder.parse(existingFile);
/*  55: 86 */       StringReader sr = new StringReader(generatedXmlFile.getFormattedContent());
/*  56: 87 */       Document newDocument = builder.parse(new InputSource(sr));
/*  57:    */       
/*  58: 89 */       DocumentType newDocType = newDocument.getDoctype();
/*  59: 90 */       DocumentType existingDocType = existingDocument.getDoctype();
/*  60: 92 */       if (!newDocType.getName().equals(existingDocType.getName())) {
/*  61: 93 */         throw new ShellException(Messages.getString("Warning.12", 
/*  62: 94 */           existingFile.getName()));
/*  63:    */       }
/*  64: 97 */       Element existingRootElement = existingDocument.getDocumentElement();
/*  65: 98 */       Element newRootElement = newDocument.getDocumentElement();
/*  66:    */       
/*  67:    */ 
/*  68:101 */       String namespace = newRootElement.getAttribute("namespace");
/*  69:102 */       existingRootElement.setAttribute("namespace", namespace);
/*  70:    */       
/*  71:    */ 
/*  72:    */ 
/*  73:106 */       List nodesToDelete = new ArrayList();
/*  74:107 */       NodeList children = existingRootElement.getChildNodes();
/*  75:108 */       int length = children.getLength();
/*  76:109 */       for (int i = 0; i < length; i++)
/*  77:    */       {
/*  78:110 */         Node node = children.item(i);
/*  79:111 */         if (isAnAbatorNode(node)) {
/*  80:112 */           nodesToDelete.add(node);
/*  81:    */         }
/*  82:115 */         short nodeType = node.getNodeType();
/*  83:116 */         if (nodeType == 3)
/*  84:    */         {
/*  85:122 */           Text tn = (Text)node;
/*  86:123 */           String text = tn.getData();
/*  87:125 */           if (text.trim().length() == 0) {
/*  88:129 */             if (i == length - 1) {
/*  89:130 */               nodesToDelete.add(tn);
/*  90:131 */             } else if (isAnAbatorNode(children.item(i + 1))) {
/*  91:132 */               nodesToDelete.add(tn);
/*  92:    */             }
/*  93:    */           }
/*  94:    */         }
/*  95:    */       }
/*  96:138 */       Iterator iter = nodesToDelete.iterator();
/*  97:139 */       while (iter.hasNext()) {
/*  98:140 */         existingRootElement.removeChild((Node)iter.next());
/*  99:    */       }
/* 100:144 */       children = newRootElement.getChildNodes();
/* 101:145 */       length = children.getLength();
/* 102:146 */       Node firstChild = existingRootElement.getFirstChild();
/* 103:147 */       for (int i = 0; i < length; i++)
/* 104:    */       {
/* 105:148 */         Node node = children.item(i);
/* 106:150 */         if (i == length - 1) {
/* 107:152 */           if (node.getNodeType() == 3)
/* 108:    */           {
/* 109:153 */             Text tn = (Text)node;
/* 110:154 */             if (tn.getData().trim().length() == 0) {
/* 111:    */               break;
/* 112:    */             }
/* 113:    */           }
/* 114:    */         }
/* 115:160 */         Node newNode = existingDocument.importNode(node, true);
/* 116:161 */         if (firstChild == null) {
/* 117:162 */           existingRootElement.appendChild(newNode);
/* 118:    */         } else {
/* 119:164 */           existingRootElement.insertBefore(newNode, firstChild);
/* 120:    */         }
/* 121:    */       }
/* 122:169 */       return prettyPrint(existingDocument);
/* 123:    */     }
/* 124:    */     catch (Exception e)
/* 125:    */     {
/* 126:171 */       throw new ShellException(Messages.getString("Warning.13", 
/* 127:172 */         existingFile.getName()), e);
/* 128:    */     }
/* 129:    */   }
/* 130:    */   
/* 131:    */   private static String prettyPrint(Document document)
/* 132:    */     throws TransformerException
/* 133:    */   {
/* 134:177 */     TransformerFactory factory = TransformerFactory.newInstance();
/* 135:    */     
/* 136:179 */     Transformer transformer = factory.newTransformer();
/* 137:180 */     transformer.setOutputProperty("omit-xml-declaration", "no");
/* 138:181 */     transformer.setOutputProperty("method", "xml");
/* 139:182 */     transformer.setOutputProperty("indent", "yes");
/* 140:183 */     transformer.setOutputProperty("encoding", "UTF-8");
/* 141:184 */     transformer.setOutputProperty("doctype-public", "-//ibatis.apache.org//DTD SQL Map 2.0//EN");
/* 142:185 */     transformer.setOutputProperty("doctype-system", "http://ibatis.apache.org/dtd/sql-map-2.dtd");
/* 143:    */     
/* 144:187 */     ByteArrayOutputStream bas = new ByteArrayOutputStream();
/* 145:    */     
/* 146:189 */     transformer.transform(new DOMSource(document), new StreamResult(bas));
/* 147:    */     
/* 148:191 */     return bas.toString();
/* 149:    */   }
/* 150:    */   
/* 151:    */   private static boolean isAnAbatorNode(Node node)
/* 152:    */   {
/* 153:195 */     boolean rc = false;
/* 154:197 */     if (node.getNodeType() == 1)
/* 155:    */     {
/* 156:198 */       Element element = (Element)node;
/* 157:199 */       String id = element.getAttribute("id");
/* 158:201 */       if (id != null) {
/* 159:202 */         rc = true;
/* 160:    */       }
/* 161:    */     }
/* 162:206 */     return rc;
/* 163:    */   }
/* 164:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.XmlFileMergerJaxp
 * JD-Core Version:    0.7.0.1
 */