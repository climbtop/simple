/*   1:    */ package org.apache.ibatis.abator.internal.java.controller;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   7:    */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   8:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   9:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  10:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  11:    */ 
/*  12:    */ public class AbstractControllerTemplate
/*  13:    */ {
/*  14:    */   private List implementationImports;
/*  15:    */   private FullyQualifiedJavaType superClass;
/*  16:    */   private List checkedExceptions;
/*  17:    */   private List fields;
/*  18:    */   private List methods;
/*  19:    */   private Method constructorTemplate;
/*  20:    */   private String listMethodTemplate;
/*  21:    */   private String createMethodTemplate;
/*  22:    */   private String saveMethodTemplate;
/*  23:    */   private String updateMethodTemplate;
/*  24:    */   private String showMethodTemplate;
/*  25:    */   private String deleteMethodTemplate;
/*  26:    */   
/*  27:    */   public AbstractControllerTemplate()
/*  28:    */   {
/*  29: 63 */     this.implementationImports = new ArrayList();
/*  30: 64 */     this.fields = new ArrayList();
/*  31: 65 */     this.methods = new ArrayList();
/*  32: 66 */     this.checkedExceptions = new ArrayList();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Method getConstructorClone(FullyQualifiedJavaType type, FullyQualifiedTable table, String urlPrefix)
/*  36:    */   {
/*  37: 70 */     Method answer = new Method();
/*  38: 71 */     answer.addComment(table);
/*  39: 72 */     answer.setConstructor(true);
/*  40: 73 */     answer.setName(type.getShortName());
/*  41: 74 */     answer.setVisibility(this.constructorTemplate.getVisibility());
/*  42: 75 */     Iterator iter = this.constructorTemplate.getParameters().iterator();
/*  43: 76 */     while (iter.hasNext()) {
/*  44: 77 */       answer.addParameter((Parameter)iter.next());
/*  45:    */     }
/*  46: 79 */     iter = this.constructorTemplate.getBodyLines().iterator();
/*  47: 80 */     while (iter.hasNext()) {
/*  48: 81 */       answer.addBodyLine((String)iter.next());
/*  49:    */     }
/*  50: 83 */     iter = this.constructorTemplate.getExceptions().iterator();
/*  51: 84 */     while (iter.hasNext()) {
/*  52: 85 */       answer.addException((FullyQualifiedJavaType)iter.next());
/*  53:    */     }
/*  54: 88 */     return answer;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public List getImplementationImports()
/*  58:    */   {
/*  59: 93 */     return this.implementationImports;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public FullyQualifiedJavaType getSuperClass()
/*  63:    */   {
/*  64: 98 */     return this.superClass;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public List getCheckedExceptions()
/*  68:    */   {
/*  69:103 */     return this.checkedExceptions;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Iterator getFieldClones(FullyQualifiedTable table)
/*  73:    */   {
/*  74:107 */     ArrayList answer = new ArrayList();
/*  75:108 */     Iterator iter = this.fields.iterator();
/*  76:109 */     while (iter.hasNext())
/*  77:    */     {
/*  78:110 */       Field field = new Field();
/*  79:111 */       Field oldField = (Field)iter.next();
/*  80:    */       
/*  81:113 */       field.addComment(table);
/*  82:114 */       field.setInitializationString(oldField.getInitializationString());
/*  83:115 */       field.setModifierFinal(oldField.isModifierFinal());
/*  84:116 */       field.setModifierStatic(oldField.isModifierStatic());
/*  85:117 */       field.setName(oldField.getName());
/*  86:118 */       field.setType(oldField.getType());
/*  87:119 */       field.setVisibility(oldField.getVisibility());
/*  88:120 */       answer.add(field);
/*  89:    */     }
/*  90:123 */     return answer.iterator();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Iterator getMethodClones(FullyQualifiedTable table)
/*  94:    */   {
/*  95:127 */     ArrayList answer = new ArrayList();
/*  96:128 */     Iterator iter = this.methods.iterator();
/*  97:129 */     while (iter.hasNext())
/*  98:    */     {
/*  99:130 */       Method method = new Method();
/* 100:131 */       Method oldMethod = (Method)iter.next();
/* 101:    */       
/* 102:133 */       Iterator iter2 = oldMethod.getBodyLines().iterator();
/* 103:134 */       while (iter2.hasNext()) {
/* 104:135 */         method.addBodyLine((String)iter2.next());
/* 105:    */       }
/* 106:138 */       iter2 = oldMethod.getExceptions().iterator();
/* 107:139 */       while (iter2.hasNext()) {
/* 108:140 */         method.addException((FullyQualifiedJavaType)iter2.next());
/* 109:    */       }
/* 110:143 */       method.addComment(table);
/* 111:    */       
/* 112:145 */       iter2 = oldMethod.getParameters().iterator();
/* 113:146 */       while (iter2.hasNext()) {
/* 114:147 */         method.addParameter((Parameter)iter2.next());
/* 115:    */       }
/* 116:150 */       method.setConstructor(oldMethod.isConstructor());
/* 117:151 */       method.setModifierFinal(oldMethod.isModifierFinal());
/* 118:152 */       method.setModifierStatic(oldMethod.isModifierStatic());
/* 119:153 */       method.setName(oldMethod.getName());
/* 120:154 */       method.setReturnType(oldMethod.getReturnType());
/* 121:155 */       method.setVisibility(oldMethod.getVisibility());
/* 122:    */       
/* 123:157 */       answer.add(method);
/* 124:    */     }
/* 125:160 */     return answer.iterator();
/* 126:    */   }
/* 127:    */   
/* 128:    */   protected void setConstructorTemplate(Method constructorTemplate)
/* 129:    */   {
/* 130:164 */     this.constructorTemplate = constructorTemplate;
/* 131:    */   }
/* 132:    */   
/* 133:    */   protected void setSuperClass(FullyQualifiedJavaType superClass)
/* 134:    */   {
/* 135:169 */     this.superClass = superClass;
/* 136:    */   }
/* 137:    */   
/* 138:    */   protected void addImplementationImport(FullyQualifiedJavaType type)
/* 139:    */   {
/* 140:174 */     this.implementationImports.add(type);
/* 141:    */   }
/* 142:    */   
/* 143:    */   protected void addCheckedException(FullyQualifiedJavaType type)
/* 144:    */   {
/* 145:178 */     this.checkedExceptions.add(type);
/* 146:    */   }
/* 147:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.controller.AbstractControllerTemplate
 * JD-Core Version:    0.7.0.1
 */