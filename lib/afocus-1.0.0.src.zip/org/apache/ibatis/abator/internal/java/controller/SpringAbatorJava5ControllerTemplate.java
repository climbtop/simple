/*  1:   */ package org.apache.ibatis.abator.internal.java.controller;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  6:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  7:   */ 
/*  8:   */ public class SpringAbatorJava5ControllerTemplate
/*  9:   */   extends AbstractControllerTemplate
/* 10:   */ {
/* 11:   */   public SpringAbatorJava5ControllerTemplate()
/* 12:   */   {
/* 13:37 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.framework.base.web.BaseController3");
/* 14:   */     
/* 15:39 */     Method method = new Method();
/* 16:40 */     method.setConstructor(true);
/* 17:41 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 18:42 */     setConstructorTemplate(method);
/* 19:   */     
/* 20:44 */     setSuperClass(fqjt);
/* 21:   */     
/* 22:   */ 
/* 23:47 */     addImplementationImport(fqjt);
/* 24:   */     
/* 25:49 */     fqjt = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/* 26:50 */     addImplementationImport(fqjt);
/* 27:51 */     fqjt = new FullyQualifiedJavaType("javax.servlet.http.HttpServletResponse");
/* 28:52 */     addImplementationImport(fqjt);
/* 29:53 */     fqjt = new FullyQualifiedJavaType("javax.annotation.Resource");
/* 30:54 */     addImplementationImport(fqjt);
/* 31:55 */     fqjt = new FullyQualifiedJavaType("org.springframework.stereotype.Controller");
/* 32:56 */     addImplementationImport(fqjt);
/* 33:57 */     fqjt = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/* 34:58 */     addImplementationImport(fqjt);
/* 35:59 */     fqjt = new FullyQualifiedJavaType("org.springframework.web.bind.annotation.RequestMapping");
/* 36:60 */     addImplementationImport(fqjt);
/* 37:61 */     fqjt = new FullyQualifiedJavaType("com.afocus.framework.util.PageList");
/* 38:62 */     addImplementationImport(fqjt);
/* 39:63 */     fqjt = new FullyQualifiedJavaType("com.afocus.framework.web.HttpRequestInfo");
/* 40:64 */     addImplementationImport(fqjt);
/* 41:65 */     fqjt = new FullyQualifiedJavaType("java.util.Arrays");
/* 42:66 */     addImplementationImport(fqjt);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Method getConstructorClone(FullyQualifiedJavaType type, FullyQualifiedTable table, String urlPrefix)
/* 46:   */   {
/* 47:70 */     Method answer = super.getConstructorClone(type, table, urlPrefix);
/* 48:71 */     answer.addBodyLine("super( \"" + urlPrefix + "\", \"" + urlPrefix + "\" );");
/* 49:72 */     return answer;
/* 50:   */   }
/* 51:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.controller.SpringAbatorJava5ControllerTemplate
 * JD-Core Version:    0.7.0.1
 */