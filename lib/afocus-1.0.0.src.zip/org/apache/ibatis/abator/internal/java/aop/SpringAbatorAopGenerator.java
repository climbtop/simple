/*  1:   */ package org.apache.ibatis.abator.internal.java.aop;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.AopGenerator;
/*  4:   */ 
/*  5:   */ public class SpringAbatorAopGenerator
/*  6:   */   extends BaseAopGenerator
/*  7:   */   implements AopGenerator
/*  8:   */ {
/*  9:   */   public SpringAbatorAopGenerator()
/* 10:   */   {
/* 11:67 */     super(new SpringAbatorJava5AopTemplate(), true);
/* 12:   */   }
/* 13:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.aop.SpringAbatorAopGenerator
 * JD-Core Version:    0.7.0.1
 */