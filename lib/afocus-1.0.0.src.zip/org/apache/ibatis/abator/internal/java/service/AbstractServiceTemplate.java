/*   1:    */ package org.apache.ibatis.abator.internal.java.service;
/*   2:    */ 
/*   3:    */ import java.text.MessageFormat;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   8:    */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   9:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  10:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  11:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  12:    */ 
/*  13:    */ public class AbstractServiceTemplate
/*  14:    */ {
/*  15:    */   private List interfaceImports;
/*  16:    */   private List implementationImports;
/*  17:    */   private FullyQualifiedJavaType superClass;
/*  18:    */   private List checkedExceptions;
/*  19:    */   private List fields;
/*  20:    */   private List methods;
/*  21:    */   private Method constructorTemplate;
/*  22:    */   private String deleteMethodTemplate;
/*  23:    */   private String insertMethodTemplate;
/*  24:    */   private String updateMethodTemplate;
/*  25:    */   private String queryForObjectMethodTemplate;
/*  26:    */   private String queryForListMethodTemplate;
/*  27:    */   
/*  28:    */   public AbstractServiceTemplate()
/*  29:    */   {
/*  30: 62 */     this.interfaceImports = new ArrayList();
/*  31: 63 */     this.implementationImports = new ArrayList();
/*  32: 64 */     this.fields = new ArrayList();
/*  33: 65 */     this.methods = new ArrayList();
/*  34: 66 */     this.checkedExceptions = new ArrayList();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Method getConstructorClone(FullyQualifiedJavaType type, FullyQualifiedTable table)
/*  38:    */   {
/*  39: 70 */     Method answer = new Method();
/*  40: 71 */     answer.addComment(table);
/*  41: 72 */     answer.setConstructor(true);
/*  42: 73 */     answer.setName(type.getBaseShortName());
/*  43: 74 */     answer.setVisibility(this.constructorTemplate.getVisibility());
/*  44: 75 */     Iterator iter = this.constructorTemplate.getParameters().iterator();
/*  45: 76 */     while (iter.hasNext()) {
/*  46: 77 */       answer.addParameter((Parameter)iter.next());
/*  47:    */     }
/*  48: 79 */     iter = this.constructorTemplate.getBodyLines().iterator();
/*  49: 80 */     while (iter.hasNext()) {
/*  50: 81 */       answer.addBodyLine((String)iter.next());
/*  51:    */     }
/*  52: 83 */     iter = this.constructorTemplate.getExceptions().iterator();
/*  53: 84 */     while (iter.hasNext()) {
/*  54: 85 */       answer.addException((FullyQualifiedJavaType)iter.next());
/*  55:    */     }
/*  56: 88 */     return answer;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String getDeleteMethod(String parameter)
/*  60:    */   {
/*  61: 92 */     String answer = MessageFormat.format(this.deleteMethodTemplate, new String[] { parameter });
/*  62: 93 */     return answer;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public List getInterfaceImports()
/*  66:    */   {
/*  67: 97 */     return this.interfaceImports;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public List getImplementationImports()
/*  71:    */   {
/*  72:101 */     return this.implementationImports;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public String getInsertMethod(String parameter)
/*  76:    */   {
/*  77:105 */     String answer = MessageFormat.format(this.insertMethodTemplate, new String[] { parameter });
/*  78:    */     
/*  79:107 */     return answer;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public String getQueryForListMethod(String parameter)
/*  83:    */   {
/*  84:111 */     String answer = MessageFormat.format(this.queryForListMethodTemplate, new String[] { parameter });
/*  85:    */     
/*  86:113 */     return answer;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String getQueryForObjectMethod(String parameter)
/*  90:    */   {
/*  91:117 */     String answer = MessageFormat.format(this.queryForObjectMethodTemplate, new String[] { parameter });
/*  92:    */     
/*  93:119 */     return answer;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public FullyQualifiedJavaType getSuperClass()
/*  97:    */   {
/*  98:123 */     return this.superClass;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public String getUpdateMethod(String parameter)
/* 102:    */   {
/* 103:127 */     String answer = MessageFormat.format(this.updateMethodTemplate, new String[] { parameter });
/* 104:    */     
/* 105:129 */     return answer;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public List getCheckedExceptions()
/* 109:    */   {
/* 110:133 */     return this.checkedExceptions;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Iterator getFieldClones(FullyQualifiedTable table)
/* 114:    */   {
/* 115:137 */     ArrayList answer = new ArrayList();
/* 116:138 */     Iterator iter = this.fields.iterator();
/* 117:139 */     while (iter.hasNext())
/* 118:    */     {
/* 119:140 */       Field field = new Field();
/* 120:141 */       Field oldField = (Field)iter.next();
/* 121:    */       
/* 122:143 */       field.addComment(table);
/* 123:144 */       field.setInitializationString(oldField.getInitializationString());
/* 124:145 */       field.setModifierFinal(oldField.isModifierFinal());
/* 125:146 */       field.setModifierStatic(oldField.isModifierStatic());
/* 126:147 */       field.setName(oldField.getName());
/* 127:148 */       field.setType(oldField.getType());
/* 128:149 */       field.setVisibility(oldField.getVisibility());
/* 129:150 */       answer.add(field);
/* 130:    */     }
/* 131:153 */     return answer.iterator();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public Iterator getMethodClones(FullyQualifiedTable table)
/* 135:    */   {
/* 136:157 */     ArrayList answer = new ArrayList();
/* 137:158 */     Iterator iter = this.methods.iterator();
/* 138:159 */     while (iter.hasNext())
/* 139:    */     {
/* 140:160 */       Method method = new Method();
/* 141:161 */       Method oldMethod = (Method)iter.next();
/* 142:    */       
/* 143:163 */       Iterator iter2 = oldMethod.getBodyLines().iterator();
/* 144:164 */       while (iter2.hasNext()) {
/* 145:165 */         method.addBodyLine((String)iter2.next());
/* 146:    */       }
/* 147:168 */       iter2 = oldMethod.getExceptions().iterator();
/* 148:169 */       while (iter2.hasNext()) {
/* 149:170 */         method.addException((FullyQualifiedJavaType)iter2.next());
/* 150:    */       }
/* 151:173 */       method.addComment(table);
/* 152:    */       
/* 153:175 */       iter2 = oldMethod.getParameters().iterator();
/* 154:176 */       while (iter2.hasNext()) {
/* 155:177 */         method.addParameter((Parameter)iter2.next());
/* 156:    */       }
/* 157:180 */       method.setConstructor(oldMethod.isConstructor());
/* 158:181 */       method.setModifierFinal(oldMethod.isModifierFinal());
/* 159:182 */       method.setModifierStatic(oldMethod.isModifierStatic());
/* 160:183 */       method.setName(oldMethod.getName());
/* 161:184 */       method.setReturnType(oldMethod.getReturnType());
/* 162:185 */       method.setVisibility(oldMethod.getVisibility());
/* 163:    */       
/* 164:187 */       answer.add(method);
/* 165:    */     }
/* 166:190 */     return answer.iterator();
/* 167:    */   }
/* 168:    */   
/* 169:    */   protected void setConstructorTemplate(Method constructorTemplate)
/* 170:    */   {
/* 171:194 */     this.constructorTemplate = constructorTemplate;
/* 172:    */   }
/* 173:    */   
/* 174:    */   protected void setDeleteMethodTemplate(String deleteMethodTemplate)
/* 175:    */   {
/* 176:198 */     this.deleteMethodTemplate = deleteMethodTemplate;
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected void addField(Field field)
/* 180:    */   {
/* 181:202 */     this.fields.add(field);
/* 182:    */   }
/* 183:    */   
/* 184:    */   protected void setInsertMethodTemplate(String insertMethodTemplate)
/* 185:    */   {
/* 186:206 */     this.insertMethodTemplate = insertMethodTemplate;
/* 187:    */   }
/* 188:    */   
/* 189:    */   protected void addMethod(Method method)
/* 190:    */   {
/* 191:210 */     this.methods.add(method);
/* 192:    */   }
/* 193:    */   
/* 194:    */   protected void setQueryForListMethodTemplate(String queryForListMethodTemplate)
/* 195:    */   {
/* 196:214 */     this.queryForListMethodTemplate = queryForListMethodTemplate;
/* 197:    */   }
/* 198:    */   
/* 199:    */   protected void setQueryForObjectMethodTemplate(String queryForObjectMethodTemplate)
/* 200:    */   {
/* 201:218 */     this.queryForObjectMethodTemplate = queryForObjectMethodTemplate;
/* 202:    */   }
/* 203:    */   
/* 204:    */   protected void setSuperClass(FullyQualifiedJavaType superClass)
/* 205:    */   {
/* 206:222 */     this.superClass = superClass;
/* 207:    */   }
/* 208:    */   
/* 209:    */   protected void setUpdateMethodTemplate(String updateMethodTemplate)
/* 210:    */   {
/* 211:226 */     this.updateMethodTemplate = updateMethodTemplate;
/* 212:    */   }
/* 213:    */   
/* 214:    */   protected void addInterfaceImport(FullyQualifiedJavaType type)
/* 215:    */   {
/* 216:230 */     this.interfaceImports.add(type);
/* 217:    */   }
/* 218:    */   
/* 219:    */   protected void addImplementationImport(FullyQualifiedJavaType type)
/* 220:    */   {
/* 221:234 */     this.implementationImports.add(type);
/* 222:    */   }
/* 223:    */   
/* 224:    */   protected void addCheckedException(FullyQualifiedJavaType type)
/* 225:    */   {
/* 226:238 */     this.checkedExceptions.add(type);
/* 227:    */   }
/* 228:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.service.AbstractServiceTemplate
 * JD-Core Version:    0.7.0.1
 */