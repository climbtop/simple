/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  6:   */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  7:   */ 
/*  8:   */ public class IbatisDAOTemplate
/*  9:   */   extends AbstractDAOTemplate
/* 10:   */ {
/* 11:   */   public IbatisDAOTemplate()
/* 12:   */   {
/* 13:34 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/* 14:35 */       "com.ibatis.dao.client.DaoManager");
/* 15:   */     
/* 16:37 */     Method method = new Method();
/* 17:38 */     method.setConstructor(true);
/* 18:39 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 19:40 */     method.addParameter(new Parameter(fqjt, "daoManager"));
/* 20:41 */     method.addBodyLine("super(daoManager);");
/* 21:42 */     setConstructorTemplate(method);
/* 22:   */     
/* 23:44 */     setSuperClass(new FullyQualifiedJavaType(
/* 24:45 */       "com.ibatis.dao.client.template.SqlMapDaoTemplate"));
/* 25:   */     
/* 26:47 */     addImplementationImport(fqjt);
/* 27:   */     
/* 28:49 */     setDeleteMethodTemplate("delete(\"{0}.{1}\", {2});");
/* 29:50 */     setInsertMethodTemplate("insert(\"{0}.{1}\", {2});");
/* 30:51 */     setQueryForObjectMethodTemplate("queryForObject(\"{0}.{1}\", {2});");
/* 31:52 */     setQueryForListMethodTemplate("queryForList(\"{0}.{1}\", {2});");
/* 32:53 */     setUpdateMethodTemplate("update(\"{0}.{1}\", {2});");
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.IbatisDAOTemplate
 * JD-Core Version:    0.7.0.1
 */