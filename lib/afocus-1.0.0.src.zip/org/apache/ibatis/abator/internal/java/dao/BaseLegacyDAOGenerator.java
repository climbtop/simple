/*   1:    */ package org.apache.ibatis.abator.internal.java.dao;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import org.apache.ibatis.abator.api.DAOGenerator;
/*   8:    */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   9:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  10:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  11:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  12:    */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*  13:    */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*  14:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  15:    */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  16:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  17:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  18:    */ import org.apache.ibatis.abator.api.dom.java.PrimitiveTypeWrapper;
/*  19:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  20:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*  21:    */ import org.apache.ibatis.abator.internal.sqlmap.ExampleClause;
/*  22:    */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*  23:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*  24:    */ 
/*  25:    */ public class BaseLegacyDAOGenerator
/*  26:    */   extends BaseDAOGenerator
/*  27:    */   implements DAOGenerator
/*  28:    */ {
/*  29:    */   protected boolean suppressTypeWarnings;
/*  30:    */   
/*  31:    */   public BaseLegacyDAOGenerator(AbstractDAOTemplate daoTemplate)
/*  32:    */   {
/*  33: 53 */     super(daoTemplate, false);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public BaseLegacyDAOGenerator(AbstractDAOTemplate daoTemplate, boolean useJava5)
/*  37:    */   {
/*  38: 57 */     super(daoTemplate, useJava5);
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected List getSelectByExampleWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  42:    */   {
/*  43: 65 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  44: 66 */       return null;
/*  45:    */     }
/*  46: 69 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  47: 70 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/*  48: 71 */     compilationUnit.addImportedType(type);
/*  49: 72 */     compilationUnit.addImportedType(FullyQualifiedJavaType.getNewListInstance());
/*  50:    */     
/*  51: 74 */     Method method1 = new Method();
/*  52: 75 */     method1.addComment(table);
/*  53: 76 */     method1.setVisibility(this.exampleMethodVisibility);
/*  54: 77 */     method1.setReturnType(FullyQualifiedJavaType.getNewListInstance());
/*  55: 78 */     method1.setName(this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable));
/*  56: 79 */     method1.addParameter(new Parameter(type, "example"));
/*  57: 80 */     method1.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), 
/*  58: 81 */       "orderByClause"));
/*  59:    */     
/*  60: 83 */     Method method2 = new Method();
/*  61: 84 */     method2.addComment(table);
/*  62: 85 */     method2.setVisibility(JavaVisibility.PUBLIC);
/*  63: 86 */     method2.setReturnType(FullyQualifiedJavaType.getNewListInstance());
/*  64: 87 */     method2.setName(this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable));
/*  65: 88 */     method2.addParameter(new Parameter(type, "example"));
/*  66:    */     
/*  67: 90 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  68: 91 */     while (iter.hasNext())
/*  69:    */     {
/*  70: 92 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  71: 93 */       method1.addException(fqjt);
/*  72: 94 */       method2.addException(fqjt);
/*  73: 95 */       compilationUnit.addImportedType(fqjt);
/*  74:    */     }
/*  75: 98 */     if (!interfaceMethod)
/*  76:    */     {
/*  77:100 */       compilationUnit.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
/*  78:    */       
/*  79:102 */       StringBuffer sb = new StringBuffer();
/*  80:104 */       if (this.suppressTypeWarnings) {
/*  81:105 */         method1.addSuppressTypeWarningsAnnotation();
/*  82:    */       }
/*  83:107 */       method1.addBodyLine("Map parms = getExampleParms(example);");
/*  84:108 */       method1.addBodyLine("if (orderByClause != null) {");
/*  85:109 */       method1.addBodyLine("parms.put(\"ABATOR_ORDER_BY_CLAUSE\", orderByClause);");
/*  86:110 */       method1.addBodyLine("}");
/*  87:    */       
/*  88:112 */       sb.append("List list = ");
/*  89:113 */       sb.append(this.daoTemplate.getQueryForListMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/*  90:114 */         this.sqlMapGenerator.getSelectByExampleStatementId(), 
/*  91:115 */         "parms"));
/*  92:116 */       method1.addBodyLine(sb.toString());
/*  93:117 */       method1.addBodyLine("return list;");
/*  94:    */       
/*  95:    */ 
/*  96:120 */       sb.setLength(0);
/*  97:121 */       sb.append("return ");
/*  98:122 */       sb.append(this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable));
/*  99:123 */       sb.append("(example, null);");
/* 100:124 */       method2.addBodyLine(sb.toString());
/* 101:    */     }
/* 102:127 */     ArrayList answer = new ArrayList();
/* 103:128 */     answer.add(method1);
/* 104:129 */     answer.add(method2);
/* 105:    */     
/* 106:131 */     return answer;
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected List getSelectByExampleWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 110:    */   {
/* 111:139 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 112:140 */       return null;
/* 113:    */     }
/* 114:143 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 115:144 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 116:145 */     compilationUnit.addImportedType(type);
/* 117:146 */     compilationUnit.addImportedType(FullyQualifiedJavaType.getNewListInstance());
/* 118:    */     
/* 119:148 */     Method method1 = new Method();
/* 120:149 */     method1.addComment(table);
/* 121:150 */     method1.setVisibility(this.exampleMethodVisibility);
/* 122:151 */     method1.setReturnType(FullyQualifiedJavaType.getNewListInstance());
/* 123:152 */     method1.setName(this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable));
/* 124:153 */     method1.addParameter(new Parameter(type, "example"));
/* 125:154 */     method1.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), 
/* 126:155 */       "orderByClause"));
/* 127:    */     
/* 128:157 */     Method method2 = new Method();
/* 129:158 */     method2.addComment(table);
/* 130:159 */     method2.setVisibility(JavaVisibility.PUBLIC);
/* 131:160 */     method2.setReturnType(FullyQualifiedJavaType.getNewListInstance());
/* 132:161 */     method2.setName(this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable));
/* 133:162 */     method2.addParameter(new Parameter(type, "example"));
/* 134:    */     
/* 135:164 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/* 136:165 */     while (iter.hasNext())
/* 137:    */     {
/* 138:166 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 139:167 */       method1.addException(fqjt);
/* 140:168 */       method2.addException(fqjt);
/* 141:169 */       compilationUnit.addImportedType(fqjt);
/* 142:    */     }
/* 143:172 */     if (!interfaceMethod)
/* 144:    */     {
/* 145:174 */       compilationUnit.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
/* 146:    */       
/* 147:176 */       StringBuffer sb = new StringBuffer();
/* 148:178 */       if (this.suppressTypeWarnings) {
/* 149:179 */         method1.addSuppressTypeWarningsAnnotation();
/* 150:    */       }
/* 151:181 */       method1.addBodyLine("Map parms = getExampleParms(example);");
/* 152:182 */       method1.addBodyLine("if (orderByClause != null) {");
/* 153:183 */       method1.addBodyLine("parms.put(\"ABATOR_ORDER_BY_CLAUSE\", orderByClause);");
/* 154:184 */       method1.addBodyLine("}");
/* 155:    */       
/* 156:186 */       sb.append("List list = ");
/* 157:187 */       sb.append(this.daoTemplate.getQueryForListMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/* 158:188 */         this.sqlMapGenerator.getSelectByExampleWithBLOBsStatementId(), 
/* 159:189 */         "parms"));
/* 160:190 */       method1.addBodyLine(sb.toString());
/* 161:191 */       method1.addBodyLine("return list;");
/* 162:    */       
/* 163:193 */       sb.setLength(0);
/* 164:194 */       sb.append("return ");
/* 165:195 */       sb.append(this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable));
/* 166:196 */       sb.append("(example, null);");
/* 167:197 */       method2.addBodyLine(sb.toString());
/* 168:    */     }
/* 169:200 */     ArrayList answer = new ArrayList();
/* 170:201 */     answer.add(method1);
/* 171:202 */     answer.add(method2);
/* 172:    */     
/* 173:204 */     return answer;
/* 174:    */   }
/* 175:    */   
/* 176:    */   protected List getDeleteByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 177:    */   {
/* 178:212 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 179:213 */       return null;
/* 180:    */     }
/* 181:216 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 182:217 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 183:218 */     compilationUnit.addImportedType(type);
/* 184:    */     
/* 185:220 */     Method method = new Method();
/* 186:221 */     method.addComment(table);
/* 187:222 */     method.setVisibility(this.exampleMethodVisibility);
/* 188:223 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 189:224 */     method.setName(this.methodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 190:225 */     method.addParameter(new Parameter(type, "example"));
/* 191:    */     
/* 192:227 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/* 193:228 */     while (iter.hasNext())
/* 194:    */     {
/* 195:229 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 196:230 */       method.addException(fqjt);
/* 197:231 */       compilationUnit.addImportedType(fqjt);
/* 198:    */     }
/* 199:234 */     if (!interfaceMethod)
/* 200:    */     {
/* 201:236 */       StringBuffer sb = new StringBuffer();
/* 202:    */       
/* 203:    */ 
/* 204:239 */       sb.append("return ");
/* 205:240 */       sb.append(this.daoTemplate.getDeleteMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/* 206:241 */         this.sqlMapGenerator.getDeleteByExampleStatementId(), 
/* 207:242 */         "getExampleParms(example)"));
/* 208:243 */       method.addBodyLine(sb.toString());
/* 209:    */     }
/* 210:248 */     ArrayList answer = new ArrayList();
/* 211:249 */     answer.add(method);
/* 212:    */     
/* 213:251 */     return answer;
/* 214:    */   }
/* 215:    */   
/* 216:    */   protected List getExtraImplementationMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/* 217:    */   {
/* 218:258 */     if (!introspectedTable.getRules().generateExampleClass()) {
/* 219:259 */       return null;
/* 220:    */     }
/* 221:262 */     ArrayList answer = new ArrayList();
/* 222:    */     
/* 223:264 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 224:265 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 225:    */     
/* 226:267 */     compilationUnit.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
/* 227:268 */     compilationUnit.addImportedType(FullyQualifiedJavaType.getNewHashMapInstance());
/* 228:269 */     compilationUnit.addImportedType(type);
/* 229:    */     
/* 230:271 */     Method method = new Method();
/* 231:272 */     method.addComment(table);
/* 232:273 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 233:274 */     if (this.suppressTypeWarnings) {
/* 234:275 */       method.addSuppressTypeWarningsAnnotation();
/* 235:    */     }
/* 236:277 */     method.setReturnType(FullyQualifiedJavaType.getNewMapInstance());
/* 237:278 */     method.setName("getExampleParms");
/* 238:279 */     method.addParameter(new Parameter(type, "example"));
/* 239:    */     
/* 240:281 */     method.addBodyLine("Map parms = new HashMap();");
/* 241:    */     
/* 242:283 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/* 243:284 */     while (iter.hasNext())
/* 244:    */     {
/* 245:285 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 246:286 */       StringBuffer sb = new StringBuffer();
/* 247:    */       
/* 248:288 */       Method method1 = getExampleParmsMethod(cd, table);
/* 249:289 */       if (method1 != null)
/* 250:    */       {
/* 251:290 */         answer.add(method1);
/* 252:    */         
/* 253:292 */         sb.setLength(0);
/* 254:293 */         sb.append("parms.putAll(");
/* 255:294 */         sb.append(method1.getName());
/* 256:295 */         sb.append("(example));");
/* 257:296 */         method.addBodyLine(sb.toString());
/* 258:    */       }
/* 259:    */     }
/* 260:300 */     method.addBodyLine("return parms;");
/* 261:    */     
/* 262:302 */     answer.add(method);
/* 263:    */     
/* 264:304 */     return answer;
/* 265:    */   }
/* 266:    */   
/* 267:    */   private Method getExampleParmsMethod(ColumnDefinition cd, FullyQualifiedTable table)
/* 268:    */   {
/* 269:333 */     StringBuffer sb = new StringBuffer();
/* 270:    */     
/* 271:335 */     Method method = new Method();
/* 272:336 */     method.addComment(table);
/* 273:337 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 274:338 */     if (this.suppressTypeWarnings) {
/* 275:339 */       method.addSuppressTypeWarningsAnnotation();
/* 276:    */     }
/* 277:341 */     method.setReturnType(FullyQualifiedJavaType.getNewMapInstance());
/* 278:342 */     sb.append("get");
/* 279:343 */     sb.append(cd.getColumnName());
/* 280:344 */     sb.append("ExampleParms");
/* 281:345 */     method.setName(sb.toString());
/* 282:    */     
/* 283:347 */     method.addParameter(new Parameter(this.javaModelGenerator.getExampleType(table), 
/* 284:348 */       "example"));
/* 285:    */     
/* 286:350 */     method.addBodyLine("Map parms = new HashMap();");
/* 287:    */     
/* 288:352 */     sb.setLength(0);
/* 289:353 */     sb.append("switch (example.");
/* 290:354 */     String property = cd.getJavaProperty() + "_Indicator";
/* 291:355 */     sb.append(JavaBeansUtil.getGetterMethodName(property));
/* 292:356 */     sb.append("()) {");
/* 293:357 */     method.addBodyLine(sb.toString());
/* 294:    */     
/* 295:359 */     Iterator clauseIterator = ExampleClause.getAllExampleClauses();
/* 296:360 */     while (clauseIterator.hasNext())
/* 297:    */     {
/* 298:361 */       ExampleClause clause = (ExampleClause)clauseIterator.next();
/* 299:363 */       if ((!clause.isCharacterOnly()) || (cd.isJdbcCharacterColumn()))
/* 300:    */       {
/* 301:367 */         sb.setLength(0);
/* 302:368 */         sb.append("case ");
/* 303:369 */         sb.append(this.javaModelGenerator.getExampleType(table)
/* 304:370 */           .getShortName());
/* 305:371 */         sb.append('.');
/* 306:372 */         sb.append(clause.getExamplePropertyName());
/* 307:373 */         sb.append(':');
/* 308:374 */         method.addBodyLine(sb.toString());
/* 309:    */         
/* 310:376 */         method.addBodyLine("if (example.isCombineTypeOr()) {");
/* 311:    */         
/* 312:378 */         sb.setLength(0);
/* 313:379 */         sb.append("parms.put(\"");
/* 314:380 */         sb.append(clause.getSelectorOrProperty(cd));
/* 315:381 */         sb.append("\", \"Y\");");
/* 316:382 */         method.addBodyLine(sb.toString());
/* 317:    */         
/* 318:384 */         method.addBodyLine("} else {");
/* 319:    */         
/* 320:386 */         sb.setLength(0);
/* 321:387 */         sb.append("parms.put(\"");
/* 322:388 */         sb.append(clause.getSelectorAndProperty(cd));
/* 323:389 */         sb.append("\", \"Y\");");
/* 324:390 */         method.addBodyLine(sb.toString());
/* 325:    */         
/* 326:392 */         method.addBodyLine("}");
/* 327:394 */         if (clause.isPropertyInMapRequired())
/* 328:    */         {
/* 329:395 */           String exampleProperty = cd.getJavaProperty();
/* 330:    */           
/* 331:397 */           sb.setLength(0);
/* 332:398 */           sb.append("parms.put(\"");
/* 333:399 */           sb.append(exampleProperty);
/* 334:400 */           sb.append("\", ");
/* 335:401 */           FullyQualifiedJavaType fqjt = cd.getResolvedJavaType()
/* 336:402 */             .getFullyQualifiedJavaType();
/* 337:403 */           if (fqjt.isPrimitive())
/* 338:    */           {
/* 339:404 */             sb.append("new ");
/* 340:405 */             sb.append(fqjt.getPrimitiveTypeWrapper().getShortName());
/* 341:406 */             sb.append('(');
/* 342:407 */             sb.append("example.");
/* 343:408 */             sb.append(
/* 344:409 */               JavaBeansUtil.getGetterMethodName(exampleProperty));
/* 345:410 */             sb.append("()));");
/* 346:    */           }
/* 347:    */           else
/* 348:    */           {
/* 349:412 */             sb.append("example.");
/* 350:413 */             sb.append(
/* 351:414 */               JavaBeansUtil.getGetterMethodName(exampleProperty));
/* 352:415 */             sb.append("());");
/* 353:    */           }
/* 354:417 */           method.addBodyLine(sb.toString());
/* 355:    */         }
/* 356:420 */         method.addBodyLine("break;");
/* 357:    */       }
/* 358:    */     }
/* 359:423 */     method.addBodyLine("}");
/* 360:    */     
/* 361:425 */     method.addBodyLine("return parms;");
/* 362:    */     
/* 363:427 */     return method;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void addContextProperties(Map properties)
/* 367:    */   {
/* 368:431 */     super.addContextProperties(properties);
/* 369:434 */     if ("true".equalsIgnoreCase((String)properties.get("suppressTypeWarnings"))) {
/* 370:435 */       this.suppressTypeWarnings = true;
/* 371:    */     }
/* 372:    */   }
/* 373:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.BaseLegacyDAOGenerator
 * JD-Core Version:    0.7.0.1
 */