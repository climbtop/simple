/*  1:   */ package org.apache.ibatis.abator.internal.java.service;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  5:   */ 
/*  6:   */ public class SpringAbatorVportalServiceGenerator
/*  7:   */   extends BaseServiceGenerator
/*  8:   */   implements ServiceGenerator
/*  9:   */ {
/* 10:   */   public SpringAbatorVportalServiceGenerator()
/* 11:   */   {
/* 12:67 */     super(new SpringAbatorServiceTemplate(), false);
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/* 16:   */   {
/* 17:71 */     return new FullyQualifiedJavaType("com.afocus.framework.util.PageList");
/* 18:   */   }
/* 19:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.service.SpringAbatorVportalServiceGenerator
 * JD-Core Version:    0.7.0.1
 */