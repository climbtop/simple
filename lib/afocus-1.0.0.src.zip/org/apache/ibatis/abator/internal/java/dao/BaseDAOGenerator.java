/*    1:     */ package org.apache.ibatis.abator.internal.java.dao;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.Arrays;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.Iterator;
/*    7:     */ import java.util.List;
/*    8:     */ import java.util.Map;
/*    9:     */ import org.apache.ibatis.abator.api.DAOGenerator;
/*   10:     */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   11:     */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   12:     */ import org.apache.ibatis.abator.api.GeneratedJavaFile;
/*   13:     */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   14:     */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   15:     */ import org.apache.ibatis.abator.api.ProgressCallback;
/*   16:     */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*   17:     */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*   18:     */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   19:     */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   20:     */ import org.apache.ibatis.abator.api.dom.java.Interface;
/*   21:     */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*   22:     */ import org.apache.ibatis.abator.api.dom.java.Method;
/*   23:     */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*   24:     */ import org.apache.ibatis.abator.api.dom.java.PrimitiveTypeWrapper;
/*   25:     */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*   26:     */ import org.apache.ibatis.abator.config.GeneratedKey;
/*   27:     */ import org.apache.ibatis.abator.internal.AbatorObjectFactory;
/*   28:     */ import org.apache.ibatis.abator.internal.DefaultDAOMethodNameCalculator;
/*   29:     */ import org.apache.ibatis.abator.internal.ExtendedDAOMethodNameCalculator;
/*   30:     */ import org.apache.ibatis.abator.internal.SimpleDAOMethodNameCalculator;
/*   31:     */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*   32:     */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   33:     */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*   34:     */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*   35:     */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   36:     */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*   37:     */ 
/*   38:     */ public class BaseDAOGenerator
/*   39:     */   implements DAOGenerator
/*   40:     */ {
/*   41:     */   protected AbstractDAOTemplate daoTemplate;
/*   42:     */   protected Map properties;
/*   43:     */   protected List warnings;
/*   44:     */   protected String targetPackage;
/*   45:     */   protected String targetProject;
/*   46:     */   protected JavaModelGenerator javaModelGenerator;
/*   47:     */   protected SqlMapGenerator sqlMapGenerator;
/*   48:     */   private Map tableValueMaps;
/*   49:     */   private boolean useJava5Features;
/*   50: 110 */   private boolean useSpringAnnotation = false;
/*   51: 112 */   protected JavaVisibility exampleMethodVisibility = JavaVisibility.PUBLIC;
/*   52: 114 */   protected DAOMethodNameCalculator methodNameCalculator = new DefaultDAOMethodNameCalculator();
/*   53:     */   
/*   54:     */   public BaseDAOGenerator(AbstractDAOTemplate daoTemplate, boolean useJava5Features)
/*   55:     */   {
/*   56: 121 */     this.daoTemplate = daoTemplate;
/*   57: 122 */     this.useJava5Features = useJava5Features;
/*   58: 123 */     this.tableValueMaps = new HashMap();
/*   59: 124 */     this.properties = new HashMap();
/*   60:     */   }
/*   61:     */   
/*   62:     */   public void addConfigurationProperties(Map properties)
/*   63:     */   {
/*   64: 128 */     this.properties.putAll(properties);
/*   65: 130 */     if (properties.containsKey("exampleMethodVisibility"))
/*   66:     */     {
/*   67: 131 */       String value = (String)properties.get("exampleMethodVisibility");
/*   68: 133 */       if ("public".equalsIgnoreCase(value)) {
/*   69: 134 */         this.exampleMethodVisibility = JavaVisibility.PUBLIC;
/*   70: 135 */       } else if ("private".equalsIgnoreCase(value)) {
/*   71: 136 */         this.exampleMethodVisibility = JavaVisibility.PRIVATE;
/*   72: 137 */       } else if ("protected".equalsIgnoreCase(value)) {
/*   73: 138 */         this.exampleMethodVisibility = JavaVisibility.PROTECTED;
/*   74: 139 */       } else if ("default".equalsIgnoreCase(value)) {
/*   75: 140 */         this.exampleMethodVisibility = JavaVisibility.DEFAULT;
/*   76:     */       } else {
/*   77: 142 */         this.warnings.add(Messages.getString("Warning.16", value));
/*   78:     */       }
/*   79:     */     }
/*   80: 146 */     if (properties.containsKey("useSpringAnnotation")) {
/*   81: 147 */       this.useSpringAnnotation = "true".equalsIgnoreCase((String)properties.get("useSpringAnnotation"));
/*   82:     */     }
/*   83: 150 */     if (properties.containsKey("methodNameCalculator"))
/*   84:     */     {
/*   85: 151 */       String value = (String)properties.get("methodNameCalculator");
/*   86: 153 */       if ("extended".equalsIgnoreCase(value)) {
/*   87: 154 */         this.methodNameCalculator = new ExtendedDAOMethodNameCalculator();
/*   88: 155 */       } else if ("simple".equalsIgnoreCase(value)) {
/*   89: 156 */         this.methodNameCalculator = new SimpleDAOMethodNameCalculator();
/*   90: 157 */       } else if ((!"default".equalsIgnoreCase(value)) && 
/*   91: 158 */         (StringUtility.stringHasValue(value))) {
/*   92:     */         try
/*   93:     */         {
/*   94: 160 */           this.methodNameCalculator = ((DAOMethodNameCalculator)
/*   95: 161 */             AbatorObjectFactory.createObject(value));
/*   96:     */         }
/*   97:     */         catch (Exception e)
/*   98:     */         {
/*   99: 163 */           this.warnings.add(Messages.getString("Warning.17", value, Arrays.deepToString(e.getStackTrace())));
/*  100:     */         }
/*  101:     */       }
/*  102:     */     }
/*  103:     */   }
/*  104:     */   
/*  105:     */   public void setWarnings(List warnings)
/*  106:     */   {
/*  107: 175 */     this.warnings = warnings;
/*  108:     */   }
/*  109:     */   
/*  110:     */   public void setTargetPackage(String targetPackage)
/*  111:     */   {
/*  112: 184 */     this.targetPackage = targetPackage;
/*  113:     */   }
/*  114:     */   
/*  115:     */   public void setTargetProject(String targetProject)
/*  116:     */   {
/*  117: 193 */     this.targetProject = targetProject;
/*  118:     */   }
/*  119:     */   
/*  120:     */   public void setJavaModelGenerator(JavaModelGenerator javaModelGenerator)
/*  121:     */   {
/*  122: 202 */     this.javaModelGenerator = javaModelGenerator;
/*  123:     */   }
/*  124:     */   
/*  125:     */   public void setSqlMapGenerator(SqlMapGenerator sqlMapGenerator)
/*  126:     */   {
/*  127: 211 */     this.sqlMapGenerator = sqlMapGenerator;
/*  128:     */   }
/*  129:     */   
/*  130:     */   public List getGeneratedJavaFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/*  131:     */   {
/*  132: 222 */     List list = new ArrayList();
/*  133:     */     
/*  134: 224 */     String tableName = introspectedTable.getTable().getFullyQualifiedTableName();
/*  135:     */     
/*  136: 226 */     callback.startSubTask(Messages.getString("Progress.10", 
/*  137: 227 */       tableName));
/*  138: 228 */     CompilationUnit cu = getDAOImplementation(introspectedTable);
/*  139: 229 */     GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  140: 230 */     list.add(gjf);
/*  141:     */     
/*  142: 232 */     callback.startSubTask(Messages.getString("Progress.11", 
/*  143: 233 */       tableName));
/*  144: 234 */     cu = getDAOInterface(introspectedTable);
/*  145: 235 */     gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  146: 236 */     list.add(gjf);
/*  147:     */     
/*  148: 238 */     return list;
/*  149:     */   }
/*  150:     */   
/*  151:     */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/*  152:     */   {
/*  153: 242 */     return FullyQualifiedJavaType.getNewListInstance();
/*  154:     */   }
/*  155:     */   
/*  156:     */   protected TopLevelClass getDAOImplementation(IntrospectedTable introspectedTable)
/*  157:     */   {
/*  158: 247 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  159: 248 */     FullyQualifiedJavaType type = getDAOImplementationType(table);
/*  160: 249 */     TopLevelClass answer = new TopLevelClass(type);
/*  161: 250 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  162: 251 */     FullyQualifiedJavaType superClass = new FullyQualifiedJavaType(this.daoTemplate.getSuperClass().getFullyQualifiedName());
/*  163:     */     
/*  164: 253 */     answer.setSuperClass(superClass);
/*  165: 254 */     answer.addImportedType(superClass);
/*  166: 255 */     answer.addSuperInterface(getDAOInterfaceType(table));
/*  167: 256 */     answer.addImportedType(getDAOInterfaceType(table));
/*  168:     */     
/*  169: 258 */     Iterator iter = this.daoTemplate.getImplementationImports().iterator();
/*  170: 259 */     while (iter.hasNext()) {
/*  171: 260 */       answer.addImportedType((FullyQualifiedJavaType)iter.next());
/*  172:     */     }
/*  173: 264 */     Method method = this.daoTemplate.getConstructorClone(this.sqlMapGenerator
/*  174: 265 */       .getSqlMapNamespace(table), getDAOImplementationType(table), table);
/*  175: 266 */     answer.addMethod(method);
/*  176:     */     
/*  177:     */ 
/*  178: 269 */     iter = this.daoTemplate.getFieldClones(table);
/*  179: 270 */     while (iter.hasNext()) {
/*  180: 271 */       answer.addField((Field)iter.next());
/*  181:     */     }
/*  182: 275 */     iter = this.daoTemplate.getMethodClones(table);
/*  183: 276 */     while (iter.hasNext()) {
/*  184: 277 */       answer.addMethod((Method)iter.next());
/*  185:     */     }
/*  186: 280 */     if (this.useJava5Features)
/*  187:     */     {
/*  188: 281 */       String propertyName = JavaBeansUtil.getValidPropertyName(getDAOInterfaceType(table).getBaseShortName());
/*  189: 282 */       answer.addImportedType(this.javaModelGenerator.getBaseRecordType(table));
/*  190: 283 */       superClass.addTypeArgument(this.javaModelGenerator.getBaseRecordType(table));
/*  191: 285 */       if (this.useSpringAnnotation)
/*  192:     */       {
/*  193: 286 */         answer.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Repository"));
/*  194: 287 */         answer.addAnnotation("@Repository(\"" + propertyName + "\")");
/*  195: 288 */         method = getSetSqlMapClientMethods(introspectedTable, answer);
/*  196: 289 */         answer.addMethod(method);
/*  197:     */       }
/*  198:     */     }
/*  199: 296 */     List methods = getExtraImplementationMethods(introspectedTable, answer);
/*  200: 297 */     if (methods != null)
/*  201:     */     {
/*  202: 298 */       iter = methods.iterator();
/*  203: 299 */       while (iter.hasNext()) {
/*  204: 300 */         answer.addMethod((Method)iter.next());
/*  205:     */       }
/*  206:     */     }
/*  207: 303 */     if (this.useJava5Features) {
/*  208: 304 */       return answer;
/*  209:     */     }
/*  210: 307 */     if (introspectedTable.getRules().generateInsert())
/*  211:     */     {
/*  212: 308 */       methods = getInsertMethods(introspectedTable, false, answer);
/*  213: 309 */       if (methods != null)
/*  214:     */       {
/*  215: 310 */         iter = methods.iterator();
/*  216: 311 */         while (iter.hasNext()) {
/*  217: 312 */           answer.addMethod((Method)iter.next());
/*  218:     */         }
/*  219:     */       }
/*  220:     */     }
/*  221: 317 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs())
/*  222:     */     {
/*  223: 318 */       methods = getUpdateByPrimaryKeyWithoutBLOBsMethods(introspectedTable, false, answer);
/*  224: 319 */       if (methods != null)
/*  225:     */       {
/*  226: 320 */         iter = methods.iterator();
/*  227: 321 */         while (iter.hasNext()) {
/*  228: 322 */           answer.addMethod((Method)iter.next());
/*  229:     */         }
/*  230:     */       }
/*  231:     */     }
/*  232: 327 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs())
/*  233:     */     {
/*  234: 328 */       methods = getUpdateByPrimaryKeyWithBLOBsMethods(introspectedTable, 
/*  235: 329 */         false, answer);
/*  236: 330 */       if (methods != null)
/*  237:     */       {
/*  238: 331 */         iter = methods.iterator();
/*  239: 332 */         while (iter.hasNext()) {
/*  240: 333 */           answer.addMethod((Method)iter.next());
/*  241:     */         }
/*  242:     */       }
/*  243:     */     }
/*  244: 338 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeySelective())
/*  245:     */     {
/*  246: 339 */       methods = getUpdateByPrimaryKeySelectiveMethods(introspectedTable, 
/*  247: 340 */         false, answer);
/*  248: 341 */       if (methods != null)
/*  249:     */       {
/*  250: 342 */         iter = methods.iterator();
/*  251: 343 */         while (iter.hasNext()) {
/*  252: 344 */           answer.addMethod((Method)iter.next());
/*  253:     */         }
/*  254:     */       }
/*  255:     */     }
/*  256: 349 */     if (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs())
/*  257:     */     {
/*  258: 350 */       methods = getSelectByExampleWithoutBLOBsMethods(introspectedTable, false, answer);
/*  259: 351 */       if (methods != null)
/*  260:     */       {
/*  261: 352 */         iter = methods.iterator();
/*  262: 353 */         while (iter.hasNext()) {
/*  263: 354 */           answer.addMethod((Method)iter.next());
/*  264:     */         }
/*  265:     */       }
/*  266:     */     }
/*  267: 359 */     if (introspectedTable.getRules().generateSelectByExampleWithBLOBs())
/*  268:     */     {
/*  269: 360 */       methods = getSelectByExampleWithBLOBsMethods(introspectedTable, false, answer);
/*  270: 361 */       if (methods != null)
/*  271:     */       {
/*  272: 362 */         iter = methods.iterator();
/*  273: 363 */         while (iter.hasNext()) {
/*  274: 364 */           answer.addMethod((Method)iter.next());
/*  275:     */         }
/*  276:     */       }
/*  277:     */     }
/*  278: 369 */     if ((introspectedTable.getRules().generateSelectByExampleWithBLOBs()) || (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()))
/*  279:     */     {
/*  280: 370 */       methods = getSelectCountByExampleMethods(introspectedTable, false, answer);
/*  281: 371 */       if (methods != null)
/*  282:     */       {
/*  283: 372 */         iter = methods.iterator();
/*  284: 373 */         while (iter.hasNext()) {
/*  285: 374 */           answer.addMethod((Method)iter.next());
/*  286:     */         }
/*  287:     */       }
/*  288:     */     }
/*  289: 379 */     if (introspectedTable.getRules().generateSelectByPrimaryKey())
/*  290:     */     {
/*  291: 380 */       methods = getSelectByPrimaryKeyMethods(introspectedTable, false, answer);
/*  292: 381 */       if (methods != null)
/*  293:     */       {
/*  294: 382 */         iter = methods.iterator();
/*  295: 383 */         while (iter.hasNext()) {
/*  296: 384 */           answer.addMethod((Method)iter.next());
/*  297:     */         }
/*  298:     */       }
/*  299:     */     }
/*  300: 389 */     if (introspectedTable.getRules().generateDeleteByExample())
/*  301:     */     {
/*  302: 390 */       methods = getDeleteByExampleMethods(introspectedTable, false, answer);
/*  303: 391 */       if (methods != null)
/*  304:     */       {
/*  305: 392 */         iter = methods.iterator();
/*  306: 393 */         while (iter.hasNext()) {
/*  307: 394 */           answer.addMethod((Method)iter.next());
/*  308:     */         }
/*  309:     */       }
/*  310:     */     }
/*  311: 399 */     if (introspectedTable.getRules().generateDeleteByPrimaryKey())
/*  312:     */     {
/*  313: 400 */       methods = getDeleteByPrimaryKeyMethods(introspectedTable, false, answer);
/*  314: 401 */       if (methods != null)
/*  315:     */       {
/*  316: 402 */         iter = methods.iterator();
/*  317: 403 */         while (iter.hasNext()) {
/*  318: 404 */           answer.addMethod((Method)iter.next());
/*  319:     */         }
/*  320:     */       }
/*  321:     */     }
/*  322: 409 */     return answer;
/*  323:     */   }
/*  324:     */   
/*  325:     */   protected List getExtraImplementationMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  326:     */   {
/*  327: 423 */     return null;
/*  328:     */   }
/*  329:     */   
/*  330:     */   protected Interface getDAOInterface(IntrospectedTable introspectedTable)
/*  331:     */   {
/*  332: 427 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  333: 428 */     Interface answer = new Interface(getDAOInterfaceType(table));
/*  334: 429 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  335: 431 */     if (this.properties.containsKey("rootInterface"))
/*  336:     */     {
/*  337: 432 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  338: 433 */         (String)this.properties.get("rootInterface"));
/*  339: 434 */       if (this.useJava5Features)
/*  340:     */       {
/*  341: 435 */         FullyQualifiedJavaType recordType = this.javaModelGenerator.getBaseRecordType(table);
/*  342: 436 */         fqjt.addTypeArgument(recordType);
/*  343: 437 */         answer.addImportedType(recordType);
/*  344:     */       }
/*  345: 439 */       answer.addSuperInterface(fqjt);
/*  346: 440 */       answer.addImportedType(fqjt);
/*  347:     */     }
/*  348: 443 */     Iterator iter = this.daoTemplate.getInterfaceImports().iterator();
/*  349: 444 */     while (iter.hasNext()) {
/*  350: 445 */       answer.addImportedType((FullyQualifiedJavaType)iter.next());
/*  351:     */     }
/*  352: 448 */     if (this.useJava5Features) {
/*  353: 449 */       return answer;
/*  354:     */     }
/*  355: 453 */     if (introspectedTable.getRules().generateInsert())
/*  356:     */     {
/*  357: 454 */       List methods = getInsertMethods(introspectedTable, true, answer);
/*  358: 455 */       if (methods != null)
/*  359:     */       {
/*  360: 456 */         iter = methods.iterator();
/*  361: 457 */         while (iter.hasNext()) {
/*  362: 458 */           answer.addMethod((Method)iter.next());
/*  363:     */         }
/*  364:     */       }
/*  365:     */     }
/*  366: 463 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs())
/*  367:     */     {
/*  368: 464 */       List methods = getUpdateByPrimaryKeyWithoutBLOBsMethods(introspectedTable, true, answer);
/*  369: 465 */       if (methods != null)
/*  370:     */       {
/*  371: 466 */         iter = methods.iterator();
/*  372: 467 */         while (iter.hasNext()) {
/*  373: 468 */           answer.addMethod((Method)iter.next());
/*  374:     */         }
/*  375:     */       }
/*  376:     */     }
/*  377: 473 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs())
/*  378:     */     {
/*  379: 474 */       List methods = getUpdateByPrimaryKeyWithBLOBsMethods(introspectedTable, 
/*  380: 475 */         true, answer);
/*  381: 476 */       if (methods != null)
/*  382:     */       {
/*  383: 477 */         iter = methods.iterator();
/*  384: 478 */         while (iter.hasNext()) {
/*  385: 479 */           answer.addMethod((Method)iter.next());
/*  386:     */         }
/*  387:     */       }
/*  388:     */     }
/*  389: 484 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeySelective())
/*  390:     */     {
/*  391: 485 */       List methods = getUpdateByPrimaryKeySelectiveMethods(introspectedTable, 
/*  392: 486 */         true, answer);
/*  393: 487 */       if (methods != null)
/*  394:     */       {
/*  395: 488 */         iter = methods.iterator();
/*  396: 489 */         while (iter.hasNext()) {
/*  397: 490 */           answer.addMethod((Method)iter.next());
/*  398:     */         }
/*  399:     */       }
/*  400:     */     }
/*  401: 495 */     if (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs())
/*  402:     */     {
/*  403: 496 */       List methods = getSelectByExampleWithoutBLOBsMethods(introspectedTable, true, answer);
/*  404: 497 */       if (methods != null)
/*  405:     */       {
/*  406: 498 */         iter = methods.iterator();
/*  407: 499 */         while (iter.hasNext()) {
/*  408: 500 */           answer.addMethod((Method)iter.next());
/*  409:     */         }
/*  410:     */       }
/*  411:     */     }
/*  412: 505 */     if (introspectedTable.getRules().generateSelectByExampleWithBLOBs())
/*  413:     */     {
/*  414: 506 */       List methods = getSelectByExampleWithBLOBsMethods(introspectedTable, true, answer);
/*  415: 507 */       if (methods != null)
/*  416:     */       {
/*  417: 508 */         iter = methods.iterator();
/*  418: 509 */         while (iter.hasNext()) {
/*  419: 510 */           answer.addMethod((Method)iter.next());
/*  420:     */         }
/*  421:     */       }
/*  422:     */     }
/*  423: 515 */     if ((introspectedTable.getRules().generateSelectByExampleWithBLOBs()) || (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()))
/*  424:     */     {
/*  425: 516 */       List methods = getSelectCountByExampleMethods(introspectedTable, true, answer);
/*  426: 517 */       if (methods != null)
/*  427:     */       {
/*  428: 518 */         iter = methods.iterator();
/*  429: 519 */         while (iter.hasNext()) {
/*  430: 520 */           answer.addMethod((Method)iter.next());
/*  431:     */         }
/*  432:     */       }
/*  433:     */     }
/*  434: 525 */     if (introspectedTable.getRules().generateSelectByPrimaryKey())
/*  435:     */     {
/*  436: 526 */       List methods = getSelectByPrimaryKeyMethods(introspectedTable, true, answer);
/*  437: 527 */       if (methods != null)
/*  438:     */       {
/*  439: 528 */         iter = methods.iterator();
/*  440: 529 */         while (iter.hasNext()) {
/*  441: 530 */           answer.addMethod((Method)iter.next());
/*  442:     */         }
/*  443:     */       }
/*  444:     */     }
/*  445: 535 */     if (introspectedTable.getRules().generateDeleteByExample())
/*  446:     */     {
/*  447: 536 */       List methods = getDeleteByExampleMethods(introspectedTable, true, answer);
/*  448: 537 */       if (methods != null)
/*  449:     */       {
/*  450: 538 */         iter = methods.iterator();
/*  451: 539 */         while (iter.hasNext()) {
/*  452: 540 */           answer.addMethod((Method)iter.next());
/*  453:     */         }
/*  454:     */       }
/*  455:     */     }
/*  456: 545 */     if (introspectedTable.getRules().generateDeleteByPrimaryKey())
/*  457:     */     {
/*  458: 546 */       List methods = getDeleteByPrimaryKeyMethods(introspectedTable, true, answer);
/*  459: 547 */       if (methods != null)
/*  460:     */       {
/*  461: 548 */         iter = methods.iterator();
/*  462: 549 */         while (iter.hasNext()) {
/*  463: 550 */           answer.addMethod((Method)iter.next());
/*  464:     */         }
/*  465:     */       }
/*  466:     */     }
/*  467: 555 */     return answer;
/*  468:     */   }
/*  469:     */   
/*  470:     */   public FullyQualifiedJavaType getDAOImplementationType(FullyQualifiedTable table)
/*  471:     */   {
/*  472: 559 */     String key = "getDAOImplementationType";
/*  473:     */     
/*  474: 561 */     Map map = getTableValueMap(table);
/*  475: 562 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  476: 563 */     if (fqjt == null)
/*  477:     */     {
/*  478: 564 */       StringBuffer sb = new StringBuffer();
/*  479: 565 */       sb.append(getDAOPackage(table));
/*  480: 566 */       sb.append(".impl.");
/*  481: 567 */       sb.append(table.getDomainObjectName());
/*  482: 568 */       sb.append("DaoImpl");
/*  483:     */       
/*  484: 570 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  485: 571 */       map.put(key, fqjt);
/*  486:     */     }
/*  487: 574 */     return fqjt;
/*  488:     */   }
/*  489:     */   
/*  490:     */   protected Method getSetSqlMapClientMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  491:     */   {
/*  492: 579 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  493: 580 */     Method method = new Method();
/*  494: 581 */     method.addComment(table);
/*  495:     */     
/*  496: 583 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("org.springframework.beans.factory.annotation.Required");
/*  497: 584 */     compilationUnit.addImportedType(parameterType);
/*  498: 585 */     method.addAnnotation("@Required");
/*  499:     */     
/*  500: 587 */     parameterType = new FullyQualifiedJavaType("javax.annotation.Resource");
/*  501: 588 */     compilationUnit.addImportedType(parameterType);
/*  502: 589 */     method.addAnnotation("@Resource");
/*  503:     */     
/*  504: 591 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  505: 592 */     method.setName("setSqlMapClientAutowired");
/*  506:     */     
/*  507: 594 */     parameterType = new FullyQualifiedJavaType("com.ibatis.sqlmap.client.SqlMapClient");
/*  508: 595 */     compilationUnit.addImportedType(parameterType);
/*  509: 596 */     method.addParameter(new Parameter(parameterType, "sqlMapClient"));
/*  510: 597 */     method.addBodyLine("super.setSqlMapClient( sqlMapClient );");
/*  511:     */     
/*  512: 599 */     return method;
/*  513:     */   }
/*  514:     */   
/*  515:     */   protected List getInsertMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  516:     */   {
/*  517: 605 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  518: 606 */     Method method = new Method();
/*  519: 607 */     method.addComment(table);
/*  520:     */     FullyQualifiedJavaType returnType;
/*  521: 610 */     if (introspectedTable.getGeneratedKey() != null)
/*  522:     */     {
/*  523: 611 */       ColumnDefinition cd = introspectedTable.getColumn(
/*  524: 612 */         introspectedTable.getGeneratedKey().getColumn());
/*  525:     */       FullyQualifiedJavaType returnType;
/*  526: 613 */       if (cd == null)
/*  527:     */       {
/*  528: 617 */         returnType = null;
/*  529:     */       }
/*  530:     */       else
/*  531:     */       {
/*  532: 619 */         FullyQualifiedJavaType returnType = cd.getResolvedJavaType()
/*  533: 620 */           .getFullyQualifiedJavaType();
/*  534: 621 */         compilationUnit.addImportedType(returnType);
/*  535:     */       }
/*  536:     */     }
/*  537:     */     else
/*  538:     */     {
/*  539: 624 */       returnType = null;
/*  540:     */     }
/*  541: 626 */     method.setReturnType(returnType);
/*  542: 627 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  543: 628 */     method.setName(this.methodNameCalculator.getInsertMethodName(introspectedTable));
/*  544:     */     
/*  545: 630 */     FullyQualifiedJavaType parameterType = 
/*  546: 631 */       introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/*  547:     */     
/*  548: 633 */     compilationUnit.addImportedType(parameterType);
/*  549: 634 */     method.addParameter(new Parameter(parameterType, "record"));
/*  550:     */     
/*  551: 636 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  552: 637 */     while (iter.hasNext())
/*  553:     */     {
/*  554: 638 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  555: 639 */       method.addException(fqjt);
/*  556: 640 */       compilationUnit.addImportedType(fqjt);
/*  557:     */     }
/*  558: 643 */     if (!interfaceMethod)
/*  559:     */     {
/*  560: 645 */       StringBuffer sb = new StringBuffer();
/*  561: 647 */       if (returnType != null) {
/*  562: 648 */         sb.append("Object newKey = ");
/*  563:     */       }
/*  564: 651 */       sb.append(this.daoTemplate.getInsertMethod(this.sqlMapGenerator
/*  565: 652 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/*  566: 653 */         .getInsertStatementId(), "record"));
/*  567: 654 */       method.addBodyLine(sb.toString());
/*  568: 656 */       if (returnType != null) {
/*  569: 657 */         if ("Object".equals(returnType.getShortName()))
/*  570:     */         {
/*  571: 659 */           method.addBodyLine("return newKey;");
/*  572:     */         }
/*  573:     */         else
/*  574:     */         {
/*  575: 661 */           sb.setLength(0);
/*  576: 663 */           if (returnType.isPrimitive())
/*  577:     */           {
/*  578: 664 */             PrimitiveTypeWrapper ptw = returnType
/*  579: 665 */               .getPrimitiveTypeWrapper();
/*  580: 666 */             sb.append("return ((");
/*  581: 667 */             sb.append(ptw.getShortName());
/*  582: 668 */             sb.append(") newKey");
/*  583: 669 */             sb.append(").");
/*  584: 670 */             sb.append(ptw.getToPrimitiveMethod());
/*  585: 671 */             sb.append(';');
/*  586:     */           }
/*  587:     */           else
/*  588:     */           {
/*  589: 673 */             sb.append("return (");
/*  590: 674 */             sb.append(returnType.getShortName());
/*  591: 675 */             sb.append(") newKey;");
/*  592:     */           }
/*  593: 678 */           method.addBodyLine(sb.toString());
/*  594:     */         }
/*  595:     */       }
/*  596:     */     }
/*  597: 683 */     List answer = new ArrayList();
/*  598: 684 */     answer.add(method);
/*  599:     */     
/*  600: 686 */     return answer;
/*  601:     */   }
/*  602:     */   
/*  603:     */   protected List getUpdateByPrimaryKeyWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  604:     */   {
/*  605: 693 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  606: 694 */     FullyQualifiedJavaType parameterType = 
/*  607: 695 */       this.javaModelGenerator.getBaseRecordType(table);
/*  608: 696 */     compilationUnit.addImportedType(parameterType);
/*  609:     */     
/*  610: 698 */     Method method = new Method();
/*  611: 699 */     method.addComment(table);
/*  612: 700 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  613: 701 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  614: 702 */     method.setName(this.methodNameCalculator.getUpdateByPrimaryKeyWithoutBLOBsMethodName(introspectedTable));
/*  615: 703 */     method.addParameter(new Parameter(parameterType, "record"));
/*  616:     */     
/*  617: 705 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  618: 706 */     while (iter.hasNext())
/*  619:     */     {
/*  620: 707 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  621: 708 */       method.addException(fqjt);
/*  622: 709 */       compilationUnit.addImportedType(fqjt);
/*  623:     */     }
/*  624: 712 */     if (!interfaceMethod)
/*  625:     */     {
/*  626: 714 */       StringBuffer sb = new StringBuffer();
/*  627:     */       
/*  628:     */ 
/*  629: 717 */       sb.append("return ");
/*  630: 718 */       sb.append(this.daoTemplate.getUpdateMethod(this.sqlMapGenerator
/*  631: 719 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/*  632: 720 */         .getUpdateByPrimaryKeyStatementId(), "record"));
/*  633: 721 */       method.addBodyLine(sb.toString());
/*  634:     */     }
/*  635: 726 */     ArrayList answer = new ArrayList();
/*  636: 727 */     answer.add(method);
/*  637:     */     
/*  638: 729 */     return answer;
/*  639:     */   }
/*  640:     */   
/*  641:     */   protected List getUpdateByPrimaryKeyWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  642:     */   {
/*  643: 736 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  644:     */     FullyQualifiedJavaType parameterType;
/*  645:     */     FullyQualifiedJavaType parameterType;
/*  646: 739 */     if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  647: 740 */       parameterType = this.javaModelGenerator.getRecordWithBLOBsType(table);
/*  648:     */     } else {
/*  649: 742 */       parameterType = this.javaModelGenerator.getBaseRecordType(table);
/*  650:     */     }
/*  651: 745 */     compilationUnit.addImportedType(parameterType);
/*  652:     */     
/*  653: 747 */     Method method = new Method();
/*  654: 748 */     method.addComment(table);
/*  655: 749 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  656: 750 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  657: 751 */     method.setName(this.methodNameCalculator.getUpdateByPrimaryKeyWithBLOBsMethodName(introspectedTable));
/*  658: 752 */     method.addParameter(new Parameter(parameterType, "record"));
/*  659:     */     
/*  660: 754 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  661: 755 */     while (iter.hasNext())
/*  662:     */     {
/*  663: 756 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  664: 757 */       method.addException(fqjt);
/*  665: 758 */       compilationUnit.addImportedType(fqjt);
/*  666:     */     }
/*  667: 761 */     if (!interfaceMethod)
/*  668:     */     {
/*  669: 763 */       StringBuffer sb = new StringBuffer();
/*  670:     */       
/*  671:     */ 
/*  672: 766 */       sb.append("return ");
/*  673: 767 */       sb.append(this.daoTemplate.getUpdateMethod(this.sqlMapGenerator
/*  674: 768 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/*  675: 769 */         .getUpdateByPrimaryKeyWithBLOBsStatementId(), "record"));
/*  676: 770 */       method.addBodyLine(sb.toString());
/*  677:     */     }
/*  678: 775 */     ArrayList answer = new ArrayList();
/*  679: 776 */     answer.add(method);
/*  680:     */     
/*  681: 778 */     return answer;
/*  682:     */   }
/*  683:     */   
/*  684:     */   protected List getUpdateByPrimaryKeySelectiveMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  685:     */   {
/*  686: 785 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  687:     */     FullyQualifiedJavaType parameterType;
/*  688:     */     FullyQualifiedJavaType parameterType;
/*  689: 788 */     if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  690: 789 */       parameterType = this.javaModelGenerator.getRecordWithBLOBsType(table);
/*  691:     */     } else {
/*  692: 791 */       parameterType = this.javaModelGenerator.getBaseRecordType(table);
/*  693:     */     }
/*  694: 794 */     compilationUnit.addImportedType(parameterType);
/*  695:     */     
/*  696: 796 */     Method method = new Method();
/*  697: 797 */     method.addComment(table);
/*  698: 798 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  699: 799 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  700: 800 */     method.setName(this.methodNameCalculator.getUpdateByPrimaryKeySelectiveMethodName(introspectedTable));
/*  701:     */     
/*  702: 802 */     method.addParameter(new Parameter(new FullyQualifiedJavaType("java.util.Map"), "param"));
/*  703:     */     
/*  704: 804 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  705: 805 */     while (iter.hasNext())
/*  706:     */     {
/*  707: 806 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  708: 807 */       method.addException(fqjt);
/*  709: 808 */       compilationUnit.addImportedType(fqjt);
/*  710:     */     }
/*  711: 811 */     if (!interfaceMethod)
/*  712:     */     {
/*  713: 813 */       StringBuffer sb = new StringBuffer();
/*  714:     */       
/*  715:     */ 
/*  716: 816 */       sb.append("return ");
/*  717: 817 */       sb.append(this.daoTemplate.getUpdateMethod(this.sqlMapGenerator
/*  718: 818 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/*  719: 819 */         .getUpdateByPrimaryKeySelectiveStatementId(), "param"));
/*  720: 820 */       method.addBodyLine(sb.toString());
/*  721:     */     }
/*  722: 825 */     ArrayList answer = new ArrayList();
/*  723: 826 */     answer.add(method);
/*  724:     */     
/*  725: 828 */     return answer;
/*  726:     */   }
/*  727:     */   
/*  728:     */   protected List getSelectByExampleWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  729:     */   {
/*  730: 835 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  731: 836 */       return null;
/*  732:     */     }
/*  733: 839 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  734: 840 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/*  735: 841 */     compilationUnit.addImportedType(type);
/*  736: 842 */     compilationUnit.addImportedType(getSelectByExampleReturnListJavaType());
/*  737:     */     
/*  738: 844 */     Method method = new Method();
/*  739: 845 */     method.addComment(table);
/*  740: 846 */     method.setVisibility(this.exampleMethodVisibility);
/*  741:     */     FullyQualifiedJavaType returnType;
/*  742: 849 */     if (this.useJava5Features)
/*  743:     */     {
/*  744:     */       FullyQualifiedJavaType fqjt;
/*  745: 851 */       if (introspectedTable.getRules().generateBaseRecordClass())
/*  746:     */       {
/*  747: 852 */         fqjt = this.javaModelGenerator.getBaseRecordType(table);
/*  748:     */       }
/*  749:     */       else
/*  750:     */       {
/*  751:     */         FullyQualifiedJavaType fqjt;
/*  752: 853 */         if (introspectedTable.getRules().generatePrimaryKeyClass()) {
/*  753: 854 */           fqjt = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/*  754:     */         } else {
/*  755: 856 */           throw new RuntimeException(
/*  756: 857 */             Messages.getString("RuntimeError.12"));
/*  757:     */         }
/*  758:     */       }
/*  759:     */       FullyQualifiedJavaType fqjt;
/*  760: 860 */       compilationUnit.addImportedType(fqjt);
/*  761: 861 */       FullyQualifiedJavaType returnType = getSelectByExampleReturnListJavaType();
/*  762: 862 */       returnType.addTypeArgument(fqjt);
/*  763:     */     }
/*  764:     */     else
/*  765:     */     {
/*  766: 864 */       returnType = getSelectByExampleReturnListJavaType();
/*  767:     */     }
/*  768: 866 */     method.setReturnType(returnType);
/*  769:     */     
/*  770: 868 */     method.setName(this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable));
/*  771: 869 */     method.addParameter(new Parameter(type, "example"));
/*  772:     */     
/*  773: 871 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  774: 872 */     while (iter.hasNext())
/*  775:     */     {
/*  776: 873 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  777: 874 */       method.addException(fqjt);
/*  778: 875 */       compilationUnit.addImportedType(fqjt);
/*  779:     */     }
/*  780: 878 */     if (!interfaceMethod)
/*  781:     */     {
/*  782: 880 */       StringBuffer sb = new StringBuffer();
/*  783: 882 */       if (this.useJava5Features)
/*  784:     */       {
/*  785: 883 */         method.addSuppressTypeWarningsAnnotation();
/*  786: 884 */         sb.append(returnType.getShortName());
/*  787: 885 */         sb.append(" list = (");
/*  788: 886 */         sb.append(returnType.getShortName());
/*  789: 887 */         sb.append(") ");
/*  790:     */       }
/*  791:     */       else
/*  792:     */       {
/*  793: 889 */         sb.append(returnType.getShortName());
/*  794: 890 */         sb.append(" list = ");
/*  795:     */       }
/*  796: 893 */       sb.append(this.daoTemplate.getQueryForListMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/*  797: 894 */         this.sqlMapGenerator.getSelectByExampleStatementId(), "example"));
/*  798: 895 */       method.addBodyLine(sb.toString());
/*  799: 896 */       method.addBodyLine("return list;");
/*  800:     */     }
/*  801: 899 */     ArrayList answer = new ArrayList();
/*  802: 900 */     answer.add(method);
/*  803:     */     
/*  804: 902 */     return answer;
/*  805:     */   }
/*  806:     */   
/*  807:     */   protected List getSelectByExampleWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  808:     */   {
/*  809: 909 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  810: 910 */       return null;
/*  811:     */     }
/*  812: 913 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  813: 914 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/*  814: 915 */     compilationUnit.addImportedType(type);
/*  815: 916 */     compilationUnit.addImportedType(getSelectByExampleReturnListJavaType());
/*  816:     */     
/*  817: 918 */     Method method = new Method();
/*  818: 919 */     method.addComment(table);
/*  819: 920 */     method.setVisibility(this.exampleMethodVisibility);
/*  820:     */     FullyQualifiedJavaType returnType;
/*  821: 923 */     if (this.useJava5Features)
/*  822:     */     {
/*  823:     */       FullyQualifiedJavaType fqjt;
/*  824:     */       FullyQualifiedJavaType fqjt;
/*  825: 925 */       if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  826: 926 */         fqjt = this.javaModelGenerator.getRecordWithBLOBsType(table);
/*  827:     */       } else {
/*  828: 929 */         fqjt = this.javaModelGenerator.getBaseRecordType(table);
/*  829:     */       }
/*  830: 932 */       compilationUnit.addImportedType(fqjt);
/*  831: 933 */       FullyQualifiedJavaType returnType = getSelectByExampleReturnListJavaType();
/*  832: 934 */       returnType.addTypeArgument(fqjt);
/*  833:     */     }
/*  834:     */     else
/*  835:     */     {
/*  836: 936 */       returnType = getSelectByExampleReturnListJavaType();
/*  837:     */     }
/*  838: 938 */     method.setReturnType(returnType);
/*  839:     */     
/*  840: 940 */     method.setName(this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable));
/*  841: 941 */     method.addParameter(new Parameter(type, "example"));
/*  842:     */     
/*  843: 943 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  844: 944 */     while (iter.hasNext())
/*  845:     */     {
/*  846: 945 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  847: 946 */       method.addException(fqjt);
/*  848: 947 */       compilationUnit.addImportedType(fqjt);
/*  849:     */     }
/*  850: 950 */     if (!interfaceMethod)
/*  851:     */     {
/*  852: 953 */       StringBuffer sb = new StringBuffer();
/*  853: 955 */       if (this.useJava5Features)
/*  854:     */       {
/*  855: 956 */         method.addSuppressTypeWarningsAnnotation();
/*  856: 957 */         sb.append(returnType.getShortName());
/*  857: 958 */         sb.append(" list = (");
/*  858: 959 */         sb.append(returnType.getShortName());
/*  859: 960 */         sb.append(") ");
/*  860:     */       }
/*  861:     */       else
/*  862:     */       {
/*  863: 962 */         sb.append(returnType.getShortName());
/*  864: 963 */         sb.append(" list = ");
/*  865:     */       }
/*  866: 966 */       sb.append(this.daoTemplate.getQueryForListMethod(this.sqlMapGenerator
/*  867: 967 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/*  868: 968 */         .getSelectByExampleWithBLOBsStatementId(), "example"));
/*  869: 969 */       method.addBodyLine(sb.toString());
/*  870: 970 */       method.addBodyLine("return list;");
/*  871:     */     }
/*  872: 973 */     ArrayList answer = new ArrayList();
/*  873: 974 */     answer.add(method);
/*  874:     */     
/*  875: 976 */     return answer;
/*  876:     */   }
/*  877:     */   
/*  878:     */   protected List getSelectByPrimaryKeyMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  879:     */   {
/*  880: 983 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  881:     */     
/*  882: 985 */     Method method = new Method();
/*  883: 986 */     method.addComment(table);
/*  884: 987 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  885:     */     
/*  886: 989 */     FullyQualifiedJavaType returnType = 
/*  887: 990 */       introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/*  888: 991 */     method.setReturnType(returnType);
/*  889: 992 */     compilationUnit.addImportedType(returnType);
/*  890:     */     
/*  891: 994 */     method.setName(this.methodNameCalculator.getSelectByPrimaryKeyMethodName(introspectedTable));
/*  892: 996 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/*  893:     */     {
/*  894: 997 */       FullyQualifiedJavaType type = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/*  895: 998 */       compilationUnit.addImportedType(type);
/*  896: 999 */       method.addParameter(new Parameter(type, "key"));
/*  897:     */     }
/*  898:     */     else
/*  899:     */     {
/*  900:1001 */       Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  901:1002 */       while (iter.hasNext())
/*  902:     */       {
/*  903:1003 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  904:1004 */         FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*  905:1005 */         compilationUnit.addImportedType(type);
/*  906:1006 */         method.addParameter(new Parameter(type, cd.getJavaProperty()));
/*  907:     */       }
/*  908:     */     }
/*  909:1010 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  910:1011 */     while (iter.hasNext())
/*  911:     */     {
/*  912:1012 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  913:1013 */       method.addException(fqjt);
/*  914:1014 */       compilationUnit.addImportedType(fqjt);
/*  915:     */     }
/*  916:1017 */     if (!interfaceMethod)
/*  917:     */     {
/*  918:1019 */       StringBuffer sb = new StringBuffer();
/*  919:     */       
/*  920:1021 */       String param = "key";
/*  921:1023 */       if (!introspectedTable.getRules().generatePrimaryKeyClass()) {
/*  922:1024 */         if (introspectedTable.getRules().getPrimaryKeyColumnSize() == 1)
/*  923:     */         {
/*  924:1025 */           iter = introspectedTable.getPrimaryKeyColumns();
/*  925:1026 */           ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  926:1027 */           param = cd.getJavaProperty();
/*  927:     */         }
/*  928:     */         else
/*  929:     */         {
/*  930:1032 */           FullyQualifiedJavaType keyType = this.javaModelGenerator.getBaseRecordType(table);
/*  931:1033 */           compilationUnit.addImportedType(keyType);
/*  932:     */           
/*  933:1035 */           sb.setLength(0);
/*  934:1036 */           sb.append(keyType.getShortName());
/*  935:1037 */           sb.append(" key = new ");
/*  936:1038 */           sb.append(keyType.getShortName());
/*  937:1039 */           sb.append("();");
/*  938:1040 */           method.addBodyLine(sb.toString());
/*  939:     */           
/*  940:1042 */           iter = introspectedTable.getPrimaryKeyColumns();
/*  941:1043 */           while (iter.hasNext())
/*  942:     */           {
/*  943:1044 */             ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  944:1045 */             sb.setLength(0);
/*  945:1046 */             sb.append("key.");
/*  946:1047 */             sb.append(JavaBeansUtil.getSetterMethodName(cd.getJavaProperty()));
/*  947:1048 */             sb.append('(');
/*  948:1049 */             sb.append(cd.getJavaProperty());
/*  949:1050 */             sb.append(");");
/*  950:1051 */             method.addBodyLine(sb.toString());
/*  951:     */           }
/*  952:     */         }
/*  953:     */       }
/*  954:1056 */       sb.setLength(0);
/*  955:1057 */       sb.append("return (");
/*  956:1058 */       sb.append(returnType.getShortName());
/*  957:1059 */       sb.append(") ");
/*  958:1060 */       sb.append(this.daoTemplate.getQueryForObjectMethod(this.sqlMapGenerator
/*  959:1061 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/*  960:1062 */         .getSelectByPrimaryKeyStatementId(), param));
/*  961:1063 */       method.addBodyLine(sb.toString());
/*  962:     */     }
/*  963:1066 */     ArrayList answer = new ArrayList();
/*  964:1067 */     answer.add(method);
/*  965:     */     
/*  966:1069 */     return answer;
/*  967:     */   }
/*  968:     */   
/*  969:     */   protected List getSelectCountByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  970:     */   {
/*  971:1075 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  972:1076 */       return null;
/*  973:     */     }
/*  974:1079 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  975:1080 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/*  976:1081 */     compilationUnit.addImportedType(type);
/*  977:     */     
/*  978:1083 */     Method method = new Method();
/*  979:1084 */     method.addComment(table);
/*  980:1085 */     method.setVisibility(this.exampleMethodVisibility);
/*  981:1086 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  982:1087 */     method.setName(this.methodNameCalculator.getSelectCountByExampleMethodName(introspectedTable));
/*  983:1088 */     method.addParameter(new Parameter(type, "params"));
/*  984:     */     
/*  985:1090 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  986:1091 */     while (iter.hasNext())
/*  987:     */     {
/*  988:1092 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  989:1093 */       method.addException(fqjt);
/*  990:1094 */       compilationUnit.addImportedType(fqjt);
/*  991:     */     }
/*  992:1097 */     if (!interfaceMethod)
/*  993:     */     {
/*  994:1099 */       StringBuffer sb = new StringBuffer();
/*  995:     */       
/*  996:1101 */       sb.append("Integer count = (Integer) ");
/*  997:1102 */       sb.append(this.daoTemplate.getQueryForObjectMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/*  998:1103 */         this.sqlMapGenerator.getSelectByExampleStatementId() + "_count", "params"));
/*  999:1104 */       method.addBodyLine(sb.toString());
/* 1000:1105 */       method.addBodyLine("return count.intValue();");
/* 1001:     */     }
/* 1002:1108 */     ArrayList answer = new ArrayList();
/* 1003:1109 */     answer.add(method);
/* 1004:     */     
/* 1005:1111 */     return answer;
/* 1006:     */   }
/* 1007:     */   
/* 1008:     */   protected List getDeleteByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1009:     */   {
/* 1010:1119 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 1011:1120 */       return null;
/* 1012:     */     }
/* 1013:1123 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1014:1124 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 1015:1125 */     compilationUnit.addImportedType(type);
/* 1016:     */     
/* 1017:1127 */     Method method = new Method();
/* 1018:1128 */     method.addComment(table);
/* 1019:1129 */     method.setVisibility(this.exampleMethodVisibility);
/* 1020:1130 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 1021:1131 */     method.setName(this.methodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 1022:1132 */     method.addParameter(new Parameter(type, "example"));
/* 1023:     */     
/* 1024:1134 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/* 1025:1135 */     while (iter.hasNext())
/* 1026:     */     {
/* 1027:1136 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1028:1137 */       method.addException(fqjt);
/* 1029:1138 */       compilationUnit.addImportedType(fqjt);
/* 1030:     */     }
/* 1031:1141 */     if (!interfaceMethod)
/* 1032:     */     {
/* 1033:1143 */       StringBuffer sb = new StringBuffer();
/* 1034:     */       
/* 1035:1145 */       sb.append("int rows = ");
/* 1036:1146 */       sb.append(this.daoTemplate.getDeleteMethod(this.sqlMapGenerator
/* 1037:1147 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/* 1038:1148 */         .getDeleteByExampleStatementId(), "example"));
/* 1039:1149 */       method.addBodyLine(sb.toString());
/* 1040:1150 */       method.addBodyLine("return rows;");
/* 1041:     */     }
/* 1042:1153 */     ArrayList answer = new ArrayList();
/* 1043:1154 */     answer.add(method);
/* 1044:     */     
/* 1045:1156 */     return answer;
/* 1046:     */   }
/* 1047:     */   
/* 1048:     */   protected List getDeleteByPrimaryKeyMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1049:     */   {
/* 1050:1163 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1051:     */     
/* 1052:1165 */     Method method = new Method();
/* 1053:1166 */     method.addComment(table);
/* 1054:1167 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1055:1168 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 1056:1169 */     method.setName(this.methodNameCalculator.getDeleteByPrimaryKeyMethodName(introspectedTable));
/* 1057:1171 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/* 1058:     */     {
/* 1059:1172 */       FullyQualifiedJavaType type = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/* 1060:1173 */       compilationUnit.addImportedType(type);
/* 1061:1174 */       method.addParameter(new Parameter(type, "key"));
/* 1062:     */     }
/* 1063:     */     else
/* 1064:     */     {
/* 1065:1176 */       Iterator iter = introspectedTable.getPrimaryKeyColumns();
/* 1066:1177 */       while (iter.hasNext())
/* 1067:     */       {
/* 1068:1178 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1069:1179 */         FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/* 1070:1180 */         compilationUnit.addImportedType(type);
/* 1071:1181 */         method.addParameter(new Parameter(type, cd.getJavaProperty()));
/* 1072:     */       }
/* 1073:     */     }
/* 1074:1185 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/* 1075:1186 */     while (iter.hasNext())
/* 1076:     */     {
/* 1077:1187 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1078:1188 */       method.addException(fqjt);
/* 1079:1189 */       compilationUnit.addImportedType(fqjt);
/* 1080:     */     }
/* 1081:1192 */     if (!interfaceMethod)
/* 1082:     */     {
/* 1083:1194 */       StringBuffer sb = new StringBuffer();
/* 1084:     */       
/* 1085:1196 */       String param = "key";
/* 1086:1198 */       if (!introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 1087:1199 */         if (introspectedTable.getRules().getPrimaryKeyColumnSize() == 1)
/* 1088:     */         {
/* 1089:1200 */           iter = introspectedTable.getPrimaryKeyColumns();
/* 1090:1201 */           ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1091:1202 */           param = cd.getJavaProperty();
/* 1092:     */         }
/* 1093:     */         else
/* 1094:     */         {
/* 1095:1207 */           FullyQualifiedJavaType keyType = this.javaModelGenerator.getBaseRecordType(table);
/* 1096:1208 */           compilationUnit.addImportedType(keyType);
/* 1097:     */           
/* 1098:1210 */           sb.setLength(0);
/* 1099:1211 */           sb.append(keyType.getShortName());
/* 1100:1212 */           sb.append(" key = new ");
/* 1101:1213 */           sb.append(keyType.getShortName());
/* 1102:1214 */           sb.append("();");
/* 1103:1215 */           method.addBodyLine(sb.toString());
/* 1104:     */           
/* 1105:1217 */           iter = introspectedTable.getPrimaryKeyColumns();
/* 1106:1218 */           while (iter.hasNext())
/* 1107:     */           {
/* 1108:1219 */             ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1109:1220 */             sb.setLength(0);
/* 1110:1221 */             sb.append("key.");
/* 1111:1222 */             sb.append(JavaBeansUtil.getSetterMethodName(cd.getJavaProperty()));
/* 1112:1223 */             sb.append('(');
/* 1113:1224 */             sb.append(cd.getJavaProperty());
/* 1114:1225 */             sb.append(");");
/* 1115:1226 */             method.addBodyLine(sb.toString());
/* 1116:     */           }
/* 1117:     */         }
/* 1118:     */       }
/* 1119:1231 */       sb.setLength(0);
/* 1120:     */       
/* 1121:1233 */       sb.append("return ");
/* 1122:1234 */       sb.append(this.daoTemplate.getDeleteMethod(this.sqlMapGenerator
/* 1123:1235 */         .getSqlMapNamespace(table), this.sqlMapGenerator
/* 1124:1236 */         .getDeleteByPrimaryKeyStatementId(), param));
/* 1125:1237 */       method.addBodyLine(sb.toString());
/* 1126:     */     }
/* 1127:1241 */     ArrayList answer = new ArrayList();
/* 1128:1242 */     answer.add(method);
/* 1129:     */     
/* 1130:1244 */     return answer;
/* 1131:     */   }
/* 1132:     */   
/* 1133:     */   protected String getDAOPackage(FullyQualifiedTable table)
/* 1134:     */   {
/* 1135:1248 */     String key = "getDAOPackage";
/* 1136:     */     
/* 1137:     */ 
/* 1138:1251 */     Map map = getTableValueMap(table);
/* 1139:1252 */     String s = (String)map.get(key);
/* 1140:1253 */     if (s == null)
/* 1141:     */     {
/* 1142:1254 */       StringBuffer sb = new StringBuffer(this.targetPackage);
/* 1143:1255 */       if ("true".equals(this.properties.get("enableSubPackages")))
/* 1144:     */       {
/* 1145:1256 */         if (StringUtility.stringHasValue(table.getCatalog()))
/* 1146:     */         {
/* 1147:1257 */           sb.append('.');
/* 1148:1258 */           sb.append(table.getCatalog().toLowerCase());
/* 1149:     */         }
/* 1150:1261 */         if (StringUtility.stringHasValue(table.getSchema()))
/* 1151:     */         {
/* 1152:1262 */           sb.append('.');
/* 1153:1263 */           sb.append(table.getSchema().toLowerCase());
/* 1154:     */         }
/* 1155:     */       }
/* 1156:1267 */       s = sb.toString();
/* 1157:1268 */       map.put(key, s);
/* 1158:     */     }
/* 1159:1271 */     return s;
/* 1160:     */   }
/* 1161:     */   
/* 1162:     */   public FullyQualifiedJavaType getDAOInterfaceType(FullyQualifiedTable table)
/* 1163:     */   {
/* 1164:1275 */     String key = "getDAOInterfaceType";
/* 1165:     */     
/* 1166:1277 */     Map map = getTableValueMap(table);
/* 1167:1278 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/* 1168:1279 */     if (fqjt == null)
/* 1169:     */     {
/* 1170:1280 */       StringBuffer sb = new StringBuffer();
/* 1171:1281 */       sb.append(getDAOPackage(table));
/* 1172:1282 */       sb.append('.');
/* 1173:1283 */       sb.append(table.getDomainObjectName());
/* 1174:1284 */       sb.append("Dao");
/* 1175:     */       
/* 1176:1286 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/* 1177:1287 */       map.put(key, fqjt);
/* 1178:     */     }
/* 1179:1290 */     return fqjt;
/* 1180:     */   }
/* 1181:     */   
/* 1182:     */   private Map getTableValueMap(FullyQualifiedTable table)
/* 1183:     */   {
/* 1184:1294 */     Map map = (Map)this.tableValueMaps.get(table);
/* 1185:1295 */     if (map == null)
/* 1186:     */     {
/* 1187:1296 */       map = new HashMap();
/* 1188:1297 */       this.tableValueMaps.put(table, map);
/* 1189:     */     }
/* 1190:1300 */     return map;
/* 1191:     */   }
/* 1192:     */   
/* 1193:     */   public void addContextProperties(Map properties)
/* 1194:     */   {
/* 1195:1304 */     this.properties.putAll(properties);
/* 1196:     */   }
/* 1197:     */   
/* 1198:     */   public DAOMethodNameCalculator getMethodNameCalculator()
/* 1199:     */   {
/* 1200:1311 */     return this.methodNameCalculator;
/* 1201:     */   }
/* 1202:     */   
/* 1203:     */   public FullyQualifiedJavaType getBaseDAOInterfaceType(FullyQualifiedTable table)
/* 1204:     */   {
/* 1205:1316 */     return null;
/* 1206:     */   }
/* 1207:     */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.BaseDAOGenerator
 * JD-Core Version:    0.7.0.1
 */