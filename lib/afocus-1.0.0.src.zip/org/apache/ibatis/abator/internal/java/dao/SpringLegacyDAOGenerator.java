/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ public class SpringLegacyDAOGenerator
/*  4:   */   extends BaseLegacyDAOGenerator
/*  5:   */ {
/*  6:   */   public SpringLegacyDAOGenerator()
/*  7:   */   {
/*  8:30 */     super(new SpringDAOTemplate());
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringLegacyDAOGenerator
 * JD-Core Version:    0.7.0.1
 */