/*   1:    */ package org.apache.ibatis.abator.internal.java.jsp;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileInputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStreamReader;
/*   7:    */ import java.text.MessageFormat;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import org.apache.ibatis.abator.api.ControllerGenerator;
/*  15:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  16:    */ import org.apache.ibatis.abator.api.GeneratedJspFile;
/*  17:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  18:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  19:    */ import org.apache.ibatis.abator.api.JspGenerator;
/*  20:    */ import org.apache.ibatis.abator.api.ProgressCallback;
/*  21:    */ import org.apache.ibatis.abator.api.ShellCallback;
/*  22:    */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*  23:    */ import org.apache.ibatis.abator.internal.DefaultShellCallback;
/*  24:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  25:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*  26:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  27:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  28:    */ 
/*  29:    */ public class BaseJspGenerator
/*  30:    */   implements JspGenerator
/*  31:    */ {
/*  32:    */   protected AbstractJspTemplate listTemplate;
/*  33:    */   protected AbstractJspTemplate treeTemplate;
/*  34:    */   protected AbstractJspTemplate editTemplate;
/*  35:    */   protected AbstractJspTemplate showTemplate;
/*  36:    */   protected AbstractJspTemplate jsonTemplate;
/*  37:    */   protected Map properties;
/*  38:    */   protected List warnings;
/*  39:    */   protected String targetPackage;
/*  40:    */   protected String targetProject;
/*  41:    */   protected JavaModelGenerator javaModelGenerator;
/*  42:    */   protected ControllerGenerator controllerGenerator;
/*  43:    */   private Map tableValueMaps;
/*  44:    */   private boolean useJava5Features;
/*  45:109 */   private boolean permission = false;
/*  46:111 */   protected String projectLabel = "";
/*  47:    */   protected String moduleUrlPrefix;
/*  48:    */   protected String listRowImageButtonPath;
/*  49:117 */   private ShellCallback shellCallback = new DefaultShellCallback(false);
/*  50:    */   
/*  51:    */   public BaseJspGenerator()
/*  52:    */   {
/*  53:123 */     this(false);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public BaseJspGenerator(boolean useJava5Features)
/*  57:    */   {
/*  58:128 */     this.useJava5Features = useJava5Features;
/*  59:129 */     this.tableValueMaps = new HashMap();
/*  60:130 */     this.properties = new HashMap();
/*  61:    */   }
/*  62:    */   
/*  63:    */   private String readTextFile(File srcFile, String encoding)
/*  64:    */     throws IOException
/*  65:    */   {
/*  66:134 */     InputStreamReader from = null;
/*  67:    */     try
/*  68:    */     {
/*  69:136 */       char[] buffer = new char[4096];
/*  70:137 */       int read = 0;
/*  71:138 */       if (StringUtility.stringHasValue(encoding)) {
/*  72:139 */         from = new InputStreamReader(new FileInputStream(srcFile), encoding);
/*  73:    */       } else {
/*  74:141 */         from = new InputStreamReader(new FileInputStream(srcFile));
/*  75:    */       }
/*  76:142 */       StringBuffer result = new StringBuffer();
/*  77:143 */       while ((read = from.read(buffer, 0, buffer.length)) != -1) {
/*  78:144 */         result.append(buffer, 0, read);
/*  79:    */       }
/*  80:146 */       return result.toString();
/*  81:    */     }
/*  82:    */     catch (IOException e)
/*  83:    */     {
/*  84:149 */       throw e;
/*  85:    */     }
/*  86:    */     finally
/*  87:    */     {
/*  88:153 */       if (from != null) {
/*  89:154 */         from.close();
/*  90:    */       }
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   private AbstractJspTemplate getTemplate(String fileName, String type)
/*  95:    */   {
/*  96:    */     try
/*  97:    */     {
/*  98:160 */       if (StringUtility.stringHasValue(fileName))
/*  99:    */       {
/* 100:161 */         File dir = new File(this.targetProject);
/* 101:162 */         if (this.shellCallback != null)
/* 102:    */         {
/* 103:163 */           File temp = this.shellCallback.getDirectory(this.targetProject, "", this.warnings);
/* 104:164 */           if (temp.exists()) {
/* 105:165 */             dir = temp;
/* 106:    */           }
/* 107:    */         }
/* 108:173 */         File file = new File(dir, fileName);
/* 109:174 */         if (!file.exists()) {
/* 110:175 */           file = new File(fileName);
/* 111:    */         }
/* 112:178 */         return new AbstractJspTemplate(readTextFile(file, null), type);
/* 113:    */       }
/* 114:    */     }
/* 115:    */     catch (Exception e)
/* 116:    */     {
/* 117:182 */       this.warnings.add(Arrays.deepToString(e.getStackTrace()));
/* 118:183 */       e.printStackTrace();
/* 119:184 */       throw new RuntimeException(e);
/* 120:    */     }
/* 121:186 */     return null;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void addConfigurationProperties(Map properties)
/* 125:    */   {
/* 126:190 */     this.properties.putAll(properties);
/* 127:192 */     if (properties.containsKey("listRowImageButtonPath"))
/* 128:    */     {
/* 129:193 */       this.listRowImageButtonPath = ((String)properties.get("listRowImageButtonPath"));
/* 130:194 */       if ((StringUtility.stringHasValue(this.listRowImageButtonPath)) && (!this.listRowImageButtonPath.endsWith("/"))) {
/* 131:195 */         this.listRowImageButtonPath += "/";
/* 132:    */       }
/* 133:    */     }
/* 134:199 */     String temp = "abator/list.jsp";
/* 135:200 */     if (properties.containsKey("listTemplateFile")) {
/* 136:201 */       temp = (String)properties.get("listTemplateFile");
/* 137:    */     }
/* 138:203 */     this.listTemplate = getTemplate(temp, "list");
/* 139:204 */     if (this.listTemplate != null)
/* 140:    */     {
/* 141:205 */       if (properties.containsKey("listTitleTemplate")) {
/* 142:206 */         this.listTemplate.setListTitleTemplate((String)properties.get("listTitleTemplate"));
/* 143:    */       }
/* 144:208 */       if (properties.containsKey("listRowTemplate")) {
/* 145:209 */         this.listTemplate.setListRowTemplate((String)properties.get("listRowTemplate"));
/* 146:    */       }
/* 147:211 */       if (properties.containsKey("listFieldTemplate")) {
/* 148:212 */         this.listTemplate.setListFieldTemplate((String)properties.get("listFieldTemplate"));
/* 149:    */       }
/* 150:214 */       if (properties.containsKey("listRowImageButtonPath")) {
/* 151:215 */         this.listTemplate.setListRowImageButtonPath((String)properties.get("listRowImageButtonPath"));
/* 152:    */       }
/* 153:217 */       if (properties.containsKey("queryFieldTemplate")) {
/* 154:218 */         this.listTemplate.setQueryFieldTemplate((String)properties.get("queryFieldTemplate"));
/* 155:    */       }
/* 156:    */     }
/* 157:222 */     temp = "abator/tree.jsp";
/* 158:223 */     if (properties.containsKey("treeTemplateFile")) {
/* 159:224 */       temp = (String)properties.get("treeTemplateFile");
/* 160:    */     }
/* 161:226 */     this.treeTemplate = getTemplate(temp, "tree");
/* 162:227 */     if (this.treeTemplate != null)
/* 163:    */     {
/* 164:228 */       if (properties.containsKey("listTitleTemplate")) {
/* 165:229 */         this.treeTemplate.setListTitleTemplate((String)properties.get("listTitleTemplate"));
/* 166:    */       }
/* 167:231 */       if (properties.containsKey("listRowImageButtonPath")) {
/* 168:232 */         this.treeTemplate.setListRowImageButtonPath((String)properties.get("listRowImageButtonPath"));
/* 169:    */       }
/* 170:234 */       if (properties.containsKey("queryFieldTemplate")) {
/* 171:235 */         this.treeTemplate.setQueryFieldTemplate((String)properties.get("queryFieldTemplate"));
/* 172:    */       }
/* 173:    */     }
/* 174:239 */     temp = "abator/json.jsp";
/* 175:240 */     if (properties.containsKey("jsonTemplateFile")) {
/* 176:241 */       temp = (String)properties.get("jsonTemplateFile");
/* 177:    */     }
/* 178:243 */     this.jsonTemplate = getTemplate(temp, "json");
/* 179:    */     
/* 180:245 */     temp = "abator/form.jsp";
/* 181:246 */     if (properties.containsKey("editTemplateFile")) {
/* 182:247 */       temp = (String)properties.get("editTemplateFile");
/* 183:    */     }
/* 184:249 */     this.editTemplate = getTemplate(temp, "form");
/* 185:250 */     if ((this.editTemplate != null) && 
/* 186:251 */       (properties.containsKey("editFieldTemplate"))) {
/* 187:252 */       this.editTemplate.setEditFieldTemplate((String)properties.get("editFieldTemplate"));
/* 188:    */     }
/* 189:256 */     temp = "abator/show.jsp";
/* 190:257 */     if (properties.containsKey("showTemplateFile")) {
/* 191:258 */       temp = (String)properties.get("showTemplateFile");
/* 192:    */     }
/* 193:260 */     this.showTemplate = getTemplate(temp, "show");
/* 194:261 */     if ((this.showTemplate != null) && 
/* 195:262 */       (properties.containsKey("showFieldTemplate"))) {
/* 196:263 */       this.showTemplate.setShowFieldTemplate((String)properties.get("showFieldTemplate"));
/* 197:    */     }
/* 198:267 */     if (properties.containsKey("permission"))
/* 199:    */     {
/* 200:268 */       temp = (String)properties.get("permission");
/* 201:269 */       this.permission = "true".equalsIgnoreCase(temp);
/* 202:    */     }
/* 203:272 */     if (properties.containsKey("projectLabel")) {
/* 204:273 */       this.projectLabel = ((String)properties.get("projectLabel"));
/* 205:    */     }
/* 206:    */   }
/* 207:    */   
/* 208:    */   public void setWarnings(List warnings)
/* 209:    */   {
/* 210:284 */     this.warnings = warnings;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public void setTargetPackage(String targetPackage)
/* 214:    */   {
/* 215:293 */     this.targetPackage = targetPackage;
/* 216:294 */     if (this.moduleUrlPrefix == null) {
/* 217:295 */       this.moduleUrlPrefix = targetPackage;
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void setTargetProject(String targetProject)
/* 222:    */   {
/* 223:305 */     this.targetProject = targetProject;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public void setJavaModelGenerator(JavaModelGenerator javaModelGenerator)
/* 227:    */   {
/* 228:314 */     this.javaModelGenerator = javaModelGenerator;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void setControllerGenerator(ControllerGenerator controllerGenerator)
/* 232:    */   {
/* 233:324 */     this.controllerGenerator = controllerGenerator;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public List getGeneratedJspFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/* 237:    */   {
/* 238:334 */     List list = new ArrayList();
/* 239:335 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 240:    */     
/* 241:337 */     callback.startSubTask(Messages.getString("Progress.13", 
/* 242:338 */       table.getFullyQualifiedTableName()));
/* 243:    */     
/* 244:340 */     String packageName = getJspPackage(table);
/* 245:    */     
/* 246:342 */     this.listTemplate.resetTempate();
/* 247:343 */     this.treeTemplate.resetTempate();
/* 248:344 */     this.jsonTemplate.resetTempate();
/* 249:345 */     this.showTemplate.resetTempate();
/* 250:346 */     this.editTemplate.resetTempate();
/* 251:    */     
/* 252:348 */     String[] pks = getPKParams(introspectedTable);
/* 253:    */     
/* 254:350 */     setCommonParams(introspectedTable);
/* 255:351 */     setPKParams(pks);
/* 256:352 */     setJsonRows(introspectedTable);
/* 257:353 */     setShowRows(introspectedTable);
/* 258:354 */     setEditRows(introspectedTable);
/* 259:    */     
/* 260:356 */     setListAndTreeParams(introspectedTable, pks);
/* 261:    */     
/* 262:358 */     GeneratedJspFile gjf = new GeneratedJspFile(this.listTemplate.getGeneratedContent(), this.listTemplate.getFileName(), packageName, this.targetProject);
/* 263:359 */     list.add(gjf);
/* 264:361 */     if (introspectedTable.hasParentIdColumn())
/* 265:    */     {
/* 266:362 */       gjf = new GeneratedJspFile(this.treeTemplate.getGeneratedContent(), this.treeTemplate.getFileName(), packageName, this.targetProject);
/* 267:363 */       list.add(gjf);
/* 268:    */     }
/* 269:366 */     gjf = new GeneratedJspFile(this.jsonTemplate.getGeneratedContent(), this.jsonTemplate.getFileName(), packageName, this.targetProject);
/* 270:367 */     list.add(gjf);
/* 271:    */     
/* 272:369 */     gjf = new GeneratedJspFile(this.showTemplate.getGeneratedContent(), this.showTemplate.getFileName(), packageName, this.targetProject);
/* 273:370 */     list.add(gjf);
/* 274:    */     
/* 275:372 */     gjf = new GeneratedJspFile(this.editTemplate.getGeneratedContent(), this.editTemplate.getFileName(), packageName, this.targetProject);
/* 276:373 */     list.add(gjf);
/* 277:    */     
/* 278:375 */     return list;
/* 279:    */   }
/* 280:    */   
/* 281:    */   public String getRecordPropertyName(FullyQualifiedTable table)
/* 282:    */   {
/* 283:380 */     String key = "getRecordPropertyName";
/* 284:    */     
/* 285:382 */     Map map = getTableValueMap(table);
/* 286:383 */     String property = (String)map.get(key);
/* 287:384 */     if (property == null)
/* 288:    */     {
/* 289:385 */       property = JavaBeansUtil.getValidPropertyName(table.getDomainObjectName());
/* 290:386 */       map.put(key, property);
/* 291:    */     }
/* 292:389 */     return property;
/* 293:    */   }
/* 294:    */   
/* 295:    */   private void setListTitles(AbstractJspTemplate jspTemplate, IntrospectedTable introspectedTable)
/* 296:    */   {
/* 297:393 */     StringBuilder sb = new StringBuilder();
/* 298:394 */     OutputUtilities.newLine(sb);
/* 299:395 */     String template = jspTemplate.getListTitleTemplate();
/* 300:396 */     Iterator listColumns = introspectedTable.getListColumns();
/* 301:398 */     while (listColumns.hasNext())
/* 302:    */     {
/* 303:399 */       ColumnDefinition cd = (ColumnDefinition)listColumns.next();
/* 304:400 */       OutputUtilities.xmlIndent(sb, 2);
/* 305:401 */       sb.append(MessageFormat.format(template, new String[] { cd.getLabel() }));
/* 306:402 */       OutputUtilities.newLine(sb);
/* 307:    */     }
/* 308:405 */     OutputUtilities.xmlIndent(sb, 2);
/* 309:406 */     sb.append(MessageFormat.format(template, new String[] { "����" }));
/* 310:407 */     OutputUtilities.newLine(sb);
/* 311:408 */     jspTemplate.setListTitles(sb.toString());
/* 312:    */   }
/* 313:    */   
/* 314:    */   private void setTreeTitles(IntrospectedTable introspectedTable)
/* 315:    */   {
/* 316:412 */     String width = "'" + 100 / (introspectedTable.getListColumnSize() + 1) + "%'";
/* 317:413 */     StringBuilder tree = new StringBuilder();
/* 318:414 */     StringBuilder tree2 = new StringBuilder();
/* 319:    */     
/* 320:416 */     Iterator listColumns = introspectedTable.getListColumns();
/* 321:417 */     while (listColumns.hasNext())
/* 322:    */     {
/* 323:418 */       ColumnDefinition cd = (ColumnDefinition)listColumns.next();
/* 324:419 */       tree.append("'").append(cd.getLabel()).append("',");
/* 325:420 */       tree2.append(width).append(",");
/* 326:    */     }
/* 327:422 */     tree.append("'����'");
/* 328:423 */     tree2.append(width);
/* 329:    */     
/* 330:425 */     this.treeTemplate.setTreeTitleArray(tree.toString());
/* 331:426 */     this.treeTemplate.setTreeTitleWidthArray(tree2.toString());
/* 332:    */   }
/* 333:    */   
/* 334:    */   protected void setListAndTreeParams(IntrospectedTable introspectedTable, String[] pks)
/* 335:    */   {
/* 336:430 */     String createParam = makeCreateParam(introspectedTable);
/* 337:431 */     String batchActionButtons = makeBatchActionButton(introspectedTable);
/* 338:433 */     if (introspectedTable.hasParentIdColumn())
/* 339:    */     {
/* 340:434 */       setCommonParams(this.treeTemplate, introspectedTable);
/* 341:435 */       setPKParams(this.treeTemplate, pks);
/* 342:436 */       setQueryFields(this.treeTemplate, introspectedTable);
/* 343:437 */       setListTitles(this.treeTemplate, introspectedTable);
/* 344:438 */       this.treeTemplate.setCreateParam(createParam);
/* 345:439 */       this.listTemplate.setListSwitchTreeView("<a href=\"javascript:switchTreeView()\">�л�����״�б�</a>");
/* 346:440 */       setTreeTitles(introspectedTable);
/* 347:441 */       setTreeRows(introspectedTable, pks);
/* 348:442 */       this.treeTemplate.setListBatchActionButtons(batchActionButtons);
/* 349:    */     }
/* 350:445 */     setCommonParams(this.listTemplate, introspectedTable);
/* 351:446 */     setPKParams(this.listTemplate, pks);
/* 352:447 */     setQueryFields(this.listTemplate, introspectedTable);
/* 353:448 */     setListTitles(this.listTemplate, introspectedTable);
/* 354:449 */     this.listTemplate.setCreateParam(createParam);
/* 355:450 */     this.listTemplate.setListSwitchTreeView("");
/* 356:451 */     setListRows(introspectedTable, pks);
/* 357:452 */     this.listTemplate.setListBatchActionButtons(batchActionButtons);
/* 358:    */   }
/* 359:    */   
/* 360:    */   private StringBuilder appendNoPermissionTagParts(FullyQualifiedTable table, StringBuilder sb, String operateCode)
/* 361:    */   {
/* 362:456 */     if (!this.permission) {
/* 363:456 */       return sb;
/* 364:    */     }
/* 365:458 */     sb.append("<user:noPermission operate=\"").append(operateCode).append("\" resource=\"").append(this.controllerGenerator.getUrlPrefix(table)).append("\"> disabled=\"disabled\" </user:noPermission>");
/* 366:459 */     return sb;
/* 367:    */   }
/* 368:    */   
/* 369:    */   private StringBuilder appendHasPermissionTagParts(FullyQualifiedTable table, StringBuilder sb, String operateCode)
/* 370:    */   {
/* 371:463 */     if (!this.permission) {
/* 372:463 */       return sb;
/* 373:    */     }
/* 374:465 */     sb.append("<user:hasPermission operate=\"").append(operateCode).append("\" resource=\"").append(this.controllerGenerator.getUrlPrefix(table)).append("\">");
/* 375:466 */     return sb;
/* 376:    */   }
/* 377:    */   
/* 378:    */   private StringBuilder getButton(StringBuilder sb, String filename, String title)
/* 379:    */   {
/* 380:470 */     if (!StringUtility.stringHasValue(this.listRowImageButtonPath)) {
/* 381:471 */       return sb.append(" <input type=\"button\" value=\"").append(title).append("\" ");
/* 382:    */     }
/* 383:472 */     return 
/* 384:473 */       sb.append(" <img src=\"").append(this.listRowImageButtonPath).append(filename).append("\" class=\"imgbtn\" alt=\"").append(title).append("\" title=\"").append(title).append("\" ");
/* 385:    */   }
/* 386:    */   
/* 387:    */   private String makeRowActionImageButton(IntrospectedTable introspectedTable, String pkPropertyValue, boolean js)
/* 388:    */   {
/* 389:477 */     StringBuilder sb = new StringBuilder();
/* 390:478 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 391:479 */     int indent = 6;
/* 392:480 */     OutputUtilities.xmlIndent(sb, indent);
/* 393:481 */     if (js) {
/* 394:482 */       sb.append("'");
/* 395:    */     }
/* 396:483 */     appendHasPermissionTagParts(table, sb, "SEARCH");
/* 397:484 */     getButton(sb, "show.gif", "�鿴").append("onclick=\"show(").append(pkPropertyValue)
/* 398:485 */       .append(")\" /></user:hasPermission>");
/* 399:486 */     if (js) {
/* 400:487 */       sb.append("'");
/* 401:    */     }
/* 402:489 */     if (introspectedTable.hasParentIdColumn())
/* 403:    */     {
/* 404:490 */       OutputUtilities.newLine(sb);
/* 405:491 */       OutputUtilities.xmlIndent(sb, indent);
/* 406:492 */       if (js) {
/* 407:493 */         sb.append("+'");
/* 408:    */       }
/* 409:494 */       appendHasPermissionTagParts(table, sb, "SEARCH");
/* 410:495 */       getButton(sb, "showchild.gif", "��" + table.getLabel()).append("onclick=\"showChild(").append(pkPropertyValue)
/* 411:496 */         .append(")\" /></user:hasPermission>");
/* 412:497 */       if (js) {
/* 413:498 */         sb.append("'");
/* 414:    */       }
/* 415:499 */       OutputUtilities.newLine(sb);
/* 416:500 */       OutputUtilities.xmlIndent(sb, indent);
/* 417:501 */       if (js) {
/* 418:502 */         sb.append("+'");
/* 419:    */       }
/* 420:503 */       appendHasPermissionTagParts(table, sb, "SEARCH");
/* 421:504 */       getButton(sb, "showtree.gif", "��״��ʾ").append("onclick=\"showTree(").append(pkPropertyValue)
/* 422:505 */         .append(")\" /></user:hasPermission>");
/* 423:506 */       if (js) {
/* 424:507 */         sb.append("'");
/* 425:    */       }
/* 426:    */     }
/* 427:509 */     OutputUtilities.newLine(sb);
/* 428:510 */     OutputUtilities.xmlIndent(sb, indent);
/* 429:511 */     if (js) {
/* 430:512 */       sb.append("+'");
/* 431:    */     }
/* 432:513 */     appendHasPermissionTagParts(table, sb, "UPDATE");
/* 433:514 */     getButton(sb, "edit.gif", "�޸�").append("onclick=\"edit(").append(pkPropertyValue)
/* 434:515 */       .append(")\" /></user:hasPermission>");
/* 435:516 */     if (js) {
/* 436:517 */       sb.append("'");
/* 437:    */     }
/* 438:518 */     if (introspectedTable.hasStatusColumn())
/* 439:    */     {
/* 440:519 */       OutputUtilities.newLine(sb);
/* 441:520 */       OutputUtilities.xmlIndent(sb, indent);
/* 442:521 */       if (js) {
/* 443:522 */         sb.append("+'");
/* 444:    */       }
/* 445:523 */       appendHasPermissionTagParts(table, sb, "AUDIT");
/* 446:524 */       getButton(sb, "audit.gif", "���ͨ��").append("onclick=\"updateStatus(1,").append(pkPropertyValue)
/* 447:525 */         .append(")\" /></user:hasPermission>");
/* 448:526 */       if (js) {
/* 449:527 */         sb.append("'");
/* 450:    */       }
/* 451:528 */       OutputUtilities.newLine(sb);
/* 452:529 */       OutputUtilities.xmlIndent(sb, indent);
/* 453:530 */       if (js) {
/* 454:531 */         sb.append("+'");
/* 455:    */       }
/* 456:532 */       appendHasPermissionTagParts(table, sb, "AUDIT");
/* 457:533 */       getButton(sb, "notpass.gif", "��ͨ��").append("onclick=\"updateStatus(2,").append(pkPropertyValue)
/* 458:534 */         .append(")\" /></user:hasPermission>");
/* 459:535 */       if (js) {
/* 460:536 */         sb.append("'");
/* 461:    */       }
/* 462:537 */       OutputUtilities.newLine(sb);
/* 463:538 */       OutputUtilities.xmlIndent(sb, indent);
/* 464:539 */       if (js) {
/* 465:540 */         sb.append("+'");
/* 466:    */       }
/* 467:541 */       appendHasPermissionTagParts(table, sb, "DELETE");
/* 468:542 */       getButton(sb, "delete1.gif", "�߼�ɾ��").append("onclick=\"updateStatus(3,").append(pkPropertyValue)
/* 469:543 */         .append(")\" /></user:hasPermission>");
/* 470:544 */       if (js) {
/* 471:545 */         sb.append("'");
/* 472:    */       }
/* 473:    */     }
/* 474:547 */     OutputUtilities.newLine(sb);
/* 475:548 */     OutputUtilities.xmlIndent(sb, indent);
/* 476:549 */     if (js) {
/* 477:550 */       sb.append("+'");
/* 478:    */     }
/* 479:551 */     appendHasPermissionTagParts(table, sb, "DELETE");
/* 480:552 */     getButton(sb, "delete2.gif", "����ɾ��").append("onclick=\"del(").append(pkPropertyValue)
/* 481:553 */       .append(")\" /></user:hasPermission>");
/* 482:554 */     if (js) {
/* 483:555 */       sb.append("'");
/* 484:    */     }
/* 485:557 */     return sb.toString();
/* 486:    */   }
/* 487:    */   
/* 488:    */   private String makeRowActionInputButton(IntrospectedTable introspectedTable, String pkPropertyValue, boolean js)
/* 489:    */   {
/* 490:561 */     StringBuilder sb = new StringBuilder();
/* 491:562 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 492:563 */     int indent = 6;
/* 493:564 */     OutputUtilities.xmlIndent(sb, indent);
/* 494:565 */     if (js) {
/* 495:566 */       sb.append("'");
/* 496:    */     }
/* 497:567 */     sb.append("<input type=\"button\" value=\"�鿴\" onclick=\"show(").append(pkPropertyValue).append(")\" ");
/* 498:568 */     appendNoPermissionTagParts(table, sb, "SEARCH").append(" />");
/* 499:569 */     if (js) {
/* 500:570 */       sb.append("'");
/* 501:    */     }
/* 502:572 */     if (introspectedTable.hasParentIdColumn())
/* 503:    */     {
/* 504:573 */       OutputUtilities.newLine(sb);
/* 505:574 */       OutputUtilities.xmlIndent(sb, indent);
/* 506:575 */       if (js) {
/* 507:576 */         sb.append("+' ");
/* 508:    */       }
/* 509:577 */       sb.append("<input type=\"button\" value=\"��").append(table.getLabel()).append("\" onclick=\"showChild(").append(pkPropertyValue).append(")\" ");
/* 510:578 */       appendNoPermissionTagParts(table, sb, "SEARCH").append(" />");
/* 511:579 */       if (js) {
/* 512:580 */         sb.append("'");
/* 513:    */       }
/* 514:581 */       OutputUtilities.newLine(sb);
/* 515:582 */       OutputUtilities.xmlIndent(sb, indent);
/* 516:583 */       if (js) {
/* 517:584 */         sb.append("+' ");
/* 518:    */       }
/* 519:585 */       sb.append("<input type=\"button\" value=\"��״��ʾ\" onclick=\"showTree(").append(pkPropertyValue).append(")\" ");
/* 520:586 */       appendNoPermissionTagParts(table, sb, "SEARCH").append(" />");
/* 521:587 */       if (js) {
/* 522:588 */         sb.append("'");
/* 523:    */       }
/* 524:    */     }
/* 525:590 */     OutputUtilities.newLine(sb);
/* 526:591 */     OutputUtilities.xmlIndent(sb, indent);
/* 527:592 */     if (js) {
/* 528:593 */       sb.append("+' ");
/* 529:    */     }
/* 530:594 */     sb.append("<input type=\"button\" value=\"�޸�\" onclick=\"edit(").append(pkPropertyValue).append(")\" ");
/* 531:595 */     appendNoPermissionTagParts(table, sb, "UPDATE").append(" />");
/* 532:596 */     if (js) {
/* 533:597 */       sb.append("'");
/* 534:    */     }
/* 535:598 */     if (introspectedTable.hasStatusColumn())
/* 536:    */     {
/* 537:599 */       OutputUtilities.newLine(sb);
/* 538:600 */       OutputUtilities.xmlIndent(sb, indent);
/* 539:601 */       if (js) {
/* 540:602 */         sb.append("+' ");
/* 541:    */       }
/* 542:603 */       sb.append("<input type=\"button\" value=\"���ͨ��\" onclick=\"updateStatus(1,").append(pkPropertyValue).append(")\" ");
/* 543:604 */       appendNoPermissionTagParts(table, sb, "AUDIT").append(" />");
/* 544:605 */       if (js) {
/* 545:606 */         sb.append("'");
/* 546:    */       }
/* 547:607 */       OutputUtilities.newLine(sb);
/* 548:608 */       OutputUtilities.xmlIndent(sb, indent);
/* 549:609 */       if (js) {
/* 550:610 */         sb.append("+' ");
/* 551:    */       }
/* 552:611 */       sb.append("<input type=\"button\" value=\"��ͨ��\" onclick=\"updateStatus(2,").append(pkPropertyValue).append(")\" ");
/* 553:612 */       appendNoPermissionTagParts(table, sb, "AUDIT").append(" />");
/* 554:613 */       if (js) {
/* 555:614 */         sb.append("'");
/* 556:    */       }
/* 557:615 */       OutputUtilities.newLine(sb);
/* 558:616 */       OutputUtilities.xmlIndent(sb, indent);
/* 559:617 */       if (js) {
/* 560:618 */         sb.append("+' ");
/* 561:    */       }
/* 562:619 */       sb.append("<input type=\"button\" value=\"�߼�ɾ��\" onclick=\"updateStatus(3,").append(pkPropertyValue).append(")\" ");
/* 563:620 */       appendNoPermissionTagParts(table, sb, "DELETE").append(" />");
/* 564:621 */       if (js) {
/* 565:622 */         sb.append("'");
/* 566:    */       }
/* 567:    */     }
/* 568:624 */     OutputUtilities.newLine(sb);
/* 569:625 */     OutputUtilities.xmlIndent(sb, indent);
/* 570:626 */     if (js) {
/* 571:627 */       sb.append("+' ");
/* 572:    */     }
/* 573:628 */     sb.append("<input type=\"button\" value=\"����ɾ��\" onclick=\"del(").append(pkPropertyValue).append(")\" ");
/* 574:629 */     appendNoPermissionTagParts(table, sb, "DELETE").append(" />");
/* 575:630 */     if (js) {
/* 576:631 */       sb.append("'");
/* 577:    */     }
/* 578:633 */     return sb.toString();
/* 579:    */   }
/* 580:    */   
/* 581:    */   private String makeCreateParam(IntrospectedTable introspectedTable)
/* 582:    */   {
/* 583:637 */     StringBuilder sb = new StringBuilder();
/* 584:638 */     boolean and = false;
/* 585:639 */     if (introspectedTable.hasMainFkColumns())
/* 586:    */     {
/* 587:640 */       Iterator iter = introspectedTable.getMainFkColumns();
/* 588:641 */       while (iter.hasNext())
/* 589:    */       {
/* 590:642 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 591:643 */         if (and)
/* 592:    */         {
/* 593:644 */           sb.append("&");
/* 594:    */         }
/* 595:    */         else
/* 596:    */         {
/* 597:646 */           sb.append("?");
/* 598:647 */           and = true;
/* 599:    */         }
/* 600:649 */         sb.append(cd.getJavaProperty()).append("=${").append(cd.getPrefixJavaProperty("eq")).append("}");
/* 601:    */       }
/* 602:    */     }
/* 603:652 */     if (introspectedTable.hasParentIdColumn())
/* 604:    */     {
/* 605:653 */       if (and)
/* 606:    */       {
/* 607:654 */         sb.append("&");
/* 608:    */       }
/* 609:    */       else
/* 610:    */       {
/* 611:656 */         sb.append("?");
/* 612:657 */         and = true;
/* 613:    */       }
/* 614:659 */       sb.append("parentId=${eqParentId}");
/* 615:    */     }
/* 616:661 */     return sb.toString();
/* 617:    */   }
/* 618:    */   
/* 619:    */   private String makeBatchActionButton(IntrospectedTable introspectedTable)
/* 620:    */   {
/* 621:665 */     StringBuilder sb = new StringBuilder();
/* 622:666 */     int indent = 8;
/* 623:667 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 624:668 */     if (introspectedTable.hasStatusColumn())
/* 625:    */     {
/* 626:669 */       OutputUtilities.xmlIndent(sb, indent);
/* 627:670 */       sb.append("<input type=\"button\" value=\"ͨ��\" onclick=\"updateStatus(1)\" ");
/* 628:671 */       appendNoPermissionTagParts(table, sb, "AUDIT").append(" />");
/* 629:672 */       OutputUtilities.newLine(sb);
/* 630:673 */       OutputUtilities.xmlIndent(sb, indent);
/* 631:674 */       sb.append("<input type=\"button\" value=\"�ܾ�\" onclick=\"updateStatus(2)\" ");
/* 632:675 */       appendNoPermissionTagParts(table, sb, "AUDIT").append(" />");
/* 633:676 */       OutputUtilities.newLine(sb);
/* 634:677 */       OutputUtilities.xmlIndent(sb, indent);
/* 635:678 */       sb.append("<input type=\"button\" value=\"�߼�ɾ��\" onclick=\"updateStatus(3)\" ");
/* 636:679 */       appendNoPermissionTagParts(table, sb, "DELETE").append(" />");
/* 637:680 */       OutputUtilities.newLine(sb);
/* 638:    */     }
/* 639:683 */     OutputUtilities.xmlIndent(sb, indent);
/* 640:684 */     sb.append("<input type=\"button\" value=\"����ɾ��\" onclick=\"del()\" ");
/* 641:685 */     appendNoPermissionTagParts(table, sb, "DELETE").append(" />");
/* 642:686 */     OutputUtilities.newLine(sb);
/* 643:688 */     if (introspectedTable.hasParentIdColumn())
/* 644:    */     {
/* 645:689 */       OutputUtilities.xmlIndent(sb, indent);
/* 646:690 */       sb.append("<input type=\"button\" value=\"�ƶ���\" onclick=\"move(this.nextSibling.value)\" ");
/* 647:691 */       appendNoPermissionTagParts(table, sb, "SEARCH").append(" />");
/* 648:692 */       sb.append("<input type=\"text\" id=\"targetId\" size=\"6\" maxlength=\"10\" class=\"text-input\" title=\"Ŀ��${title}ID\"/>");
/* 649:    */     }
/* 650:695 */     return sb.toString();
/* 651:    */   }
/* 652:    */   
/* 653:    */   private String[] getPKParams(IntrospectedTable introspectedTable)
/* 654:    */   {
/* 655:699 */     StringBuilder sb = new StringBuilder();
/* 656:700 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 657:701 */     String objName = getRecordPropertyName(table);
/* 658:    */     
/* 659:703 */     String pkPropertyName = "";
/* 660:704 */     String pkPropertyNameCamelCase = "";
/* 661:705 */     String pkPropertyValue = "";
/* 662:706 */     String pkCheckbox = "";
/* 663:    */     
/* 664:708 */     Iterator pkColumns = introspectedTable.getPrimaryKeyColumns();
/* 665:709 */     if (pkColumns.hasNext())
/* 666:    */     {
/* 667:710 */       ColumnDefinition cd = (ColumnDefinition)pkColumns.next();
/* 668:711 */       pkPropertyName = cd.getJavaProperty();
/* 669:    */       
/* 670:713 */       pkPropertyNameCamelCase = cd.getPrefixJavaProperty("");
/* 671:    */       
/* 672:715 */       sb.setLength(0);
/* 673:716 */       cd.appendProperty(sb, objName, false);
/* 674:    */       
/* 675:718 */       pkPropertyValue = sb.toString();
/* 676:    */       
/* 677:720 */       sb.setLength(0);
/* 678:721 */       sb.append("<input type=\"checkbox\" name=\"").append(cd.getPrefixJavaProperty("in")).append("List\" value=\"");
/* 679:722 */       sb.append(pkPropertyValue).append("\" />");
/* 680:723 */       pkCheckbox = sb.toString();
/* 681:    */     }
/* 682:725 */     return new String[] { pkPropertyName, pkPropertyNameCamelCase, pkPropertyValue, pkCheckbox };
/* 683:    */   }
/* 684:    */   
/* 685:    */   private void setPKParams(AbstractJspTemplate template, String[] pks)
/* 686:    */   {
/* 687:729 */     template.setPKProperty(pks[0]).setPKPropertyCamelCase(pks[1]).setPKValue(pks[2]);
/* 688:    */   }
/* 689:    */   
/* 690:    */   private void setPKParams(String[] pks)
/* 691:    */   {
/* 692:733 */     this.editTemplate.setPKProperty(pks[0]).setPKPropertyCamelCase(pks[1]).setPKValue(pks[2]);
/* 693:734 */     this.showTemplate.setPKProperty(pks[0]).setPKPropertyCamelCase(pks[1]).setPKValue(pks[2]);
/* 694:735 */     this.jsonTemplate.setPKProperty(pks[0]).setPKPropertyCamelCase(pks[1]).setPKValue(pks[2]);
/* 695:    */   }
/* 696:    */   
/* 697:    */   protected void setListRows(IntrospectedTable introspectedTable, String[] pks)
/* 698:    */   {
/* 699:739 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 700:740 */     int indent = 5;
/* 701:741 */     String objName = getRecordPropertyName(table);
/* 702:742 */     String pkPropertyName = pks[0];
/* 703:743 */     String pkPropertyValue = pks[2];
/* 704:744 */     String pkCheckbox = pks[3];
/* 705:    */     
/* 706:746 */     String template = this.listTemplate.getListFieldTemplate();
/* 707:747 */     StringBuilder row = new StringBuilder();
/* 708:748 */     StringBuilder property = new StringBuilder();
/* 709:    */     
/* 710:750 */     Iterator listColumns = introspectedTable.getListColumns();
/* 711:751 */     while (listColumns.hasNext())
/* 712:    */     {
/* 713:752 */       ColumnDefinition cd = (ColumnDefinition)listColumns.next();
/* 714:    */       
/* 715:754 */       property.setLength(0);
/* 716:755 */       if (cd.getJavaProperty().equalsIgnoreCase(pkPropertyName))
/* 717:    */       {
/* 718:756 */         property.append(pkCheckbox);
/* 719:757 */         OutputUtilities.newLine(property);
/* 720:758 */         OutputUtilities.xmlIndent(property, indent + 1);
/* 721:759 */         property.append("<a href=\"javascript:show(").append(pkPropertyValue).append(")\">").append(pkPropertyValue).append("</a>");
/* 722:    */       }
/* 723:    */       else
/* 724:    */       {
/* 725:762 */         cd.appendFormattedProperty(property, objName, false, true);
/* 726:    */       }
/* 727:764 */       OutputUtilities.xmlIndent(row, indent);
/* 728:765 */       row.append(MessageFormat.format(template, new String[] { property.toString() }));
/* 729:766 */       OutputUtilities.newLine(row);
/* 730:    */     }
/* 731:769 */     this.listTemplate.setListRow(row.toString());
/* 732:770 */     this.listTemplate.setListRowActionButtons(makeRowActionImageButton(introspectedTable, pkPropertyValue, false));
/* 733:    */   }
/* 734:    */   
/* 735:    */   protected void setTreeRows(IntrospectedTable introspectedTable, String[] pks)
/* 736:    */   {
/* 737:774 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 738:775 */     String objName = getRecordPropertyName(table);
/* 739:776 */     boolean and = false;
/* 740:777 */     String pkPropertyName = pks[0];
/* 741:778 */     String pkPropertyValue = pks[2];
/* 742:779 */     String pkCheckbox = pks[3];
/* 743:    */     
/* 744:781 */     StringBuilder row = new StringBuilder();
/* 745:782 */     StringBuilder property = new StringBuilder();
/* 746:    */     
/* 747:784 */     Iterator listColumns = introspectedTable.getListColumns();
/* 748:785 */     while (listColumns.hasNext())
/* 749:    */     {
/* 750:786 */       ColumnDefinition cd = (ColumnDefinition)listColumns.next();
/* 751:788 */       if (and) {
/* 752:789 */         row.append(",\n");
/* 753:    */       } else {
/* 754:791 */         and = true;
/* 755:    */       }
/* 756:793 */       OutputUtilities.xmlIndent(row, 6);
/* 757:    */       
/* 758:795 */       property.setLength(0);
/* 759:796 */       if (cd.getJavaProperty().equalsIgnoreCase(pkPropertyName))
/* 760:    */       {
/* 761:797 */         property.append(pkCheckbox);
/* 762:798 */         property.append("<a href=\"javascript:show(").append(pkPropertyValue).append(")\">").append(pkPropertyValue).append("</a>");
/* 763:    */       }
/* 764:    */       else
/* 765:    */       {
/* 766:801 */         cd.appendFormattedProperty(property, objName, false, true);
/* 767:    */       }
/* 768:803 */       row.append("'").append(property.toString()).append("'");
/* 769:    */     }
/* 770:806 */     this.treeTemplate.setListRow(row.toString());
/* 771:807 */     this.treeTemplate.setListRowActionButtons(makeRowActionImageButton(introspectedTable, pkPropertyValue, true));
/* 772:    */   }
/* 773:    */   
/* 774:    */   private void setQueryFields(AbstractJspTemplate jspTemplate, IntrospectedTable introspectedTable)
/* 775:    */   {
/* 776:811 */     StringBuilder sb = new StringBuilder();
/* 777:812 */     OutputUtilities.newLine(sb);
/* 778:813 */     String template = jspTemplate.getQueryFieldTemplate();
/* 779:    */     
/* 780:815 */     String objName = getRecordPropertyName(introspectedTable.getTable());
/* 781:    */     
/* 782:817 */     Iterator queryColumns = introspectedTable.getQueryColumns();
/* 783:818 */     while (queryColumns.hasNext())
/* 784:    */     {
/* 785:819 */       ColumnDefinition cd = (ColumnDefinition)queryColumns.next();
/* 786:820 */       String label = cd.toHtmlLabelString(true);
/* 787:821 */       String editor = cd.toHtmlEditorString(objName, true);
/* 788:822 */       OutputUtilities.xmlIndent(sb, 3);
/* 789:823 */       sb.append(MessageFormat.format(template, new String[] { label, editor }));
/* 790:824 */       OutputUtilities.newLine(sb);
/* 791:    */     }
/* 792:826 */     jspTemplate.setQueryFields(sb.toString());
/* 793:    */   }
/* 794:    */   
/* 795:    */   protected void setShowRows(IntrospectedTable introspectedTable)
/* 796:    */   {
/* 797:830 */     StringBuilder sb = new StringBuilder();
/* 798:831 */     OutputUtilities.newLine(sb);
/* 799:832 */     String template = this.showTemplate.getShowFieldTemplate();
/* 800:    */     
/* 801:834 */     String objName = getRecordPropertyName(introspectedTable.getTable());
/* 802:835 */     StringBuilder property = new StringBuilder();
/* 803:    */     
/* 804:837 */     Iterator queryColumns = introspectedTable.getAllColumns();
/* 805:838 */     while (queryColumns.hasNext())
/* 806:    */     {
/* 807:839 */       ColumnDefinition cd = (ColumnDefinition)queryColumns.next();
/* 808:840 */       property.setLength(0);
/* 809:841 */       cd.appendFormattedProperty(property, objName, false, true);
/* 810:    */       
/* 811:843 */       OutputUtilities.xmlIndent(sb, 3);
/* 812:844 */       sb.append(MessageFormat.format(template, new String[] { cd.getLabel(), property.toString() }));
/* 813:845 */       OutputUtilities.newLine(sb);
/* 814:    */     }
/* 815:847 */     this.showTemplate.setShowRows(sb.toString());
/* 816:    */   }
/* 817:    */   
/* 818:    */   protected void setEditRows(IntrospectedTable introspectedTable)
/* 819:    */   {
/* 820:851 */     StringBuilder sb = new StringBuilder();
/* 821:852 */     OutputUtilities.newLine(sb);
/* 822:853 */     String template = this.editTemplate.getEditFieldTemplate();
/* 823:    */     
/* 824:855 */     String objName = getRecordPropertyName(introspectedTable.getTable());
/* 825:    */     
/* 826:857 */     Iterator queryColumns = introspectedTable.getAllColumns();
/* 827:858 */     while (queryColumns.hasNext())
/* 828:    */     {
/* 829:859 */       ColumnDefinition cd = (ColumnDefinition)queryColumns.next();
/* 830:860 */       String label = cd.toHtmlLabelString(false);
/* 831:861 */       String editor = cd.toHtmlEditorString(objName, false);
/* 832:862 */       OutputUtilities.xmlIndent(sb, 3);
/* 833:863 */       sb.append(MessageFormat.format(template, new String[] { label, editor }));
/* 834:864 */       OutputUtilities.newLine(sb);
/* 835:    */     }
/* 836:866 */     this.editTemplate.setEditRows(sb.toString());
/* 837:    */   }
/* 838:    */   
/* 839:    */   protected void setJsonRows(IntrospectedTable introspectedTable)
/* 840:    */   {
/* 841:870 */     String objName = getRecordPropertyName(introspectedTable.getTable());
/* 842:871 */     Iterator queryColumns = introspectedTable.getAllColumns();
/* 843:872 */     StringBuilder sb = new StringBuilder("{");
/* 844:873 */     int line = 0;
/* 845:874 */     while (queryColumns.hasNext())
/* 846:    */     {
/* 847:875 */       ColumnDefinition cd = (ColumnDefinition)queryColumns.next();
/* 848:876 */       sb.append(" ").append(cd.getJavaProperty()).append(": \"").append(cd.getLabel().replace("\"", "\\\"")).append("\",");
/* 849:877 */       if (sb.length() / 100 > line)
/* 850:    */       {
/* 851:878 */         line = sb.length() / 100;
/* 852:879 */         OutputUtilities.newLine(sb);
/* 853:880 */         OutputUtilities.xmlIndent(sb, 3);
/* 854:    */       }
/* 855:    */     }
/* 856:883 */     if (sb.length() > 1) {
/* 857:884 */       sb.setCharAt(sb.length() - 1, '}');
/* 858:    */     }
/* 859:885 */     this.jsonTemplate.setJsonTitles(sb.toString());
/* 860:886 */     this.jsonTemplate.setJsonPartTitles("${partPropertyTitleJson}");
/* 861:887 */     this.jsonTemplate.setListJsonRows("${objListJson}");
/* 862:    */   }
/* 863:    */   
/* 864:    */   protected void setCommonParams(IntrospectedTable introspectedTable)
/* 865:    */   {
/* 866:892 */     setCommonParams(this.jsonTemplate, introspectedTable);
/* 867:893 */     setCommonParams(this.editTemplate, introspectedTable);
/* 868:894 */     setCommonParams(this.showTemplate, introspectedTable);
/* 869:    */   }
/* 870:    */   
/* 871:    */   protected void setCommonParams(AbstractJspTemplate template, IntrospectedTable introspectedTable)
/* 872:    */   {
/* 873:898 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 874:899 */     template.setProjectLabel(this.projectLabel);
/* 875:900 */     template.setObjectLabel(table.getLabel());
/* 876:901 */     template.setObjectName(getRecordPropertyName(table));
/* 877:    */     
/* 878:903 */     String urlPrefix = this.controllerGenerator.getUrlPrefix(table);
/* 879:904 */     template.setRootUrl(urlPrefix);
/* 880:905 */     template.setSaveUrl(urlPrefix + "/save.do");
/* 881:906 */     template.setListUrl(urlPrefix + "/list.do");
/* 882:907 */     template.setSearchUrl(urlPrefix + "/search.do");
/* 883:908 */     template.setCreateUrl(urlPrefix + "/create.do");
/* 884:909 */     template.setShowUrl(urlPrefix + "/show.do");
/* 885:910 */     template.setEditUrl(urlPrefix + "/edit.do");
/* 886:911 */     template.setUpdateUrl(urlPrefix + "/update.do");
/* 887:912 */     template.setMoveUrl(urlPrefix + "/move.do");
/* 888:913 */     template.setAuditUrl(urlPrefix + "/audit.do");
/* 889:914 */     template.setUpdateStatusUrl(urlPrefix + "/updateStatus.do");
/* 890:915 */     template.setDeleteUrl(urlPrefix + "/delete.do");
/* 891:    */   }
/* 892:    */   
/* 893:    */   protected String getJspPackage(FullyQualifiedTable table)
/* 894:    */   {
/* 895:920 */     String key = "getJspPackage";
/* 896:    */     
/* 897:    */ 
/* 898:923 */     Map map = getTableValueMap(table);
/* 899:924 */     String s = (String)map.get(key);
/* 900:925 */     if (s == null)
/* 901:    */     {
/* 902:926 */       StringBuffer sb = new StringBuffer(this.targetPackage);
/* 903:927 */       sb.append(".");
/* 904:928 */       sb.append(getRecordPropertyName(table));
/* 905:929 */       s = sb.toString();
/* 906:930 */       map.put(key, s);
/* 907:    */     }
/* 908:933 */     return s;
/* 909:    */   }
/* 910:    */   
/* 911:    */   private Map getTableValueMap(FullyQualifiedTable table)
/* 912:    */   {
/* 913:938 */     Map map = (Map)this.tableValueMaps.get(table);
/* 914:939 */     if (map == null)
/* 915:    */     {
/* 916:940 */       map = new HashMap();
/* 917:941 */       this.tableValueMaps.put(table, map);
/* 918:    */     }
/* 919:944 */     return map;
/* 920:    */   }
/* 921:    */   
/* 922:    */   public void addContextProperties(Map properties)
/* 923:    */   {
/* 924:948 */     this.properties.putAll(properties);
/* 925:    */   }
/* 926:    */   
/* 927:    */   public ControllerGenerator getControllerGenerator()
/* 928:    */   {
/* 929:955 */     return this.controllerGenerator;
/* 930:    */   }
/* 931:    */   
/* 932:    */   public ShellCallback getShellCallback()
/* 933:    */   {
/* 934:962 */     return this.shellCallback;
/* 935:    */   }
/* 936:    */   
/* 937:    */   public void setShellCallback(ShellCallback shellCallback)
/* 938:    */   {
/* 939:969 */     if (shellCallback != null) {
/* 940:970 */       this.shellCallback = shellCallback;
/* 941:    */     }
/* 942:    */   }
/* 943:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.jsp.BaseJspGenerator
 * JD-Core Version:    0.7.0.1
 */