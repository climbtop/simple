/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  6:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  7:   */ 
/*  8:   */ public class SpringAbatorDAOTemplate
/*  9:   */   extends AbstractDAOTemplate
/* 10:   */ {
/* 11:   */   public SpringAbatorDAOTemplate()
/* 12:   */   {
/* 13:37 */     Method method = new Method();
/* 14:38 */     method.setConstructor(true);
/* 15:39 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 16:40 */     method.addBodyLine("super();");
/* 17:41 */     setConstructorTemplate(method);
/* 18:   */     
/* 19:43 */     setSuperClass(new FullyQualifiedJavaType(
/* 20:44 */       "com.afocus.framework.base.dao.ibatis.BaseDaoIbatis"));
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Method getConstructorClone(String sqlMapNameSpace, FullyQualifiedJavaType type, FullyQualifiedTable table)
/* 24:   */   {
/* 25:54 */     Method answer = super.getConstructorClone(sqlMapNameSpace, type, table);
/* 26:55 */     answer.addBodyLine("setNameSpace( \"" + sqlMapNameSpace + "\" );");
/* 27:56 */     return answer;
/* 28:   */   }
/* 29:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringAbatorDAOTemplate
 * JD-Core Version:    0.7.0.1
 */