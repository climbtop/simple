/*   1:    */ package org.apache.ibatis.abator.internal.java.dao;
/*   2:    */ 
/*   3:    */ import java.text.MessageFormat;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   8:    */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   9:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  10:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  11:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  12:    */ 
/*  13:    */ public abstract class AbstractDAOTemplate
/*  14:    */ {
/*  15:    */   private List interfaceImports;
/*  16:    */   private List implementationImports;
/*  17:    */   private FullyQualifiedJavaType superClass;
/*  18:    */   private List checkedExceptions;
/*  19:    */   private List fields;
/*  20:    */   private List methods;
/*  21:    */   private Method constructorTemplate;
/*  22:    */   private String deleteMethodTemplate;
/*  23:    */   private String insertMethodTemplate;
/*  24:    */   private String updateMethodTemplate;
/*  25:    */   private String queryForObjectMethodTemplate;
/*  26:    */   private String queryForListMethodTemplate;
/*  27:    */   
/*  28:    */   public AbstractDAOTemplate()
/*  29:    */   {
/*  30: 62 */     this.interfaceImports = new ArrayList();
/*  31: 63 */     this.implementationImports = new ArrayList();
/*  32: 64 */     this.fields = new ArrayList();
/*  33: 65 */     this.methods = new ArrayList();
/*  34: 66 */     this.checkedExceptions = new ArrayList();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Method getConstructorClone(String sqlMapNameSpace, FullyQualifiedJavaType type, FullyQualifiedTable table)
/*  38:    */   {
/*  39: 70 */     Method answer = new Method();
/*  40: 71 */     answer.addComment(table);
/*  41: 72 */     answer.setConstructor(true);
/*  42: 73 */     answer.setName(type.getBaseShortName());
/*  43: 74 */     answer.setVisibility(this.constructorTemplate.getVisibility());
/*  44: 75 */     Iterator iter = this.constructorTemplate.getParameters().iterator();
/*  45: 76 */     while (iter.hasNext()) {
/*  46: 77 */       answer.addParameter((Parameter)iter.next());
/*  47:    */     }
/*  48: 79 */     iter = this.constructorTemplate.getBodyLines().iterator();
/*  49: 80 */     while (iter.hasNext()) {
/*  50: 81 */       answer.addBodyLine((String)iter.next());
/*  51:    */     }
/*  52: 83 */     iter = this.constructorTemplate.getExceptions().iterator();
/*  53: 84 */     while (iter.hasNext()) {
/*  54: 85 */       answer.addException((FullyQualifiedJavaType)iter.next());
/*  55:    */     }
/*  56: 88 */     return answer;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String getDeleteMethod(String sqlMapNamespace, String statementId, String parameter)
/*  60:    */   {
/*  61: 93 */     String answer = MessageFormat.format(this.deleteMethodTemplate, 
/*  62: 94 */       new String[] { sqlMapNamespace, statementId, parameter });
/*  63:    */     
/*  64: 96 */     return answer;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public List getInterfaceImports()
/*  68:    */   {
/*  69:100 */     return this.interfaceImports;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public List getImplementationImports()
/*  73:    */   {
/*  74:104 */     return this.implementationImports;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getInsertMethod(String sqlMapNamespace, String statementId, String parameter)
/*  78:    */   {
/*  79:109 */     String answer = MessageFormat.format(this.insertMethodTemplate, 
/*  80:110 */       new String[] { sqlMapNamespace, statementId, parameter });
/*  81:    */     
/*  82:112 */     return answer;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String getQueryForListMethod(String sqlMapNamespace, String statementId, String parameter)
/*  86:    */   {
/*  87:117 */     String answer = MessageFormat.format(this.queryForListMethodTemplate, 
/*  88:118 */       new String[] { sqlMapNamespace, statementId, parameter });
/*  89:    */     
/*  90:120 */     return answer;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public String getQueryForObjectMethod(String sqlMapNamespace, String statementId, String parameter)
/*  94:    */   {
/*  95:125 */     String answer = MessageFormat.format(this.queryForObjectMethodTemplate, 
/*  96:126 */       new String[] { sqlMapNamespace, statementId, parameter });
/*  97:    */     
/*  98:128 */     return answer;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public FullyQualifiedJavaType getSuperClass()
/* 102:    */   {
/* 103:132 */     return this.superClass;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public String getUpdateMethod(String sqlMapNamespace, String statementId, String parameter)
/* 107:    */   {
/* 108:137 */     String answer = MessageFormat.format(this.updateMethodTemplate, 
/* 109:138 */       new String[] { sqlMapNamespace, statementId, parameter });
/* 110:    */     
/* 111:140 */     return answer;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public List getCheckedExceptions()
/* 115:    */   {
/* 116:144 */     return this.checkedExceptions;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public Iterator getFieldClones(FullyQualifiedTable table)
/* 120:    */   {
/* 121:148 */     ArrayList answer = new ArrayList();
/* 122:149 */     Iterator iter = this.fields.iterator();
/* 123:150 */     while (iter.hasNext())
/* 124:    */     {
/* 125:151 */       Field field = new Field();
/* 126:152 */       Field oldField = (Field)iter.next();
/* 127:    */       
/* 128:154 */       field.addComment(table);
/* 129:155 */       field.setInitializationString(oldField.getInitializationString());
/* 130:156 */       field.setModifierFinal(oldField.isModifierFinal());
/* 131:157 */       field.setModifierStatic(oldField.isModifierStatic());
/* 132:158 */       field.setName(oldField.getName());
/* 133:159 */       field.setType(oldField.getType());
/* 134:160 */       field.setVisibility(oldField.getVisibility());
/* 135:161 */       answer.add(field);
/* 136:    */     }
/* 137:164 */     return answer.iterator();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public Iterator getMethodClones(FullyQualifiedTable table)
/* 141:    */   {
/* 142:168 */     ArrayList answer = new ArrayList();
/* 143:169 */     Iterator iter = this.methods.iterator();
/* 144:170 */     while (iter.hasNext())
/* 145:    */     {
/* 146:171 */       Method method = new Method();
/* 147:172 */       Method oldMethod = (Method)iter.next();
/* 148:    */       
/* 149:174 */       Iterator iter2 = oldMethod.getBodyLines().iterator();
/* 150:175 */       while (iter2.hasNext()) {
/* 151:176 */         method.addBodyLine((String)iter2.next());
/* 152:    */       }
/* 153:179 */       iter2 = oldMethod.getExceptions().iterator();
/* 154:180 */       while (iter2.hasNext()) {
/* 155:181 */         method.addException((FullyQualifiedJavaType)iter2.next());
/* 156:    */       }
/* 157:184 */       method.addComment(table);
/* 158:    */       
/* 159:186 */       iter2 = oldMethod.getParameters().iterator();
/* 160:187 */       while (iter2.hasNext()) {
/* 161:188 */         method.addParameter((Parameter)iter2.next());
/* 162:    */       }
/* 163:191 */       method.setConstructor(oldMethod.isConstructor());
/* 164:192 */       method.setModifierFinal(oldMethod.isModifierFinal());
/* 165:193 */       method.setModifierStatic(oldMethod.isModifierStatic());
/* 166:194 */       method.setName(oldMethod.getName());
/* 167:195 */       method.setReturnType(oldMethod.getReturnType());
/* 168:196 */       method.setVisibility(oldMethod.getVisibility());
/* 169:    */       
/* 170:198 */       answer.add(method);
/* 171:    */     }
/* 172:201 */     return answer.iterator();
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected void setConstructorTemplate(Method constructorTemplate)
/* 176:    */   {
/* 177:205 */     this.constructorTemplate = constructorTemplate;
/* 178:    */   }
/* 179:    */   
/* 180:    */   protected void setDeleteMethodTemplate(String deleteMethodTemplate)
/* 181:    */   {
/* 182:209 */     this.deleteMethodTemplate = deleteMethodTemplate;
/* 183:    */   }
/* 184:    */   
/* 185:    */   protected void addField(Field field)
/* 186:    */   {
/* 187:213 */     this.fields.add(field);
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected void setInsertMethodTemplate(String insertMethodTemplate)
/* 191:    */   {
/* 192:217 */     this.insertMethodTemplate = insertMethodTemplate;
/* 193:    */   }
/* 194:    */   
/* 195:    */   protected void addMethod(Method method)
/* 196:    */   {
/* 197:221 */     this.methods.add(method);
/* 198:    */   }
/* 199:    */   
/* 200:    */   protected void setQueryForListMethodTemplate(String queryForListMethodTemplate)
/* 201:    */   {
/* 202:225 */     this.queryForListMethodTemplate = queryForListMethodTemplate;
/* 203:    */   }
/* 204:    */   
/* 205:    */   protected void setQueryForObjectMethodTemplate(String queryForObjectMethodTemplate)
/* 206:    */   {
/* 207:229 */     this.queryForObjectMethodTemplate = queryForObjectMethodTemplate;
/* 208:    */   }
/* 209:    */   
/* 210:    */   protected void setSuperClass(FullyQualifiedJavaType superClass)
/* 211:    */   {
/* 212:233 */     this.superClass = superClass;
/* 213:    */   }
/* 214:    */   
/* 215:    */   protected void setUpdateMethodTemplate(String updateMethodTemplate)
/* 216:    */   {
/* 217:237 */     this.updateMethodTemplate = updateMethodTemplate;
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected void addInterfaceImport(FullyQualifiedJavaType type)
/* 221:    */   {
/* 222:241 */     this.interfaceImports.add(type);
/* 223:    */   }
/* 224:    */   
/* 225:    */   protected void addImplementationImport(FullyQualifiedJavaType type)
/* 226:    */   {
/* 227:245 */     this.implementationImports.add(type);
/* 228:    */   }
/* 229:    */   
/* 230:    */   protected void addCheckedException(FullyQualifiedJavaType type)
/* 231:    */   {
/* 232:249 */     this.checkedExceptions.add(type);
/* 233:    */   }
/* 234:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.AbstractDAOTemplate
 * JD-Core Version:    0.7.0.1
 */