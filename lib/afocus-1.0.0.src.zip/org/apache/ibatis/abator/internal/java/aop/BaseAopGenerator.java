/*   1:    */ package org.apache.ibatis.abator.internal.java.aop;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import org.apache.ibatis.abator.api.AopGenerator;
/*  10:    */ import org.apache.ibatis.abator.api.AopMethodNameCalculator;
/*  11:    */ import org.apache.ibatis.abator.api.DAOGenerator;
/*  12:    */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*  13:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  14:    */ import org.apache.ibatis.abator.api.GeneratedJavaFile;
/*  15:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  16:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  17:    */ import org.apache.ibatis.abator.api.ProgressCallback;
/*  18:    */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*  19:    */ import org.apache.ibatis.abator.api.dom.java.Field;
/*  20:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  21:    */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  22:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  23:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  24:    */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*  25:    */ import org.apache.ibatis.abator.internal.AbatorObjectFactory;
/*  26:    */ import org.apache.ibatis.abator.internal.DefaultAopMethodNameCalculator;
/*  27:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*  28:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*  29:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  30:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  31:    */ 
/*  32:    */ public class BaseAopGenerator
/*  33:    */   implements AopGenerator
/*  34:    */ {
/*  35:    */   protected AbstractAopTemplate aopTemplate;
/*  36:    */   protected Map properties;
/*  37:    */   protected List warnings;
/*  38:    */   protected String targetPackage;
/*  39:    */   protected String targetProject;
/*  40:    */   protected JavaModelGenerator javaModelGenerator;
/*  41:    */   protected DAOGenerator daoGenerator;
/*  42:    */   private Map tableValueMaps;
/*  43:    */   private boolean useJava5Features;
/*  44: 71 */   protected JavaVisibility exampleMethodVisibility = JavaVisibility.PUBLIC;
/*  45: 73 */   protected AopMethodNameCalculator methodNameCalculator = new DefaultAopMethodNameCalculator();
/*  46:    */   private DAOMethodNameCalculator daoMethodNameCalculator;
/*  47:    */   
/*  48:    */   public BaseAopGenerator()
/*  49:    */   {
/*  50: 81 */     this(new AbstractAopTemplate(), false);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public BaseAopGenerator(AbstractAopTemplate aopTemplate, boolean useJava5Features)
/*  54:    */   {
/*  55: 87 */     this.aopTemplate = aopTemplate;
/*  56: 88 */     this.useJava5Features = useJava5Features;
/*  57: 89 */     this.tableValueMaps = new HashMap();
/*  58: 90 */     this.properties = new HashMap();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void addConfigurationProperties(Map properties)
/*  62:    */   {
/*  63: 95 */     this.properties.putAll(properties);
/*  64: 97 */     if (properties.containsKey("exampleMethodVisibility"))
/*  65:    */     {
/*  66: 98 */       String value = (String)properties.get("exampleMethodVisibility");
/*  67:100 */       if ("public".equalsIgnoreCase(value)) {
/*  68:101 */         this.exampleMethodVisibility = JavaVisibility.PUBLIC;
/*  69:102 */       } else if ("private".equalsIgnoreCase(value)) {
/*  70:103 */         this.exampleMethodVisibility = JavaVisibility.PRIVATE;
/*  71:104 */       } else if ("protected".equalsIgnoreCase(value)) {
/*  72:105 */         this.exampleMethodVisibility = JavaVisibility.PROTECTED;
/*  73:106 */       } else if ("default".equalsIgnoreCase(value)) {
/*  74:107 */         this.exampleMethodVisibility = JavaVisibility.DEFAULT;
/*  75:    */       } else {
/*  76:109 */         this.warnings.add(Messages.getString("Warning.16", value));
/*  77:    */       }
/*  78:    */     }
/*  79:113 */     if (properties.containsKey("methodNameCalculator"))
/*  80:    */     {
/*  81:114 */       String value = (String)properties.get("methodNameCalculator");
/*  82:116 */       if ((!"default".equalsIgnoreCase(value)) && 
/*  83:117 */         (StringUtility.stringHasValue(value))) {
/*  84:    */         try
/*  85:    */         {
/*  86:119 */           this.methodNameCalculator = ((AopMethodNameCalculator)
/*  87:120 */             AbatorObjectFactory.createObject(value));
/*  88:    */         }
/*  89:    */         catch (Exception e)
/*  90:    */         {
/*  91:122 */           this.warnings.add(Messages.getString("Warning.17", value, Arrays.deepToString(e.getStackTrace())));
/*  92:    */         }
/*  93:    */       }
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setWarnings(List warnings)
/*  98:    */   {
/*  99:134 */     this.warnings = warnings;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setTargetPackage(String targetPackage)
/* 103:    */   {
/* 104:143 */     this.targetPackage = targetPackage;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setTargetProject(String targetProject)
/* 108:    */   {
/* 109:152 */     this.targetProject = targetProject;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setJavaModelGenerator(JavaModelGenerator javaModelGenerator)
/* 113:    */   {
/* 114:161 */     this.javaModelGenerator = javaModelGenerator;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void setDaoGenerator(DAOGenerator daoGenerator)
/* 118:    */   {
/* 119:170 */     this.daoGenerator = daoGenerator;
/* 120:171 */     this.daoMethodNameCalculator = daoGenerator.getMethodNameCalculator();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public AopMethodNameCalculator getMethodNameCalculator()
/* 124:    */   {
/* 125:178 */     return this.methodNameCalculator;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setMethodNameCalculator(AopMethodNameCalculator methodNameCalculator)
/* 129:    */   {
/* 130:185 */     this.methodNameCalculator = methodNameCalculator;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public List getGeneratedJavaFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/* 134:    */   {
/* 135:196 */     List list = new ArrayList();
/* 136:    */     
/* 137:198 */     String tableName = introspectedTable.getTable()
/* 138:199 */       .getFullyQualifiedTableName();
/* 139:    */     
/* 140:201 */     callback.startSubTask(Messages.getString("Progress.13", 
/* 141:202 */       tableName));
/* 142:203 */     CompilationUnit cu = getAopImplementation(introspectedTable);
/* 143:204 */     GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/* 144:205 */     list.add(gjf);
/* 145:    */     
/* 146:207 */     return list;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public String getDAOPropertyName(FullyQualifiedTable table)
/* 150:    */   {
/* 151:211 */     String key = "getDAOPropertyName";
/* 152:    */     
/* 153:213 */     Map map = getTableValueMap(table);
/* 154:214 */     String property = (String)map.get(key);
/* 155:215 */     if (property == null)
/* 156:    */     {
/* 157:216 */       FullyQualifiedJavaType fqjt = this.daoGenerator.getDAOInterfaceType(table);
/* 158:217 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getBaseShortName());
/* 159:218 */       map.put(key, property);
/* 160:    */     }
/* 161:221 */     return property;
/* 162:    */   }
/* 163:    */   
/* 164:    */   protected String getBaseDaoPropertyName(FullyQualifiedTable table)
/* 165:    */   {
/* 166:225 */     String key = "getBaseDaoPropertyName";
/* 167:    */     
/* 168:227 */     Map map = getTableValueMap(table);
/* 169:228 */     String property = (String)map.get(key);
/* 170:229 */     if (property == null)
/* 171:    */     {
/* 172:230 */       FullyQualifiedJavaType fqjt = this.daoGenerator.getBaseDAOInterfaceType(table);
/* 173:231 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getBaseShortName());
/* 174:232 */       map.put(key, property);
/* 175:    */     }
/* 176:235 */     return property;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public String getAopPropertyName(FullyQualifiedTable table)
/* 180:    */   {
/* 181:239 */     String key = "getAopPropertyName";
/* 182:    */     
/* 183:241 */     Map map = getTableValueMap(table);
/* 184:242 */     String property = (String)map.get(key);
/* 185:243 */     if (property == null)
/* 186:    */     {
/* 187:244 */       FullyQualifiedJavaType fqjt = getAopInterfaceType(table);
/* 188:245 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getShortName());
/* 189:246 */       map.put(key, property);
/* 190:    */     }
/* 191:249 */     return property;
/* 192:    */   }
/* 193:    */   
/* 194:    */   protected FullyQualifiedJavaType makeDaoPropertyClassParts(FullyQualifiedTable table, TopLevelClass topLevelClass)
/* 195:    */   {
/* 196:253 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(table.getDomainObjectName() + "LogDao");
/* 197:254 */     String property = getRecordPropertyName(table) + "LogDao";
/* 198:255 */     Field field = new Field();
/* 199:256 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 200:257 */     field.setType(fqjt);
/* 201:258 */     field.setName(property);
/* 202:260 */     if (this.useJava5Features) {
/* 203:261 */       field.addAnnotation("@Resource");
/* 204:    */     }
/* 205:263 */     topLevelClass.addField(field);
/* 206:264 */     topLevelClass.addImportedType(fqjt);
/* 207:265 */     return fqjt;
/* 208:    */   }
/* 209:    */   
/* 210:    */   protected FullyQualifiedJavaType makePermissionPropertyClassParts(TopLevelClass topLevelClass)
/* 211:    */   {
/* 212:270 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.component.permission.api.service.PermissionHelper");
/* 213:271 */     Field field = new Field();
/* 214:272 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 215:273 */     field.setType(fqjt);
/* 216:274 */     field.setName("permissionHelper");
/* 217:276 */     if (this.useJava5Features) {
/* 218:277 */       field.addAnnotation("@Resource(name = \"permissionHelper\")");
/* 219:    */     }
/* 220:279 */     topLevelClass.addField(field);
/* 221:280 */     topLevelClass.addImportedType(fqjt);
/* 222:281 */     return fqjt;
/* 223:    */   }
/* 224:    */   
/* 225:    */   protected TopLevelClass getAopImplementation(IntrospectedTable introspectedTable)
/* 226:    */   {
/* 227:286 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 228:287 */     FullyQualifiedJavaType type = getAopImplementationType(table);
/* 229:288 */     TopLevelClass answer = new TopLevelClass(type);
/* 230:289 */     answer.setVisibility(JavaVisibility.PUBLIC);
/* 231:290 */     answer.addImportedType(new FullyQualifiedJavaType("java.util.Date"));
/* 232:291 */     answer.addImportedType(new FullyQualifiedJavaType("com.afocus.component.permission.entity.User"));
/* 233:293 */     if (this.useJava5Features)
/* 234:    */     {
/* 235:295 */       answer.addAnnotation("@Aspect");
/* 236:296 */       answer.addAnnotation("@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class) ");
/* 237:297 */       answer.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Transactional"));
/* 238:298 */       answer.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Propagation"));
/* 239:299 */       answer.addAnnotation("@Service(\"" + getAopPropertyName(table) + "\")");
/* 240:    */     }
/* 241:302 */     Iterator iter = this.aopTemplate.getImplementationImports().iterator();
/* 242:303 */     while (iter.hasNext()) {
/* 243:304 */       answer.addImportedType((FullyQualifiedJavaType)iter.next());
/* 244:    */     }
/* 245:308 */     iter = this.aopTemplate.getMethodClones(table);
/* 246:309 */     while (iter.hasNext()) {
/* 247:310 */       answer.addMethod((Method)iter.next());
/* 248:    */     }
/* 249:313 */     makeDaoPropertyClassParts(table, answer);
/* 250:314 */     makePermissionPropertyClassParts(answer);
/* 251:317 */     if (introspectedTable.getRules().generateInsert())
/* 252:    */     {
/* 253:318 */       List methods = getAfterMethod(introspectedTable, answer);
/* 254:319 */       if (methods != null)
/* 255:    */       {
/* 256:320 */         iter = methods.iterator();
/* 257:321 */         while (iter.hasNext()) {
/* 258:322 */           answer.addMethod((Method)iter.next());
/* 259:    */         }
/* 260:    */       }
/* 261:326 */       methods = getAsyncInsertLog(introspectedTable, answer);
/* 262:327 */       if (methods != null)
/* 263:    */       {
/* 264:328 */         iter = methods.iterator();
/* 265:329 */         while (iter.hasNext()) {
/* 266:330 */           answer.addMethod((Method)iter.next());
/* 267:    */         }
/* 268:    */       }
/* 269:    */     }
/* 270:335 */     return answer;
/* 271:    */   }
/* 272:    */   
/* 273:    */   public FullyQualifiedJavaType getAopImplementationType(FullyQualifiedTable table)
/* 274:    */   {
/* 275:340 */     String key = "getAopImplementationType";
/* 276:    */     
/* 277:342 */     Map map = getTableValueMap(table);
/* 278:343 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/* 279:344 */     if (fqjt == null)
/* 280:    */     {
/* 281:345 */       StringBuffer sb = new StringBuffer();
/* 282:346 */       sb.append(getAopPackage(table));
/* 283:347 */       sb.append(".aop.");
/* 284:348 */       sb.append(table.getDomainObjectName());
/* 285:349 */       sb.append("AopImpl");
/* 286:    */       
/* 287:351 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/* 288:352 */       map.put(key, fqjt);
/* 289:    */     }
/* 290:355 */     return fqjt;
/* 291:    */   }
/* 292:    */   
/* 293:    */   protected List getAsyncInsertLog(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/* 294:    */   {
/* 295:360 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 296:361 */     Method method = new Method();
/* 297:362 */     method.addComment(table);
/* 298:363 */     method.addAnnotation("@Async");
/* 299:    */     
/* 300:365 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 301:    */     
/* 302:367 */     method.setName("insertLog");
/* 303:    */     
/* 304:369 */     FullyQualifiedJavaType parameterType = introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/* 305:370 */     parameterType = new FullyQualifiedJavaType(table.getDomainObjectName() + "Log");
/* 306:371 */     method.addParameter(new Parameter(parameterType, getRecordPropertyName(table) + "Log"));
/* 307:    */     
/* 308:373 */     method.addBodyLine(getRecordPropertyName(table) + "LogDao.insert(" + getRecordPropertyName(table) + "Log);");
/* 309:374 */     List answer = new ArrayList();
/* 310:375 */     answer.add(method);
/* 311:376 */     return answer;
/* 312:    */   }
/* 313:    */   
/* 314:    */   protected List getAfterMethod(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/* 315:    */   {
/* 316:382 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 317:383 */     Method method = new Method();
/* 318:384 */     method.addComment(table);
/* 319:385 */     method.addAnnotation("@AfterReturning(pointcut=\"execution(* *.*.add*(..))\")");
/* 320:    */     
/* 321:    */ 
/* 322:    */ 
/* 323:389 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 324:390 */     method.setName(this.methodNameCalculator.getAfterMethodName(introspectedTable));
/* 325:    */     
/* 326:392 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("org.aspectj.lang.JoinPoint");
/* 327:393 */     compilationUnit.addImportedType(parameterType);
/* 328:394 */     method.addParameter(new Parameter(parameterType, "jp"));
/* 329:395 */     Iterator iter = this.aopTemplate.getCheckedExceptions().iterator();
/* 330:396 */     while (iter.hasNext())
/* 331:    */     {
/* 332:397 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 333:398 */       method.addException(fqjt);
/* 334:399 */       compilationUnit.addImportedType(fqjt);
/* 335:    */     }
/* 336:403 */     method.addBodyLine("try {");
/* 337:404 */     method.addBodyLine("HttpServletRequest request = (HttpServletRequest)jp.getArgs()[0];");
/* 338:405 */     method.addBodyLine("HttpServletResponse response = (HttpServletResponse)jp.getArgs()[1];");
/* 339:406 */     method.addBodyLine(table.getDomainObjectName() + " " + getRecordPropertyName(table) + " = (" + getRecordPropertyName(table) + ")jp.getArgs()[2];");
/* 340:407 */     method.addBodyLine(table.getDomainObjectName() + "Log " + getRecordPropertyName(table) + "Log = new " + table.getDomainObjectName() + "Log(); ");
/* 341:    */     
/* 342:409 */     parameterType = new FullyQualifiedJavaType(table.getDomainObjectName());
/* 343:410 */     compilationUnit.addImportedType(parameterType);
/* 344:411 */     parameterType = new FullyQualifiedJavaType(table.getDomainObjectName() + "Log");
/* 345:412 */     compilationUnit.addImportedType(parameterType);
/* 346:    */     
/* 347:414 */     method.addBodyLine("PropertyUtils.copyProperties(" + getRecordPropertyName(table) + "Log, " + getRecordPropertyName(table) + ");");
/* 348:415 */     method.addBodyLine("//do not init permissionHelper,filter already do it;");
/* 349:    */     
/* 350:417 */     method.addBodyLine("User user = permissionHelper.getUser();");
/* 351:418 */     method.addBodyLine(getRecordPropertyName(table) + "Log.setAdminId(user.getUserId());");
/* 352:419 */     method.addBodyLine(getRecordPropertyName(table) + "Log.setUpdateTime(new Date());");
/* 353:    */     
/* 354:421 */     method.addBodyLine("String method = jp.getStaticPart().getSignature().getName();");
/* 355:422 */     method.addBodyLine("this.insertLog(" + getRecordPropertyName(table) + "Log);");
/* 356:423 */     method.addBodyLine("} catch (Exception e) {");
/* 357:424 */     method.addBodyLine("log.error(\"func[doAfterReturning] jp[\" + jp + \"] error[\" + Arrays.deepToString(e.getStackTrace()) + \"]\", e);");
/* 358:425 */     method.addBodyLine("}");
/* 359:    */     
/* 360:427 */     List answer = new ArrayList();
/* 361:428 */     answer.add(method);
/* 362:    */     
/* 363:430 */     return answer;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public String getRecordPropertyName(FullyQualifiedTable table)
/* 367:    */   {
/* 368:434 */     String key = "getRecordPropertyName";
/* 369:    */     
/* 370:436 */     Map map = getTableValueMap(table);
/* 371:437 */     String property = (String)map.get(key);
/* 372:438 */     if (property == null)
/* 373:    */     {
/* 374:439 */       property = JavaBeansUtil.getValidPropertyName(table.getDomainObjectName());
/* 375:440 */       map.put(key, property);
/* 376:    */     }
/* 377:443 */     return property;
/* 378:    */   }
/* 379:    */   
/* 380:    */   protected String getAopPackage(FullyQualifiedTable table)
/* 381:    */   {
/* 382:529 */     String key = "getAopPackage";
/* 383:    */     
/* 384:    */ 
/* 385:532 */     Map map = getTableValueMap(table);
/* 386:533 */     String s = (String)map.get(key);
/* 387:534 */     if (s == null)
/* 388:    */     {
/* 389:535 */       StringBuffer sb = new StringBuffer(this.targetPackage);
/* 390:536 */       if ("true".equals(this.properties.get("enableSubPackages")))
/* 391:    */       {
/* 392:537 */         if (StringUtility.stringHasValue(table.getCatalog()))
/* 393:    */         {
/* 394:538 */           sb.append('.');
/* 395:539 */           sb.append(table.getCatalog().toLowerCase());
/* 396:    */         }
/* 397:542 */         if (StringUtility.stringHasValue(table.getSchema()))
/* 398:    */         {
/* 399:543 */           sb.append('.');
/* 400:544 */           sb.append(table.getSchema().toLowerCase());
/* 401:    */         }
/* 402:    */       }
/* 403:548 */       s = sb.toString();
/* 404:549 */       map.put(key, s);
/* 405:    */     }
/* 406:552 */     return s;
/* 407:    */   }
/* 408:    */   
/* 409:    */   private Map getTableValueMap(FullyQualifiedTable table)
/* 410:    */   {
/* 411:556 */     Map map = (Map)this.tableValueMaps.get(table);
/* 412:557 */     if (map == null)
/* 413:    */     {
/* 414:558 */       map = new HashMap();
/* 415:559 */       this.tableValueMaps.put(table, map);
/* 416:    */     }
/* 417:562 */     return map;
/* 418:    */   }
/* 419:    */   
/* 420:    */   public void addContextProperties(Map properties)
/* 421:    */   {
/* 422:567 */     this.properties.putAll(properties);
/* 423:    */   }
/* 424:    */   
/* 425:    */   public FullyQualifiedJavaType getAopInterfaceType(FullyQualifiedTable table)
/* 426:    */   {
/* 427:573 */     String key = "getAopInterfaceType";
/* 428:    */     
/* 429:575 */     Map map = getTableValueMap(table);
/* 430:576 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/* 431:577 */     if (fqjt == null)
/* 432:    */     {
/* 433:578 */       StringBuffer sb = new StringBuffer();
/* 434:579 */       sb.append(getAopPackage(table));
/* 435:580 */       sb.append('.');
/* 436:581 */       sb.append(table.getDomainObjectName());
/* 437:582 */       sb.append("Aop");
/* 438:    */       
/* 439:584 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/* 440:585 */       map.put(key, fqjt);
/* 441:    */     }
/* 442:588 */     return fqjt;
/* 443:    */   }
/* 444:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.aop.BaseAopGenerator
 * JD-Core Version:    0.7.0.1
 */