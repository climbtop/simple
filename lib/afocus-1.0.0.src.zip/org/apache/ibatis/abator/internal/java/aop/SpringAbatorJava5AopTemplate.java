/*  1:   */ package org.apache.ibatis.abator.internal.java.aop;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  4:   */ 
/*  5:   */ public class SpringAbatorJava5AopTemplate
/*  6:   */   extends AbstractAopTemplate
/*  7:   */ {
/*  8:   */   public SpringAbatorJava5AopTemplate()
/*  9:   */   {
/* 10:31 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/* 11:32 */     addImplementationImport(fqjt);
/* 12:33 */     fqjt = new FullyQualifiedJavaType("javax.annotation.Resource");
/* 13:34 */     addImplementationImport(fqjt);
/* 14:35 */     fqjt = new FullyQualifiedJavaType("org.aspectj.lang.JoinPoint");
/* 15:36 */     addImplementationImport(fqjt);
/* 16:37 */     fqjt = new FullyQualifiedJavaType("org.aspectj.lang.annotation.AfterReturning");
/* 17:38 */     addImplementationImport(fqjt);
/* 18:39 */     fqjt = new FullyQualifiedJavaType("org.aspectj.lang.annotation.Aspect");
/* 19:40 */     addImplementationImport(fqjt);
/* 20:41 */     fqjt = new FullyQualifiedJavaType("org.springframework.scheduling.annotation.Async");
/* 21:42 */     addImplementationImport(fqjt);
/* 22:43 */     fqjt = new FullyQualifiedJavaType("org.springframework.stereotype.Service");
/* 23:44 */     addImplementationImport(fqjt);
/* 24:45 */     fqjt = new FullyQualifiedJavaType("org.springframework.transaction.annotation.Propagation");
/* 25:46 */     addImplementationImport(fqjt);
/* 26:47 */     fqjt = new FullyQualifiedJavaType("org.springframework.transaction.annotation.Transactional");
/* 27:48 */     addImplementationImport(fqjt);
/* 28:   */   }
/* 29:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.aop.SpringAbatorJava5AopTemplate
 * JD-Core Version:    0.7.0.1
 */