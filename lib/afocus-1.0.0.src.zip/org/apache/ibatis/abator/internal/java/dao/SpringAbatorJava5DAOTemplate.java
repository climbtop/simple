/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  6:   */ 
/*  7:   */ public class SpringAbatorJava5DAOTemplate
/*  8:   */   extends SpringAbatorDAOTemplate
/*  9:   */ {
/* 10:   */   public SpringAbatorJava5DAOTemplate()
/* 11:   */   {
/* 12:33 */     Method method = new Method();
/* 13:34 */     method.setConstructor(true);
/* 14:35 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 15:36 */     method.addBodyLine("super();");
/* 16:37 */     setConstructorTemplate(method);
/* 17:38 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.framework.base.dao.ibatis.BaseDaoIbatis");
/* 18:   */     
/* 19:40 */     setSuperClass(fqjt);
/* 20:   */   }
/* 21:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringAbatorJava5DAOTemplate
 * JD-Core Version:    0.7.0.1
 */