/*    1:     */ package org.apache.ibatis.abator.internal.java.model;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.HashMap;
/*    5:     */ import java.util.Iterator;
/*    6:     */ import java.util.List;
/*    7:     */ import java.util.Map;
/*    8:     */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*    9:     */ import org.apache.ibatis.abator.api.GeneratedJavaFile;
/*   10:     */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   11:     */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   12:     */ import org.apache.ibatis.abator.api.ProgressCallback;
/*   13:     */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*   14:     */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   15:     */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   16:     */ import org.apache.ibatis.abator.api.dom.java.InnerClass;
/*   17:     */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*   18:     */ import org.apache.ibatis.abator.api.dom.java.Method;
/*   19:     */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*   20:     */ import org.apache.ibatis.abator.api.dom.java.PrimitiveTypeWrapper;
/*   21:     */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*   22:     */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*   23:     */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   24:     */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*   25:     */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*   26:     */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   27:     */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*   28:     */ 
/*   29:     */ public class JavaModelGeneratorJava2Impl
/*   30:     */   implements JavaModelGenerator
/*   31:     */ {
/*   32:     */   protected List warnings;
/*   33:     */   protected Map properties;
/*   34:     */   protected String targetPackage;
/*   35:     */   protected String targetProject;
/*   36:     */   private Map tableValueMaps;
/*   37:     */   private boolean suppressTypeWarnings;
/*   38:     */   
/*   39:     */   public JavaModelGeneratorJava2Impl()
/*   40:     */   {
/*   41:  98 */     this.tableValueMaps = new HashMap();
/*   42:  99 */     this.properties = new HashMap();
/*   43:     */   }
/*   44:     */   
/*   45:     */   public void addConfigurationProperties(Map properties)
/*   46:     */   {
/*   47: 103 */     this.properties.putAll(properties);
/*   48:     */   }
/*   49:     */   
/*   50:     */   public void addContextProperties(Map properties)
/*   51:     */   {
/*   52: 107 */     this.properties.putAll(properties);
/*   53: 110 */     if ("true".equalsIgnoreCase((String)properties.get("suppressTypeWarnings"))) {
/*   54: 111 */       this.suppressTypeWarnings = true;
/*   55:     */     }
/*   56:     */   }
/*   57:     */   
/*   58:     */   public void setTargetPackage(String targetPackage)
/*   59:     */   {
/*   60: 123 */     this.targetPackage = targetPackage;
/*   61:     */   }
/*   62:     */   
/*   63:     */   private Map getTableValueMap(FullyQualifiedTable table)
/*   64:     */   {
/*   65: 127 */     Map map = (Map)this.tableValueMaps.get(table);
/*   66: 128 */     if (map == null)
/*   67:     */     {
/*   68: 129 */       map = new HashMap();
/*   69: 130 */       this.tableValueMaps.put(table, map);
/*   70:     */     }
/*   71: 133 */     return map;
/*   72:     */   }
/*   73:     */   
/*   74:     */   protected void generateClassParts(IntrospectedTable introspectedTable, Iterator columnDefinitions, TopLevelClass topLevelClass)
/*   75:     */   {
/*   76: 151 */     while (columnDefinitions.hasNext())
/*   77:     */     {
/*   78: 152 */       ColumnDefinition cd = (ColumnDefinition)columnDefinitions.next();
/*   79: 153 */       generateOneFieldClassParts(introspectedTable, cd, topLevelClass);
/*   80:     */     }
/*   81:     */   }
/*   82:     */   
/*   83:     */   protected void generateOneFieldClassParts(IntrospectedTable introspectedTable, ColumnDefinition cd, TopLevelClass topLevelClass)
/*   84:     */   {
/*   85: 158 */     FullyQualifiedTable table = introspectedTable.getTable();
/*   86: 159 */     boolean trimStrings = "true".equalsIgnoreCase((String)this.properties.get("trimStrings"));
/*   87:     */     
/*   88: 161 */     StringBuilder sb = new StringBuilder();
/*   89: 162 */     FullyQualifiedJavaType fqjt = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*   90: 163 */     topLevelClass.addImportedType(fqjt);
/*   91: 164 */     String property = cd.getJavaProperty();
/*   92:     */     
/*   93: 166 */     Field field = new Field();
/*   94: 167 */     field.setVisibility(JavaVisibility.PRIVATE);
/*   95: 168 */     field.setType(fqjt);
/*   96: 169 */     field.setName(property);
/*   97: 170 */     if ((StringUtility.stringHasValue(cd.getDefaultValue())) && (!cd.getDefaultValue().equalsIgnoreCase("CURRENT_TIMESTAMP"))) {
/*   98: 171 */       field.setInitializationString(cd.getDefaultValue());
/*   99: 172 */     } else if ((fqjt == FullyQualifiedJavaType.getDateInstance()) || ("Date".equalsIgnoreCase(fqjt.getBaseShortName()))) {
/*  100: 174 */       field.setInitializationString("null");
/*  101: 175 */     } else if ((fqjt == FullyQualifiedJavaType.getIntInstance()) || ("Integer".equalsIgnoreCase(fqjt.getBaseShortName())) || ("Short".equalsIgnoreCase(fqjt.getBaseShortName()))) {
/*  102: 176 */       field.setInitializationString("0");
/*  103: 177 */     } else if ((fqjt == FullyQualifiedJavaType.getBooleanPrimitiveInstance()) || ("Boolean".equalsIgnoreCase(fqjt.getBaseShortName()))) {
/*  104: 178 */       field.setInitializationString("false");
/*  105: 179 */     } else if ("Long".equalsIgnoreCase(fqjt.getBaseShortName())) {
/*  106: 180 */       field.setInitializationString("0L");
/*  107:     */     }
/*  108: 182 */     field.addComment(table, cd.getColumnName(), cd.getLabel(), cd.getMemo());
/*  109: 183 */     topLevelClass.addField(field);
/*  110:     */     
/*  111: 185 */     Method method = new Method();
/*  112: 186 */     method.addGetterComment(table, cd);
/*  113: 187 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  114: 188 */     method.setReturnType(fqjt);
/*  115: 189 */     method.setName(JavaBeansUtil.getGetterMethodName(property));
/*  116: 190 */     sb.setLength(0);
/*  117: 191 */     sb.append("return ");
/*  118: 192 */     sb.append(property);
/*  119: 193 */     sb.append(';');
/*  120: 194 */     method.addBodyLine(sb.toString());
/*  121: 195 */     topLevelClass.addMethod(method);
/*  122:     */     
/*  123: 197 */     method = new Method();
/*  124: 198 */     method.addSetterComment(table, cd);
/*  125: 199 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  126: 200 */     method.setName(JavaBeansUtil.getSetterMethodName(property));
/*  127: 201 */     method.addParameter(new Parameter(fqjt, property));
/*  128: 203 */     if ((trimStrings) && (cd.isStringColumn()))
/*  129:     */     {
/*  130: 204 */       sb.setLength(0);
/*  131: 205 */       sb.append("if (");
/*  132: 206 */       sb.append(property);
/*  133: 207 */       sb.append(" != null) {");
/*  134: 208 */       method.addBodyLine(sb.toString());
/*  135: 209 */       sb.setLength(0);
/*  136: 210 */       sb.append(property);
/*  137: 211 */       sb.append(" = ");
/*  138: 212 */       sb.append(property);
/*  139: 213 */       sb.append(".trim();");
/*  140: 214 */       method.addBodyLine(sb.toString());
/*  141: 215 */       method.addBodyLine("}");
/*  142:     */     }
/*  143: 218 */     sb.setLength(0);
/*  144: 219 */     sb.append("this.").append(property).append(" = ").append(property).append(';');
/*  145: 220 */     method.addBodyLine(sb.toString());
/*  146: 221 */     topLevelClass.addMethod(method);
/*  147: 223 */     if (cd.getJavaProperty().toLowerCase().indexOf("parentid") > -1)
/*  148:     */     {
/*  149: 224 */       String pkName = "";
/*  150: 225 */       if (introspectedTable.hasPrimaryKeyColumns())
/*  151:     */       {
/*  152: 226 */         ColumnDefinition pk = (ColumnDefinition)introspectedTable.getPrimaryKeyColumns().next();
/*  153: 227 */         pkName = pk.getJavaProperty();
/*  154:     */       }
/*  155: 230 */       method.addBodyLine("if( parentId != null && parentId > 0 ){");
/*  156: 231 */       method.addBodyLine("getParent" + table.getDomainObjectName() + "()." + pkName + " = parentId;");
/*  157: 232 */       method.addBodyLine("}");
/*  158: 233 */       generateParentIdParts(introspectedTable, pkName, topLevelClass);
/*  159:     */     }
/*  160:     */   }
/*  161:     */   
/*  162:     */   private void generateParentIdParts(IntrospectedTable introspectedTable, String pkName, TopLevelClass topLevelClass)
/*  163:     */   {
/*  164: 239 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  165: 240 */     StringBuilder sb = new StringBuilder();
/*  166: 241 */     FullyQualifiedJavaType fqjt = topLevelClass.getType();
/*  167:     */     
/*  168: 243 */     Field field = new Field();
/*  169: 244 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  170: 245 */     field.setType(fqjt);
/*  171: 246 */     String property = "parent" + table.getDomainObjectName();
/*  172: 247 */     field.setName(property);
/*  173: 248 */     field.setInitializationString("null");
/*  174: 249 */     topLevelClass.addField(field);
/*  175:     */     
/*  176: 251 */     Method method = new Method();
/*  177: 252 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  178: 253 */     method.setReturnType(fqjt);
/*  179: 254 */     method.setName(JavaBeansUtil.getGetterMethodName(property));
/*  180: 255 */     sb.setLength(0);
/*  181: 256 */     sb.append("if( ").append(property).append(" == null  && parentId > 0 ){");
/*  182: 257 */     method.addBodyLine(sb.toString());
/*  183: 258 */     sb.setLength(0);
/*  184: 259 */     sb.append(property).append(" = new ").append(table.getDomainObjectName()).append("();");
/*  185: 260 */     method.addBodyLine(sb.toString());
/*  186: 261 */     method.addBodyLine("}");
/*  187: 262 */     sb.setLength(0);
/*  188: 263 */     sb.append("return ").append(property).append(';');
/*  189: 264 */     method.addBodyLine(sb.toString());
/*  190: 265 */     topLevelClass.addMethod(method);
/*  191:     */     
/*  192: 267 */     method = new Method();
/*  193: 268 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  194: 269 */     method.setName(JavaBeansUtil.getSetterMethodName(property));
/*  195: 270 */     method.addParameter(new Parameter(fqjt, property));
/*  196: 271 */     sb.setLength(0);
/*  197: 272 */     sb.append("this.").append(property).append(" = ").append(property).append(';');
/*  198: 273 */     method.addBodyLine(sb.toString());
/*  199: 274 */     method.addBodyLine("if( " + property + "!= null ){");
/*  200: 275 */     method.addBodyLine("parentId = " + property + "." + pkName + ";");
/*  201: 276 */     method.addBodyLine("}");
/*  202:     */     
/*  203: 278 */     topLevelClass.addMethod(method);
/*  204:     */     
/*  205: 280 */     FullyQualifiedJavaType fqjtChild = FullyQualifiedJavaType.getNewListInstance();
/*  206: 281 */     topLevelClass.addImportedType(fqjtChild);
/*  207: 282 */     fqjtChild.addTypeArgument(fqjt);
/*  208: 283 */     field = new Field();
/*  209: 284 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  210: 285 */     field.setType(fqjtChild);
/*  211: 286 */     property = "child" + table.getDomainObjectName() + "List";
/*  212: 287 */     field.setName(property);
/*  213: 288 */     field.setInitializationString("null");
/*  214: 289 */     topLevelClass.addField(field);
/*  215:     */     
/*  216: 291 */     method = new Method();
/*  217: 292 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  218: 293 */     method.setReturnType(fqjtChild);
/*  219: 294 */     method.setName(JavaBeansUtil.getGetterMethodName(property));
/*  220: 295 */     sb.setLength(0);
/*  221: 296 */     sb.append("return ").append(property).append(';');
/*  222: 297 */     method.addBodyLine(sb.toString());
/*  223: 298 */     topLevelClass.addMethod(method);
/*  224:     */     
/*  225: 300 */     method = new Method();
/*  226: 301 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  227: 302 */     method.setName(JavaBeansUtil.getSetterMethodName(property));
/*  228: 303 */     method.addParameter(new Parameter(fqjtChild, property));
/*  229: 304 */     sb.setLength(0);
/*  230: 305 */     sb.append("this.").append(property).append(" = ").append(property).append(';');
/*  231: 306 */     method.addBodyLine(sb.toString());
/*  232: 307 */     topLevelClass.addMethod(method);
/*  233:     */   }
/*  234:     */   
/*  235:     */   protected String getJavaModelPackage(FullyQualifiedTable table)
/*  236:     */   {
/*  237: 318 */     String key = "getJavaModelPackage";
/*  238:     */     
/*  239:     */ 
/*  240: 321 */     Map map = getTableValueMap(table);
/*  241: 322 */     String s = (String)map.get(key);
/*  242: 323 */     if (s == null)
/*  243:     */     {
/*  244: 324 */       if ("true".equals(this.properties.get("enableSubPackages")))
/*  245:     */       {
/*  246: 325 */         StringBuffer sb = new StringBuffer(this.targetPackage);
/*  247: 327 */         if (StringUtility.stringHasValue(table.getCatalog()))
/*  248:     */         {
/*  249: 328 */           sb.append('.');
/*  250: 329 */           sb.append(table.getCatalog().toLowerCase());
/*  251:     */         }
/*  252: 332 */         if (StringUtility.stringHasValue(table.getSchema()))
/*  253:     */         {
/*  254: 333 */           sb.append('.');
/*  255: 334 */           sb.append(table.getSchema().toLowerCase());
/*  256:     */         }
/*  257: 337 */         s = sb.toString();
/*  258:     */       }
/*  259:     */       else
/*  260:     */       {
/*  261: 339 */         s = this.targetPackage;
/*  262:     */       }
/*  263: 342 */       map.put(key, s);
/*  264:     */     }
/*  265: 345 */     return s;
/*  266:     */   }
/*  267:     */   
/*  268:     */   protected CompilationUnit getPrimaryKey(IntrospectedTable introspectedTable)
/*  269:     */   {
/*  270: 350 */     if (!introspectedTable.getRules().generatePrimaryKeyClass()) {
/*  271: 351 */       return null;
/*  272:     */     }
/*  273: 354 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  274: 355 */     FullyQualifiedJavaType type = getPrimaryKeyType(introspectedTable);
/*  275: 356 */     TopLevelClass answer = new TopLevelClass(type);
/*  276: 357 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  277:     */     
/*  278: 359 */     String rootClass = (String)this.properties.get("rootClass");
/*  279: 360 */     if (rootClass != null)
/*  280:     */     {
/*  281: 361 */       answer.setSuperClass(new FullyQualifiedJavaType(rootClass));
/*  282: 362 */       answer.addImportedType(answer.getSuperClass());
/*  283:     */     }
/*  284: 365 */     generateClassParts(introspectedTable, introspectedTable.getPrimaryKeyColumns(), answer);
/*  285:     */     
/*  286: 367 */     return answer;
/*  287:     */   }
/*  288:     */   
/*  289:     */   private void makeSerializabeParts(TopLevelClass answer)
/*  290:     */   {
/*  291: 371 */     answer.addSuperInterface(FullyQualifiedJavaType.getSerializableInstance());
/*  292: 372 */     answer.addImportedType(FullyQualifiedJavaType.getSerializableInstance());
/*  293: 373 */     Field field = new Field();
/*  294: 374 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  295: 375 */     field.setModifierStatic(true);
/*  296: 376 */     field.setModifierFinal(true);
/*  297: 377 */     field.setType(FullyQualifiedJavaType.getLongPrimitiveInstance());
/*  298: 378 */     field.setName("serialVersionUID");
/*  299: 379 */     field.setInitializationString(StringUtility.getRandomLongString());
/*  300: 380 */     answer.addField(field);
/*  301:     */   }
/*  302:     */   
/*  303:     */   protected CompilationUnit getBaseRecord(IntrospectedTable introspectedTable)
/*  304:     */   {
/*  305: 385 */     if (!introspectedTable.getRules().generateBaseRecordClass()) {
/*  306: 386 */       return null;
/*  307:     */     }
/*  308: 389 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  309: 390 */     FullyQualifiedJavaType type = getBaseRecordType(table);
/*  310: 391 */     TopLevelClass answer = new TopLevelClass(type);
/*  311: 392 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  312: 393 */     makeSerializabeParts(answer);
/*  313: 395 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/*  314:     */     {
/*  315: 396 */       answer.setSuperClass(getPrimaryKeyType(introspectedTable));
/*  316:     */     }
/*  317:     */     else
/*  318:     */     {
/*  319: 398 */       String rootClass = (String)this.properties.get("rootClass");
/*  320: 399 */       if (rootClass != null)
/*  321:     */       {
/*  322: 400 */         answer.setSuperClass(new FullyQualifiedJavaType(rootClass));
/*  323: 401 */         answer.addImportedType(answer.getSuperClass());
/*  324:     */       }
/*  325:     */     }
/*  326: 405 */     if ((!introspectedTable.getRules().generatePrimaryKeyClass()) && (introspectedTable.hasPrimaryKeyColumns())) {
/*  327: 406 */       generateClassParts(introspectedTable, introspectedTable.getPrimaryKeyColumns(), answer);
/*  328:     */     }
/*  329: 409 */     generateClassParts(introspectedTable, introspectedTable.getBaseColumns(), answer);
/*  330: 411 */     if ((!introspectedTable.getRules().generateRecordWithBLOBsClass()) && (introspectedTable.hasBLOBColumns())) {
/*  331: 412 */       generateClassParts(introspectedTable, introspectedTable.getBLOBColumns(), answer);
/*  332:     */     }
/*  333: 415 */     return answer;
/*  334:     */   }
/*  335:     */   
/*  336:     */   protected CompilationUnit getRecordWithBLOBs(IntrospectedTable introspectedTable)
/*  337:     */   {
/*  338: 420 */     if (!introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  339: 421 */       return null;
/*  340:     */     }
/*  341: 424 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  342: 425 */     FullyQualifiedJavaType type = getRecordWithBLOBsType(table);
/*  343: 426 */     TopLevelClass answer = new TopLevelClass(type);
/*  344: 427 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  345: 428 */     makeSerializabeParts(answer);
/*  346: 430 */     if (introspectedTable.getRules().generateBaseRecordClass()) {
/*  347: 431 */       answer.setSuperClass(getBaseRecordType(table));
/*  348:     */     } else {
/*  349: 433 */       answer.setSuperClass(getPrimaryKeyType(introspectedTable));
/*  350:     */     }
/*  351: 436 */     generateClassParts(introspectedTable, introspectedTable.getBLOBColumns(), answer);
/*  352:     */     
/*  353: 438 */     return answer;
/*  354:     */   }
/*  355:     */   
/*  356:     */   public void setTargetProject(String targetProject)
/*  357:     */   {
/*  358: 442 */     this.targetProject = targetProject;
/*  359:     */   }
/*  360:     */   
/*  361:     */   public FullyQualifiedJavaType getExampleType(FullyQualifiedTable table)
/*  362:     */   {
/*  363: 453 */     String key = "getExampleType";
/*  364:     */     
/*  365: 455 */     Map map = getTableValueMap(table);
/*  366: 456 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  367: 457 */     if (fqjt == null)
/*  368:     */     {
/*  369: 458 */       StringBuffer sb = new StringBuffer();
/*  370: 459 */       sb.append(getJavaModelPackage(table));
/*  371: 460 */       sb.append('.');
/*  372: 461 */       sb.append(table.getDomainObjectName());
/*  373: 462 */       sb.append("Example");
/*  374:     */       
/*  375: 464 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  376: 465 */       map.put(key, fqjt);
/*  377:     */     }
/*  378: 468 */     return fqjt;
/*  379:     */   }
/*  380:     */   
/*  381:     */   public List getGeneratedJavaFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/*  382:     */   {
/*  383: 480 */     List list = new ArrayList();
/*  384:     */     
/*  385: 482 */     String tableName = introspectedTable.getTable().getFullyQualifiedTableName();
/*  386:     */     
/*  387: 484 */     callback.startSubTask(Messages.getString("Progress.6", 
/*  388: 485 */       tableName));
/*  389: 486 */     CompilationUnit cu = getExample(introspectedTable);
/*  390: 487 */     if (cu != null)
/*  391:     */     {
/*  392: 488 */       GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  393: 489 */       list.add(gjf);
/*  394:     */     }
/*  395: 492 */     callback.startSubTask(Messages.getString("Progress.7", 
/*  396: 493 */       tableName));
/*  397: 494 */     cu = getPrimaryKey(introspectedTable);
/*  398: 495 */     if (cu != null)
/*  399:     */     {
/*  400: 496 */       GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  401: 497 */       list.add(gjf);
/*  402:     */     }
/*  403: 500 */     callback.startSubTask(Messages.getString("Progress.8", 
/*  404: 501 */       tableName));
/*  405: 502 */     cu = getBaseRecord(introspectedTable);
/*  406: 503 */     if (cu != null)
/*  407:     */     {
/*  408: 504 */       GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  409: 505 */       list.add(gjf);
/*  410:     */     }
/*  411: 508 */     callback.startSubTask(Messages.getString("Progress.9", 
/*  412: 509 */       tableName));
/*  413: 510 */     cu = getRecordWithBLOBs(introspectedTable);
/*  414: 511 */     if (cu != null)
/*  415:     */     {
/*  416: 512 */       GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  417: 513 */       list.add(gjf);
/*  418:     */     }
/*  419: 516 */     return list;
/*  420:     */   }
/*  421:     */   
/*  422:     */   public FullyQualifiedJavaType getPrimaryKeyType(IntrospectedTable introspectedTable)
/*  423:     */   {
/*  424: 527 */     String key = "getPrimaryKeyType";
/*  425:     */     
/*  426: 529 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  427: 530 */     Map map = getTableValueMap(table);
/*  428: 531 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  429: 532 */     if (fqjt == null)
/*  430:     */     {
/*  431: 533 */       StringBuffer sb = new StringBuffer();
/*  432: 534 */       sb.append(getJavaModelPackage(table));
/*  433: 535 */       sb.append('.');
/*  434: 536 */       sb.append(table.getDomainObjectName());
/*  435: 538 */       if (introspectedTable.getNonPrimaryKeyColumns().hasNext()) {
/*  436: 539 */         sb.append("Key");
/*  437:     */       }
/*  438: 541 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  439: 542 */       map.put(key, fqjt);
/*  440:     */     }
/*  441: 545 */     return fqjt;
/*  442:     */   }
/*  443:     */   
/*  444:     */   public FullyQualifiedJavaType getBaseRecordType(FullyQualifiedTable table)
/*  445:     */   {
/*  446: 571 */     String key = "getRecordType";
/*  447:     */     
/*  448: 573 */     Map map = getTableValueMap(table);
/*  449: 574 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  450: 575 */     if (fqjt == null)
/*  451:     */     {
/*  452: 576 */       StringBuffer sb = new StringBuffer();
/*  453: 577 */       sb.append(getJavaModelPackage(table));
/*  454: 578 */       sb.append('.');
/*  455: 579 */       sb.append(table.getDomainObjectName());
/*  456:     */       
/*  457: 581 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  458: 582 */       map.put(key, fqjt);
/*  459:     */     }
/*  460: 585 */     return fqjt;
/*  461:     */   }
/*  462:     */   
/*  463:     */   public FullyQualifiedJavaType getRecordWithBLOBsType(FullyQualifiedTable table)
/*  464:     */   {
/*  465: 596 */     String key = "getRecordWithBLOBsType";
/*  466:     */     
/*  467: 598 */     Map map = getTableValueMap(table);
/*  468: 599 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  469: 600 */     if (fqjt == null)
/*  470:     */     {
/*  471: 601 */       StringBuffer sb = new StringBuffer();
/*  472: 602 */       sb.append(getJavaModelPackage(table));
/*  473: 603 */       sb.append('.');
/*  474: 604 */       sb.append(table.getDomainObjectName());
/*  475: 605 */       sb.append("WithBLOBs");
/*  476:     */       
/*  477: 607 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  478: 608 */       map.put(key, fqjt);
/*  479:     */     }
/*  480: 611 */     return fqjt;
/*  481:     */   }
/*  482:     */   
/*  483:     */   public void setWarnings(List warnings)
/*  484:     */   {
/*  485: 622 */     this.warnings = warnings;
/*  486:     */   }
/*  487:     */   
/*  488:     */   protected Method getSetNullMethod(ColumnDefinition cd)
/*  489:     */   {
/*  490: 626 */     return getNoValueMethod(cd, "IsNull", "is null");
/*  491:     */   }
/*  492:     */   
/*  493:     */   protected Method getSetNotNullMethod(ColumnDefinition cd)
/*  494:     */   {
/*  495: 630 */     return getNoValueMethod(cd, "IsNotNull", "is not null");
/*  496:     */   }
/*  497:     */   
/*  498:     */   protected Method getSetEqualMethod(ColumnDefinition cd)
/*  499:     */   {
/*  500: 634 */     return getSingleValueMethod(cd, "EqualTo", "=");
/*  501:     */   }
/*  502:     */   
/*  503:     */   protected Method getSetNotEqualMethod(ColumnDefinition cd)
/*  504:     */   {
/*  505: 638 */     return getSingleValueMethod(cd, "NotEqualTo", "<>");
/*  506:     */   }
/*  507:     */   
/*  508:     */   protected Method getSetGreaterThanMethod(ColumnDefinition cd)
/*  509:     */   {
/*  510: 642 */     return getSingleValueMethod(cd, "GreaterThan", ">");
/*  511:     */   }
/*  512:     */   
/*  513:     */   protected Method getSetGreaterThenOrEqualMethod(ColumnDefinition cd)
/*  514:     */   {
/*  515: 646 */     return getSingleValueMethod(cd, "GreaterThanOrEqualTo", ">=");
/*  516:     */   }
/*  517:     */   
/*  518:     */   protected Method getSetLessThanMethod(ColumnDefinition cd)
/*  519:     */   {
/*  520: 650 */     return getSingleValueMethod(cd, "LessThan", "<");
/*  521:     */   }
/*  522:     */   
/*  523:     */   protected Method getSetLessThanOrEqualMethod(ColumnDefinition cd)
/*  524:     */   {
/*  525: 654 */     return getSingleValueMethod(cd, "LessThanOrEqualTo", "<=");
/*  526:     */   }
/*  527:     */   
/*  528:     */   protected Method getSetLikeMethod(ColumnDefinition cd)
/*  529:     */   {
/*  530: 658 */     return getSingleValueMethod(cd, "Like", "like");
/*  531:     */   }
/*  532:     */   
/*  533:     */   protected Method getSetNotLikeMethod(ColumnDefinition cd)
/*  534:     */   {
/*  535: 662 */     return getSingleValueMethod(cd, "NotLike", "not like");
/*  536:     */   }
/*  537:     */   
/*  538:     */   protected Method getSingleValueMethod(ColumnDefinition cd, String nameFragment, String operator)
/*  539:     */   {
/*  540: 666 */     Method method = new Method();
/*  541: 667 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  542: 668 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value"));
/*  543: 669 */     StringBuffer sb = new StringBuffer();
/*  544: 670 */     sb.append(cd.getJavaProperty());
/*  545: 671 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  546: 672 */     sb.insert(0, "and");
/*  547: 673 */     sb.append(nameFragment);
/*  548: 674 */     method.setName(sb.toString());
/*  549: 675 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  550: 676 */     sb.setLength(0);
/*  551: 678 */     if (cd.isJDBCDateColumn())
/*  552:     */     {
/*  553: 679 */       sb.append("addCriterionForJDBCDate(\"");
/*  554:     */     }
/*  555: 680 */     else if (cd.isJDBCTimeColumn())
/*  556:     */     {
/*  557: 681 */       sb.append("addCriterionForJDBCTime(\"");
/*  558:     */     }
/*  559: 682 */     else if (StringUtility.stringHasValue(cd.getTypeHandler()))
/*  560:     */     {
/*  561: 683 */       sb.append("add");
/*  562: 684 */       sb.append(cd.getJavaProperty());
/*  563: 685 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  564: 686 */       sb.append("Criterion(\"");
/*  565:     */     }
/*  566:     */     else
/*  567:     */     {
/*  568: 688 */       sb.append("addCriterion(\"");
/*  569:     */     }
/*  570: 691 */     sb.append(cd.getAliasedColumnName());
/*  571: 692 */     sb.append(' ');
/*  572: 693 */     sb.append(operator);
/*  573: 694 */     sb.append("\", ");
/*  574: 696 */     if (cd.getResolvedJavaType().getFullyQualifiedJavaType().isPrimitive())
/*  575:     */     {
/*  576: 697 */       sb.append("new ");
/*  577: 698 */       sb.append(cd.getResolvedJavaType().getFullyQualifiedJavaType().getPrimitiveTypeWrapper().getShortName());
/*  578: 699 */       sb.append("(value)");
/*  579:     */     }
/*  580:     */     else
/*  581:     */     {
/*  582: 701 */       sb.append("value");
/*  583:     */     }
/*  584: 704 */     sb.append(", \"");
/*  585: 705 */     sb.append(cd.getJavaProperty());
/*  586: 706 */     sb.append("\");");
/*  587: 707 */     method.addBodyLine(sb.toString());
/*  588: 708 */     method.addBodyLine("return this;");
/*  589:     */     
/*  590: 710 */     return method;
/*  591:     */   }
/*  592:     */   
/*  593:     */   protected Method getNoValueMethod(ColumnDefinition cd, String nameFragment, String operator)
/*  594:     */   {
/*  595: 714 */     Method method = new Method();
/*  596: 715 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  597: 716 */     if ((!(this instanceof JavaModelGeneratorJava5Impl)) && 
/*  598: 717 */       (this.suppressTypeWarnings)) {
/*  599: 718 */       method.addSuppressTypeWarningsAnnotation();
/*  600:     */     }
/*  601: 721 */     StringBuffer sb = new StringBuffer();
/*  602: 722 */     sb.append(cd.getJavaProperty());
/*  603: 723 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  604: 724 */     sb.insert(0, "and");
/*  605: 725 */     sb.append(nameFragment);
/*  606: 726 */     method.setName(sb.toString());
/*  607: 727 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  608: 728 */     sb.setLength(0);
/*  609: 729 */     sb.append("criteriaWithoutValue.add(\"");
/*  610: 730 */     sb.append(cd.getAliasedColumnName());
/*  611: 731 */     sb.append(' ');
/*  612: 732 */     sb.append(operator);
/*  613: 733 */     sb.append("\");");
/*  614: 734 */     method.addBodyLine(sb.toString());
/*  615: 735 */     method.addBodyLine("return this;");
/*  616:     */     
/*  617: 737 */     return method;
/*  618:     */   }
/*  619:     */   
/*  620:     */   protected Method getSetBetweenOrNotBetweenMethod(ColumnDefinition cd, boolean betweenMethod)
/*  621:     */   {
/*  622: 748 */     Method method = new Method();
/*  623: 749 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  624: 750 */     FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*  625:     */     
/*  626: 752 */     method.addParameter(new Parameter(type, "value1"));
/*  627: 753 */     method.addParameter(new Parameter(type, "value2"));
/*  628: 754 */     StringBuffer sb = new StringBuffer();
/*  629: 755 */     sb.append(cd.getJavaProperty());
/*  630: 756 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  631: 757 */     sb.insert(0, "and");
/*  632: 758 */     if (betweenMethod) {
/*  633: 759 */       sb.append("Between");
/*  634:     */     } else {
/*  635: 761 */       sb.append("NotBetween");
/*  636:     */     }
/*  637: 763 */     method.setName(sb.toString());
/*  638: 764 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  639: 765 */     sb.setLength(0);
/*  640: 767 */     if (cd.isJDBCDateColumn())
/*  641:     */     {
/*  642: 768 */       sb.append("addCriterionForJDBCDate(\"");
/*  643:     */     }
/*  644: 769 */     else if (cd.isJDBCTimeColumn())
/*  645:     */     {
/*  646: 770 */       sb.append("addCriterionForJDBCTime(\"");
/*  647:     */     }
/*  648: 771 */     else if (StringUtility.stringHasValue(cd.getTypeHandler()))
/*  649:     */     {
/*  650: 772 */       sb.append("add");
/*  651: 773 */       sb.append(cd.getJavaProperty());
/*  652: 774 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  653: 775 */       sb.append("Criterion(\"");
/*  654:     */     }
/*  655:     */     else
/*  656:     */     {
/*  657: 777 */       sb.append("addCriterion(\"");
/*  658:     */     }
/*  659: 780 */     sb.append(cd.getAliasedColumnName());
/*  660: 781 */     if (betweenMethod) {
/*  661: 782 */       sb.append(" between");
/*  662:     */     } else {
/*  663: 784 */       sb.append(" not between");
/*  664:     */     }
/*  665: 786 */     sb.append("\", ");
/*  666: 787 */     if (cd.getResolvedJavaType().getFullyQualifiedJavaType().isPrimitive())
/*  667:     */     {
/*  668: 788 */       sb.append("new ");
/*  669: 789 */       sb.append(cd.getResolvedJavaType().getFullyQualifiedJavaType().getPrimitiveTypeWrapper().getShortName());
/*  670: 790 */       sb.append("(value1), ");
/*  671: 791 */       sb.append("new ");
/*  672: 792 */       sb.append(cd.getResolvedJavaType().getFullyQualifiedJavaType().getPrimitiveTypeWrapper().getShortName());
/*  673: 793 */       sb.append("(value2)");
/*  674:     */     }
/*  675:     */     else
/*  676:     */     {
/*  677: 795 */       sb.append("value1, value2");
/*  678:     */     }
/*  679: 798 */     sb.append(", \"");
/*  680: 799 */     sb.append(cd.getJavaProperty());
/*  681: 800 */     sb.append("\");");
/*  682: 801 */     method.addBodyLine(sb.toString());
/*  683: 802 */     method.addBodyLine("return this;");
/*  684:     */     
/*  685: 804 */     return method;
/*  686:     */   }
/*  687:     */   
/*  688:     */   protected TopLevelClass getExample(IntrospectedTable introspectedTable)
/*  689:     */   {
/*  690: 808 */     if (!introspectedTable.getRules().generateExampleClass()) {
/*  691: 809 */       return null;
/*  692:     */     }
/*  693: 812 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  694: 813 */     FullyQualifiedJavaType type = getExampleType(table);
/*  695: 814 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*  696: 815 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*  697:     */     
/*  698:     */ 
/*  699: 818 */     Field field = new Field();
/*  700: 819 */     field.addComment(table);
/*  701: 820 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  702: 821 */     field.setType(FullyQualifiedJavaType.getStringInstance());
/*  703: 822 */     field.setName("orderByClause");
/*  704: 823 */     topLevelClass.addField(field);
/*  705:     */     
/*  706: 825 */     Method method = new Method();
/*  707: 826 */     method.addComment(table);
/*  708: 827 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  709: 828 */     method.setName("setOrderByClause");
/*  710: 829 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "orderByClause"));
/*  711: 830 */     method.addBodyLine("this.orderByClause = orderByClause;");
/*  712: 831 */     topLevelClass.addMethod(method);
/*  713:     */     
/*  714: 833 */     method = new Method();
/*  715: 834 */     method.addComment(table);
/*  716: 835 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  717: 836 */     method.setReturnType(FullyQualifiedJavaType.getStringInstance());
/*  718: 837 */     method.setName("getOrderByClause");
/*  719: 838 */     method.addBodyLine("return orderByClause;");
/*  720: 839 */     topLevelClass.addMethod(method);
/*  721:     */     
/*  722:     */ 
/*  723: 842 */     field = new Field();
/*  724: 843 */     field.addComment(table);
/*  725: 844 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  726:     */     
/*  727: 846 */     FullyQualifiedJavaType fqjt = FullyQualifiedJavaType.getNewListInstance();
/*  728:     */     
/*  729: 848 */     field.setType(fqjt);
/*  730: 849 */     field.setName("oredCriteria");
/*  731: 850 */     field.setInitializationString("new ArrayList()");
/*  732: 851 */     topLevelClass.addField(field);
/*  733:     */     
/*  734: 853 */     method = new Method();
/*  735: 854 */     method.addComment(table);
/*  736: 855 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  737: 856 */     method.setReturnType(fqjt);
/*  738: 857 */     method.setName("getOredCriteria");
/*  739: 858 */     method.addBodyLine("return oredCriteria;");
/*  740: 859 */     topLevelClass.addMethod(method);
/*  741:     */     
/*  742: 861 */     method = new Method();
/*  743: 862 */     method.addComment(table);
/*  744: 863 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  745: 864 */     if (this.suppressTypeWarnings) {
/*  746: 865 */       method.addSuppressTypeWarningsAnnotation();
/*  747:     */     }
/*  748: 867 */     method.setName("or");
/*  749: 868 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getCriteriaInstance(), "criteria"));
/*  750: 869 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  751:     */     
/*  752: 871 */     topLevelClass.addMethod(method);
/*  753:     */     
/*  754: 873 */     method = new Method();
/*  755: 874 */     method.addComment(table);
/*  756: 875 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  757: 876 */     if (this.suppressTypeWarnings) {
/*  758: 877 */       method.addSuppressTypeWarningsAnnotation();
/*  759:     */     }
/*  760: 879 */     method.setName("createCriteria");
/*  761: 880 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  762: 881 */     method.addBodyLine("Criteria criteria = new Criteria();");
/*  763: 882 */     method.addBodyLine("if (oredCriteria.size() == 0) {");
/*  764: 883 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  765: 884 */     method.addBodyLine("}");
/*  766: 885 */     method.addBodyLine("return criteria;");
/*  767: 886 */     topLevelClass.addMethod(method);
/*  768:     */     
/*  769:     */ 
/*  770: 889 */     topLevelClass.addInnerClass(getCriteriaInnerClass(topLevelClass, introspectedTable));
/*  771:     */     
/*  772: 891 */     return topLevelClass;
/*  773:     */   }
/*  774:     */   
/*  775:     */   protected InnerClass getCriteriaInnerClass(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*  776:     */   {
/*  777: 898 */     InnerClass answer = new InnerClass(FullyQualifiedJavaType.getCriteriaInstance());
/*  778:     */     
/*  779: 900 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  780: 901 */     answer.setModifierStatic(true);
/*  781: 902 */     answer.addComment(introspectedTable.getTable());
/*  782:     */     
/*  783: 904 */     Method method = new Method();
/*  784: 905 */     method.setVisibility(JavaVisibility.PRIVATE);
/*  785: 906 */     method.setName("Criteria");
/*  786: 907 */     method.setConstructor(true);
/*  787: 908 */     method.addBodyLine("super();");
/*  788: 909 */     method.addBodyLine("criteriaWithoutValue = new ArrayList();");
/*  789: 910 */     method.addBodyLine("criteriaWithSingleValue = new ArrayList();");
/*  790: 911 */     method.addBodyLine("criteriaWithListValue = new ArrayList();");
/*  791: 912 */     method.addBodyLine("criteriaWithBetweenValue = new ArrayList();");
/*  792: 913 */     answer.addMethod(method);
/*  793:     */     
/*  794: 915 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/*  795: 916 */     while (iter.hasNext())
/*  796:     */     {
/*  797: 917 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  798: 919 */       if (StringUtility.stringHasValue(cd.getTypeHandler())) {
/*  799: 920 */         addtypeHandledObjectsAndMethods(cd, method, answer);
/*  800:     */       }
/*  801:     */     }
/*  802: 926 */     topLevelClass.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
/*  803: 927 */     topLevelClass.addImportedType(FullyQualifiedJavaType.getNewListInstance());
/*  804: 928 */     topLevelClass.addImportedType(FullyQualifiedJavaType.getNewHashMapInstance());
/*  805: 929 */     topLevelClass.addImportedType(FullyQualifiedJavaType.getNewArrayListInstance());
/*  806:     */     
/*  807: 931 */     Field field = new Field();
/*  808: 932 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  809: 933 */     FullyQualifiedJavaType listOfStrings = FullyQualifiedJavaType.getNewListInstance();
/*  810: 934 */     field.setType(listOfStrings);
/*  811: 935 */     field.setName("criteriaWithoutValue");
/*  812: 936 */     answer.addField(field);
/*  813:     */     
/*  814: 938 */     method = new Method();
/*  815: 939 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  816: 940 */     method.setReturnType(field.getType());
/*  817: 941 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/*  818: 942 */     method.addBodyLine("return criteriaWithoutValue;");
/*  819: 943 */     answer.addMethod(method);
/*  820:     */     
/*  821: 945 */     FullyQualifiedJavaType listOfMaps = FullyQualifiedJavaType.getNewListInstance();
/*  822:     */     
/*  823: 947 */     field = new Field();
/*  824: 948 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  825: 949 */     field.setType(listOfMaps);
/*  826: 950 */     field.setName("criteriaWithSingleValue");
/*  827: 951 */     answer.addField(field);
/*  828:     */     
/*  829: 953 */     method = new Method();
/*  830: 954 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  831: 955 */     method.setReturnType(field.getType());
/*  832: 956 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/*  833: 957 */     method.addBodyLine("return criteriaWithSingleValue;");
/*  834: 958 */     answer.addMethod(method);
/*  835:     */     
/*  836: 960 */     field = new Field();
/*  837: 961 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  838: 962 */     field.setType(listOfMaps);
/*  839: 963 */     field.setName("criteriaWithListValue");
/*  840: 964 */     answer.addField(field);
/*  841:     */     
/*  842: 966 */     method = new Method();
/*  843: 967 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  844: 968 */     method.setReturnType(field.getType());
/*  845: 969 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/*  846: 970 */     method.addBodyLine("return criteriaWithListValue;");
/*  847: 971 */     answer.addMethod(method);
/*  848:     */     
/*  849: 973 */     field = new Field();
/*  850: 974 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  851: 975 */     field.setType(listOfMaps);
/*  852: 976 */     field.setName("criteriaWithBetweenValue");
/*  853: 977 */     answer.addField(field);
/*  854:     */     
/*  855: 979 */     method = new Method();
/*  856: 980 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  857: 981 */     method.setReturnType(field.getType());
/*  858: 982 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/*  859: 983 */     method.addBodyLine("return criteriaWithBetweenValue;");
/*  860: 984 */     answer.addMethod(method);
/*  861:     */     
/*  862:     */ 
/*  863: 987 */     method = new Method();
/*  864: 988 */     method.setVisibility(JavaVisibility.PRIVATE);
/*  865: 989 */     if (this.suppressTypeWarnings) {
/*  866: 990 */       method.addSuppressTypeWarningsAnnotation();
/*  867:     */     }
/*  868: 992 */     method.setName("addCriterion");
/*  869: 993 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  870: 994 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  871: 995 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  872: 996 */     method.addBodyLine("if (value == null) {");
/*  873: 997 */     method.addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  874: 998 */     method.addBodyLine("}");
/*  875: 999 */     method.addBodyLine("Map map = new HashMap();");
/*  876:1000 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  877:1001 */     method.addBodyLine("map.put(\"value\", value);");
/*  878:1002 */     method.addBodyLine("criteriaWithSingleValue.add(map);");
/*  879:1003 */     answer.addMethod(method);
/*  880:     */     
/*  881:1005 */     FullyQualifiedJavaType listOfObjects = FullyQualifiedJavaType.getNewListInstance();
/*  882:     */     
/*  883:1007 */     method = new Method();
/*  884:1008 */     method.setVisibility(JavaVisibility.PRIVATE);
/*  885:1009 */     if (this.suppressTypeWarnings) {
/*  886:1010 */       method.addSuppressTypeWarningsAnnotation();
/*  887:     */     }
/*  888:1012 */     method.setName("addCriterion");
/*  889:1013 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  890:1014 */     method.addParameter(new Parameter(listOfObjects, "values"));
/*  891:1015 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  892:1016 */     method.addBodyLine("if (values == null || values.size() == 0) {");
/*  893:1017 */     method.addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  894:1018 */     method.addBodyLine("}");
/*  895:1019 */     method.addBodyLine("Map map = new HashMap();");
/*  896:1020 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  897:1021 */     method.addBodyLine("map.put(\"values\", values);");
/*  898:1022 */     method.addBodyLine("criteriaWithListValue.add(map);");
/*  899:1023 */     answer.addMethod(method);
/*  900:     */     
/*  901:1025 */     method = new Method();
/*  902:1026 */     method.setVisibility(JavaVisibility.PRIVATE);
/*  903:1027 */     if (this.suppressTypeWarnings) {
/*  904:1028 */       method.addSuppressTypeWarningsAnnotation();
/*  905:     */     }
/*  906:1030 */     method.setName("addCriterion");
/*  907:1031 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  908:1032 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getObjectInstance(), "value1"));
/*  909:1033 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getObjectInstance(), "value2"));
/*  910:1034 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  911:1035 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/*  912:1036 */     method.addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  913:1037 */     method.addBodyLine("}");
/*  914:1038 */     method.addBodyLine("List list = new ArrayList();");
/*  915:1039 */     method.addBodyLine("list.add(value1);");
/*  916:1040 */     method.addBodyLine("list.add(value2);");
/*  917:1041 */     method.addBodyLine("Map map = new HashMap();");
/*  918:1042 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  919:1043 */     method.addBodyLine("map.put(\"values\", list);");
/*  920:1044 */     method.addBodyLine("criteriaWithBetweenValue.add(map);");
/*  921:1045 */     answer.addMethod(method);
/*  922:     */     
/*  923:1047 */     FullyQualifiedJavaType listOfDates = FullyQualifiedJavaType.getNewListInstance();
/*  924:1049 */     if (introspectedTable.hasJDBCDateColumns())
/*  925:     */     {
/*  926:1050 */       topLevelClass.addImportedType(FullyQualifiedJavaType.getDateInstance());
/*  927:1051 */       topLevelClass.addImportedType(FullyQualifiedJavaType.getNewIteratorInstance());
/*  928:1052 */       method = new Method();
/*  929:1053 */       method.setVisibility(JavaVisibility.PRIVATE);
/*  930:1054 */       method.setName("addCriterionForJDBCDate");
/*  931:1055 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  932:1056 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getDateInstance(), "value"));
/*  933:1057 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  934:1058 */       method.addBodyLine("addCriterion(condition, new java.sql.Date(value.getTime()), property);");
/*  935:1059 */       answer.addMethod(method);
/*  936:     */       
/*  937:1061 */       method = new Method();
/*  938:1062 */       method.setVisibility(JavaVisibility.PRIVATE);
/*  939:1063 */       if (this.suppressTypeWarnings) {
/*  940:1064 */         method.addSuppressTypeWarningsAnnotation();
/*  941:     */       }
/*  942:1066 */       method.setName("addCriterionForJDBCDate");
/*  943:1067 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  944:1068 */       method.addParameter(new Parameter(listOfDates, "values"));
/*  945:1069 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  946:1070 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/*  947:1071 */       method.addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  948:1072 */       method.addBodyLine("}");
/*  949:1073 */       method.addBodyLine("List dateList = new ArrayList();");
/*  950:1074 */       method.addBodyLine("Iterator iter = values.iterator();");
/*  951:1075 */       method.addBodyLine("while (iter.hasNext()) {");
/*  952:1076 */       method.addBodyLine("dateList.add(new java.sql.Date(((Date)iter.next()).getTime()));");
/*  953:1077 */       method.addBodyLine("}");
/*  954:1078 */       method.addBodyLine("addCriterion(condition, dateList, property);");
/*  955:1079 */       answer.addMethod(method);
/*  956:     */       
/*  957:1081 */       method = new Method();
/*  958:1082 */       method.setVisibility(JavaVisibility.PRIVATE);
/*  959:1083 */       method.setName("addCriterionForJDBCDate");
/*  960:1084 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  961:1085 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getDateInstance(), "value1"));
/*  962:1086 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getDateInstance(), "value2"));
/*  963:1087 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  964:1088 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/*  965:1089 */       method.addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  966:1090 */       method.addBodyLine("}");
/*  967:1091 */       method.addBodyLine("addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);");
/*  968:1092 */       answer.addMethod(method);
/*  969:     */     }
/*  970:1095 */     if (introspectedTable.hasJDBCTimeColumns())
/*  971:     */     {
/*  972:1096 */       topLevelClass.addImportedType(FullyQualifiedJavaType.getDateInstance());
/*  973:1097 */       topLevelClass.addImportedType(FullyQualifiedJavaType.getNewIteratorInstance());
/*  974:1098 */       method = new Method();
/*  975:1099 */       method.setVisibility(JavaVisibility.PRIVATE);
/*  976:1100 */       method.setName("addCriterionForJDBCTime");
/*  977:1101 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  978:1102 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getDateInstance(), "value"));
/*  979:1103 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  980:1104 */       method.addBodyLine("addCriterion(condition, new java.sql.Time(value.getTime()), property);");
/*  981:1105 */       answer.addMethod(method);
/*  982:     */       
/*  983:1107 */       method = new Method();
/*  984:1108 */       method.setVisibility(JavaVisibility.PRIVATE);
/*  985:1109 */       if (this.suppressTypeWarnings) {
/*  986:1110 */         method.addSuppressTypeWarningsAnnotation();
/*  987:     */       }
/*  988:1112 */       method.setName("addCriterionForJDBCTime");
/*  989:1113 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  990:1114 */       method.addParameter(new Parameter(listOfDates, "values"));
/*  991:1115 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/*  992:1116 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/*  993:1117 */       method.addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  994:1118 */       method.addBodyLine("}");
/*  995:1119 */       method.addBodyLine("List dateList = new ArrayList();");
/*  996:1120 */       method.addBodyLine("Iterator iter = values.iterator();");
/*  997:1121 */       method.addBodyLine("while (iter.hasNext()) {");
/*  998:1122 */       method.addBodyLine("dateList.add(new java.sql.Time(((Date)iter.next()).getTime()));");
/*  999:1123 */       method.addBodyLine("}");
/* 1000:1124 */       method.addBodyLine("addCriterion(condition, dateList, property);");
/* 1001:1125 */       answer.addMethod(method);
/* 1002:     */       
/* 1003:1127 */       method = new Method();
/* 1004:1128 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 1005:1129 */       method.setName("addCriterionForJDBCTime");
/* 1006:1130 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 1007:1131 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getDateInstance(), "value1"));
/* 1008:1132 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getDateInstance(), "value2"));
/* 1009:1133 */       method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/* 1010:1134 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/* 1011:1135 */       method.addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 1012:1136 */       method.addBodyLine("}");
/* 1013:1137 */       method.addBodyLine("addCriterion(condition, new java.sql.Time(value1.getTime()), new java.sql.Time(value2.getTime()), property);");
/* 1014:1138 */       answer.addMethod(method);
/* 1015:     */     }
/* 1016:1141 */     iter = introspectedTable.getNonBLOBColumns();
/* 1017:1142 */     while (iter.hasNext())
/* 1018:     */     {
/* 1019:1143 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1020:     */       
/* 1021:1145 */       topLevelClass.addImportedType(cd.getResolvedJavaType().getFullyQualifiedJavaType());
/* 1022:     */       
/* 1023:     */ 
/* 1024:     */ 
/* 1025:1149 */       answer.addMethod(getSetNullMethod(cd));
/* 1026:1150 */       answer.addMethod(getSetNotNullMethod(cd));
/* 1027:1151 */       answer.addMethod(getSetEqualMethod(cd));
/* 1028:1152 */       answer.addMethod(getSetNotEqualMethod(cd));
/* 1029:1153 */       answer.addMethod(getSetGreaterThanMethod(cd));
/* 1030:1154 */       answer.addMethod(getSetGreaterThenOrEqualMethod(cd));
/* 1031:1155 */       answer.addMethod(getSetLessThanMethod(cd));
/* 1032:1156 */       answer.addMethod(getSetLessThanOrEqualMethod(cd));
/* 1033:1158 */       if (cd.isJdbcCharacterColumn())
/* 1034:     */       {
/* 1035:1159 */         answer.addMethod(getSetLikeMethod(cd));
/* 1036:1160 */         answer.addMethod(getSetNotLikeMethod(cd));
/* 1037:     */       }
/* 1038:1163 */       answer.addMethod(getSetInOrNotInMethod(cd, true));
/* 1039:1164 */       answer.addMethod(getSetInOrNotInMethod(cd, false));
/* 1040:1165 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(cd, true));
/* 1041:1166 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(cd, false));
/* 1042:     */     }
/* 1043:1169 */     return answer;
/* 1044:     */   }
/* 1045:     */   
/* 1046:     */   protected Method getSetInOrNotInMethod(ColumnDefinition cd, boolean inMethod)
/* 1047:     */   {
/* 1048:1181 */     Method method = new Method();
/* 1049:1182 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1050:1183 */     FullyQualifiedJavaType type = FullyQualifiedJavaType.getNewListInstance();
/* 1051:1184 */     method.addParameter(new Parameter(type, "values"));
/* 1052:1185 */     StringBuffer sb = new StringBuffer();
/* 1053:1186 */     sb.append(cd.getJavaProperty());
/* 1054:1187 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 1055:1188 */     sb.insert(0, "and");
/* 1056:1189 */     if (inMethod) {
/* 1057:1190 */       sb.append("In");
/* 1058:     */     } else {
/* 1059:1192 */       sb.append("NotIn");
/* 1060:     */     }
/* 1061:1194 */     method.setName(sb.toString());
/* 1062:1195 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/* 1063:1196 */     sb.setLength(0);
/* 1064:1198 */     if (cd.isJDBCDateColumn())
/* 1065:     */     {
/* 1066:1199 */       sb.append("addCriterionForJDBCDate(\"");
/* 1067:     */     }
/* 1068:1200 */     else if (cd.isJDBCTimeColumn())
/* 1069:     */     {
/* 1070:1201 */       sb.append("addCriterionForJDBCTime(\"");
/* 1071:     */     }
/* 1072:1202 */     else if (StringUtility.stringHasValue(cd.getTypeHandler()))
/* 1073:     */     {
/* 1074:1203 */       sb.append("add");
/* 1075:1204 */       sb.append(cd.getJavaProperty());
/* 1076:1205 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1077:1206 */       sb.append("Criterion(\"");
/* 1078:     */     }
/* 1079:     */     else
/* 1080:     */     {
/* 1081:1208 */       sb.append("addCriterion(\"");
/* 1082:     */     }
/* 1083:1211 */     sb.append(cd.getAliasedColumnName());
/* 1084:1212 */     if (inMethod) {
/* 1085:1213 */       sb.append(" in");
/* 1086:     */     } else {
/* 1087:1215 */       sb.append(" not in");
/* 1088:     */     }
/* 1089:1217 */     sb.append("\", values, \"");
/* 1090:1218 */     sb.append(cd.getJavaProperty());
/* 1091:1219 */     sb.append("\");");
/* 1092:1220 */     method.addBodyLine(sb.toString());
/* 1093:1221 */     method.addBodyLine("return this;");
/* 1094:     */     
/* 1095:1223 */     return method;
/* 1096:     */   }
/* 1097:     */   
/* 1098:     */   private void addtypeHandledObjectsAndMethods(ColumnDefinition cd, Method constructor, InnerClass innerClass)
/* 1099:     */   {
/* 1100:1235 */     StringBuffer sb = new StringBuffer();
/* 1101:     */     
/* 1102:     */ 
/* 1103:1238 */     FullyQualifiedJavaType listOfMaps = FullyQualifiedJavaType.getNewListInstance();
/* 1104:     */     
/* 1105:1240 */     sb.setLength(0);
/* 1106:1241 */     sb.append(cd.getJavaProperty());
/* 1107:1242 */     sb.append("CriteriaWithSingleValue");
/* 1108:     */     
/* 1109:1244 */     Field field = new Field();
/* 1110:1245 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 1111:1246 */     field.setType(listOfMaps);
/* 1112:1247 */     field.setName(sb.toString());
/* 1113:1248 */     innerClass.addField(field);
/* 1114:     */     
/* 1115:1250 */     Method method = new Method();
/* 1116:1251 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1117:1252 */     method.setReturnType(field.getType());
/* 1118:1253 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 1119:1254 */     sb.insert(0, "return ");
/* 1120:1255 */     sb.append(';');
/* 1121:1256 */     method.addBodyLine(sb.toString());
/* 1122:1257 */     innerClass.addMethod(method);
/* 1123:     */     
/* 1124:1259 */     sb.setLength(0);
/* 1125:1260 */     sb.append(cd.getJavaProperty());
/* 1126:1261 */     sb.append("CriteriaWithListValue");
/* 1127:     */     
/* 1128:1263 */     field = new Field();
/* 1129:1264 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 1130:1265 */     field.setType(listOfMaps);
/* 1131:1266 */     field.setName(sb.toString());
/* 1132:1267 */     innerClass.addField(field);
/* 1133:     */     
/* 1134:1269 */     method = new Method();
/* 1135:1270 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1136:1271 */     method.setReturnType(field.getType());
/* 1137:1272 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 1138:1273 */     sb.insert(0, "return ");
/* 1139:1274 */     sb.append(';');
/* 1140:1275 */     method.addBodyLine(sb.toString());
/* 1141:1276 */     innerClass.addMethod(method);
/* 1142:     */     
/* 1143:1278 */     sb.setLength(0);
/* 1144:1279 */     sb.append(cd.getJavaProperty());
/* 1145:1280 */     sb.append("CriteriaWithBetweenValue");
/* 1146:     */     
/* 1147:1282 */     field = new Field();
/* 1148:1283 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 1149:1284 */     field.setType(listOfMaps);
/* 1150:1285 */     field.setName(sb.toString());
/* 1151:1286 */     innerClass.addField(field);
/* 1152:     */     
/* 1153:1288 */     method = new Method();
/* 1154:1289 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1155:1290 */     method.setReturnType(field.getType());
/* 1156:1291 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 1157:1292 */     sb.insert(0, "return ");
/* 1158:1293 */     sb.append(';');
/* 1159:1294 */     method.addBodyLine(sb.toString());
/* 1160:1295 */     innerClass.addMethod(method);
/* 1161:     */     
/* 1162:     */ 
/* 1163:1298 */     sb.setLength(0);
/* 1164:1299 */     sb.append(cd.getJavaProperty());
/* 1165:1300 */     sb.append("CriteriaWithSingleValue = new ArrayList();");
/* 1166:1301 */     constructor.addBodyLine(sb.toString());
/* 1167:     */     
/* 1168:1303 */     sb.setLength(0);
/* 1169:1304 */     sb.append(cd.getJavaProperty());
/* 1170:1305 */     sb.append("CriteriaWithListValue = new ArrayList();");
/* 1171:1306 */     constructor.addBodyLine(sb.toString());
/* 1172:     */     
/* 1173:1308 */     sb.setLength(0);
/* 1174:1309 */     sb.append(cd.getJavaProperty());
/* 1175:1310 */     sb.append("CriteriaWithBetweenValue = new ArrayList();");
/* 1176:1311 */     constructor.addBodyLine(sb.toString());
/* 1177:     */     
/* 1178:     */ 
/* 1179:1314 */     method = new Method();
/* 1180:1315 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 1181:1316 */     sb.setLength(0);
/* 1182:1317 */     sb.append("add");
/* 1183:1318 */     sb.append(cd.getJavaProperty());
/* 1184:1319 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1185:1320 */     sb.append("Criterion");
/* 1186:     */     
/* 1187:1322 */     method.setName(sb.toString());
/* 1188:1323 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 1189:1324 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value"));
/* 1190:1325 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/* 1191:1326 */     method.addBodyLine("if (value == null) {");
/* 1192:1327 */     method.addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/* 1193:1328 */     method.addBodyLine("}");
/* 1194:1329 */     method.addBodyLine("Map map = new HashMap();");
/* 1195:1330 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 1196:1331 */     method.addBodyLine("map.put(\"value\", value);");
/* 1197:     */     
/* 1198:1333 */     sb.setLength(0);
/* 1199:1334 */     sb.append(cd.getJavaProperty());
/* 1200:1335 */     sb.append("CriteriaWithSingleValue.add(map);");
/* 1201:1336 */     method.addBodyLine(sb.toString());
/* 1202:1337 */     innerClass.addMethod(method);
/* 1203:     */     
/* 1204:1339 */     FullyQualifiedJavaType listOfObjects = FullyQualifiedJavaType.getNewListInstance();
/* 1205:     */     
/* 1206:1341 */     sb.setLength(0);
/* 1207:1342 */     sb.append("add");
/* 1208:1343 */     sb.append(cd.getJavaProperty());
/* 1209:1344 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1210:1345 */     sb.append("Criterion");
/* 1211:     */     
/* 1212:1347 */     method = new Method();
/* 1213:1348 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 1214:1349 */     method.setName(sb.toString());
/* 1215:1350 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 1216:1351 */     method.addParameter(new Parameter(listOfObjects, "values"));
/* 1217:1352 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/* 1218:1353 */     method.addBodyLine("if (values == null || values.size() == 0) {");
/* 1219:1354 */     method.addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/* 1220:1355 */     method.addBodyLine("}");
/* 1221:1356 */     method.addBodyLine("Map map = new HashMap();");
/* 1222:1357 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 1223:1358 */     method.addBodyLine("map.put(\"values\", values);");
/* 1224:     */     
/* 1225:1360 */     sb.setLength(0);
/* 1226:1361 */     sb.append(cd.getJavaProperty());
/* 1227:1362 */     sb.append("CriteriaWithListValue.add(map);");
/* 1228:1363 */     method.addBodyLine(sb.toString());
/* 1229:1364 */     innerClass.addMethod(method);
/* 1230:     */     
/* 1231:1366 */     sb.setLength(0);
/* 1232:1367 */     sb.append("add");
/* 1233:1368 */     sb.append(cd.getJavaProperty());
/* 1234:1369 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1235:1370 */     sb.append("Criterion");
/* 1236:     */     
/* 1237:1372 */     method = new Method();
/* 1238:1373 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 1239:1374 */     method.setName(sb.toString());
/* 1240:1375 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 1241:1376 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value1"));
/* 1242:1377 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value2"));
/* 1243:1378 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(), "property"));
/* 1244:1379 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/* 1245:1380 */     method.addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 1246:1381 */     method.addBodyLine("}");
/* 1247:1382 */     method.addBodyLine("List list = new ArrayList();");
/* 1248:1383 */     method.addBodyLine("list.add(value1);");
/* 1249:1384 */     method.addBodyLine("list.add(value2);");
/* 1250:1385 */     method.addBodyLine("Map map = new HashMap();");
/* 1251:1386 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 1252:1387 */     method.addBodyLine("map.put(\"values\", list);");
/* 1253:     */     
/* 1254:1389 */     sb.setLength(0);
/* 1255:1390 */     sb.append(cd.getJavaProperty());
/* 1256:1391 */     sb.append("CriteriaWithBetweenValue.add(map);");
/* 1257:1392 */     method.addBodyLine(sb.toString());
/* 1258:1393 */     innerClass.addMethod(method);
/* 1259:     */   }
/* 1260:     */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorJava2Impl
 * JD-Core Version:    0.7.0.1
 */