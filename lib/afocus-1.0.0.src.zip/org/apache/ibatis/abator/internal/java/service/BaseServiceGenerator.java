/*    1:     */ package org.apache.ibatis.abator.internal.java.service;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.Arrays;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.Iterator;
/*    7:     */ import java.util.List;
/*    8:     */ import java.util.Map;
/*    9:     */ import org.apache.ibatis.abator.api.DAOGenerator;
/*   10:     */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   11:     */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   12:     */ import org.apache.ibatis.abator.api.GeneratedJavaFile;
/*   13:     */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   14:     */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   15:     */ import org.apache.ibatis.abator.api.ProgressCallback;
/*   16:     */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*   17:     */ import org.apache.ibatis.abator.api.ServiceMethodNameCalculator;
/*   18:     */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*   19:     */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   20:     */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   21:     */ import org.apache.ibatis.abator.api.dom.java.Interface;
/*   22:     */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*   23:     */ import org.apache.ibatis.abator.api.dom.java.Method;
/*   24:     */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*   25:     */ import org.apache.ibatis.abator.api.dom.java.PrimitiveTypeWrapper;
/*   26:     */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*   27:     */ import org.apache.ibatis.abator.config.GeneratedKey;
/*   28:     */ import org.apache.ibatis.abator.internal.AbatorObjectFactory;
/*   29:     */ import org.apache.ibatis.abator.internal.DefaultServiceMethodNameCalculator;
/*   30:     */ import org.apache.ibatis.abator.internal.ExtendedServiceMethodNameCalculator;
/*   31:     */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*   32:     */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   33:     */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*   34:     */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*   35:     */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   36:     */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*   37:     */ 
/*   38:     */ public class BaseServiceGenerator
/*   39:     */   implements ServiceGenerator
/*   40:     */ {
/*   41:     */   protected AbstractServiceTemplate serviceTemplate;
/*   42:     */   protected Map properties;
/*   43:     */   protected List warnings;
/*   44:     */   protected String targetPackage;
/*   45:     */   protected String targetProject;
/*   46:     */   protected JavaModelGenerator javaModelGenerator;
/*   47:     */   protected DAOGenerator daoGenerator;
/*   48:     */   private Map tableValueMaps;
/*   49:     */   private boolean useJava5Features;
/*   50: 111 */   protected JavaVisibility exampleMethodVisibility = JavaVisibility.PUBLIC;
/*   51: 113 */   protected ServiceMethodNameCalculator methodNameCalculator = new DefaultServiceMethodNameCalculator();
/*   52:     */   private DAOMethodNameCalculator daoMethodNameCalculator;
/*   53:     */   
/*   54:     */   public BaseServiceGenerator()
/*   55:     */   {
/*   56: 121 */     this(new AbstractServiceTemplate(), false);
/*   57:     */   }
/*   58:     */   
/*   59:     */   public BaseServiceGenerator(AbstractServiceTemplate serviceTemplate, boolean useJava5Features)
/*   60:     */   {
/*   61: 127 */     this.serviceTemplate = serviceTemplate;
/*   62: 128 */     this.useJava5Features = useJava5Features;
/*   63: 129 */     this.tableValueMaps = new HashMap();
/*   64: 130 */     this.properties = new HashMap();
/*   65:     */   }
/*   66:     */   
/*   67:     */   public void addConfigurationProperties(Map properties)
/*   68:     */   {
/*   69: 135 */     this.properties.putAll(properties);
/*   70: 137 */     if (properties.containsKey("exampleMethodVisibility"))
/*   71:     */     {
/*   72: 138 */       String value = (String)properties.get("exampleMethodVisibility");
/*   73: 140 */       if ("public".equalsIgnoreCase(value)) {
/*   74: 141 */         this.exampleMethodVisibility = JavaVisibility.PUBLIC;
/*   75: 142 */       } else if ("private".equalsIgnoreCase(value)) {
/*   76: 143 */         this.exampleMethodVisibility = JavaVisibility.PRIVATE;
/*   77: 144 */       } else if ("protected".equalsIgnoreCase(value)) {
/*   78: 145 */         this.exampleMethodVisibility = JavaVisibility.PROTECTED;
/*   79: 146 */       } else if ("default".equalsIgnoreCase(value)) {
/*   80: 147 */         this.exampleMethodVisibility = JavaVisibility.DEFAULT;
/*   81:     */       } else {
/*   82: 149 */         this.warnings.add(Messages.getString("Warning.16", value));
/*   83:     */       }
/*   84:     */     }
/*   85: 153 */     if (properties.containsKey("methodNameCalculator"))
/*   86:     */     {
/*   87: 154 */       String value = (String)properties.get("methodNameCalculator");
/*   88: 156 */       if ("extended".equalsIgnoreCase(value)) {
/*   89: 157 */         this.methodNameCalculator = new ExtendedServiceMethodNameCalculator();
/*   90: 158 */       } else if ("simple".equalsIgnoreCase(value)) {
/*   91: 159 */         this.methodNameCalculator = new DefaultServiceMethodNameCalculator();
/*   92: 160 */       } else if ((!"default".equalsIgnoreCase(value)) && 
/*   93: 161 */         (StringUtility.stringHasValue(value))) {
/*   94:     */         try
/*   95:     */         {
/*   96: 163 */           this.methodNameCalculator = ((ServiceMethodNameCalculator)
/*   97: 164 */             AbatorObjectFactory.createObject(value));
/*   98:     */         }
/*   99:     */         catch (Exception e)
/*  100:     */         {
/*  101: 166 */           this.warnings.add(Messages.getString("Warning.17", value, Arrays.deepToString(e.getStackTrace())));
/*  102:     */         }
/*  103:     */       }
/*  104:     */     }
/*  105:     */   }
/*  106:     */   
/*  107:     */   public void setWarnings(List warnings)
/*  108:     */   {
/*  109: 178 */     this.warnings = warnings;
/*  110:     */   }
/*  111:     */   
/*  112:     */   public void setTargetPackage(String targetPackage)
/*  113:     */   {
/*  114: 187 */     this.targetPackage = targetPackage;
/*  115:     */   }
/*  116:     */   
/*  117:     */   public void setTargetProject(String targetProject)
/*  118:     */   {
/*  119: 196 */     this.targetProject = targetProject;
/*  120:     */   }
/*  121:     */   
/*  122:     */   public void setJavaModelGenerator(JavaModelGenerator javaModelGenerator)
/*  123:     */   {
/*  124: 205 */     this.javaModelGenerator = javaModelGenerator;
/*  125:     */   }
/*  126:     */   
/*  127:     */   public void setDaoGenerator(DAOGenerator daoGenerator)
/*  128:     */   {
/*  129: 214 */     this.daoGenerator = daoGenerator;
/*  130: 215 */     this.daoMethodNameCalculator = daoGenerator.getMethodNameCalculator();
/*  131:     */   }
/*  132:     */   
/*  133:     */   public ServiceMethodNameCalculator getMethodNameCalculator()
/*  134:     */   {
/*  135: 222 */     return this.methodNameCalculator;
/*  136:     */   }
/*  137:     */   
/*  138:     */   public void setMethodNameCalculator(ServiceMethodNameCalculator methodNameCalculator)
/*  139:     */   {
/*  140: 229 */     this.methodNameCalculator = methodNameCalculator;
/*  141:     */   }
/*  142:     */   
/*  143:     */   public List getGeneratedJavaFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/*  144:     */   {
/*  145: 240 */     List list = new ArrayList();
/*  146:     */     
/*  147: 242 */     String tableName = introspectedTable.getTable()
/*  148: 243 */       .getFullyQualifiedTableName();
/*  149:     */     
/*  150: 245 */     callback.startSubTask(Messages.getString("Progress.13", 
/*  151: 246 */       tableName));
/*  152: 247 */     CompilationUnit cu = getServiceImplementation(introspectedTable);
/*  153: 248 */     GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  154: 249 */     list.add(gjf);
/*  155:     */     
/*  156: 251 */     callback.startSubTask(Messages.getString("Progress.14", 
/*  157: 252 */       tableName));
/*  158: 253 */     cu = getServiceInterface(introspectedTable);
/*  159: 254 */     gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  160: 255 */     list.add(gjf);
/*  161:     */     
/*  162: 257 */     return list;
/*  163:     */   }
/*  164:     */   
/*  165:     */   public String getDAOPropertyName(FullyQualifiedTable table)
/*  166:     */   {
/*  167: 261 */     String key = "getDAOPropertyName";
/*  168:     */     
/*  169: 263 */     Map map = getTableValueMap(table);
/*  170: 264 */     String property = (String)map.get(key);
/*  171: 265 */     if (property == null)
/*  172:     */     {
/*  173: 266 */       FullyQualifiedJavaType fqjt = this.daoGenerator.getDAOInterfaceType(table);
/*  174: 267 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getBaseShortName());
/*  175: 268 */       map.put(key, property);
/*  176:     */     }
/*  177: 271 */     return property;
/*  178:     */   }
/*  179:     */   
/*  180:     */   protected String getBaseDaoPropertyName(FullyQualifiedTable table)
/*  181:     */   {
/*  182: 275 */     String key = "getBaseDaoPropertyName";
/*  183:     */     
/*  184: 277 */     Map map = getTableValueMap(table);
/*  185: 278 */     String property = (String)map.get(key);
/*  186: 279 */     if (property == null)
/*  187:     */     {
/*  188: 280 */       FullyQualifiedJavaType fqjt = this.daoGenerator.getBaseDAOInterfaceType(table);
/*  189: 281 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getBaseShortName());
/*  190: 282 */       map.put(key, property);
/*  191:     */     }
/*  192: 285 */     return property;
/*  193:     */   }
/*  194:     */   
/*  195:     */   public String getServicePropertyName(FullyQualifiedTable table)
/*  196:     */   {
/*  197: 289 */     String key = "getServicePropertyName";
/*  198:     */     
/*  199: 291 */     Map map = getTableValueMap(table);
/*  200: 292 */     String property = (String)map.get(key);
/*  201: 293 */     if (property == null)
/*  202:     */     {
/*  203: 294 */       FullyQualifiedJavaType fqjt = getServiceInterfaceType(table);
/*  204: 295 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getShortName());
/*  205: 296 */       map.put(key, property);
/*  206:     */     }
/*  207: 299 */     return property;
/*  208:     */   }
/*  209:     */   
/*  210:     */   protected FullyQualifiedJavaType makeDaoPropertyClassParts(FullyQualifiedTable table, TopLevelClass topLevelClass)
/*  211:     */   {
/*  212: 304 */     FullyQualifiedJavaType fqjt = this.daoGenerator.getDAOInterfaceType(table);
/*  213: 305 */     String property = getDAOPropertyName(table);
/*  214: 306 */     Field field = new Field();
/*  215: 307 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  216: 308 */     field.setType(fqjt);
/*  217: 309 */     field.setName(property);
/*  218: 311 */     if (this.useJava5Features) {
/*  219: 312 */       field.addAnnotation("@Resource");
/*  220:     */     }
/*  221: 314 */     topLevelClass.addField(field);
/*  222: 315 */     topLevelClass.addImportedType(fqjt);
/*  223:     */     
/*  224: 317 */     Method method = new Method();
/*  225: 318 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  226: 319 */     method.setReturnType(fqjt);
/*  227: 320 */     method.setName(JavaBeansUtil.getGetterMethodName(property));
/*  228: 321 */     StringBuffer sb = new StringBuffer();
/*  229: 322 */     sb.setLength(0);
/*  230: 323 */     sb.append("return ");
/*  231: 324 */     sb.append(property);
/*  232: 325 */     sb.append(';');
/*  233: 326 */     method.addBodyLine(sb.toString());
/*  234: 329 */     if (this.useJava5Features)
/*  235:     */     {
/*  236: 330 */       FullyQualifiedJavaType baseDao = this.daoGenerator.getBaseDAOInterfaceType(table);
/*  237: 331 */       method = new Method();
/*  238: 332 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  239: 333 */       method.setReturnType(baseDao);
/*  240: 334 */       method.setName(JavaBeansUtil.getGetterMethodName(getBaseDaoPropertyName(table)));
/*  241: 335 */       method.addAnnotation("@Override");
/*  242: 336 */       method.addJavaDocLine("/** Override getBaseDao.**/");
/*  243: 337 */       sb.setLength(0);
/*  244: 338 */       sb.append("return ");
/*  245: 339 */       sb.append(property);
/*  246: 340 */       sb.append(';');
/*  247: 341 */       method.addBodyLine(sb.toString());
/*  248: 342 */       topLevelClass.addMethod(method);
/*  249: 343 */       topLevelClass.addImportedType(baseDao);
/*  250:     */     }
/*  251: 346 */     method = new Method();
/*  252: 347 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  253: 348 */     method.setName(JavaBeansUtil.getSetterMethodName(property));
/*  254: 349 */     method.addParameter(new Parameter(fqjt, property));
/*  255: 350 */     sb.setLength(0);
/*  256: 351 */     sb.append("this.");
/*  257: 352 */     sb.append(property);
/*  258: 353 */     sb.append(" = ");
/*  259: 354 */     sb.append(property);
/*  260: 355 */     sb.append(";");
/*  261: 356 */     method.addBodyLine(sb.toString());
/*  262:     */     
/*  263: 358 */     return fqjt;
/*  264:     */   }
/*  265:     */   
/*  266:     */   protected TopLevelClass getServiceImplementation(IntrospectedTable introspectedTable)
/*  267:     */   {
/*  268: 363 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  269: 364 */     FullyQualifiedJavaType type = getServiceImplementationType(table);
/*  270: 365 */     TopLevelClass answer = new TopLevelClass(type);
/*  271: 366 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  272:     */     
/*  273: 368 */     FullyQualifiedJavaType superClass = new FullyQualifiedJavaType(this.serviceTemplate.getSuperClass().getFullyQualifiedName());
/*  274: 370 */     if (this.useJava5Features)
/*  275:     */     {
/*  276: 371 */       answer.addImportedType(this.javaModelGenerator.getBaseRecordType(table));
/*  277: 372 */       superClass.addTypeArgument(this.javaModelGenerator.getBaseRecordType(table));
/*  278: 373 */       answer.addAnnotation("@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class) ");
/*  279: 374 */       answer.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Transactional"));
/*  280: 375 */       answer.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Propagation"));
/*  281:     */     }
/*  282: 377 */     answer.setSuperClass(superClass);
/*  283: 378 */     answer.addImportedType(superClass);
/*  284: 379 */     answer.addSuperInterface(getServiceInterfaceType(table));
/*  285: 380 */     answer.addImportedType(getServiceInterfaceType(table));
/*  286: 382 */     if (this.useJava5Features) {
/*  287: 383 */       answer.addAnnotation("@Service(\"" + getServicePropertyName(table) + "\")");
/*  288:     */     }
/*  289: 386 */     Iterator iter = this.serviceTemplate.getImplementationImports().iterator();
/*  290: 387 */     while (iter.hasNext()) {
/*  291: 388 */       answer.addImportedType((FullyQualifiedJavaType)iter.next());
/*  292:     */     }
/*  293: 392 */     Method method = this.serviceTemplate.getConstructorClone(
/*  294: 393 */       getServiceImplementationType(table), table);
/*  295: 394 */     answer.addMethod(method);
/*  296:     */     
/*  297:     */ 
/*  298: 397 */     iter = this.serviceTemplate.getFieldClones(table);
/*  299: 398 */     while (iter.hasNext()) {
/*  300: 399 */       answer.addField((Field)iter.next());
/*  301:     */     }
/*  302: 403 */     iter = this.serviceTemplate.getMethodClones(table);
/*  303: 404 */     while (iter.hasNext()) {
/*  304: 405 */       answer.addMethod((Method)iter.next());
/*  305:     */     }
/*  306: 408 */     makeDaoPropertyClassParts(table, answer);
/*  307:     */     
/*  308:     */ 
/*  309:     */ 
/*  310: 412 */     List methods = getExtraMethods(introspectedTable, false, answer);
/*  311: 413 */     if (methods != null)
/*  312:     */     {
/*  313: 414 */       iter = methods.iterator();
/*  314: 415 */       while (iter.hasNext()) {
/*  315: 416 */         answer.addMethod((Method)iter.next());
/*  316:     */       }
/*  317:     */     }
/*  318: 420 */     if (this.useJava5Features) {
/*  319: 421 */       return answer;
/*  320:     */     }
/*  321: 424 */     if (introspectedTable.getRules().generateInsert())
/*  322:     */     {
/*  323: 425 */       methods = getInsertMethods(introspectedTable, false, answer);
/*  324: 426 */       if (methods != null)
/*  325:     */       {
/*  326: 427 */         iter = methods.iterator();
/*  327: 428 */         while (iter.hasNext()) {
/*  328: 429 */           answer.addMethod((Method)iter.next());
/*  329:     */         }
/*  330:     */       }
/*  331:     */     }
/*  332: 434 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs())
/*  333:     */     {
/*  334: 435 */       methods = getUpdateByPrimaryKeyWithoutBLOBsMethods(introspectedTable, false, answer);
/*  335: 436 */       if (methods != null)
/*  336:     */       {
/*  337: 437 */         iter = methods.iterator();
/*  338: 438 */         while (iter.hasNext()) {
/*  339: 439 */           answer.addMethod((Method)iter.next());
/*  340:     */         }
/*  341:     */       }
/*  342:     */     }
/*  343: 444 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs())
/*  344:     */     {
/*  345: 445 */       methods = getUpdateByPrimaryKeyWithBLOBsMethods(introspectedTable, 
/*  346: 446 */         false, answer);
/*  347: 447 */       if (methods != null)
/*  348:     */       {
/*  349: 448 */         iter = methods.iterator();
/*  350: 449 */         while (iter.hasNext()) {
/*  351: 450 */           answer.addMethod((Method)iter.next());
/*  352:     */         }
/*  353:     */       }
/*  354:     */     }
/*  355: 455 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeySelective())
/*  356:     */     {
/*  357: 456 */       methods = getUpdateByPrimaryKeySelectiveMethods(introspectedTable, 
/*  358: 457 */         false, answer);
/*  359: 458 */       if (methods != null)
/*  360:     */       {
/*  361: 459 */         iter = methods.iterator();
/*  362: 460 */         while (iter.hasNext()) {
/*  363: 461 */           answer.addMethod((Method)iter.next());
/*  364:     */         }
/*  365:     */       }
/*  366:     */     }
/*  367: 466 */     if (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs())
/*  368:     */     {
/*  369: 467 */       methods = getSelectByExampleWithoutBLOBsMethods(introspectedTable, false, answer);
/*  370: 468 */       if (methods != null)
/*  371:     */       {
/*  372: 469 */         iter = methods.iterator();
/*  373: 470 */         while (iter.hasNext()) {
/*  374: 471 */           answer.addMethod((Method)iter.next());
/*  375:     */         }
/*  376:     */       }
/*  377:     */     }
/*  378: 476 */     if (introspectedTable.getRules().generateSelectByExampleWithBLOBs())
/*  379:     */     {
/*  380: 477 */       methods = getSelectByExampleWithBLOBsMethods(introspectedTable, false, answer);
/*  381: 478 */       if (methods != null)
/*  382:     */       {
/*  383: 479 */         iter = methods.iterator();
/*  384: 480 */         while (iter.hasNext()) {
/*  385: 481 */           answer.addMethod((Method)iter.next());
/*  386:     */         }
/*  387:     */       }
/*  388:     */     }
/*  389: 486 */     if ((introspectedTable.getRules().generateSelectByExampleWithBLOBs()) || (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()))
/*  390:     */     {
/*  391: 487 */       methods = getSelectCountByExampleMethods(introspectedTable, false, answer);
/*  392: 488 */       if (methods != null)
/*  393:     */       {
/*  394: 489 */         iter = methods.iterator();
/*  395: 490 */         while (iter.hasNext()) {
/*  396: 491 */           answer.addMethod((Method)iter.next());
/*  397:     */         }
/*  398:     */       }
/*  399:     */     }
/*  400: 496 */     if (introspectedTable.getRules().generateSelectByPrimaryKey())
/*  401:     */     {
/*  402: 497 */       methods = getSelectByPrimaryKeyMethods(introspectedTable, false, answer);
/*  403: 498 */       if (methods != null)
/*  404:     */       {
/*  405: 499 */         iter = methods.iterator();
/*  406: 500 */         while (iter.hasNext()) {
/*  407: 501 */           answer.addMethod((Method)iter.next());
/*  408:     */         }
/*  409:     */       }
/*  410:     */     }
/*  411: 506 */     if (introspectedTable.getRules().generateDeleteByExample())
/*  412:     */     {
/*  413: 507 */       methods = getDeleteByExampleMethods(introspectedTable, false, answer);
/*  414: 508 */       if (methods != null)
/*  415:     */       {
/*  416: 509 */         iter = methods.iterator();
/*  417: 510 */         while (iter.hasNext()) {
/*  418: 511 */           answer.addMethod((Method)iter.next());
/*  419:     */         }
/*  420:     */       }
/*  421:     */     }
/*  422: 516 */     if (introspectedTable.getRules().generateDeleteByPrimaryKey())
/*  423:     */     {
/*  424: 517 */       methods = getDeleteByPrimaryKeyMethods(introspectedTable, false, answer);
/*  425: 518 */       if (methods != null)
/*  426:     */       {
/*  427: 519 */         iter = methods.iterator();
/*  428: 520 */         while (iter.hasNext()) {
/*  429: 521 */           answer.addMethod((Method)iter.next());
/*  430:     */         }
/*  431:     */       }
/*  432:     */     }
/*  433: 526 */     return answer;
/*  434:     */   }
/*  435:     */   
/*  436:     */   private Method getGetAllParentListMethod(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit, FullyQualifiedJavaType returnType, String selectByExampleMethodName)
/*  437:     */   {
/*  438: 540 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  439: 541 */     Method method = new Method();
/*  440: 542 */     method.addComment(table);
/*  441: 543 */     method.setVisibility(this.exampleMethodVisibility);
/*  442: 544 */     method.setReturnType(returnType);
/*  443: 545 */     method.setName("getAllParentList");
/*  444:     */     
/*  445: 547 */     Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  446: 548 */     String pkProperty = "";
/*  447: 549 */     if (iter.hasNext())
/*  448:     */     {
/*  449: 550 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  450: 551 */       FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*  451: 552 */       compilationUnit.addImportedType(type);
/*  452: 553 */       method.addParameter(new Parameter(type, cd.getJavaProperty()));
/*  453: 554 */       pkProperty = cd.getJavaProperty();
/*  454:     */     }
/*  455: 557 */     iter = this.serviceTemplate.getCheckedExceptions().iterator();
/*  456: 558 */     while (iter.hasNext())
/*  457:     */     {
/*  458: 559 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  459: 560 */       method.addException(fqjt);
/*  460: 561 */       compilationUnit.addImportedType(fqjt);
/*  461:     */     }
/*  462: 563 */     if (!interfaceMethod)
/*  463:     */     {
/*  464: 566 */       StringBuffer sb = new StringBuffer();
/*  465: 567 */       FullyQualifiedJavaType type = FullyQualifiedJavaType.getNewMapInstance();
/*  466: 568 */       compilationUnit.addImportedType(type);
/*  467: 569 */       type = FullyQualifiedJavaType.getNewHashMapInstance();
/*  468: 570 */       compilationUnit.addImportedType(type);
/*  469: 572 */       if (this.useJava5Features) {
/*  470: 573 */         method.addBodyLine("Map<String,Object> params = new HashMap<String,Object>(); ");
/*  471:     */       } else {
/*  472: 576 */         method.addBodyLine("Map params = new HashMap(); ");
/*  473:     */       }
/*  474: 578 */       sb.setLength(0);
/*  475: 579 */       sb.append("params.put( \"").append(JavaBeansUtil.getPrefixProperty("eq", pkProperty));
/*  476: 580 */       sb.append("AsChildId\", ").append(pkProperty).append(");");
/*  477: 581 */       method.addBodyLine(sb.toString());
/*  478:     */       
/*  479: 583 */       sb.setLength(0);
/*  480: 584 */       sb.append("return ");
/*  481: 585 */       sb.append(selectByExampleMethodName);
/*  482: 586 */       sb.append("( params, 1, 1000, false );");
/*  483: 587 */       method.addBodyLine(sb.toString());
/*  484:     */     }
/*  485: 590 */     return method;
/*  486:     */   }
/*  487:     */   
/*  488:     */   private Method getGetAllChildListMethod(IntrospectedTable introspectedTable, boolean interfaceMethod, FullyQualifiedJavaType returnType, String selectByExampleMethodName)
/*  489:     */   {
/*  490: 595 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  491:     */     
/*  492: 597 */     Method method = new Method();
/*  493: 598 */     method.addComment(table);
/*  494: 599 */     method.setVisibility(this.exampleMethodVisibility);
/*  495: 600 */     method.setReturnType(returnType);
/*  496: 601 */     method.setName("getAllChildList");
/*  497:     */     
/*  498: 603 */     Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  499: 604 */     String pkProperty = "";
/*  500: 605 */     if (iter.hasNext())
/*  501:     */     {
/*  502: 606 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  503: 607 */       FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*  504: 608 */       method.addParameter(new Parameter(type, cd.getJavaProperty() + ", int pageNum, int numPerPage"));
/*  505: 609 */       pkProperty = cd.getJavaProperty();
/*  506:     */     }
/*  507: 612 */     if (!interfaceMethod)
/*  508:     */     {
/*  509: 615 */       StringBuffer sb = new StringBuffer();
/*  510: 617 */       if (this.useJava5Features) {
/*  511: 618 */         method.addBodyLine("Map<String,Object> params = new HashMap<String,Object>(); ");
/*  512:     */       } else {
/*  513: 621 */         method.addBodyLine("Map params = new HashMap(); ");
/*  514:     */       }
/*  515: 623 */       sb.setLength(0);
/*  516: 624 */       sb.append("params.put( \"").append(JavaBeansUtil.getPrefixProperty("eq", pkProperty));
/*  517: 625 */       sb.append("AsParentId\", ").append(pkProperty).append(");");
/*  518: 626 */       method.addBodyLine(sb.toString());
/*  519:     */       
/*  520: 628 */       sb.setLength(0);
/*  521: 629 */       sb.append("return ");
/*  522: 630 */       sb.append(selectByExampleMethodName);
/*  523: 631 */       sb.append("( params, pageNum, numPerPage, true );");
/*  524: 632 */       method.addBodyLine(sb.toString());
/*  525:     */     }
/*  526: 635 */     return method;
/*  527:     */   }
/*  528:     */   
/*  529:     */   private Method getGetAllTopLevelListMethod(IntrospectedTable introspectedTable, boolean interfaceMethod, FullyQualifiedJavaType returnType, String selectByExampleMethodName)
/*  530:     */   {
/*  531: 640 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  532:     */     
/*  533: 642 */     Method method = new Method();
/*  534: 643 */     method.addComment(table);
/*  535: 644 */     method.setVisibility(this.exampleMethodVisibility);
/*  536: 645 */     method.setReturnType(returnType);
/*  537: 646 */     method.setName("getAllTopLevelList");
/*  538:     */     
/*  539: 648 */     Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  540: 649 */     String pkProperty = "";
/*  541: 650 */     if (iter.hasNext())
/*  542:     */     {
/*  543: 651 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  544: 652 */       pkProperty = cd.getJavaProperty();
/*  545:     */     }
/*  546: 655 */     if (!interfaceMethod)
/*  547:     */     {
/*  548: 658 */       StringBuffer sb = new StringBuffer();
/*  549: 660 */       if (this.useJava5Features) {
/*  550: 661 */         method.addBodyLine("Map<String,Object> params = new HashMap<String,Object>(); ");
/*  551:     */       } else {
/*  552: 664 */         method.addBodyLine("Map params = new HashMap(); ");
/*  553:     */       }
/*  554: 666 */       method.addBodyLine("params.put( \"eqParentId\", 0 );");
/*  555:     */       
/*  556: 668 */       sb.setLength(0);
/*  557: 669 */       sb.append("return ");
/*  558: 670 */       sb.append(selectByExampleMethodName);
/*  559: 671 */       sb.append("( params, 1, 1000, false );");
/*  560: 672 */       method.addBodyLine(sb.toString());
/*  561:     */     }
/*  562: 675 */     return method;
/*  563:     */   }
/*  564:     */   
/*  565:     */   private Method getOverrideDeleteByIdMethod(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  566:     */   {
/*  567: 679 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  568: 680 */     compilationUnit.addImportedType(new FullyQualifiedJavaType("com.afocus.framework.exception.BusinessRuntimeException"));
/*  569:     */     
/*  570: 682 */     Method method = new Method();
/*  571: 683 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  572: 684 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  573: 685 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getObjectInstance(), "id"));
/*  574: 686 */     method.setName("delete");
/*  575: 687 */     method.addAnnotation("@Override");
/*  576:     */     
/*  577: 689 */     method.addBodyLine("Map<String,Object> params = new HashMap<String,Object>(); ");
/*  578: 690 */     method.addBodyLine("params.put( \"eqParentId\", id );");
/*  579: 691 */     method.addBodyLine("int count = " + getDAOPropertyName(table) + ".selectCountByMap( params );");
/*  580: 692 */     method.addBodyLine("if( count > 0 ){");
/*  581: 693 */     method.addBodyLine("throw new BusinessRuntimeException( \"error." + getRecordPropertyName(table) + ".has.child" + table.getDomainObjectName() + "\" );");
/*  582: 694 */     method.addBodyLine("}");
/*  583: 695 */     method.addBodyLine("return " + getDAOPropertyName(table) + ".deleteById( id );");
/*  584:     */     
/*  585: 697 */     return method;
/*  586:     */   }
/*  587:     */   
/*  588:     */   private Method getOverrideDeleteByMapMethod(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  589:     */   {
/*  590: 701 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  591: 702 */     compilationUnit.addImportedType(new FullyQualifiedJavaType("com.afocus.framework.exception.BusinessRuntimeException"));
/*  592: 703 */     FullyQualifiedJavaType type = FullyQualifiedJavaType.getNewMapInstance();
/*  593: 704 */     type.addTypeArgument(FullyQualifiedJavaType.getStringInstance());
/*  594: 705 */     type.addTypeArgument(FullyQualifiedJavaType.getObjectInstance());
/*  595: 706 */     compilationUnit.addImportedType(type);
/*  596:     */     
/*  597: 708 */     Method method = new Method();
/*  598: 709 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  599: 710 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  600: 711 */     method.addParameter(new Parameter(type, "param"));
/*  601: 712 */     method.setName("delete");
/*  602: 713 */     method.addAnnotation("@Override");
/*  603:     */     
/*  604: 715 */     method.addBodyLine("Map<String,Object> countparams = new HashMap<String,Object>(); ");
/*  605: 716 */     method.addBodyLine("if( param.containsKey( \"eq" + table.getDomainObjectName() + "Id\" ) ){");
/*  606: 717 */     method.addBodyLine("countparams.put( \"eqParentId\", param.get( \"eq" + table.getDomainObjectName() + "Id\" ) );");
/*  607: 718 */     method.addBodyLine("}");
/*  608:     */     
/*  609: 720 */     method.addBodyLine("if( param.containsKey( \"in" + table.getDomainObjectName() + "Ids\" ) ){");
/*  610: 721 */     method.addBodyLine("countparams.put( \"inParentIds\", param.get( \"in" + table.getDomainObjectName() + "Ids\" ) );");
/*  611: 722 */     method.addBodyLine("}");
/*  612:     */     
/*  613: 724 */     method.addBodyLine("if( param.containsKey( \"in" + table.getDomainObjectName() + "IdList\" ) ){");
/*  614: 725 */     method.addBodyLine("countparams.put( \"inParentIdList\", param.get( \"in" + table.getDomainObjectName() + "IdList\" ) );");
/*  615: 726 */     method.addBodyLine("}");
/*  616:     */     
/*  617: 728 */     method.addBodyLine("if( countparams.size() > 0 ){");
/*  618: 729 */     method.addBodyLine("int count = " + getDAOPropertyName(table) + ".selectCountByMap( countparams );");
/*  619: 730 */     method.addBodyLine("if( count > 0 ){");
/*  620: 731 */     method.addBodyLine("throw new BusinessRuntimeException( \"error." + getRecordPropertyName(table) + ".has.child" + table.getDomainObjectName() + "\" );");
/*  621: 732 */     method.addBodyLine("}");
/*  622: 733 */     method.addBodyLine("}");
/*  623: 734 */     method.addBodyLine("return " + getDAOPropertyName(table) + ".deleteByMap( param );");
/*  624:     */     
/*  625: 736 */     return method;
/*  626:     */   }
/*  627:     */   
/*  628:     */   protected List getExtraMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  629:     */   {
/*  630: 741 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  631: 742 */       return null;
/*  632:     */     }
/*  633: 744 */     if (!introspectedTable.hasParentIdColumn()) {
/*  634: 745 */       return null;
/*  635:     */     }
/*  636: 747 */     FullyQualifiedJavaType returnType = getSelectByExampleReturnListJavaType();
/*  637:     */     
/*  638: 749 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  639: 750 */     String selectByExampleMethodName = this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable);
/*  640: 751 */     if (this.useJava5Features)
/*  641:     */     {
/*  642: 752 */       FullyQualifiedJavaType fqjt = this.javaModelGenerator.getBaseRecordType(table);
/*  643: 753 */       compilationUnit.addImportedType(fqjt);
/*  644: 754 */       returnType.addTypeArgument(fqjt);
/*  645: 755 */       selectByExampleMethodName = "getList";
/*  646:     */     }
/*  647: 757 */     compilationUnit.addImportedType(returnType);
/*  648:     */     
/*  649: 759 */     ArrayList answer = new ArrayList();
/*  650: 760 */     Method method = getGetAllParentListMethod(introspectedTable, interfaceMethod, compilationUnit, returnType, selectByExampleMethodName);
/*  651: 761 */     answer.add(method);
/*  652:     */     
/*  653: 763 */     method = getGetAllChildListMethod(introspectedTable, interfaceMethod, returnType, selectByExampleMethodName);
/*  654: 764 */     answer.add(method);
/*  655:     */     
/*  656: 766 */     method = getGetAllTopLevelListMethod(introspectedTable, interfaceMethod, returnType, selectByExampleMethodName);
/*  657: 767 */     answer.add(method);
/*  658: 769 */     if (!interfaceMethod)
/*  659:     */     {
/*  660: 770 */       method = getOverrideDeleteByIdMethod(introspectedTable, compilationUnit);
/*  661: 771 */       answer.add(method);
/*  662:     */       
/*  663: 773 */       method = getOverrideDeleteByMapMethod(introspectedTable, compilationUnit);
/*  664: 774 */       answer.add(method);
/*  665:     */     }
/*  666: 777 */     return answer;
/*  667:     */   }
/*  668:     */   
/*  669:     */   protected Interface getServiceInterface(IntrospectedTable introspectedTable)
/*  670:     */   {
/*  671: 782 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  672: 783 */     Interface answer = new Interface(getServiceInterfaceType(table));
/*  673: 784 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  674: 786 */     if (this.properties.containsKey("rootInterface"))
/*  675:     */     {
/*  676: 787 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  677: 788 */         (String)this.properties.get("rootInterface"));
/*  678: 789 */       if (this.useJava5Features)
/*  679:     */       {
/*  680: 790 */         fqjt.addTypeArgument(this.javaModelGenerator.getBaseRecordType(table));
/*  681: 791 */         answer.addImportedType(this.javaModelGenerator.getBaseRecordType(table));
/*  682:     */       }
/*  683: 793 */       answer.addSuperInterface(fqjt);
/*  684: 794 */       answer.addImportedType(fqjt);
/*  685:     */     }
/*  686: 797 */     Iterator iter = this.serviceTemplate.getInterfaceImports().iterator();
/*  687: 798 */     while (iter.hasNext()) {
/*  688: 799 */       answer.addImportedType((FullyQualifiedJavaType)iter.next());
/*  689:     */     }
/*  690: 804 */     List methods = getExtraMethods(introspectedTable, true, answer);
/*  691: 805 */     if (methods != null)
/*  692:     */     {
/*  693: 806 */       iter = methods.iterator();
/*  694: 807 */       while (iter.hasNext()) {
/*  695: 808 */         answer.addMethod((Method)iter.next());
/*  696:     */       }
/*  697:     */     }
/*  698: 812 */     if (this.useJava5Features) {
/*  699: 813 */       return answer;
/*  700:     */     }
/*  701: 816 */     if (introspectedTable.getRules().generateInsert())
/*  702:     */     {
/*  703: 817 */       methods = getInsertMethods(introspectedTable, true, answer);
/*  704: 818 */       if (methods != null)
/*  705:     */       {
/*  706: 819 */         iter = methods.iterator();
/*  707: 820 */         while (iter.hasNext()) {
/*  708: 821 */           answer.addMethod((Method)iter.next());
/*  709:     */         }
/*  710:     */       }
/*  711:     */     }
/*  712: 826 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs())
/*  713:     */     {
/*  714: 827 */       methods = getUpdateByPrimaryKeyWithoutBLOBsMethods(introspectedTable, true, answer);
/*  715: 828 */       if (methods != null)
/*  716:     */       {
/*  717: 829 */         iter = methods.iterator();
/*  718: 830 */         while (iter.hasNext()) {
/*  719: 831 */           answer.addMethod((Method)iter.next());
/*  720:     */         }
/*  721:     */       }
/*  722:     */     }
/*  723: 836 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs())
/*  724:     */     {
/*  725: 837 */       methods = getUpdateByPrimaryKeyWithBLOBsMethods(introspectedTable, 
/*  726: 838 */         true, answer);
/*  727: 839 */       if (methods != null)
/*  728:     */       {
/*  729: 840 */         iter = methods.iterator();
/*  730: 841 */         while (iter.hasNext()) {
/*  731: 842 */           answer.addMethod((Method)iter.next());
/*  732:     */         }
/*  733:     */       }
/*  734:     */     }
/*  735: 847 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeySelective())
/*  736:     */     {
/*  737: 848 */       methods = getUpdateByPrimaryKeySelectiveMethods(introspectedTable, 
/*  738: 849 */         true, answer);
/*  739: 850 */       if (methods != null)
/*  740:     */       {
/*  741: 851 */         iter = methods.iterator();
/*  742: 852 */         while (iter.hasNext()) {
/*  743: 853 */           answer.addMethod((Method)iter.next());
/*  744:     */         }
/*  745:     */       }
/*  746:     */     }
/*  747: 858 */     if (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs())
/*  748:     */     {
/*  749: 859 */       methods = getSelectByExampleWithoutBLOBsMethods(introspectedTable, true, answer);
/*  750: 860 */       if (methods != null)
/*  751:     */       {
/*  752: 861 */         iter = methods.iterator();
/*  753: 862 */         while (iter.hasNext()) {
/*  754: 863 */           answer.addMethod((Method)iter.next());
/*  755:     */         }
/*  756:     */       }
/*  757:     */     }
/*  758: 868 */     if (introspectedTable.getRules().generateSelectByExampleWithBLOBs())
/*  759:     */     {
/*  760: 869 */       methods = getSelectByExampleWithBLOBsMethods(introspectedTable, true, answer);
/*  761: 870 */       if (methods != null)
/*  762:     */       {
/*  763: 871 */         iter = methods.iterator();
/*  764: 872 */         while (iter.hasNext()) {
/*  765: 873 */           answer.addMethod((Method)iter.next());
/*  766:     */         }
/*  767:     */       }
/*  768:     */     }
/*  769: 878 */     if ((introspectedTable.getRules().generateSelectByExampleWithBLOBs()) || (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()))
/*  770:     */     {
/*  771: 879 */       methods = getSelectCountByExampleMethods(introspectedTable, true, answer);
/*  772: 880 */       if (methods != null)
/*  773:     */       {
/*  774: 881 */         iter = methods.iterator();
/*  775: 882 */         while (iter.hasNext()) {
/*  776: 883 */           answer.addMethod((Method)iter.next());
/*  777:     */         }
/*  778:     */       }
/*  779:     */     }
/*  780: 888 */     if (introspectedTable.getRules().generateSelectByPrimaryKey())
/*  781:     */     {
/*  782: 889 */       methods = getSelectByPrimaryKeyMethods(introspectedTable, true, answer);
/*  783: 890 */       if (methods != null)
/*  784:     */       {
/*  785: 891 */         iter = methods.iterator();
/*  786: 892 */         while (iter.hasNext()) {
/*  787: 893 */           answer.addMethod((Method)iter.next());
/*  788:     */         }
/*  789:     */       }
/*  790:     */     }
/*  791: 898 */     if (introspectedTable.getRules().generateDeleteByExample())
/*  792:     */     {
/*  793: 899 */       methods = getDeleteByExampleMethods(introspectedTable, true, answer);
/*  794: 900 */       if (methods != null)
/*  795:     */       {
/*  796: 901 */         iter = methods.iterator();
/*  797: 902 */         while (iter.hasNext()) {
/*  798: 903 */           answer.addMethod((Method)iter.next());
/*  799:     */         }
/*  800:     */       }
/*  801:     */     }
/*  802: 908 */     if (introspectedTable.getRules().generateDeleteByPrimaryKey())
/*  803:     */     {
/*  804: 909 */       methods = getDeleteByPrimaryKeyMethods(introspectedTable, true, answer);
/*  805: 910 */       if (methods != null)
/*  806:     */       {
/*  807: 911 */         iter = methods.iterator();
/*  808: 912 */         while (iter.hasNext()) {
/*  809: 913 */           answer.addMethod((Method)iter.next());
/*  810:     */         }
/*  811:     */       }
/*  812:     */     }
/*  813: 918 */     return answer;
/*  814:     */   }
/*  815:     */   
/*  816:     */   public FullyQualifiedJavaType getServiceImplementationType(FullyQualifiedTable table)
/*  817:     */   {
/*  818: 923 */     String key = "getServiceImplementationType";
/*  819:     */     
/*  820: 925 */     Map map = getTableValueMap(table);
/*  821: 926 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  822: 927 */     if (fqjt == null)
/*  823:     */     {
/*  824: 928 */       StringBuffer sb = new StringBuffer();
/*  825: 929 */       sb.append(getServicePackage(table));
/*  826: 930 */       sb.append(".impl.");
/*  827: 931 */       sb.append(table.getDomainObjectName());
/*  828: 932 */       sb.append("ServiceImpl");
/*  829:     */       
/*  830: 934 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  831: 935 */       map.put(key, fqjt);
/*  832:     */     }
/*  833: 938 */     return fqjt;
/*  834:     */   }
/*  835:     */   
/*  836:     */   protected List getInsertMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  837:     */   {
/*  838: 944 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  839: 945 */     Method method = new Method();
/*  840: 946 */     method.addComment(table);
/*  841:     */     FullyQualifiedJavaType returnType;
/*  842: 949 */     if (introspectedTable.getGeneratedKey() != null)
/*  843:     */     {
/*  844: 950 */       ColumnDefinition cd = introspectedTable.getColumn(
/*  845: 951 */         introspectedTable.getGeneratedKey().getColumn());
/*  846:     */       FullyQualifiedJavaType returnType;
/*  847: 952 */       if (cd == null)
/*  848:     */       {
/*  849: 956 */         returnType = null;
/*  850:     */       }
/*  851:     */       else
/*  852:     */       {
/*  853: 958 */         FullyQualifiedJavaType returnType = cd.getResolvedJavaType()
/*  854: 959 */           .getFullyQualifiedJavaType();
/*  855: 960 */         compilationUnit.addImportedType(returnType);
/*  856:     */       }
/*  857:     */     }
/*  858:     */     else
/*  859:     */     {
/*  860: 963 */       returnType = null;
/*  861:     */     }
/*  862: 965 */     method.setReturnType(returnType);
/*  863: 966 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  864: 967 */     method.setName(this.methodNameCalculator.getInsertMethodName(introspectedTable));
/*  865:     */     
/*  866: 969 */     FullyQualifiedJavaType parameterType = 
/*  867: 970 */       introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/*  868:     */     
/*  869: 972 */     compilationUnit.addImportedType(parameterType);
/*  870: 973 */     method.addParameter(new Parameter(parameterType, "record"));
/*  871:     */     
/*  872: 975 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/*  873: 976 */     while (iter.hasNext())
/*  874:     */     {
/*  875: 977 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  876: 978 */       method.addException(fqjt);
/*  877: 979 */       compilationUnit.addImportedType(fqjt);
/*  878:     */     }
/*  879: 982 */     if (!interfaceMethod)
/*  880:     */     {
/*  881: 984 */       StringBuffer sb = new StringBuffer();
/*  882: 986 */       if (returnType != null) {
/*  883: 987 */         sb.append("Object newKey = ");
/*  884:     */       }
/*  885: 990 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getInsertMethodName(introspectedTable));
/*  886: 991 */       sb.append("( record ); ");
/*  887: 992 */       method.addBodyLine(sb.toString());
/*  888: 994 */       if (returnType != null) {
/*  889: 995 */         if ("Object".equals(returnType.getShortName()))
/*  890:     */         {
/*  891: 997 */           method.addBodyLine("return newKey;");
/*  892:     */         }
/*  893:     */         else
/*  894:     */         {
/*  895: 999 */           sb.setLength(0);
/*  896:1001 */           if (returnType.isPrimitive())
/*  897:     */           {
/*  898:1002 */             PrimitiveTypeWrapper ptw = returnType
/*  899:1003 */               .getPrimitiveTypeWrapper();
/*  900:1004 */             sb.append("return ((");
/*  901:1005 */             sb.append(ptw.getShortName());
/*  902:1006 */             sb.append(") newKey");
/*  903:1007 */             sb.append(").");
/*  904:1008 */             sb.append(ptw.getToPrimitiveMethod());
/*  905:1009 */             sb.append(';');
/*  906:     */           }
/*  907:     */           else
/*  908:     */           {
/*  909:1011 */             sb.append("return (");
/*  910:1012 */             sb.append(returnType.getShortName());
/*  911:1013 */             sb.append(") newKey;");
/*  912:     */           }
/*  913:1016 */           method.addBodyLine(sb.toString());
/*  914:     */         }
/*  915:     */       }
/*  916:     */     }
/*  917:1021 */     List answer = new ArrayList();
/*  918:1022 */     answer.add(method);
/*  919:     */     
/*  920:1024 */     return answer;
/*  921:     */   }
/*  922:     */   
/*  923:     */   protected List getUpdateByPrimaryKeyWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  924:     */   {
/*  925:1031 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  926:1032 */     FullyQualifiedJavaType parameterType = 
/*  927:1033 */       this.javaModelGenerator.getBaseRecordType(table);
/*  928:1034 */     compilationUnit.addImportedType(parameterType);
/*  929:     */     
/*  930:1036 */     Method method = new Method();
/*  931:1037 */     method.addComment(table);
/*  932:1038 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  933:1039 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  934:1040 */     method.setName(this.methodNameCalculator.getUpdateByPrimaryKeyWithoutBLOBsMethodName(introspectedTable));
/*  935:1041 */     method.addParameter(new Parameter(parameterType, "record"));
/*  936:     */     
/*  937:1043 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/*  938:1044 */     while (iter.hasNext())
/*  939:     */     {
/*  940:1045 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  941:1046 */       method.addException(fqjt);
/*  942:1047 */       compilationUnit.addImportedType(fqjt);
/*  943:     */     }
/*  944:1050 */     if (!interfaceMethod)
/*  945:     */     {
/*  946:1052 */       StringBuffer sb = new StringBuffer();
/*  947:     */       
/*  948:     */ 
/*  949:1055 */       sb.append("return ");
/*  950:1056 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getUpdateByPrimaryKeyWithoutBLOBsMethodName(introspectedTable));
/*  951:1057 */       sb.append("( record ); ");
/*  952:1058 */       method.addBodyLine(sb.toString());
/*  953:     */     }
/*  954:1063 */     ArrayList answer = new ArrayList();
/*  955:1064 */     answer.add(method);
/*  956:     */     
/*  957:1066 */     return answer;
/*  958:     */   }
/*  959:     */   
/*  960:     */   protected List getUpdateByPrimaryKeyWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  961:     */   {
/*  962:1073 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  963:     */     FullyQualifiedJavaType parameterType;
/*  964:     */     FullyQualifiedJavaType parameterType;
/*  965:1076 */     if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  966:1077 */       parameterType = this.javaModelGenerator.getRecordWithBLOBsType(table);
/*  967:     */     } else {
/*  968:1079 */       parameterType = this.javaModelGenerator.getBaseRecordType(table);
/*  969:     */     }
/*  970:1082 */     compilationUnit.addImportedType(parameterType);
/*  971:     */     
/*  972:1084 */     Method method = new Method();
/*  973:1085 */     method.addComment(table);
/*  974:1086 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  975:1087 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  976:1088 */     method.setName(this.methodNameCalculator.getUpdateByPrimaryKeyWithBLOBsMethodName(introspectedTable));
/*  977:1089 */     method.addParameter(new Parameter(parameterType, "record"));
/*  978:     */     
/*  979:1091 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/*  980:1092 */     while (iter.hasNext())
/*  981:     */     {
/*  982:1093 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  983:1094 */       method.addException(fqjt);
/*  984:1095 */       compilationUnit.addImportedType(fqjt);
/*  985:     */     }
/*  986:1098 */     if (!interfaceMethod)
/*  987:     */     {
/*  988:1100 */       StringBuffer sb = new StringBuffer();
/*  989:     */       
/*  990:     */ 
/*  991:1103 */       sb.append("return ");
/*  992:1104 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getUpdateByPrimaryKeyWithBLOBsMethodName(introspectedTable));
/*  993:1105 */       sb.append("( record ); ");
/*  994:1106 */       method.addBodyLine(sb.toString());
/*  995:     */     }
/*  996:1111 */     ArrayList answer = new ArrayList();
/*  997:1112 */     answer.add(method);
/*  998:     */     
/*  999:1114 */     return answer;
/* 1000:     */   }
/* 1001:     */   
/* 1002:     */   protected List getUpdateByPrimaryKeySelectiveMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1003:     */   {
/* 1004:1121 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1005:     */     FullyQualifiedJavaType parameterType;
/* 1006:     */     FullyQualifiedJavaType parameterType;
/* 1007:1124 */     if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/* 1008:1125 */       parameterType = this.javaModelGenerator.getRecordWithBLOBsType(table);
/* 1009:     */     } else {
/* 1010:1127 */       parameterType = this.javaModelGenerator.getBaseRecordType(table);
/* 1011:     */     }
/* 1012:1130 */     compilationUnit.addImportedType(parameterType);
/* 1013:     */     
/* 1014:1132 */     Method method = new Method();
/* 1015:1133 */     method.addComment(table);
/* 1016:1134 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1017:1135 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 1018:1136 */     method.setName(this.methodNameCalculator.getUpdateByPrimaryKeySelectiveMethodName(introspectedTable));
/* 1019:     */     
/* 1020:1138 */     method.addParameter(new Parameter(new FullyQualifiedJavaType("java.util.Map"), "param"));
/* 1021:     */     
/* 1022:1140 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/* 1023:1141 */     while (iter.hasNext())
/* 1024:     */     {
/* 1025:1142 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1026:1143 */       method.addException(fqjt);
/* 1027:1144 */       compilationUnit.addImportedType(fqjt);
/* 1028:     */     }
/* 1029:1147 */     if (!interfaceMethod)
/* 1030:     */     {
/* 1031:1149 */       StringBuffer sb = new StringBuffer();
/* 1032:     */       
/* 1033:     */ 
/* 1034:1152 */       sb.append("return ");
/* 1035:1153 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getUpdateByPrimaryKeySelectiveMethodName(introspectedTable));
/* 1036:1154 */       sb.append("( param ); ");
/* 1037:1155 */       method.addBodyLine(sb.toString());
/* 1038:     */     }
/* 1039:1160 */     ArrayList answer = new ArrayList();
/* 1040:1161 */     answer.add(method);
/* 1041:     */     
/* 1042:1163 */     return answer;
/* 1043:     */   }
/* 1044:     */   
/* 1045:     */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/* 1046:     */   {
/* 1047:1168 */     return FullyQualifiedJavaType.getNewListInstance();
/* 1048:     */   }
/* 1049:     */   
/* 1050:     */   protected List getSelectByExampleWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1051:     */   {
/* 1052:1174 */     return getSelectByExampleMethods(introspectedTable, interfaceMethod, compilationUnit, 
/* 1053:1175 */       this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable), 
/* 1054:1176 */       this.daoMethodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable));
/* 1055:     */   }
/* 1056:     */   
/* 1057:     */   protected List getSelectByExampleWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1058:     */   {
/* 1059:1182 */     return getSelectByExampleMethods(introspectedTable, interfaceMethod, compilationUnit, 
/* 1060:1183 */       this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable), 
/* 1061:1184 */       this.daoMethodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable));
/* 1062:     */   }
/* 1063:     */   
/* 1064:     */   private List getSelectByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit, String selectByExampleMethodName, String daoSelectByExampleMethodName)
/* 1065:     */   {
/* 1066:1194 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 1067:1195 */       return null;
/* 1068:     */     }
/* 1069:1198 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1070:1199 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 1071:1200 */     compilationUnit.addImportedType(type);
/* 1072:1201 */     compilationUnit.addImportedType(getSelectByExampleReturnListJavaType());
/* 1073:     */     FullyQualifiedJavaType returnType;
/* 1074:1204 */     if (this.useJava5Features)
/* 1075:     */     {
/* 1076:     */       FullyQualifiedJavaType fqjt;
/* 1077:     */       FullyQualifiedJavaType fqjt;
/* 1078:1206 */       if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/* 1079:1207 */         fqjt = this.javaModelGenerator.getRecordWithBLOBsType(table);
/* 1080:     */       } else {
/* 1081:1210 */         fqjt = this.javaModelGenerator.getBaseRecordType(table);
/* 1082:     */       }
/* 1083:1213 */       compilationUnit.addImportedType(fqjt);
/* 1084:1214 */       FullyQualifiedJavaType returnType = getSelectByExampleReturnListJavaType();
/* 1085:1215 */       returnType.addTypeArgument(fqjt);
/* 1086:     */     }
/* 1087:     */     else
/* 1088:     */     {
/* 1089:1217 */       returnType = getSelectByExampleReturnListJavaType();
/* 1090:     */     }
/* 1091:1219 */     Method method = new Method();
/* 1092:1220 */     method.addComment(table);
/* 1093:1221 */     method.setVisibility(this.exampleMethodVisibility);
/* 1094:1222 */     method.setReturnType(returnType);
/* 1095:1223 */     method.setName(selectByExampleMethodName);
/* 1096:1224 */     method.addParameter(new Parameter(type, "params, int pageNum, int numPerPage, boolean doCount"));
/* 1097:     */     
/* 1098:1226 */     Method method2 = new Method();
/* 1099:1227 */     method2.addComment(table);
/* 1100:1228 */     method2.setVisibility(this.exampleMethodVisibility);
/* 1101:1229 */     method2.setReturnType(returnType);
/* 1102:1230 */     method2.setName(selectByExampleMethodName);
/* 1103:1231 */     method2.addParameter(new Parameter(type, "params, int pageNum, int numPerPage"));
/* 1104:     */     
/* 1105:1233 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/* 1106:1234 */     while (iter.hasNext())
/* 1107:     */     {
/* 1108:1235 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1109:1236 */       method.addException(fqjt);
/* 1110:1237 */       compilationUnit.addImportedType(fqjt);
/* 1111:     */     }
/* 1112:1240 */     if (!interfaceMethod)
/* 1113:     */     {
/* 1114:1243 */       StringBuffer sb = new StringBuffer();
/* 1115:1245 */       if (this.useJava5Features)
/* 1116:     */       {
/* 1117:1246 */         method.addSuppressTypeWarningsAnnotation();
/* 1118:1247 */         sb.append(returnType.getShortName());
/* 1119:1248 */         sb.append(" list = (");
/* 1120:1249 */         sb.append(returnType.getShortName());
/* 1121:1250 */         sb.append(") ");
/* 1122:     */       }
/* 1123:     */       else
/* 1124:     */       {
/* 1125:1252 */         sb.append(returnType.getShortName());
/* 1126:1253 */         sb.append(" list = ");
/* 1127:     */       }
/* 1128:1256 */       sb.append(getDAOPropertyName(table)).append(".").append(daoSelectByExampleMethodName);
/* 1129:1257 */       sb.append("( params, pageNum, numPerPage, doCount ); ");
/* 1130:1258 */       method.addBodyLine(sb.toString());
/* 1131:1259 */       method.addBodyLine("return list;");
/* 1132:     */       
/* 1133:1261 */       sb.setLength(0);
/* 1134:1262 */       sb.append("return ");
/* 1135:1263 */       sb.append(selectByExampleMethodName);
/* 1136:1264 */       sb.append("(params, pageNum, numPerPage, true);");
/* 1137:1265 */       method2.addBodyLine(sb.toString());
/* 1138:     */     }
/* 1139:1268 */     ArrayList answer = new ArrayList();
/* 1140:1269 */     answer.add(method);
/* 1141:1270 */     answer.add(method2);
/* 1142:     */     
/* 1143:1272 */     return answer;
/* 1144:     */   }
/* 1145:     */   
/* 1146:     */   protected List getSelectCountByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1147:     */   {
/* 1148:1278 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 1149:1279 */       return null;
/* 1150:     */     }
/* 1151:1282 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1152:1283 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 1153:1284 */     compilationUnit.addImportedType(type);
/* 1154:     */     
/* 1155:1286 */     Method method = new Method();
/* 1156:1287 */     method.addComment(table);
/* 1157:1288 */     method.setVisibility(this.exampleMethodVisibility);
/* 1158:1289 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 1159:1290 */     method.setName(this.methodNameCalculator.getSelectCountByExampleMethodName(introspectedTable));
/* 1160:1291 */     method.addParameter(new Parameter(type, "param"));
/* 1161:     */     
/* 1162:1293 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/* 1163:1294 */     while (iter.hasNext())
/* 1164:     */     {
/* 1165:1295 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1166:1296 */       method.addException(fqjt);
/* 1167:1297 */       compilationUnit.addImportedType(fqjt);
/* 1168:     */     }
/* 1169:1300 */     if (!interfaceMethod)
/* 1170:     */     {
/* 1171:1302 */       StringBuffer sb = new StringBuffer();
/* 1172:     */       
/* 1173:1304 */       sb.append("return  ");
/* 1174:1305 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getSelectCountByExampleMethodName(introspectedTable));
/* 1175:1306 */       sb.append("( param ); ");
/* 1176:1307 */       method.addBodyLine(sb.toString());
/* 1177:     */     }
/* 1178:1310 */     ArrayList answer = new ArrayList();
/* 1179:1311 */     answer.add(method);
/* 1180:     */     
/* 1181:1313 */     return answer;
/* 1182:     */   }
/* 1183:     */   
/* 1184:     */   protected List getSelectByPrimaryKeyMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1185:     */   {
/* 1186:1321 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1187:     */     
/* 1188:1323 */     Method method = new Method();
/* 1189:1324 */     method.addComment(table);
/* 1190:1325 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1191:     */     
/* 1192:1327 */     FullyQualifiedJavaType returnType = 
/* 1193:1328 */       introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/* 1194:1329 */     method.setReturnType(returnType);
/* 1195:1330 */     compilationUnit.addImportedType(returnType);
/* 1196:     */     
/* 1197:1332 */     method.setName(this.methodNameCalculator.getSelectByPrimaryKeyMethodName(introspectedTable));
/* 1198:1334 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/* 1199:     */     {
/* 1200:1335 */       FullyQualifiedJavaType type = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/* 1201:1336 */       compilationUnit.addImportedType(type);
/* 1202:1337 */       method.addParameter(new Parameter(type, "key"));
/* 1203:     */     }
/* 1204:     */     else
/* 1205:     */     {
/* 1206:1339 */       Iterator iter = introspectedTable.getPrimaryKeyColumns();
/* 1207:1340 */       while (iter.hasNext())
/* 1208:     */       {
/* 1209:1341 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1210:1342 */         FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/* 1211:1343 */         compilationUnit.addImportedType(type);
/* 1212:1344 */         method.addParameter(new Parameter(type, cd.getJavaProperty()));
/* 1213:     */       }
/* 1214:     */     }
/* 1215:1348 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/* 1216:1349 */     while (iter.hasNext())
/* 1217:     */     {
/* 1218:1350 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1219:1351 */       method.addException(fqjt);
/* 1220:1352 */       compilationUnit.addImportedType(fqjt);
/* 1221:     */     }
/* 1222:1355 */     if (!interfaceMethod)
/* 1223:     */     {
/* 1224:1357 */       StringBuffer sb = new StringBuffer();
/* 1225:     */       
/* 1226:1359 */       String param = "key";
/* 1227:1361 */       if (!introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 1228:1362 */         if (introspectedTable.getRules().getPrimaryKeyColumnSize() == 1)
/* 1229:     */         {
/* 1230:1363 */           iter = introspectedTable.getPrimaryKeyColumns();
/* 1231:1364 */           ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1232:1365 */           param = cd.getJavaProperty();
/* 1233:     */         }
/* 1234:     */         else
/* 1235:     */         {
/* 1236:1370 */           FullyQualifiedJavaType keyType = this.javaModelGenerator.getBaseRecordType(table);
/* 1237:1371 */           compilationUnit.addImportedType(keyType);
/* 1238:     */           
/* 1239:1373 */           sb.setLength(0);
/* 1240:1374 */           sb.append(keyType.getShortName());
/* 1241:1375 */           sb.append(" key = new ");
/* 1242:1376 */           sb.append(keyType.getShortName());
/* 1243:1377 */           sb.append("();");
/* 1244:1378 */           method.addBodyLine(sb.toString());
/* 1245:     */           
/* 1246:1380 */           iter = introspectedTable.getPrimaryKeyColumns();
/* 1247:1381 */           while (iter.hasNext())
/* 1248:     */           {
/* 1249:1382 */             ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1250:1383 */             sb.setLength(0);
/* 1251:1384 */             sb.append("key.");
/* 1252:1385 */             sb.append(JavaBeansUtil.getSetterMethodName(cd.getJavaProperty()));
/* 1253:1386 */             sb.append('(');
/* 1254:1387 */             sb.append(cd.getJavaProperty());
/* 1255:1388 */             sb.append(");");
/* 1256:1389 */             method.addBodyLine(sb.toString());
/* 1257:     */           }
/* 1258:     */         }
/* 1259:     */       }
/* 1260:1393 */       sb.setLength(0);
/* 1261:1394 */       sb.append(" return (");
/* 1262:1395 */       sb.append(returnType.getShortName());
/* 1263:1396 */       sb.append(") ");
/* 1264:1397 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getSelectByPrimaryKeyMethodName(introspectedTable));
/* 1265:1398 */       sb.append("( " + param + " ); ");
/* 1266:1399 */       method.addBodyLine(sb.toString());
/* 1267:     */     }
/* 1268:1402 */     ArrayList answer = new ArrayList();
/* 1269:1403 */     answer.add(method);
/* 1270:     */     
/* 1271:1405 */     return answer;
/* 1272:     */   }
/* 1273:     */   
/* 1274:     */   protected List getDeleteByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1275:     */   {
/* 1276:1411 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 1277:1412 */       return null;
/* 1278:     */     }
/* 1279:1415 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1280:1416 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 1281:1417 */     compilationUnit.addImportedType(type);
/* 1282:     */     
/* 1283:1419 */     Method method = new Method();
/* 1284:1420 */     method.addComment(table);
/* 1285:1421 */     method.setVisibility(this.exampleMethodVisibility);
/* 1286:1422 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 1287:1423 */     method.setName(this.methodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 1288:1424 */     method.addParameter(new Parameter(type, "param"));
/* 1289:     */     
/* 1290:1426 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/* 1291:1427 */     while (iter.hasNext())
/* 1292:     */     {
/* 1293:1428 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1294:1429 */       method.addException(fqjt);
/* 1295:1430 */       compilationUnit.addImportedType(fqjt);
/* 1296:     */     }
/* 1297:1433 */     if (!interfaceMethod)
/* 1298:     */     {
/* 1299:1435 */       StringBuffer sb = new StringBuffer();
/* 1300:     */       
/* 1301:1437 */       sb.append("return ");
/* 1302:1438 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 1303:1439 */       sb.append("( param ); ");
/* 1304:1440 */       method.addBodyLine(sb.toString());
/* 1305:     */     }
/* 1306:1443 */     ArrayList answer = new ArrayList();
/* 1307:1444 */     answer.add(method);
/* 1308:     */     
/* 1309:1446 */     return answer;
/* 1310:     */   }
/* 1311:     */   
/* 1312:     */   protected List getDeleteByPrimaryKeyMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 1313:     */   {
/* 1314:1453 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1315:     */     
/* 1316:1455 */     Method method = new Method();
/* 1317:1456 */     method.addComment(table);
/* 1318:1457 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1319:1458 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 1320:1459 */     method.setName(this.methodNameCalculator.getDeleteByPrimaryKeyMethodName(introspectedTable));
/* 1321:1461 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/* 1322:     */     {
/* 1323:1462 */       FullyQualifiedJavaType type = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/* 1324:1463 */       compilationUnit.addImportedType(type);
/* 1325:1464 */       method.addParameter(new Parameter(type, "key"));
/* 1326:     */     }
/* 1327:     */     else
/* 1328:     */     {
/* 1329:1466 */       Iterator iter = introspectedTable.getPrimaryKeyColumns();
/* 1330:1467 */       while (iter.hasNext())
/* 1331:     */       {
/* 1332:1468 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1333:1469 */         FullyQualifiedJavaType type = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/* 1334:1470 */         compilationUnit.addImportedType(type);
/* 1335:1471 */         method.addParameter(new Parameter(type, cd.getJavaProperty()));
/* 1336:     */       }
/* 1337:     */     }
/* 1338:1475 */     Iterator iter = this.serviceTemplate.getCheckedExceptions().iterator();
/* 1339:1476 */     while (iter.hasNext())
/* 1340:     */     {
/* 1341:1477 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 1342:1478 */       method.addException(fqjt);
/* 1343:1479 */       compilationUnit.addImportedType(fqjt);
/* 1344:     */     }
/* 1345:1482 */     if (!interfaceMethod)
/* 1346:     */     {
/* 1347:1484 */       StringBuffer sb = new StringBuffer();
/* 1348:     */       
/* 1349:1486 */       String param = "key";
/* 1350:1488 */       if (!introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 1351:1489 */         if (introspectedTable.getRules().getPrimaryKeyColumnSize() == 1)
/* 1352:     */         {
/* 1353:1490 */           iter = introspectedTable.getPrimaryKeyColumns();
/* 1354:1491 */           ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1355:1492 */           param = cd.getJavaProperty();
/* 1356:     */         }
/* 1357:     */         else
/* 1358:     */         {
/* 1359:1497 */           FullyQualifiedJavaType keyType = this.javaModelGenerator.getBaseRecordType(table);
/* 1360:1498 */           compilationUnit.addImportedType(keyType);
/* 1361:     */           
/* 1362:1500 */           sb.setLength(0);
/* 1363:1501 */           sb.append(keyType.getShortName());
/* 1364:1502 */           sb.append(" key = new ");
/* 1365:1503 */           sb.append(keyType.getShortName());
/* 1366:1504 */           sb.append("();");
/* 1367:1505 */           method.addBodyLine(sb.toString());
/* 1368:     */           
/* 1369:1507 */           iter = introspectedTable.getPrimaryKeyColumns();
/* 1370:1508 */           while (iter.hasNext())
/* 1371:     */           {
/* 1372:1509 */             ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1373:1510 */             sb.setLength(0);
/* 1374:1511 */             sb.append("key.");
/* 1375:1512 */             sb.append(JavaBeansUtil.getSetterMethodName(cd.getJavaProperty()));
/* 1376:1513 */             sb.append('(');
/* 1377:1514 */             sb.append(cd.getJavaProperty());
/* 1378:1515 */             sb.append(");");
/* 1379:1516 */             method.addBodyLine(sb.toString());
/* 1380:     */           }
/* 1381:     */         }
/* 1382:     */       }
/* 1383:1521 */       sb.setLength(0);
/* 1384:     */       
/* 1385:1523 */       sb.append("return ");
/* 1386:1524 */       sb.append(getDAOPropertyName(table)).append(".").append(this.daoMethodNameCalculator.getDeleteByPrimaryKeyMethodName(introspectedTable));
/* 1387:1525 */       sb.append("( " + param + " ); ");
/* 1388:1526 */       method.addBodyLine(sb.toString());
/* 1389:     */     }
/* 1390:1530 */     ArrayList answer = new ArrayList();
/* 1391:1531 */     answer.add(method);
/* 1392:     */     
/* 1393:1533 */     return answer;
/* 1394:     */   }
/* 1395:     */   
/* 1396:     */   public String getRecordPropertyName(FullyQualifiedTable table)
/* 1397:     */   {
/* 1398:1537 */     String key = "getRecordPropertyName";
/* 1399:     */     
/* 1400:1539 */     Map map = getTableValueMap(table);
/* 1401:1540 */     String property = (String)map.get(key);
/* 1402:1541 */     if (property == null)
/* 1403:     */     {
/* 1404:1542 */       property = JavaBeansUtil.getValidPropertyName(table.getDomainObjectName());
/* 1405:1543 */       map.put(key, property);
/* 1406:     */     }
/* 1407:1546 */     return property;
/* 1408:     */   }
/* 1409:     */   
/* 1410:     */   protected String getServicePackage(FullyQualifiedTable table)
/* 1411:     */   {
/* 1412:1551 */     String key = "getServicePackage";
/* 1413:     */     
/* 1414:     */ 
/* 1415:1554 */     Map map = getTableValueMap(table);
/* 1416:1555 */     String s = (String)map.get(key);
/* 1417:1556 */     if (s == null)
/* 1418:     */     {
/* 1419:1557 */       StringBuffer sb = new StringBuffer(this.targetPackage);
/* 1420:1558 */       if ("true".equals(this.properties.get("enableSubPackages")))
/* 1421:     */       {
/* 1422:1559 */         if (StringUtility.stringHasValue(table.getCatalog()))
/* 1423:     */         {
/* 1424:1560 */           sb.append('.');
/* 1425:1561 */           sb.append(table.getCatalog().toLowerCase());
/* 1426:     */         }
/* 1427:1564 */         if (StringUtility.stringHasValue(table.getSchema()))
/* 1428:     */         {
/* 1429:1565 */           sb.append('.');
/* 1430:1566 */           sb.append(table.getSchema().toLowerCase());
/* 1431:     */         }
/* 1432:     */       }
/* 1433:1570 */       s = sb.toString();
/* 1434:1571 */       map.put(key, s);
/* 1435:     */     }
/* 1436:1574 */     return s;
/* 1437:     */   }
/* 1438:     */   
/* 1439:     */   public FullyQualifiedJavaType getServiceInterfaceType(FullyQualifiedTable table)
/* 1440:     */   {
/* 1441:1579 */     String key = "getServiceInterfaceType";
/* 1442:     */     
/* 1443:1581 */     Map map = getTableValueMap(table);
/* 1444:1582 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/* 1445:1583 */     if (fqjt == null)
/* 1446:     */     {
/* 1447:1584 */       StringBuffer sb = new StringBuffer();
/* 1448:1585 */       sb.append(getServicePackage(table));
/* 1449:1586 */       sb.append('.');
/* 1450:1587 */       sb.append(table.getDomainObjectName());
/* 1451:1588 */       sb.append("Service");
/* 1452:     */       
/* 1453:1590 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/* 1454:1591 */       map.put(key, fqjt);
/* 1455:     */     }
/* 1456:1594 */     return fqjt;
/* 1457:     */   }
/* 1458:     */   
/* 1459:     */   private Map getTableValueMap(FullyQualifiedTable table)
/* 1460:     */   {
/* 1461:1598 */     Map map = (Map)this.tableValueMaps.get(table);
/* 1462:1599 */     if (map == null)
/* 1463:     */     {
/* 1464:1600 */       map = new HashMap();
/* 1465:1601 */       this.tableValueMaps.put(table, map);
/* 1466:     */     }
/* 1467:1604 */     return map;
/* 1468:     */   }
/* 1469:     */   
/* 1470:     */   public void addContextProperties(Map properties)
/* 1471:     */   {
/* 1472:1608 */     this.properties.putAll(properties);
/* 1473:     */   }
/* 1474:     */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.service.BaseServiceGenerator
 * JD-Core Version:    0.7.0.1
 */