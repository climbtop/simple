/*   1:    */ package org.apache.ibatis.abator.internal.java.jsp;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   4:    */ 
/*   5:    */ public class AbstractJspTemplate
/*   6:    */ {
/*   7:    */   private String templateContent;
/*   8:    */   private String generatedContent;
/*   9:    */   private String type;
/*  10:    */   public static final String rootUrlTag = "{ABATOR_ROOT_URL}";
/*  11:    */   public static final String listUrlTag = "{ABATOR_LIST_URL}";
/*  12:    */   public static final String searchUrlTag = "{ABATOR_SEARCH_URL}";
/*  13:    */   public static final String saveUrlTag = "{ABATOR_SAVE_URL}";
/*  14:    */   public static final String createUrlTag = "{ABATOR_CREATE_URL}";
/*  15:    */   public static final String showUrlTag = "{ABATOR_SHOW_URL}";
/*  16:    */   public static final String editUrlTag = "{ABATOR_EDIT_URL}";
/*  17:    */   public static final String moveUrlTag = "{ABATOR_MOVE_URL}";
/*  18:    */   public static final String updateUrlTag = "{ABATOR_UPDATE_URL}";
/*  19:    */   public static final String deleteUrlTag = "{ABATOR_DELETE_URL}";
/*  20:    */   public static final String auditUrlTag = "{ABATOR_AUDIT_URL}";
/*  21:    */   public static final String updateStatusUrlTag = "{ABATOR_UPDATE_STATUS_URL}";
/*  22:    */   public static final String queryFieldsTag = "{ABATOR_QUERY_FIELDS}";
/*  23:    */   public static final String listTitlesTag = "{ABATOR_LIST_TITLES}";
/*  24:    */   public static final String listSwitchTreeViewTag = "{ABATOR_LIST_SWITCH_TREE_VIEW}";
/*  25:    */   public static final String treeTitleArrayTag = "{ABATOR_TREE_TITLE_ARRAY}";
/*  26:    */   public static final String treeTitleWidthArrayTag = "{ABATOR_TREE_TITLE_WIDTH_ARRAY}";
/*  27:    */   public static final String listRowActionButtonsTag = "{ABATOR_LIST_ROW_ACTION_BUTTONS}";
/*  28:    */   public static final String listBatchActionButtonsTag = "{ABATOR_LIST_BATCH_ACTION_BUTTONS}";
/*  29:    */   public static final String listRowTag = "{ABATOR_LIST_ROW}";
/*  30:    */   public static final String jsonTitlesTag = "{ABATOR_JSON_TITLES}";
/*  31:    */   public static final String jsonPartTitlesTag = "{ABATOR_JSON_PART_TITLES}";
/*  32:    */   public static final String listRowsJsonTag = "{ABATOR_LIST_JSON_ROWS}";
/*  33:    */   public static final String showRowsTag = "{ABATOR_SHOW_ROWS}";
/*  34:    */   public static final String editRowsTag = "{ABATOR_EDIT_ROWS}";
/*  35:    */   public static final String projectLabelTag = "{ABATOR_PROJECT_LABEL}";
/*  36:    */   public static final String domainObjectLabelTag = "{ABATOR_OBJECT_LABEL}";
/*  37:    */   public static final String domainObjectNameTag = "{ABATOR_OBJECT_NAME}";
/*  38:    */   public static final String primaryKeyPropertyTag = "{ABATOR_PK_PROPERTY}";
/*  39:    */   public static final String primaryKeyPropertyCamelCaseTag = "{ABATOR_PK_PROPERTY_CAMEL_CASE}";
/*  40:    */   public static final String primaryKeyValueTag = "{ABATOR_PK_VALUE}";
/*  41:    */   public static final String createParamTag = "{ABATOR_CREATE_PARAM}";
/*  42: 47 */   protected String listTitleTemplate = "<th>{0}</th>";
/*  43: 48 */   protected String listRowTemplate = "<tr>{0}</tr>";
/*  44: 49 */   protected String listFieldTemplate = "<td>{0}</td>";
/*  45: 50 */   protected String listRowImageButtonPath = "";
/*  46: 51 */   protected String queryFieldTemplate = "<td>{0}{1}</td>";
/*  47: 52 */   protected String showFieldTemplate = "<tr><td>{0}</td><td>{1}</td></tr>";
/*  48: 53 */   protected String editFieldTemplate = "<tr><td>{0}</td><td>{1}</td></tr>";
/*  49:    */   
/*  50:    */   public AbstractJspTemplate(String content, String type)
/*  51:    */   {
/*  52: 56 */     this.templateContent = content;
/*  53: 57 */     this.generatedContent = content;
/*  54: 58 */     this.type = type;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public AbstractJspTemplate setQueryFields(String s)
/*  58:    */   {
/*  59: 62 */     return repalceTag("{ABATOR_QUERY_FIELDS}", s);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public AbstractJspTemplate setProjectLabel(String s)
/*  63:    */   {
/*  64: 66 */     return repalceTag("{ABATOR_PROJECT_LABEL}", s);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public AbstractJspTemplate setListTitles(String s)
/*  68:    */   {
/*  69: 70 */     return repalceTag("{ABATOR_LIST_TITLES}", s);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public AbstractJspTemplate setListSwitchTreeView(String s)
/*  73:    */   {
/*  74: 74 */     return repalceTag("{ABATOR_LIST_SWITCH_TREE_VIEW}", s);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public AbstractJspTemplate setTreeTitleWidthArray(String s)
/*  78:    */   {
/*  79: 78 */     return repalceTag("{ABATOR_TREE_TITLE_WIDTH_ARRAY}", s);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public AbstractJspTemplate setTreeTitleArray(String s)
/*  83:    */   {
/*  84: 82 */     return repalceTag("{ABATOR_TREE_TITLE_ARRAY}", s);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public AbstractJspTemplate setListRowActionButtons(String s)
/*  88:    */   {
/*  89: 86 */     return repalceTag("{ABATOR_LIST_ROW_ACTION_BUTTONS}", s);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public AbstractJspTemplate setListBatchActionButtons(String s)
/*  93:    */   {
/*  94: 90 */     return repalceTag("{ABATOR_LIST_BATCH_ACTION_BUTTONS}", s);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public AbstractJspTemplate setListRow(String s)
/*  98:    */   {
/*  99: 94 */     return repalceTag("{ABATOR_LIST_ROW}", s);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public AbstractJspTemplate setJsonTitles(String s)
/* 103:    */   {
/* 104: 98 */     return repalceTag("{ABATOR_JSON_TITLES}", s);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public AbstractJspTemplate setJsonPartTitles(String s)
/* 108:    */   {
/* 109:102 */     return repalceTag("{ABATOR_JSON_PART_TITLES}", s);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public AbstractJspTemplate setListJsonRows(String s)
/* 113:    */   {
/* 114:106 */     return repalceTag("{ABATOR_LIST_JSON_ROWS}", s);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public AbstractJspTemplate setShowRows(String s)
/* 118:    */   {
/* 119:110 */     return repalceTag("{ABATOR_SHOW_ROWS}", s);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public AbstractJspTemplate setEditRows(String s)
/* 123:    */   {
/* 124:114 */     return repalceTag("{ABATOR_EDIT_ROWS}", s);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public AbstractJspTemplate setObjectLabel(String s)
/* 128:    */   {
/* 129:118 */     return repalceTag("{ABATOR_OBJECT_LABEL}", s);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public AbstractJspTemplate setObjectName(String s)
/* 133:    */   {
/* 134:122 */     return repalceTag("{ABATOR_OBJECT_NAME}", s);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public AbstractJspTemplate setPKProperty(String s)
/* 138:    */   {
/* 139:126 */     return repalceTag("{ABATOR_PK_PROPERTY}", s);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public AbstractJspTemplate setPKPropertyCamelCase(String s)
/* 143:    */   {
/* 144:130 */     return repalceTag("{ABATOR_PK_PROPERTY_CAMEL_CASE}", s);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public AbstractJspTemplate setPKValue(String s)
/* 148:    */   {
/* 149:134 */     return repalceTag("{ABATOR_PK_VALUE}", s);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public AbstractJspTemplate setCreateParam(String s)
/* 153:    */   {
/* 154:138 */     return repalceTag("{ABATOR_CREATE_PARAM}", s);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public AbstractJspTemplate setRootUrl(String url)
/* 158:    */   {
/* 159:142 */     return repalceTag("{ABATOR_ROOT_URL}", url);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public AbstractJspTemplate setMoveUrl(String url)
/* 163:    */   {
/* 164:145 */     return repalceTag("{ABATOR_MOVE_URL}", url);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public AbstractJspTemplate setListUrl(String url)
/* 168:    */   {
/* 169:148 */     return repalceTag("{ABATOR_LIST_URL}", url);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public AbstractJspTemplate setSearchUrl(String url)
/* 173:    */   {
/* 174:151 */     return repalceTag("{ABATOR_SEARCH_URL}", url);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public AbstractJspTemplate setSaveUrl(String url)
/* 178:    */   {
/* 179:154 */     return repalceTag("{ABATOR_SAVE_URL}", url);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public AbstractJspTemplate setCreateUrl(String url)
/* 183:    */   {
/* 184:157 */     return repalceTag("{ABATOR_CREATE_URL}", url);
/* 185:    */   }
/* 186:    */   
/* 187:    */   public AbstractJspTemplate setShowUrl(String url)
/* 188:    */   {
/* 189:160 */     return repalceTag("{ABATOR_SHOW_URL}", url);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public AbstractJspTemplate setEditUrl(String url)
/* 193:    */   {
/* 194:163 */     return repalceTag("{ABATOR_EDIT_URL}", url);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public AbstractJspTemplate setUpdateUrl(String url)
/* 198:    */   {
/* 199:167 */     return repalceTag("{ABATOR_UPDATE_URL}", url);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public AbstractJspTemplate setDeleteUrl(String url)
/* 203:    */   {
/* 204:171 */     return repalceTag("{ABATOR_DELETE_URL}", url);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public AbstractJspTemplate setAuditUrl(String url)
/* 208:    */   {
/* 209:175 */     return repalceTag("{ABATOR_AUDIT_URL}", url);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public AbstractJspTemplate setUpdateStatusUrl(String url)
/* 213:    */   {
/* 214:179 */     return repalceTag("{ABATOR_UPDATE_STATUS_URL}", url);
/* 215:    */   }
/* 216:    */   
/* 217:    */   private AbstractJspTemplate repalceTag(String tag, String text)
/* 218:    */   {
/* 219:183 */     if (StringUtility.stringHasValue(this.generatedContent)) {
/* 220:184 */       this.generatedContent = this.generatedContent.replace(tag, text);
/* 221:    */     }
/* 222:185 */     return this;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public void resetTempate()
/* 226:    */   {
/* 227:189 */     this.generatedContent = this.templateContent;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public String getGeneratedContent()
/* 231:    */   {
/* 232:196 */     return this.generatedContent;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public String getTemplateContent()
/* 236:    */   {
/* 237:200 */     return this.templateContent;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public String getListTitleTemplate()
/* 241:    */   {
/* 242:207 */     return this.listTitleTemplate;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void setListTitleTemplate(String listTitleTemplate)
/* 246:    */   {
/* 247:214 */     this.listTitleTemplate = listTitleTemplate;
/* 248:    */   }
/* 249:    */   
/* 250:    */   public String getListRowTemplate()
/* 251:    */   {
/* 252:221 */     return this.listRowTemplate;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public void setListRowTemplate(String listRowTemplate)
/* 256:    */   {
/* 257:228 */     this.listRowTemplate = listRowTemplate;
/* 258:    */   }
/* 259:    */   
/* 260:    */   public String getListRowImageButtonPath()
/* 261:    */   {
/* 262:232 */     return this.listRowImageButtonPath;
/* 263:    */   }
/* 264:    */   
/* 265:    */   public void setListRowImageButtonPath(String listRowImageButtonPath)
/* 266:    */   {
/* 267:236 */     this.listRowImageButtonPath = listRowImageButtonPath;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public String getType()
/* 271:    */   {
/* 272:243 */     return this.type;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public String getFileName()
/* 276:    */   {
/* 277:250 */     return this.type + ".jsp";
/* 278:    */   }
/* 279:    */   
/* 280:    */   public void setType(String type)
/* 281:    */   {
/* 282:256 */     this.type = type;
/* 283:    */   }
/* 284:    */   
/* 285:    */   public String getListFieldTemplate()
/* 286:    */   {
/* 287:263 */     return this.listFieldTemplate;
/* 288:    */   }
/* 289:    */   
/* 290:    */   public void setListFieldTemplate(String listFieldTemplate)
/* 291:    */   {
/* 292:270 */     this.listFieldTemplate = listFieldTemplate;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public String getShowFieldTemplate()
/* 296:    */   {
/* 297:277 */     return this.showFieldTemplate;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void setShowFieldTemplate(String showFieldTemplate)
/* 301:    */   {
/* 302:284 */     this.showFieldTemplate = showFieldTemplate;
/* 303:    */   }
/* 304:    */   
/* 305:    */   public String getEditFieldTemplate()
/* 306:    */   {
/* 307:291 */     return this.editFieldTemplate;
/* 308:    */   }
/* 309:    */   
/* 310:    */   public void setEditFieldTemplate(String editFieldTemplate)
/* 311:    */   {
/* 312:298 */     this.editFieldTemplate = editFieldTemplate;
/* 313:    */   }
/* 314:    */   
/* 315:    */   public String getQueryFieldTemplate()
/* 316:    */   {
/* 317:305 */     return this.queryFieldTemplate;
/* 318:    */   }
/* 319:    */   
/* 320:    */   public void setQueryFieldTemplate(String queryFieldTemplate)
/* 321:    */   {
/* 322:312 */     this.queryFieldTemplate = queryFieldTemplate;
/* 323:    */   }
/* 324:    */   
/* 325:    */   public String toString()
/* 326:    */   {
/* 327:316 */     return this.type + ":" + this.generatedContent;
/* 328:    */   }
/* 329:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.jsp.AbstractJspTemplate
 * JD-Core Version:    0.7.0.1
 */