/*   1:    */ package org.apache.ibatis.abator.internal.java.model;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   5:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   6:    */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   7:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   8:    */ import org.apache.ibatis.abator.api.dom.java.InnerClass;
/*   9:    */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  10:    */ import org.apache.ibatis.abator.api.dom.java.JavaWildcardType;
/*  11:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  12:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  13:    */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*  14:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  15:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*  16:    */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*  17:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*  18:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  19:    */ 
/*  20:    */ public class JavaModelGeneratorJava5Impl
/*  21:    */   extends JavaModelGeneratorJava2Impl
/*  22:    */ {
/*  23:    */   protected TopLevelClass getExample(IntrospectedTable introspectedTable)
/*  24:    */   {
/*  25: 47 */     if (!introspectedTable.getRules().generateExampleClass()) {
/*  26: 48 */       return null;
/*  27:    */     }
/*  28: 51 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  29: 52 */     FullyQualifiedJavaType type = getExampleType(table);
/*  30: 53 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*  31: 54 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*  32:    */     
/*  33:    */ 
/*  34: 57 */     Field field = new Field();
/*  35: 58 */     field.addComment(table);
/*  36: 59 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  37: 60 */     field.setType(FullyQualifiedJavaType.getStringInstance());
/*  38: 61 */     field.setName("orderByClause");
/*  39: 62 */     topLevelClass.addField(field);
/*  40:    */     
/*  41: 64 */     Method method = new Method();
/*  42: 65 */     method.addComment(table);
/*  43: 66 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  44: 67 */     method.setName("setOrderByClause");
/*  45: 68 */     method.addParameter(new Parameter(
/*  46: 69 */       FullyQualifiedJavaType.getStringInstance(), "orderByClause"));
/*  47: 70 */     method.addBodyLine("this.orderByClause = orderByClause;");
/*  48: 71 */     topLevelClass.addMethod(method);
/*  49:    */     
/*  50: 73 */     method = new Method();
/*  51: 74 */     method.addComment(table);
/*  52: 75 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  53: 76 */     method.setReturnType(FullyQualifiedJavaType.getStringInstance());
/*  54: 77 */     method.setName("getOrderByClause");
/*  55: 78 */     method.addBodyLine("return orderByClause;");
/*  56: 79 */     topLevelClass.addMethod(method);
/*  57:    */     
/*  58:    */ 
/*  59: 82 */     field = new Field();
/*  60: 83 */     field.addComment(table);
/*  61: 84 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  62:    */     
/*  63: 86 */     FullyQualifiedJavaType fqjt = 
/*  64: 87 */       FullyQualifiedJavaType.getNewListInstance();
/*  65: 88 */     fqjt.addTypeArgument(FullyQualifiedJavaType.getCriteriaInstance());
/*  66:    */     
/*  67: 90 */     field.setType(fqjt);
/*  68: 91 */     field.setName("oredCriteria");
/*  69: 92 */     field.setInitializationString("new ArrayList<Criteria>()");
/*  70: 93 */     topLevelClass.addField(field);
/*  71:    */     
/*  72: 95 */     method = new Method();
/*  73: 96 */     method.addComment(table);
/*  74: 97 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  75: 98 */     method.setReturnType(fqjt);
/*  76: 99 */     method.setName("getOredCriteria");
/*  77:100 */     method.addBodyLine("return oredCriteria;");
/*  78:101 */     topLevelClass.addMethod(method);
/*  79:    */     
/*  80:103 */     method = new Method();
/*  81:104 */     method.addComment(table);
/*  82:105 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  83:106 */     method.setName("or");
/*  84:107 */     method.addParameter(new Parameter(FullyQualifiedJavaType.getCriteriaInstance(), 
/*  85:108 */       "criteria"));
/*  86:109 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  87:    */     
/*  88:111 */     topLevelClass.addMethod(method);
/*  89:    */     
/*  90:113 */     method = new Method();
/*  91:114 */     method.addComment(table);
/*  92:115 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  93:116 */     method.setName("createCriteria");
/*  94:117 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  95:118 */     method.addBodyLine("Criteria criteria = new Criteria();");
/*  96:119 */     method.addBodyLine("if (oredCriteria.size() == 0) {");
/*  97:120 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  98:121 */     method.addBodyLine("}");
/*  99:122 */     method.addBodyLine("return criteria;");
/* 100:123 */     topLevelClass.addMethod(method);
/* 101:    */     
/* 102:    */ 
/* 103:126 */     topLevelClass.addInnerClass(getCriteriaInnerClass(topLevelClass, 
/* 104:127 */       introspectedTable));
/* 105:    */     
/* 106:129 */     return topLevelClass;
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected InnerClass getCriteriaInnerClass(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/* 110:    */   {
/* 111:137 */     InnerClass answer = new InnerClass(FullyQualifiedJavaType.getCriteriaInstance());
/* 112:    */     
/* 113:139 */     answer.setVisibility(JavaVisibility.PUBLIC);
/* 114:140 */     answer.setModifierStatic(true);
/* 115:141 */     answer.addComment(introspectedTable.getTable());
/* 116:    */     
/* 117:143 */     Method method = new Method();
/* 118:144 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 119:145 */     method.setName("Criteria");
/* 120:146 */     method.setConstructor(true);
/* 121:147 */     method.addBodyLine("super();");
/* 122:148 */     method.addBodyLine("criteriaWithoutValue = new ArrayList<String>();");
/* 123:149 */     method
/* 124:150 */       .addBodyLine("criteriaWithSingleValue = new ArrayList<Map<String, Object>>();");
/* 125:151 */     method
/* 126:152 */       .addBodyLine("criteriaWithListValue = new ArrayList<Map<String, Object>>();");
/* 127:153 */     method
/* 128:154 */       .addBodyLine("criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();");
/* 129:155 */     answer.addMethod(method);
/* 130:    */     
/* 131:157 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/* 132:158 */     while (iter.hasNext())
/* 133:    */     {
/* 134:159 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 135:161 */       if (StringUtility.stringHasValue(cd.getTypeHandler())) {
/* 136:162 */         addtypeHandledObjectsAndMethods(cd, method, answer);
/* 137:    */       }
/* 138:    */     }
/* 139:168 */     topLevelClass.addImportedType(
/* 140:169 */       FullyQualifiedJavaType.getNewMapInstance());
/* 141:170 */     topLevelClass.addImportedType(
/* 142:171 */       FullyQualifiedJavaType.getNewListInstance());
/* 143:172 */     topLevelClass.addImportedType(
/* 144:173 */       FullyQualifiedJavaType.getNewHashMapInstance());
/* 145:174 */     topLevelClass.addImportedType(
/* 146:175 */       FullyQualifiedJavaType.getNewArrayListInstance());
/* 147:    */     
/* 148:177 */     Field field = new Field();
/* 149:178 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 150:179 */     FullyQualifiedJavaType listOfStrings = 
/* 151:180 */       FullyQualifiedJavaType.getNewListInstance();
/* 152:181 */     listOfStrings.addTypeArgument(
/* 153:182 */       FullyQualifiedJavaType.getStringInstance());
/* 154:183 */     field.setType(listOfStrings);
/* 155:184 */     field.setName("criteriaWithoutValue");
/* 156:185 */     answer.addField(field);
/* 157:    */     
/* 158:187 */     method = new Method();
/* 159:188 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 160:189 */     method.setReturnType(field.getType());
/* 161:190 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 162:191 */     method.addBodyLine("return criteriaWithoutValue;");
/* 163:192 */     answer.addMethod(method);
/* 164:    */     
/* 165:194 */     FullyQualifiedJavaType innerMapType = 
/* 166:195 */       FullyQualifiedJavaType.getNewMapInstance();
/* 167:196 */     innerMapType
/* 168:197 */       .addTypeArgument(FullyQualifiedJavaType.getStringInstance());
/* 169:198 */     innerMapType
/* 170:199 */       .addTypeArgument(FullyQualifiedJavaType.getObjectInstance());
/* 171:    */     
/* 172:201 */     FullyQualifiedJavaType listOfMaps = 
/* 173:202 */       FullyQualifiedJavaType.getNewListInstance();
/* 174:203 */     listOfMaps.addTypeArgument(innerMapType);
/* 175:    */     
/* 176:205 */     field = new Field();
/* 177:206 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 178:207 */     field.setType(listOfMaps);
/* 179:208 */     field.setName("criteriaWithSingleValue");
/* 180:209 */     answer.addField(field);
/* 181:    */     
/* 182:211 */     method = new Method();
/* 183:212 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 184:213 */     method.setReturnType(field.getType());
/* 185:214 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 186:215 */     method.addBodyLine("return criteriaWithSingleValue;");
/* 187:216 */     answer.addMethod(method);
/* 188:    */     
/* 189:218 */     field = new Field();
/* 190:219 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 191:220 */     field.setType(listOfMaps);
/* 192:221 */     field.setName("criteriaWithListValue");
/* 193:222 */     answer.addField(field);
/* 194:    */     
/* 195:224 */     method = new Method();
/* 196:225 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 197:226 */     method.setReturnType(field.getType());
/* 198:227 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 199:228 */     method.addBodyLine("return criteriaWithListValue;");
/* 200:229 */     answer.addMethod(method);
/* 201:    */     
/* 202:231 */     field = new Field();
/* 203:232 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 204:233 */     field.setType(listOfMaps);
/* 205:234 */     field.setName("criteriaWithBetweenValue");
/* 206:235 */     answer.addField(field);
/* 207:    */     
/* 208:237 */     method = new Method();
/* 209:238 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 210:239 */     method.setReturnType(field.getType());
/* 211:240 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 212:241 */     method.addBodyLine("return criteriaWithBetweenValue;");
/* 213:242 */     answer.addMethod(method);
/* 214:    */     
/* 215:    */ 
/* 216:245 */     method = new Method();
/* 217:246 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 218:247 */     method.setName("addCriterion");
/* 219:248 */     method.addParameter(new Parameter(
/* 220:249 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 221:250 */     method.addParameter(new Parameter(
/* 222:251 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/* 223:252 */     method.addParameter(new Parameter(
/* 224:253 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 225:254 */     method.addBodyLine("if (value == null) {");
/* 226:255 */     method
/* 227:256 */       .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/* 228:257 */     method.addBodyLine("}");
/* 229:258 */     method
/* 230:259 */       .addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/* 231:260 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 232:261 */     method.addBodyLine("map.put(\"value\", value);");
/* 233:262 */     method.addBodyLine("criteriaWithSingleValue.add(map);");
/* 234:263 */     answer.addMethod(method);
/* 235:    */     
/* 236:265 */     FullyQualifiedJavaType listOfObjects = 
/* 237:266 */       FullyQualifiedJavaType.getNewListInstance();
/* 238:267 */     listOfObjects.addTypeArgument(new JavaWildcardType(
/* 239:268 */       "java.lang.Object", true));
/* 240:    */     
/* 241:270 */     method = new Method();
/* 242:271 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 243:272 */     method.setName("addCriterion");
/* 244:273 */     method.addParameter(new Parameter(
/* 245:274 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 246:275 */     method.addParameter(new Parameter(listOfObjects, "values"));
/* 247:276 */     method.addParameter(new Parameter(
/* 248:277 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 249:278 */     method.addBodyLine("if (values == null || values.size() == 0) {");
/* 250:279 */     method
/* 251:280 */       .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/* 252:281 */     method.addBodyLine("}");
/* 253:282 */     method
/* 254:283 */       .addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/* 255:284 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 256:285 */     method.addBodyLine("map.put(\"values\", values);");
/* 257:286 */     method.addBodyLine("criteriaWithListValue.add(map);");
/* 258:287 */     answer.addMethod(method);
/* 259:    */     
/* 260:289 */     method = new Method();
/* 261:290 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 262:291 */     method.setName("addCriterion");
/* 263:292 */     method.addParameter(new Parameter(
/* 264:293 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 265:294 */     method.addParameter(new Parameter(
/* 266:295 */       FullyQualifiedJavaType.getObjectInstance(), "value1"));
/* 267:296 */     method.addParameter(new Parameter(
/* 268:297 */       FullyQualifiedJavaType.getObjectInstance(), "value2"));
/* 269:298 */     method.addParameter(new Parameter(
/* 270:299 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 271:300 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/* 272:301 */     method
/* 273:302 */       .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 274:303 */     method.addBodyLine("}");
/* 275:304 */     method.addBodyLine("List<Object> list = new ArrayList<Object>();");
/* 276:305 */     method.addBodyLine("list.add(value1);");
/* 277:306 */     method.addBodyLine("list.add(value2);");
/* 278:307 */     method
/* 279:308 */       .addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/* 280:309 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 281:310 */     method.addBodyLine("map.put(\"values\", list);");
/* 282:311 */     method.addBodyLine("criteriaWithBetweenValue.add(map);");
/* 283:312 */     answer.addMethod(method);
/* 284:    */     
/* 285:314 */     FullyQualifiedJavaType listOfDates = 
/* 286:315 */       FullyQualifiedJavaType.getNewListInstance();
/* 287:316 */     listOfDates.addTypeArgument(FullyQualifiedJavaType.getDateInstance());
/* 288:318 */     if (introspectedTable.hasJDBCDateColumns())
/* 289:    */     {
/* 290:319 */       topLevelClass.addImportedType(
/* 291:320 */         FullyQualifiedJavaType.getDateInstance());
/* 292:321 */       topLevelClass.addImportedType(
/* 293:322 */         FullyQualifiedJavaType.getNewIteratorInstance());
/* 294:323 */       method = new Method();
/* 295:324 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 296:325 */       method.setName("addCriterionForJDBCDate");
/* 297:326 */       method.addParameter(new Parameter(
/* 298:327 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 299:328 */       method.addParameter(new Parameter(
/* 300:329 */         FullyQualifiedJavaType.getDateInstance(), "value"));
/* 301:330 */       method.addParameter(new Parameter(
/* 302:331 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/* 303:332 */       method
/* 304:333 */         .addBodyLine("addCriterion(condition, new java.sql.Date(value.getTime()), property);");
/* 305:334 */       answer.addMethod(method);
/* 306:    */       
/* 307:336 */       method = new Method();
/* 308:337 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 309:338 */       method.setName("addCriterionForJDBCDate");
/* 310:339 */       method.addParameter(new Parameter(
/* 311:340 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 312:341 */       method.addParameter(new Parameter(listOfDates, "values"));
/* 313:342 */       method.addParameter(new Parameter(
/* 314:343 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/* 315:344 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/* 316:345 */       method
/* 317:346 */         .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/* 318:347 */       method.addBodyLine("}");
/* 319:348 */       method
/* 320:349 */         .addBodyLine("List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();");
/* 321:350 */       method.addBodyLine("Iterator<Date> iter = values.iterator();");
/* 322:351 */       method.addBodyLine("while (iter.hasNext()) {");
/* 323:352 */       method
/* 324:353 */         .addBodyLine("dateList.add(new java.sql.Date(iter.next().getTime()));");
/* 325:354 */       method.addBodyLine("}");
/* 326:355 */       method
/* 327:356 */         .addBodyLine("addCriterion(condition, dateList, property);");
/* 328:357 */       answer.addMethod(method);
/* 329:    */       
/* 330:359 */       method = new Method();
/* 331:360 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 332:361 */       method.setName("addCriterionForJDBCDate");
/* 333:362 */       method.addParameter(new Parameter(
/* 334:363 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 335:364 */       method.addParameter(new Parameter(
/* 336:365 */         FullyQualifiedJavaType.getDateInstance(), "value1"));
/* 337:366 */       method.addParameter(new Parameter(
/* 338:367 */         FullyQualifiedJavaType.getDateInstance(), "value2"));
/* 339:368 */       method.addParameter(new Parameter(
/* 340:369 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/* 341:370 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/* 342:371 */       method
/* 343:372 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 344:373 */       method.addBodyLine("}");
/* 345:374 */       method
/* 346:375 */         .addBodyLine("addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);");
/* 347:376 */       answer.addMethod(method);
/* 348:    */     }
/* 349:379 */     if (introspectedTable.hasJDBCTimeColumns())
/* 350:    */     {
/* 351:380 */       topLevelClass.addImportedType(
/* 352:381 */         FullyQualifiedJavaType.getDateInstance());
/* 353:382 */       topLevelClass.addImportedType(
/* 354:383 */         FullyQualifiedJavaType.getNewIteratorInstance());
/* 355:384 */       method = new Method();
/* 356:385 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 357:386 */       method.setName("addCriterionForJDBCTime");
/* 358:387 */       method.addParameter(new Parameter(
/* 359:388 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 360:389 */       method.addParameter(new Parameter(
/* 361:390 */         FullyQualifiedJavaType.getDateInstance(), "value"));
/* 362:391 */       method.addParameter(new Parameter(
/* 363:392 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/* 364:393 */       method
/* 365:394 */         .addBodyLine("addCriterion(condition, new java.sql.Time(value.getTime()), property);");
/* 366:395 */       answer.addMethod(method);
/* 367:    */       
/* 368:397 */       method = new Method();
/* 369:398 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 370:399 */       method.setName("addCriterionForJDBCTime");
/* 371:400 */       method.addParameter(new Parameter(
/* 372:401 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 373:402 */       method.addParameter(new Parameter(listOfDates, "values"));
/* 374:403 */       method.addParameter(new Parameter(
/* 375:404 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/* 376:405 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/* 377:406 */       method
/* 378:407 */         .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/* 379:408 */       method.addBodyLine("}");
/* 380:409 */       method
/* 381:410 */         .addBodyLine("List<java.sql.Time> dateList = new ArrayList<java.sql.Time>();");
/* 382:411 */       method.addBodyLine("Iterator<Date> iter = values.iterator();");
/* 383:412 */       method.addBodyLine("while (iter.hasNext()) {");
/* 384:413 */       method
/* 385:414 */         .addBodyLine("dateList.add(new java.sql.Time(iter.next().getTime()));");
/* 386:415 */       method.addBodyLine("}");
/* 387:416 */       method
/* 388:417 */         .addBodyLine("addCriterion(condition, dateList, property);");
/* 389:418 */       answer.addMethod(method);
/* 390:    */       
/* 391:420 */       method = new Method();
/* 392:421 */       method.setVisibility(JavaVisibility.PRIVATE);
/* 393:422 */       method.setName("addCriterionForJDBCTime");
/* 394:423 */       method.addParameter(new Parameter(
/* 395:424 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 396:425 */       method.addParameter(new Parameter(
/* 397:426 */         FullyQualifiedJavaType.getDateInstance(), "value1"));
/* 398:427 */       method.addParameter(new Parameter(
/* 399:428 */         FullyQualifiedJavaType.getDateInstance(), "value2"));
/* 400:429 */       method.addParameter(new Parameter(
/* 401:430 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/* 402:431 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/* 403:432 */       method
/* 404:433 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 405:434 */       method.addBodyLine("}");
/* 406:435 */       method
/* 407:436 */         .addBodyLine("addCriterion(condition, new java.sql.Time(value1.getTime()), new java.sql.Time(value2.getTime()), property);");
/* 408:437 */       answer.addMethod(method);
/* 409:    */     }
/* 410:440 */     iter = introspectedTable.getNonBLOBColumns();
/* 411:441 */     while (iter.hasNext())
/* 412:    */     {
/* 413:442 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 414:    */       
/* 415:444 */       topLevelClass.addImportedType(cd.getResolvedJavaType()
/* 416:445 */         .getFullyQualifiedJavaType());
/* 417:    */       
/* 418:    */ 
/* 419:    */ 
/* 420:449 */       answer.addMethod(getSetNullMethod(cd));
/* 421:450 */       answer.addMethod(getSetNotNullMethod(cd));
/* 422:451 */       answer.addMethod(getSetEqualMethod(cd));
/* 423:452 */       answer.addMethod(getSetNotEqualMethod(cd));
/* 424:453 */       answer.addMethod(getSetGreaterThanMethod(cd));
/* 425:454 */       answer.addMethod(getSetGreaterThenOrEqualMethod(cd));
/* 426:455 */       answer.addMethod(getSetLessThanMethod(cd));
/* 427:456 */       answer.addMethod(getSetLessThanOrEqualMethod(cd));
/* 428:458 */       if (cd.isJdbcCharacterColumn())
/* 429:    */       {
/* 430:459 */         answer.addMethod(getSetLikeMethod(cd));
/* 431:460 */         answer.addMethod(getSetNotLikeMethod(cd));
/* 432:    */       }
/* 433:463 */       answer.addMethod(getSetInOrNotInMethod(cd, true));
/* 434:464 */       answer.addMethod(getSetInOrNotInMethod(cd, false));
/* 435:465 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(cd, true));
/* 436:466 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(cd, false));
/* 437:    */     }
/* 438:469 */     return answer;
/* 439:    */   }
/* 440:    */   
/* 441:    */   protected Method getSetInOrNotInMethod(ColumnDefinition cd, boolean inMethod)
/* 442:    */   {
/* 443:481 */     Method method = new Method();
/* 444:482 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 445:483 */     FullyQualifiedJavaType type = 
/* 446:484 */       FullyQualifiedJavaType.getNewListInstance();
/* 447:485 */     if (cd.getResolvedJavaType().getFullyQualifiedJavaType().isPrimitive()) {
/* 448:486 */       type.addTypeArgument(cd.getResolvedJavaType()
/* 449:487 */         .getFullyQualifiedJavaType().getPrimitiveTypeWrapper());
/* 450:    */     } else {
/* 451:489 */       type.addTypeArgument(cd.getResolvedJavaType()
/* 452:490 */         .getFullyQualifiedJavaType());
/* 453:    */     }
/* 454:492 */     method.addParameter(new Parameter(type, "values"));
/* 455:493 */     StringBuffer sb = new StringBuffer();
/* 456:494 */     sb.append(cd.getJavaProperty());
/* 457:495 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 458:496 */     sb.insert(0, "and");
/* 459:497 */     if (inMethod) {
/* 460:498 */       sb.append("In");
/* 461:    */     } else {
/* 462:500 */       sb.append("NotIn");
/* 463:    */     }
/* 464:502 */     method.setName(sb.toString());
/* 465:503 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/* 466:504 */     sb.setLength(0);
/* 467:506 */     if (cd.isJDBCDateColumn())
/* 468:    */     {
/* 469:507 */       sb.append("addCriterionForJDBCDate(\"");
/* 470:    */     }
/* 471:508 */     else if (cd.isJDBCTimeColumn())
/* 472:    */     {
/* 473:509 */       sb.append("addCriterionForJDBCTime(\"");
/* 474:    */     }
/* 475:510 */     else if (StringUtility.stringHasValue(cd.getTypeHandler()))
/* 476:    */     {
/* 477:511 */       sb.append("add");
/* 478:512 */       sb.append(cd.getJavaProperty());
/* 479:513 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 480:514 */       sb.append("Criterion(\"");
/* 481:    */     }
/* 482:    */     else
/* 483:    */     {
/* 484:516 */       sb.append("addCriterion(\"");
/* 485:    */     }
/* 486:519 */     sb.append(cd.getAliasedColumnName());
/* 487:520 */     if (inMethod) {
/* 488:521 */       sb.append(" in");
/* 489:    */     } else {
/* 490:523 */       sb.append(" not in");
/* 491:    */     }
/* 492:525 */     sb.append("\", values, \"");
/* 493:526 */     sb.append(cd.getJavaProperty());
/* 494:527 */     sb.append("\");");
/* 495:528 */     method.addBodyLine(sb.toString());
/* 496:529 */     method.addBodyLine("return this;");
/* 497:    */     
/* 498:531 */     return method;
/* 499:    */   }
/* 500:    */   
/* 501:    */   private void addtypeHandledObjectsAndMethods(ColumnDefinition cd, Method constructor, InnerClass innerClass)
/* 502:    */   {
/* 503:544 */     StringBuffer sb = new StringBuffer();
/* 504:    */     
/* 505:    */ 
/* 506:547 */     FullyQualifiedJavaType innerMapType = 
/* 507:548 */       FullyQualifiedJavaType.getNewMapInstance();
/* 508:549 */     innerMapType
/* 509:550 */       .addTypeArgument(FullyQualifiedJavaType.getStringInstance());
/* 510:551 */     innerMapType
/* 511:552 */       .addTypeArgument(FullyQualifiedJavaType.getObjectInstance());
/* 512:    */     
/* 513:554 */     FullyQualifiedJavaType listOfMaps = 
/* 514:555 */       FullyQualifiedJavaType.getNewListInstance();
/* 515:556 */     listOfMaps.addTypeArgument(innerMapType);
/* 516:    */     
/* 517:558 */     sb.setLength(0);
/* 518:559 */     sb.append(cd.getJavaProperty());
/* 519:560 */     sb.append("CriteriaWithSingleValue");
/* 520:    */     
/* 521:562 */     Field field = new Field();
/* 522:563 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 523:564 */     field.setType(listOfMaps);
/* 524:565 */     field.setName(sb.toString());
/* 525:566 */     innerClass.addField(field);
/* 526:    */     
/* 527:568 */     Method method = new Method();
/* 528:569 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 529:570 */     method.setReturnType(field.getType());
/* 530:571 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 531:572 */     sb.insert(0, "return ");
/* 532:573 */     sb.append(';');
/* 533:574 */     method.addBodyLine(sb.toString());
/* 534:575 */     innerClass.addMethod(method);
/* 535:    */     
/* 536:577 */     sb.setLength(0);
/* 537:578 */     sb.append(cd.getJavaProperty());
/* 538:579 */     sb.append("CriteriaWithListValue");
/* 539:    */     
/* 540:581 */     field = new Field();
/* 541:582 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 542:583 */     field.setType(listOfMaps);
/* 543:584 */     field.setName(sb.toString());
/* 544:585 */     innerClass.addField(field);
/* 545:    */     
/* 546:587 */     method = new Method();
/* 547:588 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 548:589 */     method.setReturnType(field.getType());
/* 549:590 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 550:591 */     sb.insert(0, "return ");
/* 551:592 */     sb.append(';');
/* 552:593 */     method.addBodyLine(sb.toString());
/* 553:594 */     innerClass.addMethod(method);
/* 554:    */     
/* 555:596 */     sb.setLength(0);
/* 556:597 */     sb.append(cd.getJavaProperty());
/* 557:598 */     sb.append("CriteriaWithBetweenValue");
/* 558:    */     
/* 559:600 */     field = new Field();
/* 560:601 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 561:602 */     field.setType(listOfMaps);
/* 562:603 */     field.setName(sb.toString());
/* 563:604 */     innerClass.addField(field);
/* 564:    */     
/* 565:606 */     method = new Method();
/* 566:607 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 567:608 */     method.setReturnType(field.getType());
/* 568:609 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName()));
/* 569:610 */     sb.insert(0, "return ");
/* 570:611 */     sb.append(';');
/* 571:612 */     method.addBodyLine(sb.toString());
/* 572:613 */     innerClass.addMethod(method);
/* 573:    */     
/* 574:    */ 
/* 575:616 */     sb.setLength(0);
/* 576:617 */     sb.append(cd.getJavaProperty());
/* 577:618 */     sb
/* 578:619 */       .append("CriteriaWithSingleValue = new ArrayList<Map<String, Object>>();");
/* 579:620 */     constructor.addBodyLine(sb.toString());
/* 580:    */     
/* 581:622 */     sb.setLength(0);
/* 582:623 */     sb.append(cd.getJavaProperty());
/* 583:624 */     sb
/* 584:625 */       .append("CriteriaWithListValue = new ArrayList<Map<String, Object>>();");
/* 585:626 */     constructor.addBodyLine(sb.toString());
/* 586:    */     
/* 587:628 */     sb.setLength(0);
/* 588:629 */     sb.append(cd.getJavaProperty());
/* 589:630 */     sb
/* 590:631 */       .append("CriteriaWithBetweenValue = new ArrayList<Map<String, Object>>();");
/* 591:632 */     constructor.addBodyLine(sb.toString());
/* 592:    */     
/* 593:    */ 
/* 594:635 */     method = new Method();
/* 595:636 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 596:637 */     sb.setLength(0);
/* 597:638 */     sb.append("add");
/* 598:639 */     sb.append(cd.getJavaProperty());
/* 599:640 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 600:641 */     sb.append("Criterion");
/* 601:    */     
/* 602:643 */     method.setName(sb.toString());
/* 603:644 */     method.addParameter(new Parameter(
/* 604:645 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 605:646 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value"));
/* 606:647 */     method.addParameter(new Parameter(
/* 607:648 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 608:649 */     method.addBodyLine("if (value == null) {");
/* 609:650 */     method
/* 610:651 */       .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/* 611:652 */     method.addBodyLine("}");
/* 612:653 */     method
/* 613:654 */       .addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/* 614:655 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 615:656 */     method.addBodyLine("map.put(\"value\", value);");
/* 616:    */     
/* 617:658 */     sb.setLength(0);
/* 618:659 */     sb.append(cd.getJavaProperty());
/* 619:660 */     sb.append("CriteriaWithSingleValue.add(map);");
/* 620:661 */     method.addBodyLine(sb.toString());
/* 621:662 */     innerClass.addMethod(method);
/* 622:    */     
/* 623:664 */     FullyQualifiedJavaType listOfObjects = 
/* 624:665 */       FullyQualifiedJavaType.getNewListInstance();
/* 625:666 */     listOfObjects.addTypeArgument(cd.getResolvedJavaType().getFullyQualifiedJavaType());
/* 626:    */     
/* 627:    */ 
/* 628:669 */     sb.setLength(0);
/* 629:670 */     sb.append("add");
/* 630:671 */     sb.append(cd.getJavaProperty());
/* 631:672 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 632:673 */     sb.append("Criterion");
/* 633:    */     
/* 634:675 */     method = new Method();
/* 635:676 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 636:677 */     method.setName(sb.toString());
/* 637:678 */     method.addParameter(new Parameter(
/* 638:679 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 639:680 */     method.addParameter(new Parameter(listOfObjects, "values"));
/* 640:681 */     method.addParameter(new Parameter(
/* 641:682 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 642:683 */     method.addBodyLine("if (values == null || values.size() == 0) {");
/* 643:684 */     method
/* 644:685 */       .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/* 645:686 */     method.addBodyLine("}");
/* 646:687 */     method
/* 647:688 */       .addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/* 648:689 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 649:690 */     method.addBodyLine("map.put(\"values\", values);");
/* 650:    */     
/* 651:692 */     sb.setLength(0);
/* 652:693 */     sb.append(cd.getJavaProperty());
/* 653:694 */     sb.append("CriteriaWithListValue.add(map);");
/* 654:695 */     method.addBodyLine(sb.toString());
/* 655:696 */     innerClass.addMethod(method);
/* 656:    */     
/* 657:698 */     sb.setLength(0);
/* 658:699 */     sb.append("add");
/* 659:700 */     sb.append(cd.getJavaProperty());
/* 660:701 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 661:702 */     sb.append("Criterion");
/* 662:    */     
/* 663:704 */     method = new Method();
/* 664:705 */     method.setVisibility(JavaVisibility.PRIVATE);
/* 665:706 */     method.setName(sb.toString());
/* 666:707 */     method.addParameter(new Parameter(
/* 667:708 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 668:709 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value1"));
/* 669:710 */     method.addParameter(new Parameter(cd.getResolvedJavaType().getFullyQualifiedJavaType(), "value2"));
/* 670:711 */     method.addParameter(new Parameter(
/* 671:712 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 672:713 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/* 673:714 */     method
/* 674:715 */       .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 675:716 */     method.addBodyLine("}");
/* 676:717 */     method.addBodyLine("List<Object> list = new ArrayList<Object>();");
/* 677:718 */     method.addBodyLine("list.add(value1);");
/* 678:719 */     method.addBodyLine("list.add(value2);");
/* 679:720 */     method
/* 680:721 */       .addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/* 681:722 */     method.addBodyLine("map.put(\"condition\", condition);");
/* 682:723 */     method.addBodyLine("map.put(\"values\", list);");
/* 683:    */     
/* 684:725 */     sb.setLength(0);
/* 685:726 */     sb.append(cd.getJavaProperty());
/* 686:727 */     sb.append("CriteriaWithBetweenValue.add(map);");
/* 687:728 */     method.addBodyLine(sb.toString());
/* 688:729 */     innerClass.addMethod(method);
/* 689:    */   }
/* 690:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorJava5Impl
 * JD-Core Version:    0.7.0.1
 */