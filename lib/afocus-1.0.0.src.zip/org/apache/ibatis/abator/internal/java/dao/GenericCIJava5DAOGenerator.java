/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ public class GenericCIJava5DAOGenerator
/*  4:   */   extends BaseDAOGenerator
/*  5:   */ {
/*  6:   */   public GenericCIJava5DAOGenerator()
/*  7:   */   {
/*  8:24 */     super(new GenericCIDAOTemplate(), true);
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.GenericCIJava5DAOGenerator
 * JD-Core Version:    0.7.0.1
 */