/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.Field;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  6:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  7:   */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  8:   */ 
/*  9:   */ public class GenericCIDAOTemplate
/* 10:   */   extends AbstractDAOTemplate
/* 11:   */ {
/* 12:   */   public GenericCIDAOTemplate()
/* 13:   */   {
/* 14:35 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.ibatis.sqlmap.client.SqlMapClient");
/* 15:   */     
/* 16:37 */     Method constructor = new Method();
/* 17:38 */     constructor.setConstructor(true);
/* 18:39 */     constructor.setVisibility(JavaVisibility.PUBLIC);
/* 19:40 */     constructor.addParameter(new Parameter(fqjt, "sqlMapClient"));
/* 20:41 */     constructor.addBodyLine("super();");
/* 21:42 */     constructor.addBodyLine("this.sqlMapClient = sqlMapClient;");
/* 22:43 */     setConstructorTemplate(constructor);
/* 23:   */     
/* 24:45 */     Field field = new Field();
/* 25:46 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 26:47 */     field.setType(fqjt);
/* 27:48 */     field.setName("sqlMapClient");
/* 28:49 */     addField(field);
/* 29:   */     
/* 30:51 */     addImplementationImport(fqjt);
/* 31:   */     
/* 32:53 */     addCheckedException(new FullyQualifiedJavaType("java.sql.SQLException"));
/* 33:54 */     setDeleteMethodTemplate("sqlMapClient.delete(\"{0}.{1}\", {2});");
/* 34:55 */     setInsertMethodTemplate("sqlMapClient.insert(\"{0}.{1}\", {2});");
/* 35:56 */     setQueryForObjectMethodTemplate("sqlMapClient.queryForObject(\"{0}.{1}\", {2});");
/* 36:57 */     setQueryForListMethodTemplate("sqlMapClient.queryForList(\"{0}.{1}\", {2});");
/* 37:58 */     setUpdateMethodTemplate("sqlMapClient.update(\"{0}.{1}\", {2});");
/* 38:   */   }
/* 39:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.GenericCIDAOTemplate
 * JD-Core Version:    0.7.0.1
 */