/*   1:    */ package org.apache.ibatis.abator.internal.java.dao;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   7:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   8:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   9:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  10:    */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*  11:    */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*  12:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  13:    */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  14:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  15:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  16:    */ 
/*  17:    */ public class SpringAbatorLegacyDAOGenerator
/*  18:    */   extends BaseLegacyDAOGenerator
/*  19:    */ {
/*  20:    */   public SpringAbatorLegacyDAOGenerator()
/*  21:    */   {
/*  22: 42 */     super(new SpringAbatorDAOTemplate());
/*  23:    */   }
/*  24:    */   
/*  25:    */   public SpringAbatorLegacyDAOGenerator(AbstractDAOTemplate daoTemplate, boolean useJava5)
/*  26:    */   {
/*  27: 46 */     super(daoTemplate, useJava5);
/*  28:    */   }
/*  29:    */   
/*  30:    */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/*  31:    */   {
/*  32: 50 */     return new FullyQualifiedJavaType("com.afocus.framework.util.PageList");
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected List getExtraImplementationMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  36:    */   {
/*  37: 55 */     return null;
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected List getSelectByExampleWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  41:    */   {
/*  42: 61 */     return getSelectByExampleWithoutBLOBsMethods(introspectedTable, interfaceMethod, compilationUnit, 
/*  43: 62 */       this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable), 
/*  44: 63 */       this.sqlMapGenerator.getSelectByExampleStatementId());
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected List getSelectByExampleWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  48:    */   {
/*  49: 69 */     return getSelectByExampleWithoutBLOBsMethods(introspectedTable, interfaceMethod, compilationUnit, 
/*  50: 70 */       this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable), 
/*  51: 71 */       this.sqlMapGenerator.getSelectByExampleWithBLOBsStatementId());
/*  52:    */   }
/*  53:    */   
/*  54:    */   private List getSelectByExampleWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit, String selectByExampleMethodName, String selectByExampleStatementId)
/*  55:    */   {
/*  56: 78 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  57: 79 */       return null;
/*  58:    */     }
/*  59: 82 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  60: 83 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/*  61: 84 */     compilationUnit.addImportedType(type);
/*  62: 85 */     compilationUnit.addImportedType(getSelectByExampleReturnListJavaType());
/*  63:    */     
/*  64: 87 */     Method method = new Method();
/*  65: 88 */     method.addComment(table);
/*  66: 89 */     method.setVisibility(this.exampleMethodVisibility);
/*  67: 90 */     method.setReturnType(getSelectByExampleReturnListJavaType());
/*  68: 91 */     method.setName(selectByExampleMethodName);
/*  69: 92 */     method.addParameter(new Parameter(type, "params, int pageNum, int numPerPage, boolean doCount"));
/*  70:    */     
/*  71: 94 */     Method method2 = new Method();
/*  72: 95 */     method2.addComment(table);
/*  73: 96 */     method2.setVisibility(this.exampleMethodVisibility);
/*  74: 97 */     method2.setReturnType(getSelectByExampleReturnListJavaType());
/*  75: 98 */     method2.setName(selectByExampleMethodName);
/*  76: 99 */     method2.addParameter(new Parameter(type, "params, int pageNum, int numPerPage"));
/*  77:    */     
/*  78:101 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  79:102 */     while (iter.hasNext())
/*  80:    */     {
/*  81:103 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  82:104 */       method.addException(fqjt);
/*  83:105 */       method2.addException(fqjt);
/*  84:106 */       compilationUnit.addImportedType(fqjt);
/*  85:    */     }
/*  86:109 */     if (!interfaceMethod)
/*  87:    */     {
/*  88:111 */       compilationUnit.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
/*  89:    */       
/*  90:113 */       StringBuffer sb = new StringBuffer();
/*  91:115 */       if (this.suppressTypeWarnings) {
/*  92:116 */         method.addSuppressTypeWarningsAnnotation();
/*  93:    */       }
/*  94:119 */       sb.append("return ");
/*  95:120 */       sb.append(this.daoTemplate.getQueryForListMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/*  96:121 */         selectByExampleStatementId, "params, pageNum, numPerPage, doCount"));
/*  97:122 */       method.addBodyLine(sb.toString());
/*  98:    */       
/*  99:124 */       sb.setLength(0);
/* 100:125 */       sb.append("return ");
/* 101:126 */       sb.append(selectByExampleMethodName);
/* 102:127 */       sb.append("(params, pageNum, numPerPage, true);");
/* 103:128 */       method2.addBodyLine(sb.toString());
/* 104:    */     }
/* 105:131 */     ArrayList answer = new ArrayList();
/* 106:132 */     answer.add(method);
/* 107:133 */     answer.add(method2);
/* 108:    */     
/* 109:135 */     return answer;
/* 110:    */   }
/* 111:    */   
/* 112:    */   protected List getDeleteByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 113:    */   {
/* 114:143 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 115:144 */       return null;
/* 116:    */     }
/* 117:147 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 118:148 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 119:149 */     compilationUnit.addImportedType(type);
/* 120:    */     
/* 121:151 */     Method method = new Method();
/* 122:152 */     method.addComment(table);
/* 123:153 */     method.setVisibility(this.exampleMethodVisibility);
/* 124:154 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 125:155 */     method.setName(this.methodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 126:156 */     method.addParameter(new Parameter(type, "params"));
/* 127:    */     
/* 128:158 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/* 129:159 */     while (iter.hasNext())
/* 130:    */     {
/* 131:160 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 132:161 */       method.addException(fqjt);
/* 133:162 */       compilationUnit.addImportedType(fqjt);
/* 134:    */     }
/* 135:165 */     if (!interfaceMethod)
/* 136:    */     {
/* 137:167 */       StringBuffer sb = new StringBuffer();
/* 138:    */       
/* 139:    */ 
/* 140:170 */       sb.append("return ");
/* 141:171 */       sb.append(this.daoTemplate.getDeleteMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/* 142:172 */         this.sqlMapGenerator.getDeleteByExampleStatementId(), 
/* 143:173 */         "params"));
/* 144:174 */       method.addBodyLine(sb.toString());
/* 145:    */     }
/* 146:179 */     ArrayList answer = new ArrayList();
/* 147:180 */     answer.add(method);
/* 148:    */     
/* 149:182 */     return answer;
/* 150:    */   }
/* 151:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringAbatorLegacyDAOGenerator
 * JD-Core Version:    0.7.0.1
 */