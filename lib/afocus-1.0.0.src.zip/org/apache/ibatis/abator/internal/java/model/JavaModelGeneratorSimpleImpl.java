/*  1:   */ package org.apache.ibatis.abator.internal.java.model;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  4:   */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  5:   */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  6:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  7:   */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*  8:   */ 
/*  9:   */ public class JavaModelGeneratorSimpleImpl
/* 10:   */   extends JavaModelGeneratorJava2Impl
/* 11:   */   implements JavaModelGenerator
/* 12:   */ {
/* 13:   */   public FullyQualifiedJavaType getExampleType(FullyQualifiedTable table)
/* 14:   */   {
/* 15:64 */     return new FullyQualifiedJavaType("java.util.Map");
/* 16:   */   }
/* 17:   */   
/* 18:   */   public TopLevelClass getExample(IntrospectedTable introspectedTable)
/* 19:   */   {
/* 20:68 */     return null;
/* 21:   */   }
/* 22:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorSimpleImpl
 * JD-Core Version:    0.7.0.1
 */