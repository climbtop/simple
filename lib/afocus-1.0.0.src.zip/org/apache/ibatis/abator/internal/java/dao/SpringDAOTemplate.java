/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  6:   */ 
/*  7:   */ public class SpringDAOTemplate
/*  8:   */   extends AbstractDAOTemplate
/*  9:   */ {
/* 10:   */   public SpringDAOTemplate()
/* 11:   */   {
/* 12:33 */     Method method = new Method();
/* 13:34 */     method.setConstructor(true);
/* 14:35 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 15:36 */     method.addBodyLine("super();");
/* 16:37 */     setConstructorTemplate(method);
/* 17:   */     
/* 18:39 */     setSuperClass(new FullyQualifiedJavaType(
/* 19:40 */       "org.springframework.orm.ibatis.support.SqlMapClientDaoSupport"));
/* 20:   */     
/* 21:42 */     setDeleteMethodTemplate("getSqlMapClientTemplate().delete(\"{0}.{1}\", {2});");
/* 22:43 */     setInsertMethodTemplate("getSqlMapClientTemplate().insert(\"{0}.{1}\", {2});");
/* 23:44 */     setQueryForObjectMethodTemplate("getSqlMapClientTemplate().queryForObject(\"{0}.{1}\", {2});");
/* 24:45 */     setQueryForListMethodTemplate("getSqlMapClientTemplate().queryForList(\"{0}.{1}\", {2});");
/* 25:46 */     setUpdateMethodTemplate("getSqlMapClientTemplate().update(\"{0}.{1}\", {2});");
/* 26:   */   }
/* 27:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringDAOTemplate
 * JD-Core Version:    0.7.0.1
 */