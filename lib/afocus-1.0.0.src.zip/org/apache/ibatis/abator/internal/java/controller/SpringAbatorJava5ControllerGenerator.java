/*  1:   */ package org.apache.ibatis.abator.internal.java.controller;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.ControllerGenerator;
/*  4:   */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  6:   */ import org.apache.ibatis.abator.internal.SpringAbatorJava5ServiceMethodNameCalculator;
/*  7:   */ 
/*  8:   */ public class SpringAbatorJava5ControllerGenerator
/*  9:   */   extends BaseControllerGenerator
/* 10:   */   implements ControllerGenerator
/* 11:   */ {
/* 12:   */   public SpringAbatorJava5ControllerGenerator()
/* 13:   */   {
/* 14:69 */     super(new SpringAbatorJava5ControllerTemplate(), true);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setServiceGenerator(ServiceGenerator serviceGenerator)
/* 18:   */   {
/* 19:73 */     this.serviceGenerator = serviceGenerator;
/* 20:74 */     this.serviceMethodNameCalculator = new SpringAbatorJava5ServiceMethodNameCalculator();
/* 21:   */   }
/* 22:   */   
/* 23:   */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/* 24:   */   {
/* 25:79 */     return new FullyQualifiedJavaType("com.afocus.framework.util.PageList");
/* 26:   */   }
/* 27:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.controller.SpringAbatorJava5ControllerGenerator
 * JD-Core Version:    0.7.0.1
 */