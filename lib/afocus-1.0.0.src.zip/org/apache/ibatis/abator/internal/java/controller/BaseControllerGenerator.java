/*    1:     */ package org.apache.ibatis.abator.internal.java.controller;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.Arrays;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.Iterator;
/*    7:     */ import java.util.List;
/*    8:     */ import java.util.Map;
/*    9:     */ import org.apache.ibatis.abator.api.ControllerGenerator;
/*   10:     */ import org.apache.ibatis.abator.api.ControllerMethodNameCalculator;
/*   11:     */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   12:     */ import org.apache.ibatis.abator.api.GeneratedJavaFile;
/*   13:     */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   14:     */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   15:     */ import org.apache.ibatis.abator.api.ProgressCallback;
/*   16:     */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*   17:     */ import org.apache.ibatis.abator.api.ServiceMethodNameCalculator;
/*   18:     */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*   19:     */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   20:     */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   21:     */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*   22:     */ import org.apache.ibatis.abator.api.dom.java.Method;
/*   23:     */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*   24:     */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*   25:     */ import org.apache.ibatis.abator.internal.AbatorObjectFactory;
/*   26:     */ import org.apache.ibatis.abator.internal.DefaultControllerMethodNameCalculator;
/*   27:     */ import org.apache.ibatis.abator.internal.DefaultServiceMethodNameCalculator;
/*   28:     */ import org.apache.ibatis.abator.internal.ExtendedControllerMethodNameCalculator;
/*   29:     */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*   30:     */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   31:     */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*   32:     */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*   33:     */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   34:     */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*   35:     */ 
/*   36:     */ public class BaseControllerGenerator
/*   37:     */   implements ControllerGenerator
/*   38:     */ {
/*   39:     */   protected AbstractControllerTemplate controllerTemplate;
/*   40:     */   protected Map properties;
/*   41:     */   protected List warnings;
/*   42:     */   protected String targetPackage;
/*   43:     */   protected String targetProject;
/*   44:     */   protected JavaModelGenerator javaModelGenerator;
/*   45:     */   protected ServiceGenerator serviceGenerator;
/*   46:     */   private Map tableValueMaps;
/*   47:     */   private boolean useJava5Features;
/*   48: 109 */   private boolean permission = false;
/*   49: 110 */   private boolean operateLog = false;
/*   50:     */   protected String moduleUrlPrefix;
/*   51: 114 */   protected ServiceMethodNameCalculator serviceMethodNameCalculator = new DefaultServiceMethodNameCalculator();
/*   52: 116 */   protected ControllerMethodNameCalculator methodNameCalculator = new DefaultControllerMethodNameCalculator();
/*   53:     */   
/*   54:     */   public BaseControllerGenerator()
/*   55:     */   {
/*   56: 121 */     this(new AbstractControllerTemplate(), false);
/*   57:     */   }
/*   58:     */   
/*   59:     */   public BaseControllerGenerator(AbstractControllerTemplate serviceTemplate, boolean useJava5Features)
/*   60:     */   {
/*   61: 126 */     this.controllerTemplate = serviceTemplate;
/*   62: 127 */     this.useJava5Features = useJava5Features;
/*   63: 128 */     this.tableValueMaps = new HashMap();
/*   64: 129 */     this.properties = new HashMap();
/*   65:     */   }
/*   66:     */   
/*   67:     */   public void addConfigurationProperties(Map properties)
/*   68:     */   {
/*   69: 133 */     this.properties.putAll(properties);
/*   70: 135 */     if (properties.containsKey("moduleUrlPrefix"))
/*   71:     */     {
/*   72: 136 */       String temp = (String)properties.get("moduleUrlPrefix");
/*   73: 137 */       if ((temp != null) && (temp.trim().length() > 0)) {
/*   74: 138 */         this.moduleUrlPrefix = temp;
/*   75:     */       }
/*   76:     */     }
/*   77: 141 */     if (properties.containsKey("permission"))
/*   78:     */     {
/*   79: 142 */       String temp = (String)properties.get("permission");
/*   80: 143 */       this.permission = "true".equalsIgnoreCase(temp);
/*   81:     */     }
/*   82: 146 */     if (properties.containsKey("operateLog"))
/*   83:     */     {
/*   84: 147 */       String temp = (String)properties.get("operateLog");
/*   85: 148 */       this.operateLog = "true".equalsIgnoreCase(temp);
/*   86:     */     }
/*   87: 151 */     if (properties.containsKey("methodNameCalculator"))
/*   88:     */     {
/*   89: 152 */       String value = (String)properties.get("methodNameCalculator");
/*   90: 154 */       if ("extended".equalsIgnoreCase(value)) {
/*   91: 155 */         this.methodNameCalculator = new ExtendedControllerMethodNameCalculator();
/*   92: 157 */       } else if ((!"default".equalsIgnoreCase(value)) && 
/*   93: 158 */         (StringUtility.stringHasValue(value))) {
/*   94:     */         try
/*   95:     */         {
/*   96: 160 */           this.methodNameCalculator = ((ControllerMethodNameCalculator)AbatorObjectFactory.createObject(value));
/*   97:     */         }
/*   98:     */         catch (Exception e)
/*   99:     */         {
/*  100: 163 */           this.warnings.add(Messages.getString("Warning.17", value, Arrays.deepToString(e.getStackTrace())));
/*  101:     */         }
/*  102:     */       }
/*  103:     */     }
/*  104:     */   }
/*  105:     */   
/*  106:     */   public void setWarnings(List warnings)
/*  107:     */   {
/*  108: 175 */     this.warnings = warnings;
/*  109:     */   }
/*  110:     */   
/*  111:     */   public void setTargetPackage(String targetPackage)
/*  112:     */   {
/*  113: 184 */     this.targetPackage = targetPackage;
/*  114: 185 */     if (this.moduleUrlPrefix == null)
/*  115:     */     {
/*  116: 186 */       this.moduleUrlPrefix = targetPackage;
/*  117: 187 */       if (targetPackage.endsWith(".web.controller")) {
/*  118: 188 */         this.moduleUrlPrefix = targetPackage.substring(0, targetPackage.lastIndexOf(".web.controller"));
/*  119: 189 */       } else if (targetPackage.endsWith(".controller")) {
/*  120: 190 */         this.moduleUrlPrefix = targetPackage.substring(0, targetPackage.lastIndexOf(".controller"));
/*  121:     */       }
/*  122: 191 */       if (this.moduleUrlPrefix.endsWith(".")) {
/*  123: 192 */         this.moduleUrlPrefix = this.moduleUrlPrefix.substring(this.moduleUrlPrefix.lastIndexOf(".") + 1);
/*  124:     */       }
/*  125:     */     }
/*  126:     */   }
/*  127:     */   
/*  128:     */   public void setTargetProject(String targetProject)
/*  129:     */   {
/*  130: 202 */     this.targetProject = targetProject;
/*  131:     */   }
/*  132:     */   
/*  133:     */   public void setJavaModelGenerator(JavaModelGenerator javaModelGenerator)
/*  134:     */   {
/*  135: 211 */     this.javaModelGenerator = javaModelGenerator;
/*  136:     */   }
/*  137:     */   
/*  138:     */   public void setServiceGenerator(ServiceGenerator serviceGenerator)
/*  139:     */   {
/*  140: 220 */     this.serviceGenerator = serviceGenerator;
/*  141: 221 */     this.serviceMethodNameCalculator = serviceGenerator.getMethodNameCalculator();
/*  142:     */   }
/*  143:     */   
/*  144:     */   public List getGeneratedJavaFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/*  145:     */   {
/*  146: 231 */     List list = new ArrayList();
/*  147:     */     
/*  148: 233 */     String tableName = introspectedTable.getTable().getFullyQualifiedTableName();
/*  149:     */     
/*  150: 235 */     callback.startSubTask(Messages.getString("Progress.13", 
/*  151: 236 */       tableName));
/*  152:     */     
/*  153: 238 */     CompilationUnit cu = getController(introspectedTable);
/*  154: 239 */     GeneratedJavaFile gjf = new GeneratedJavaFile(cu, this.targetProject);
/*  155: 240 */     list.add(gjf);
/*  156:     */     
/*  157:     */ 
/*  158:     */ 
/*  159:     */ 
/*  160:     */ 
/*  161: 246 */     return list;
/*  162:     */   }
/*  163:     */   
/*  164:     */   public String getServicePropertyName(FullyQualifiedTable table)
/*  165:     */   {
/*  166: 250 */     String key = "getServicePropertyName";
/*  167:     */     
/*  168: 252 */     Map map = getTableValueMap(table);
/*  169: 253 */     String property = (String)map.get(key);
/*  170: 254 */     if (property == null)
/*  171:     */     {
/*  172: 255 */       FullyQualifiedJavaType fqjt = this.serviceGenerator.getServiceInterfaceType(table);
/*  173: 256 */       property = JavaBeansUtil.getValidPropertyName(fqjt.getShortName());
/*  174: 257 */       map.put(key, property);
/*  175:     */     }
/*  176: 260 */     return property;
/*  177:     */   }
/*  178:     */   
/*  179:     */   public String getValidatorPropertyName(FullyQualifiedTable table)
/*  180:     */   {
/*  181: 264 */     String key = "getValidatorPropertyName";
/*  182:     */     
/*  183: 266 */     Map map = getTableValueMap(table);
/*  184: 267 */     String property = (String)map.get(key);
/*  185: 268 */     if (property == null)
/*  186:     */     {
/*  187: 269 */       property = getRecordPropertyName(table) + "Validator";
/*  188: 270 */       map.put(key, property);
/*  189:     */     }
/*  190: 273 */     return property;
/*  191:     */   }
/*  192:     */   
/*  193:     */   public String getRecordPropertyName(FullyQualifiedTable table)
/*  194:     */   {
/*  195: 277 */     String key = "getRecordPropertyName";
/*  196:     */     
/*  197: 279 */     Map map = getTableValueMap(table);
/*  198: 280 */     String property = (String)map.get(key);
/*  199: 281 */     if (property == null)
/*  200:     */     {
/*  201: 282 */       property = JavaBeansUtil.getValidPropertyName(table.getDomainObjectName());
/*  202: 283 */       map.put(key, property);
/*  203:     */     }
/*  204: 286 */     return property;
/*  205:     */   }
/*  206:     */   
/*  207:     */   protected FullyQualifiedJavaType makeServicePropertyClassParts(FullyQualifiedTable table, TopLevelClass topLevelClass)
/*  208:     */   {
/*  209: 290 */     FullyQualifiedJavaType fqjt = this.serviceGenerator.getServiceInterfaceType(table);
/*  210: 291 */     String property = getServicePropertyName(table);
/*  211: 292 */     Field field = new Field();
/*  212: 293 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  213: 294 */     field.setType(fqjt);
/*  214: 295 */     field.setName(property);
/*  215: 296 */     topLevelClass.addField(field);
/*  216: 297 */     topLevelClass.addImportedType(fqjt);
/*  217: 299 */     if (this.useJava5Features) {
/*  218: 300 */       field.addAnnotation("@Resource");
/*  219:     */     }
/*  220: 302 */     return fqjt;
/*  221:     */   }
/*  222:     */   
/*  223:     */   public String getUrlPrefix(FullyQualifiedTable table)
/*  224:     */   {
/*  225: 306 */     String key = "getUrlPrefix";
/*  226:     */     
/*  227: 308 */     String urlPrefix = "";
/*  228: 309 */     Map map = getTableValueMap(table);
/*  229: 310 */     urlPrefix = (String)map.get(key);
/*  230: 311 */     if (urlPrefix == null)
/*  231:     */     {
/*  232: 312 */       if (this.useJava5Features)
/*  233:     */       {
/*  234: 313 */         urlPrefix = "/" + this.moduleUrlPrefix + "/" + getRecordPropertyName(table);
/*  235: 314 */         urlPrefix = urlPrefix.replaceAll("//", "/");
/*  236:     */       }
/*  237:     */       else
/*  238:     */       {
/*  239: 317 */         urlPrefix = "";
/*  240:     */       }
/*  241: 318 */       map.put(key, urlPrefix);
/*  242:     */     }
/*  243: 321 */     return urlPrefix;
/*  244:     */   }
/*  245:     */   
/*  246:     */   protected TopLevelClass getController(IntrospectedTable introspectedTable)
/*  247:     */   {
/*  248: 326 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  249: 327 */     FullyQualifiedJavaType type = getControllerType(table);
/*  250: 328 */     TopLevelClass answer = new TopLevelClass(type);
/*  251: 329 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  252: 330 */     answer.setSuperClass(this.controllerTemplate.getSuperClass());
/*  253: 331 */     answer.addImportedType(this.controllerTemplate.getSuperClass());
/*  254:     */     
/*  255: 333 */     String urlPrefix = getUrlPrefix(table);
/*  256: 334 */     if (this.useJava5Features)
/*  257:     */     {
/*  258: 335 */       answer.addAnnotation("@Controller");
/*  259:     */       
/*  260: 337 */       answer.addAnnotation("@RequestMapping(\"" + urlPrefix + "\")");
/*  261:     */     }
/*  262: 340 */     Iterator iter = this.controllerTemplate.getImplementationImports().iterator();
/*  263: 341 */     while (iter.hasNext()) {
/*  264: 342 */       answer.addImportedType((FullyQualifiedJavaType)iter.next());
/*  265:     */     }
/*  266: 345 */     if (this.permission) {
/*  267: 346 */       createStaticFinalField("RESOURCE_CODE", JavaVisibility.PUBLIC, answer, table, getUrlPrefix(table));
/*  268:     */     }
/*  269: 348 */     createStaticFinalField("ROOT_VIEW", JavaVisibility.PRIVATE, answer, table, getUrlPrefix(table).substring(1));
/*  270: 349 */     createStaticFinalField("HOME_VIEW", JavaVisibility.PRIVATE, answer, table, getUrlPrefix(table).substring(1) + "/home");
/*  271: 350 */     createStaticFinalField("EDIT_VIEW", JavaVisibility.PRIVATE, answer, table, getUrlPrefix(table).substring(1) + "/edit");
/*  272:     */     
/*  273:     */ 
/*  274:     */ 
/*  275: 354 */     iter = this.controllerTemplate.getFieldClones(table);
/*  276: 355 */     while (iter.hasNext()) {
/*  277: 356 */       answer.addField((Field)iter.next());
/*  278:     */     }
/*  279: 360 */     iter = this.controllerTemplate.getMethodClones(table);
/*  280: 361 */     while (iter.hasNext()) {
/*  281: 362 */       answer.addMethod((Method)iter.next());
/*  282:     */     }
/*  283: 365 */     makeServicePropertyClassParts(table, answer);
/*  284:     */     
/*  285:     */ 
/*  286: 368 */     List methods = getListMethods(introspectedTable, answer);
/*  287: 369 */     addMethod(methods, answer);
/*  288:     */     
/*  289: 371 */     methods = getEditMethods(introspectedTable, answer);
/*  290: 372 */     addMethod(methods, answer);
/*  291:     */     
/*  292: 374 */     methods = getSaveMethods(introspectedTable, answer);
/*  293: 375 */     addMethod(methods, answer);
/*  294:     */     
/*  295: 377 */     methods = getDetailMethods(introspectedTable, answer);
/*  296: 378 */     addMethod(methods, answer);
/*  297:     */     
/*  298: 380 */     methods = getUpdateMethods(introspectedTable, answer);
/*  299: 381 */     addMethod(methods, answer);
/*  300:     */     
/*  301:     */ 
/*  302:     */ 
/*  303:     */ 
/*  304: 386 */     methods = getAuditMethods(introspectedTable, answer);
/*  305: 387 */     addMethod(methods, answer);
/*  306:     */     
/*  307:     */ 
/*  308:     */ 
/*  309:     */ 
/*  310: 392 */     methods = getDeleteMethods(introspectedTable, answer);
/*  311: 393 */     addMethod(methods, answer);
/*  312:     */     
/*  313: 395 */     methods = getGetPageListMethods(introspectedTable, answer);
/*  314: 396 */     addMethod(methods, answer);
/*  315:     */     
/*  316: 398 */     methods = getExtraImplementationMethods(introspectedTable, answer);
/*  317: 399 */     addMethod(methods, answer);
/*  318:     */     
/*  319: 401 */     return answer;
/*  320:     */   }
/*  321:     */   
/*  322:     */   private void addMethod(List methods, TopLevelClass answer)
/*  323:     */   {
/*  324: 433 */     if (methods != null)
/*  325:     */     {
/*  326: 434 */       Iterator iter = methods.iterator();
/*  327: 435 */       while (iter.hasNext()) {
/*  328: 436 */         answer.addMethod((Method)iter.next());
/*  329:     */       }
/*  330:     */     }
/*  331:     */   }
/*  332:     */   
/*  333:     */   protected List<Method> getExtraImplementationMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  334:     */   {
/*  335: 450 */     return null;
/*  336:     */   }
/*  337:     */   
/*  338:     */   public FullyQualifiedJavaType getControllerType(FullyQualifiedTable table)
/*  339:     */   {
/*  340: 455 */     String key = "getControllerType";
/*  341:     */     
/*  342: 457 */     Map map = getTableValueMap(table);
/*  343: 458 */     FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)map.get(key);
/*  344: 459 */     if (fqjt == null)
/*  345:     */     {
/*  346: 460 */       StringBuffer sb = new StringBuffer();
/*  347: 461 */       sb.append(getControllerPackage(table)).append(".");
/*  348: 462 */       sb.append(table.getDomainObjectName());
/*  349: 463 */       sb.append("Controller");
/*  350:     */       
/*  351: 465 */       fqjt = new FullyQualifiedJavaType(sb.toString());
/*  352: 466 */       map.put(key, fqjt);
/*  353:     */     }
/*  354: 469 */     return fqjt;
/*  355:     */   }
/*  356:     */   
/*  357:     */   protected List getGetPageListMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  358:     */   {
/*  359: 492 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  360: 493 */     Method method = new Method();
/*  361: 494 */     method.addComment(table);
/*  362:     */     
/*  363: 496 */     FullyQualifiedJavaType returnType = getSelectByExampleReturnListJavaType();
/*  364: 497 */     if (this.useJava5Features) {
/*  365: 498 */       returnType.addTypeArgument(new FullyQualifiedJavaType(table.getDomainObjectName()));
/*  366:     */     }
/*  367: 499 */     method.setReturnType(returnType);
/*  368: 500 */     method.setVisibility(JavaVisibility.PRIVATE);
/*  369: 501 */     method.setName("getPageList");
/*  370:     */     
/*  371: 503 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  372: 504 */     compilationUnit.addImportedType(parameterType);
/*  373: 505 */     method.addParameter(new Parameter(parameterType, "model"));
/*  374:     */     
/*  375: 507 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  376: 508 */     while (iter.hasNext())
/*  377:     */     {
/*  378: 509 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  379: 510 */       method.addException(fqjt);
/*  380: 511 */       compilationUnit.addImportedType(fqjt);
/*  381:     */     }
/*  382: 515 */     StringBuffer sb = new StringBuffer();
/*  383: 516 */     sb.append(returnType.getShortName()).append(" ").append(getRecordPropertyName(table)).append("List = ");
/*  384:     */     
/*  385: 518 */     sb.append(getServicePropertyName(table)).append(".").append(
/*  386: 519 */       this.serviceMethodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable));
/*  387: 520 */     sb.append("( model, Integer.parseInt(model.get(\"pageNum\").toString()), Integer.parseInt(model.get(\"numPerPage\").toString()) ); ");
/*  388: 521 */     method.addBodyLine(sb.toString());
/*  389:     */     
/*  390: 523 */     sb.setLength(0);
/*  391: 524 */     sb.append("model.put(\"").append(getRecordPropertyName(table)).append("List\",").append(getRecordPropertyName(table)).append("List);");
/*  392: 525 */     method.addBodyLine(sb.toString());
/*  393:     */     
/*  394: 527 */     sb.setLength(0);
/*  395: 528 */     sb.append("model.put(\"").append("pageTurn").append("\",").append(getRecordPropertyName(table)).append("List.getPageTurn());");
/*  396: 529 */     method.addBodyLine(sb.toString());
/*  397:     */     
/*  398: 531 */     sb.setLength(0);
/*  399: 532 */     sb.append("return ").append(getRecordPropertyName(table)).append("List;");
/*  400: 533 */     method.addBodyLine(sb.toString());
/*  401:     */     
/*  402: 535 */     List answer = new ArrayList();
/*  403: 536 */     answer.add(method);
/*  404:     */     
/*  405: 538 */     return answer;
/*  406:     */   }
/*  407:     */   
/*  408:     */   protected List getSupportsMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  409:     */   {
/*  410: 543 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  411: 544 */     Method method = new Method();
/*  412: 545 */     method.addComment(table);
/*  413:     */     
/*  414:     */ 
/*  415: 548 */     method.setReturnType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  416: 549 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  417: 550 */     method.setName("supports");
/*  418:     */     
/*  419: 552 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("java.lang.Class");
/*  420: 553 */     parameterType.addTypeArgument(new FullyQualifiedJavaType("?"));
/*  421: 554 */     method.addParameter(new Parameter(parameterType, "clazz"));
/*  422: 555 */     compilationUnit.addImportedType(this.javaModelGenerator.getBaseRecordType(table));
/*  423:     */     
/*  424: 557 */     StringBuilder sb = new StringBuilder();
/*  425: 558 */     sb.append("return ").append(table.getDomainObjectName()).append(".class.equals( clazz );");
/*  426: 559 */     method.addBodyLine(sb.toString());
/*  427:     */     
/*  428: 561 */     List answer = new ArrayList();
/*  429: 562 */     answer.add(method);
/*  430:     */     
/*  431: 564 */     return answer;
/*  432:     */   }
/*  433:     */   
/*  434:     */   protected List getValidateMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  435:     */   {
/*  436: 569 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  437: 570 */     Method method = new Method();
/*  438: 571 */     method.addComment(table);
/*  439:     */     
/*  440:     */ 
/*  441: 574 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  442: 575 */     method.setName("validate");
/*  443:     */     
/*  444: 577 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("java.lang.Object");
/*  445: 578 */     method.addParameter(new Parameter(parameterType, "target"));
/*  446:     */     
/*  447: 580 */     parameterType = new FullyQualifiedJavaType("org.springframework.validation.Errors");
/*  448: 581 */     method.addParameter(new Parameter(parameterType, "errors"));
/*  449: 582 */     compilationUnit.addImportedType(parameterType);
/*  450:     */     
/*  451: 584 */     StringBuilder sb = new StringBuilder();
/*  452: 585 */     sb.append(table.getDomainObjectName()).append(" object = (")
/*  453: 586 */       .append(table.getDomainObjectName()).append(")target;");
/*  454: 587 */     method.addBodyLine(sb.toString());
/*  455: 588 */     method.addBodyLine("//TODO: add your validating code");
/*  456: 589 */     method.addBodyLine("//errors.rejectValue( fieldName, errorCode, errorArgs, defaultMessage );");
/*  457:     */     
/*  458: 591 */     List answer = new ArrayList();
/*  459: 592 */     answer.add(method);
/*  460:     */     
/*  461: 594 */     return answer;
/*  462:     */   }
/*  463:     */   
/*  464:     */   protected void createStaticFinalField(String propertyEditView, JavaVisibility visibility, TopLevelClass answer, FullyQualifiedTable table, String initializationString)
/*  465:     */   {
/*  466: 602 */     Field fieldEdit = new Field();
/*  467: 603 */     fieldEdit.setVisibility(visibility);
/*  468: 604 */     fieldEdit.setType(FullyQualifiedJavaType.getStringInstance());
/*  469: 605 */     fieldEdit.setName(propertyEditView);
/*  470: 606 */     fieldEdit.setModifierStatic(true);
/*  471: 607 */     fieldEdit.setModifierFinal(true);
/*  472: 608 */     fieldEdit.setInitializationString(initializationString);
/*  473: 609 */     answer.addField(fieldEdit);
/*  474:     */   }
/*  475:     */   
/*  476:     */   protected List getListMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  477:     */   {
/*  478: 614 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  479: 615 */     Method method = new Method();
/*  480: 616 */     method.addComment(table);
/*  481: 617 */     method.addAnnotation("@RequestMapping()");
/*  482:     */     
/*  483: 619 */     FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("java.lang.String");
/*  484: 620 */     method.setReturnType(returnType);
/*  485: 621 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  486: 622 */     method.setName(this.methodNameCalculator.getListMethodName(introspectedTable));
/*  487:     */     
/*  488: 624 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/*  489: 625 */     compilationUnit.addImportedType(parameterType);
/*  490: 626 */     method.addParameter(new Parameter(parameterType, "request"));
/*  491:     */     
/*  492: 628 */     parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  493: 629 */     compilationUnit.addImportedType(parameterType);
/*  494: 630 */     method.addParameter(new Parameter(parameterType, "model"));
/*  495:     */     
/*  496: 632 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  497: 633 */     while (iter.hasNext())
/*  498:     */     {
/*  499: 634 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  500: 635 */       method.addException(fqjt);
/*  501: 636 */       compilationUnit.addImportedType(fqjt);
/*  502:     */     }
/*  503: 639 */     StringBuilder sb = new StringBuilder();
/*  504:     */     
/*  505:     */ 
/*  506: 642 */     method.addBodyLine("HttpRequestInfo reqInfo = new HttpRequestInfo(request);");
/*  507: 643 */     method.addBodyLine("setRequestModelMap( request, model, true );");
/*  508:     */     
/*  509: 645 */     method.addBodyLine("getPageList( model );");
/*  510: 646 */     method.addBodyLine("return HOME_VIEW;");
/*  511:     */     
/*  512: 648 */     List answer = new ArrayList();
/*  513: 649 */     answer.add(method);
/*  514:     */     
/*  515: 651 */     return answer;
/*  516:     */   }
/*  517:     */   
/*  518:     */   private void addPermissionParts(FullyQualifiedTable table, StringBuilder sb, Method method, CompilationUnit compilationUnit, String operateCode)
/*  519:     */   {
/*  520: 664 */     if (this.permission)
/*  521:     */     {
/*  522: 665 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.component.permission.api.PermissionHelper");
/*  523: 666 */       compilationUnit.addImportedType(fqjt);
/*  524:     */       
/*  525: 668 */       method.addBodyLine("PermissionHelper permissionHelper = PermissionHelper.getInstance();");
/*  526: 669 */       method.addBodyLine("//TODO: add your permission validating code");
/*  527: 670 */       method.addBodyLine("//User uesr = permissionHelper.getUser();");
/*  528: 671 */       sb.setLength(0);
/*  529: 672 */       String code = ("UPDATE_STATUS".equalsIgnoreCase(operateCode)) || ("MOVE".equalsIgnoreCase(operateCode)) ? "UPDATE" : operateCode;
/*  530: 673 */       sb.append("permissionHelper.validatePermission( \"").append(code).append("\", RESOURCE_CODE );");
/*  531: 674 */       method.addBodyLine(sb.toString());
/*  532: 675 */       method.addBodyLine("");
/*  533:     */     }
/*  534: 677 */     if ((this.permission) && (this.operateLog))
/*  535:     */     {
/*  536: 678 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.framework.util.StringUtil");
/*  537: 679 */       compilationUnit.addImportedType(fqjt);
/*  538:     */     }
/*  539:     */   }
/*  540:     */   
/*  541:     */   private void addOperatelogParts(FullyQualifiedTable table, StringBuilder sb, Method method, ColumnDefinition pk, String op)
/*  542:     */   {
/*  543: 684 */     if ((this.permission) && (this.operateLog))
/*  544:     */     {
/*  545: 685 */       sb.setLength(0);
/*  546: 686 */       sb.append("permissionHelper.writeLog( \"").append(op).append("\", StringUtil.gbk2iso( \"").append(table.getLabel())
/*  547: 687 */         .append("\" ) ,").append(getRecordPropertyName(table)).append(".")
/*  548: 688 */         .append(pk.getPrefixJavaProperty("get")).append("().toString(), \"\", \"OK\" );");
/*  549: 689 */       method.addBodyLine(sb.toString());
/*  550:     */     }
/*  551:     */   }
/*  552:     */   
/*  553:     */   private void addOperatelogPartsSimple(FullyQualifiedTable table, StringBuilder sb, Method method, ColumnDefinition pk, String op)
/*  554:     */   {
/*  555: 694 */     if ((this.permission) && (this.operateLog))
/*  556:     */     {
/*  557: 695 */       sb.setLength(0);
/*  558: 696 */       sb.append("permissionHelper.writeLog( \"").append(op).append("\", StringUtil.gbk2iso( \"").append(table.getLabel())
/*  559: 697 */         .append("\" ) , ").append(pk.getJavaProperty()).append(".toString(), \"\", \"OK\" );");
/*  560: 698 */       method.addBodyLine(sb.toString());
/*  561:     */     }
/*  562:     */   }
/*  563:     */   
/*  564:     */   private void addOperatelogParts(FullyQualifiedTable table, StringBuilder sb, Method method, String paramName, String op)
/*  565:     */   {
/*  566: 703 */     if ((this.permission) && (this.operateLog))
/*  567:     */     {
/*  568: 704 */       sb.setLength(0);
/*  569: 705 */       sb.append("permissionHelper.writeLog( \"").append(op).append("\", StringUtil.gbk2iso( \"").append(table.getLabel())
/*  570: 706 */         .append("\" ) , objectIds, \"");
/*  571: 707 */       if (StringUtility.stringHasValue(paramName)) {
/*  572: 708 */         sb.append(paramName).append(":\" + ").append(paramName).append(", \"OK\" );");
/*  573:     */       } else {
/*  574: 710 */         sb.append("\", \"OK\" );");
/*  575:     */       }
/*  576: 711 */       method.addBodyLine(sb.toString());
/*  577:     */     }
/*  578:     */   }
/*  579:     */   
/*  580:     */   protected List getSaveMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  581:     */   {
/*  582: 718 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  583: 719 */     Method method = new Method();
/*  584: 720 */     method.addComment(table);
/*  585: 721 */     method.addAnnotation("@RequestMapping(ADD)");
/*  586:     */     
/*  587: 723 */     FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("java.lang.String");
/*  588: 724 */     method.setReturnType(returnType);
/*  589: 725 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  590: 726 */     method.setName(this.methodNameCalculator.getAddMethodName(introspectedTable));
/*  591:     */     
/*  592: 728 */     FullyQualifiedJavaType parameterType = introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/*  593: 729 */     compilationUnit.addImportedType(parameterType);
/*  594:     */     
/*  595: 731 */     parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/*  596: 732 */     compilationUnit.addImportedType(parameterType);
/*  597: 733 */     method.addParameter(new Parameter(parameterType, "request"));
/*  598:     */     
/*  599: 735 */     parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletResponse");
/*  600: 736 */     compilationUnit.addImportedType(parameterType);
/*  601: 737 */     method.addParameter(new Parameter(parameterType, "response"));
/*  602:     */     
/*  603: 739 */     parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  604: 740 */     compilationUnit.addImportedType(parameterType);
/*  605: 741 */     method.addParameter(new Parameter(parameterType, "model"));
/*  606:     */     
/*  607: 743 */     parameterType = new FullyQualifiedJavaType(table.getDomainObjectName());
/*  608: 744 */     compilationUnit.addImportedType(parameterType);
/*  609: 745 */     method.addParameter(new Parameter(parameterType, getRecordPropertyName(table)));
/*  610:     */     
/*  611: 747 */     parameterType = new FullyQualifiedJavaType("com.afocus.framework.util.RenderUtil");
/*  612: 748 */     compilationUnit.addImportedType(parameterType);
/*  613:     */     
/*  614: 750 */     parameterType = new FullyQualifiedJavaType("com.afocus.framework.util.DWZResponse");
/*  615: 751 */     compilationUnit.addImportedType(parameterType);
/*  616:     */     
/*  617: 753 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  618: 754 */     while (iter.hasNext())
/*  619:     */     {
/*  620: 755 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  621: 756 */       method.addException(fqjt);
/*  622: 757 */       compilationUnit.addImportedType(fqjt);
/*  623:     */     }
/*  624: 761 */     StringBuilder sb = new StringBuilder();
/*  625:     */     
/*  626:     */ 
/*  627:     */ 
/*  628: 765 */     method.addBodyLine("setRequestModelMap(request, model, false);");
/*  629: 766 */     method.addBodyLine("DWZResponse.Builder builder;");
/*  630: 767 */     method.addBodyLine("try {");
/*  631:     */     
/*  632:     */ 
/*  633: 770 */     sb.setLength(0);
/*  634: 771 */     sb.append(getServicePropertyName(table)).append(".").append(this.serviceMethodNameCalculator.getInsertMethodName(introspectedTable));
/*  635: 772 */     sb.append("( " + getRecordPropertyName(table) + " ); ");
/*  636: 773 */     method.addBodyLine(sb.toString());
/*  637:     */     
/*  638: 775 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  639: 776 */     if (iter.hasNext())
/*  640:     */     {
/*  641: 777 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  642: 778 */       addOperatelogParts(table, sb, method, cd, "CREATE");
/*  643:     */     }
/*  644: 781 */     method.addBodyLine("builder = DWZResponse.getSucessBuilder(\"success\");");
/*  645: 782 */     method.addBodyLine("} catch (Exception e) {");
/*  646: 783 */     method.addBodyLine("builder = DWZResponse.getFailBuilder(\"fail\" + Arrays.deepToString(e.getStackTrace()));");
/*  647: 784 */     method.addBodyLine("}");
/*  648: 785 */     method.addBodyLine("RenderUtil.renderHtml(builder.build().toString(), response);");
/*  649: 786 */     method.addBodyLine("return null;");
/*  650:     */     
/*  651: 788 */     List answer = new ArrayList();
/*  652: 789 */     answer.add(method);
/*  653: 790 */     return answer;
/*  654:     */   }
/*  655:     */   
/*  656:     */   protected List getEditMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  657:     */   {
/*  658: 795 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  659: 796 */     Method method = new Method();
/*  660: 797 */     method.addComment(table);
/*  661: 798 */     method.addAnnotation("@RequestMapping(EDIT)");
/*  662:     */     
/*  663: 800 */     FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("java.lang.String");
/*  664: 801 */     method.setReturnType(returnType);
/*  665: 802 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  666: 803 */     method.setName(this.methodNameCalculator.getEditMethodName(introspectedTable));
/*  667:     */     
/*  668: 805 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/*  669: 806 */     compilationUnit.addImportedType(parameterType);
/*  670: 807 */     method.addParameter(new Parameter(parameterType, "request"));
/*  671:     */     
/*  672: 809 */     parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  673: 810 */     compilationUnit.addImportedType(parameterType);
/*  674: 811 */     method.addParameter(new Parameter(parameterType, "model"));
/*  675:     */     
/*  676: 813 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  677: 814 */     while (iter.hasNext())
/*  678:     */     {
/*  679: 815 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  680: 816 */       method.addException(fqjt);
/*  681: 817 */       compilationUnit.addImportedType(fqjt);
/*  682:     */     }
/*  683: 819 */     StringBuilder sb = new StringBuilder();
/*  684:     */     
/*  685: 821 */     method.addBodyLine("HttpRequestInfo reqInfo = new HttpRequestInfo(request);");
/*  686: 822 */     method.addBodyLine("setRequestModelMap( request, model, false );");
/*  687:     */     
/*  688:     */ 
/*  689: 825 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  690: 826 */     if (iter.hasNext())
/*  691:     */     {
/*  692: 827 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  693: 828 */       addBodyLine4PKparam(method, cd, sb, compilationUnit);
/*  694:     */       
/*  695: 830 */       sb.setLength(0);
/*  696: 831 */       sb.append("model.put( \"model\",").append(getServicePropertyName(table)).append(".").append(this.serviceMethodNameCalculator.getSelectByPrimaryKeyMethodName(introspectedTable));
/*  697: 832 */       sb.append("( " + cd.getJavaProperty() + " ) ); ");
/*  698: 833 */       method.addBodyLine(sb.toString());
/*  699: 834 */       method.addBodyLine("}");
/*  700:     */     }
/*  701: 837 */     method.addBodyLine("return EDIT_VIEW;");
/*  702:     */     
/*  703: 839 */     List answer = new ArrayList();
/*  704: 840 */     answer.add(method);
/*  705:     */     
/*  706: 842 */     return answer;
/*  707:     */   }
/*  708:     */   
/*  709:     */   private void addBodyLine4PKparam(Method method, ColumnDefinition pk, StringBuilder sb, CompilationUnit compilationUnit)
/*  710:     */   {
/*  711: 846 */     String javaType = pk.getResolvedJavaType().getFullyQualifiedJavaType().getShortName();
/*  712: 847 */     String property = pk.getJavaProperty();
/*  713: 848 */     sb.setLength(0);
/*  714: 849 */     if (javaType.equalsIgnoreCase("Integer"))
/*  715:     */     {
/*  716: 851 */       sb.append(javaType).append(" ").append(property).append(" = reqInfo.getIntParameter( \"").append(property).append("\", -1 );");
/*  717: 852 */       method.addBodyLine(sb.toString());
/*  718: 853 */       sb.setLength(0);
/*  719: 854 */       sb.append("if( ").append(property).append(" > 0 ){");
/*  720: 855 */       method.addBodyLine(sb.toString());
/*  721:     */     }
/*  722: 857 */     else if (javaType.equalsIgnoreCase("Long"))
/*  723:     */     {
/*  724: 859 */       sb.append(javaType).append(" ").append(property).append(" = reqInfo.getLongParameter( \"").append(property).append("\", -1L );");
/*  725: 860 */       method.addBodyLine(sb.toString());
/*  726: 861 */       sb.setLength(0);
/*  727: 862 */       sb.append("if( ").append(property).append(" > 0L ){");
/*  728: 863 */       method.addBodyLine(sb.toString());
/*  729:     */     }
/*  730:     */     else
/*  731:     */     {
/*  732: 867 */       sb.append("String").append(" ").append(property).append(" = reqInfo.getParameter( \"").append(property).append("\", \"\" );");
/*  733: 868 */       method.addBodyLine(sb.toString());
/*  734: 869 */       sb.setLength(0);
/*  735: 870 */       sb.append("if( !StringUtil.isEmpty(").append(property).append(" ) ){");
/*  736: 871 */       method.addBodyLine(sb.toString());
/*  737: 872 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.framework.util.StringUtil");
/*  738: 873 */       compilationUnit.addImportedType(fqjt);
/*  739:     */     }
/*  740:     */   }
/*  741:     */   
/*  742:     */   protected List getDetailMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  743:     */   {
/*  744: 880 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  745: 881 */     Method method = new Method();
/*  746: 882 */     method.addComment(table);
/*  747: 883 */     method.addAnnotation("@RequestMapping(DETAIL)");
/*  748:     */     
/*  749: 885 */     FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("java.lang.String");
/*  750: 886 */     method.setReturnType(returnType);
/*  751: 887 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  752: 888 */     method.setName(this.methodNameCalculator.getDetailMethodName(introspectedTable));
/*  753:     */     
/*  754: 890 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/*  755: 891 */     compilationUnit.addImportedType(parameterType);
/*  756: 892 */     method.addParameter(new Parameter(parameterType, "request"));
/*  757:     */     
/*  758: 894 */     parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  759: 895 */     compilationUnit.addImportedType(parameterType);
/*  760: 896 */     method.addParameter(new Parameter(parameterType, "model"));
/*  761:     */     
/*  762: 898 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  763: 899 */     while (iter.hasNext())
/*  764:     */     {
/*  765: 900 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  766: 901 */       method.addException(fqjt);
/*  767: 902 */       compilationUnit.addImportedType(fqjt);
/*  768:     */     }
/*  769: 905 */     StringBuilder sb = new StringBuilder();
/*  770:     */     
/*  771: 907 */     method.addBodyLine("HttpRequestInfo reqInfo = new HttpRequestInfo(request);");
/*  772:     */     
/*  773:     */ 
/*  774: 910 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  775: 911 */     if (iter.hasNext())
/*  776:     */     {
/*  777: 912 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  778: 913 */       addBodyLine4PKparam(method, cd, sb, compilationUnit);
/*  779:     */       
/*  780: 915 */       sb.setLength(0);
/*  781: 916 */       sb.append("model.addAttribute( ").append(getServicePropertyName(table)).append(".").append(
/*  782: 917 */         this.serviceMethodNameCalculator.getSelectByPrimaryKeyMethodName(introspectedTable));
/*  783: 918 */       sb.append("( " + cd.getJavaProperty() + " ) ); ");
/*  784: 919 */       method.addBodyLine(sb.toString());
/*  785: 920 */       method.addBodyLine("}");
/*  786:     */     }
/*  787: 923 */     method.addBodyLine("setRequestModelMap(request, model);");
/*  788: 924 */     method.addBodyLine("return null;");
/*  789:     */     
/*  790: 926 */     List answer = new ArrayList();
/*  791: 927 */     answer.add(method);
/*  792:     */     
/*  793: 929 */     return answer;
/*  794:     */   }
/*  795:     */   
/*  796:     */   protected List getUpdateMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  797:     */   {
/*  798: 934 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  799: 935 */     Method method = new Method();
/*  800: 936 */     method.addComment(table);
/*  801: 937 */     method.addAnnotation("@RequestMapping(UPDATE)");
/*  802:     */     
/*  803: 939 */     FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("java.lang.String");
/*  804: 940 */     method.setReturnType(returnType);
/*  805: 941 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  806: 942 */     method.setName(this.methodNameCalculator.getUpdateMethodName(introspectedTable));
/*  807:     */     
/*  808: 944 */     FullyQualifiedJavaType parameterType = introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/*  809: 945 */     compilationUnit.addImportedType(parameterType);
/*  810:     */     
/*  811: 947 */     parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/*  812: 948 */     compilationUnit.addImportedType(parameterType);
/*  813: 949 */     method.addParameter(new Parameter(parameterType, "request"));
/*  814:     */     
/*  815: 951 */     parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletResponse");
/*  816: 952 */     compilationUnit.addImportedType(parameterType);
/*  817: 953 */     method.addParameter(new Parameter(parameterType, "response"));
/*  818:     */     
/*  819: 955 */     parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  820: 956 */     compilationUnit.addImportedType(parameterType);
/*  821: 957 */     method.addParameter(new Parameter(parameterType, "model"));
/*  822:     */     
/*  823: 959 */     parameterType = new FullyQualifiedJavaType(table.getDomainObjectName());
/*  824: 960 */     compilationUnit.addImportedType(parameterType);
/*  825: 961 */     method.addParameter(new Parameter(parameterType, getRecordPropertyName(table) + "New"));
/*  826:     */     
/*  827: 963 */     parameterType = new FullyQualifiedJavaType("java.lang.Exception");
/*  828: 964 */     method.addException(parameterType);
/*  829:     */     
/*  830: 966 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  831: 967 */     while (iter.hasNext())
/*  832:     */     {
/*  833: 968 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  834: 969 */       method.addException(fqjt);
/*  835: 970 */       compilationUnit.addImportedType(fqjt);
/*  836:     */     }
/*  837: 973 */     StringBuilder sb = new StringBuilder();
/*  838:     */     
/*  839: 975 */     method.addBodyLine("HttpRequestInfo reqInfo = new HttpRequestInfo(request);");
/*  840:     */     
/*  841: 977 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  842: 978 */     if (iter.hasNext())
/*  843:     */     {
/*  844: 979 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  845: 980 */       addBodyLine4PKparam(method, cd, sb, compilationUnit);
/*  846:     */       
/*  847: 982 */       method.addBodyLine("DWZResponse.Builder builder;");
/*  848: 983 */       method.addBodyLine("try {");
/*  849:     */       
/*  850: 985 */       sb.setLength(0);
/*  851: 986 */       sb.append(table.getDomainObjectName()).append(" ").append(getRecordPropertyName(table))
/*  852: 987 */         .append(" = ").append(getServicePropertyName(table)).append(".")
/*  853: 988 */         .append(this.serviceMethodNameCalculator.getSelectByPrimaryKeyMethodName(introspectedTable))
/*  854: 989 */         .append("( " + cd.getJavaProperty() + " ); ");
/*  855: 990 */       method.addBodyLine(sb.toString());
/*  856: 991 */       method.addBodyLine("super.copyProperties(" + getRecordPropertyName(table) + ", " + getRecordPropertyName(table) + "New);");
/*  857:     */       
/*  858: 993 */       sb.setLength(0);
/*  859:     */       
/*  860: 995 */       sb.append(getServicePropertyName(table)).append(".").append(
/*  861: 996 */         this.serviceMethodNameCalculator.getUpdateByPrimaryKeyWithBLOBsMethodName(introspectedTable));
/*  862: 997 */       sb.append("( " + getRecordPropertyName(table) + " ); ");
/*  863:     */       
/*  864:     */ 
/*  865:1000 */       method.addBodyLine(sb.toString());
/*  866:     */       
/*  867:1002 */       method.addBodyLine("model.clear();");
/*  868:1003 */       method.addBodyLine("builder = DWZResponse.getSucessBuilder(\"success\");");
/*  869:1004 */       method.addBodyLine("} catch (Exception e) {");
/*  870:1005 */       method.addBodyLine("builder = DWZResponse.getFailBuilder(\"fail\" + Arrays.deepToString(e.getStackTrace()));");
/*  871:1006 */       method.addBodyLine("}");
/*  872:1007 */       method.addBodyLine("RenderUtil.renderHtml(builder.build().toString(), response);");
/*  873:1008 */       method.addBodyLine("}");
/*  874:     */     }
/*  875:1011 */     method.addBodyLine("return null;");
/*  876:     */     
/*  877:1013 */     List answer = new ArrayList();
/*  878:1014 */     answer.add(method);
/*  879:     */     
/*  880:1016 */     return answer;
/*  881:     */   }
/*  882:     */   
/*  883:     */   protected List getMoveMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  884:     */   {
/*  885:1020 */     Iterator iter = introspectedTable.getAllColumns();
/*  886:1021 */     while (iter.hasNext())
/*  887:     */     {
/*  888:1022 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  889:1023 */       String property = cd.getJavaProperty().toLowerCase();
/*  890:1024 */       if ((property.indexOf("parentid") > -1) || (property.indexOf("channelid") > -1) || 
/*  891:1025 */         (property.indexOf("folderid") > -1) || (property.indexOf("typeid") > -1))
/*  892:     */       {
/*  893:1026 */         String methodName = this.methodNameCalculator.getMoveMethodName(introspectedTable);
/*  894:1027 */         return getUpdateOrDeleteRowsInternalMethods(introspectedTable, compilationUnit, "MOVE", cd.getJavaProperty(), methodName);
/*  895:     */       }
/*  896:     */     }
/*  897:1030 */     return null;
/*  898:     */   }
/*  899:     */   
/*  900:     */   protected List getAuditMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  901:     */   {
/*  902:1034 */     Iterator iter = introspectedTable.getAllColumns();
/*  903:1035 */     while (iter.hasNext())
/*  904:     */     {
/*  905:1036 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  906:1037 */       String property = cd.getJavaProperty().toLowerCase();
/*  907:1038 */       if ((property.indexOf("status") > -1) || (property.indexOf("auditflag") > -1) || (property.indexOf("flag") > -1))
/*  908:     */       {
/*  909:1039 */         String methodName = this.methodNameCalculator.getAuditMethodName(introspectedTable);
/*  910:1040 */         return getUpdateOrDeleteRowsInternalMethods(introspectedTable, compilationUnit, "AUDIT", cd.getJavaProperty(), methodName);
/*  911:     */       }
/*  912:     */     }
/*  913:1043 */     return null;
/*  914:     */   }
/*  915:     */   
/*  916:     */   protected List getUpdateStatusMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  917:     */   {
/*  918:1047 */     Iterator iter = introspectedTable.getAllColumns();
/*  919:1048 */     while (iter.hasNext())
/*  920:     */     {
/*  921:1049 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  922:1050 */       if (cd.getJavaProperty().trim().indexOf("status") > -1)
/*  923:     */       {
/*  924:1051 */         String methodName = this.methodNameCalculator.getUpdateStatusMethodName(introspectedTable);
/*  925:1052 */         return getUpdateOrDeleteRowsInternalMethods(introspectedTable, compilationUnit, "UPDATE_STATUS", cd.getJavaProperty(), methodName);
/*  926:     */       }
/*  927:     */     }
/*  928:1055 */     return null;
/*  929:     */   }
/*  930:     */   
/*  931:     */   protected List getDeleteMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  932:     */   {
/*  933:1059 */     String methodName = this.methodNameCalculator.getDeleteMethodName(introspectedTable);
/*  934:1060 */     return getUpdateOrDeleteRowsInternalMethods(introspectedTable, compilationUnit, "DELETE", "", methodName);
/*  935:     */   }
/*  936:     */   
/*  937:     */   private List getUpdateOrDeleteRowsInternalMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit, String path, String paramName, String methodName)
/*  938:     */   {
/*  939:1090 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  940:1091 */     Method method = new Method();
/*  941:1092 */     method.addComment(table);
/*  942:1093 */     method.addAnnotation("@RequestMapping(" + path + ")");
/*  943:     */     
/*  944:1095 */     FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("java.lang.String");
/*  945:1096 */     method.setReturnType(returnType);
/*  946:1097 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  947:1098 */     method.setName(methodName);
/*  948:     */     
/*  949:1100 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
/*  950:1101 */     compilationUnit.addImportedType(parameterType);
/*  951:1102 */     method.addParameter(new Parameter(parameterType, "request"));
/*  952:     */     
/*  953:1104 */     parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletResponse");
/*  954:1105 */     compilationUnit.addImportedType(parameterType);
/*  955:1106 */     method.addParameter(new Parameter(parameterType, "response"));
/*  956:     */     
/*  957:1108 */     parameterType = new FullyQualifiedJavaType("org.springframework.ui.ModelMap");
/*  958:1109 */     compilationUnit.addImportedType(parameterType);
/*  959:1110 */     method.addParameter(new Parameter(parameterType, "model"));
/*  960:     */     
/*  961:1112 */     parameterType = new FullyQualifiedJavaType("java.lang.String");
/*  962:1113 */     compilationUnit.addImportedType(parameterType);
/*  963:1114 */     method.addParameter(new Parameter(parameterType, "inIdList"));
/*  964:     */     
/*  965:1116 */     Iterator iter = this.controllerTemplate.getCheckedExceptions().iterator();
/*  966:1117 */     while (iter.hasNext())
/*  967:     */     {
/*  968:1118 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  969:1119 */       method.addException(fqjt);
/*  970:1120 */       compilationUnit.addImportedType(fqjt);
/*  971:     */     }
/*  972:1123 */     StringBuilder sb = new StringBuilder();
/*  973:     */     
/*  974:     */ 
/*  975:1126 */     method.addBodyLine("HttpRequestInfo reqInfo = new HttpRequestInfo(request);");
/*  976:1127 */     if (!"DELETE".equalsIgnoreCase(path))
/*  977:     */     {
/*  978:1128 */       method.addBodyLine("Integer " + paramName + " = reqInfo.getIntParameter( \"" + paramName + "\", -1 );");
/*  979:1129 */       method.addBodyLine("");
/*  980:     */     }
/*  981:1131 */     method.addBodyLine("setRequestModelMap(request, model);");
/*  982:1132 */     method.addBodyLine("DWZResponse.Builder builder;");
/*  983:1133 */     method.addBodyLine("try {");
/*  984:1134 */     method.addBodyLine("String[] idArray = inIdList.split(\",\");");
/*  985:1135 */     method.addBodyLine("model.put(\"inIdList\", idArray);");
/*  986:     */     
/*  987:1137 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  988:1138 */     if (iter.hasNext())
/*  989:     */     {
/*  990:1139 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  991:1140 */       sb.setLength(0);
/*  992:1141 */       if (!"DELETE".equalsIgnoreCase(path))
/*  993:     */       {
/*  994:1142 */         sb.append(getServicePropertyName(table)).append(".").append(
/*  995:1143 */           this.serviceMethodNameCalculator.getUpdateByPrimaryKeySelectiveMethodName(introspectedTable));
/*  996:1144 */         sb.append("( model ); ");
/*  997:     */       }
/*  998:     */       else
/*  999:     */       {
/* 1000:1147 */         sb.append(getServicePropertyName(table)).append(".").append(
/* 1001:1148 */           this.serviceMethodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 1002:1149 */         sb.append("( model ); ");
/* 1003:     */       }
/* 1004:1151 */       method.addBodyLine(sb.toString());
/* 1005:     */       
/* 1006:1153 */       addOperatelogParts(table, sb, method, paramName, path);
/* 1007:     */     }
/* 1008:1156 */     method.addBodyLine("builder = DWZResponse.getSucessBuilder(\"success\");");
/* 1009:1157 */     method.addBodyLine("} catch (Exception e) {");
/* 1010:1158 */     method.addBodyLine("builder = DWZResponse.getFailBuilder(\"fail\" + Arrays.deepToString(e.getStackTrace()));");
/* 1011:1159 */     method.addBodyLine("}");
/* 1012:1160 */     method.addBodyLine("RenderUtil.renderHtml(builder.build().toString(), response);");
/* 1013:     */     
/* 1014:1162 */     method.addBodyLine("model.clear();");
/* 1015:1163 */     method.addBodyLine("return null;");
/* 1016:1164 */     List answer = new ArrayList();
/* 1017:1165 */     answer.add(method);
/* 1018:     */     
/* 1019:1167 */     return answer;
/* 1020:     */   }
/* 1021:     */   
/* 1022:     */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/* 1023:     */   {
/* 1024:1256 */     return FullyQualifiedJavaType.getNewListInstance();
/* 1025:     */   }
/* 1026:     */   
/* 1027:     */   protected String getControllerPackage(FullyQualifiedTable table)
/* 1028:     */   {
/* 1029:1260 */     String key = "getControllerPackage";
/* 1030:     */     
/* 1031:     */ 
/* 1032:1263 */     Map map = getTableValueMap(table);
/* 1033:1264 */     String s = (String)map.get(key);
/* 1034:1265 */     if (s == null)
/* 1035:     */     {
/* 1036:1266 */       StringBuffer sb = new StringBuffer(this.targetPackage);
/* 1037:1267 */       if ("true".equals(this.properties.get("enableSubPackages")))
/* 1038:     */       {
/* 1039:1268 */         if (StringUtility.stringHasValue(table.getCatalog()))
/* 1040:     */         {
/* 1041:1269 */           sb.append('.');
/* 1042:1270 */           sb.append(table.getCatalog().toLowerCase());
/* 1043:     */         }
/* 1044:1273 */         if (StringUtility.stringHasValue(table.getSchema()))
/* 1045:     */         {
/* 1046:1274 */           sb.append('.');
/* 1047:1275 */           sb.append(table.getSchema().toLowerCase());
/* 1048:     */         }
/* 1049:     */       }
/* 1050:1279 */       s = sb.toString();
/* 1051:1280 */       map.put(key, s);
/* 1052:     */     }
/* 1053:1283 */     return s;
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   private Map getTableValueMap(FullyQualifiedTable table)
/* 1057:     */   {
/* 1058:1316 */     Map map = (Map)this.tableValueMaps.get(table);
/* 1059:1317 */     if (map == null)
/* 1060:     */     {
/* 1061:1318 */       map = new HashMap();
/* 1062:1319 */       this.tableValueMaps.put(table, map);
/* 1063:     */     }
/* 1064:1322 */     return map;
/* 1065:     */   }
/* 1066:     */   
/* 1067:     */   public void addContextProperties(Map properties)
/* 1068:     */   {
/* 1069:1326 */     this.properties.putAll(properties);
/* 1070:     */   }
/* 1071:     */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.controller.BaseControllerGenerator
 * JD-Core Version:    0.7.0.1
 */