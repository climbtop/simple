/*   1:    */ package org.apache.ibatis.abator.internal.java.model;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   5:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   6:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   7:    */ import org.apache.ibatis.abator.api.dom.java.Field;
/*   8:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   9:    */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  10:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  11:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  12:    */ import org.apache.ibatis.abator.api.dom.java.TopLevelClass;
/*  13:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  14:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*  15:    */ import org.apache.ibatis.abator.internal.sqlmap.ExampleClause;
/*  16:    */ import org.apache.ibatis.abator.internal.util.JavaBeansUtil;
/*  17:    */ 
/*  18:    */ public class JavaModelGeneratorLegacyImpl
/*  19:    */   extends JavaModelGeneratorJava2Impl
/*  20:    */   implements JavaModelGenerator
/*  21:    */ {
/*  22:    */   protected TopLevelClass getExample(IntrospectedTable introspectedTable)
/*  23:    */   {
/*  24: 58 */     if (!introspectedTable.getRules().generateExampleClass()) {
/*  25: 59 */       return null;
/*  26:    */     }
/*  27: 62 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  28: 63 */     FullyQualifiedJavaType type = getExampleType(table);
/*  29: 64 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*  30: 65 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*  31: 67 */     if (introspectedTable.getRules().generateBaseRecordClass()) {
/*  32: 68 */       topLevelClass.setSuperClass(getBaseRecordType(table));
/*  33:    */     } else {
/*  34: 70 */       topLevelClass.setSuperClass(getPrimaryKeyType(introspectedTable));
/*  35:    */     }
/*  36: 73 */     StringBuffer sb = new StringBuffer();
/*  37: 74 */     Field field = new Field();
/*  38: 75 */     field.addComment(table);
/*  39: 76 */     field.setVisibility(JavaVisibility.PUBLIC);
/*  40: 77 */     field.setModifierStatic(true);
/*  41: 78 */     field.setModifierFinal(true);
/*  42: 79 */     field.setType(FullyQualifiedJavaType.getIntInstance());
/*  43: 80 */     field.setName("EXAMPLE_IGNORE");
/*  44: 81 */     field.setInitializationString("0");
/*  45: 82 */     topLevelClass.addField(field);
/*  46:    */     
/*  47: 84 */     Iterator iter = ExampleClause.getAllExampleClauses();
/*  48: 85 */     while (iter.hasNext())
/*  49:    */     {
/*  50: 86 */       ExampleClause clause = (ExampleClause)iter.next();
/*  51: 87 */       field = new Field();
/*  52: 88 */       field.addComment(table);
/*  53: 89 */       field.setVisibility(JavaVisibility.PUBLIC);
/*  54: 90 */       field.setModifierStatic(true);
/*  55: 91 */       field.setModifierFinal(true);
/*  56: 92 */       field.setType(FullyQualifiedJavaType.getIntInstance());
/*  57: 93 */       field.setName(clause.getExamplePropertyName());
/*  58: 94 */       field.setInitializationString(Integer.toString(clause
/*  59: 95 */         .getExamplePropertyValue()));
/*  60: 96 */       topLevelClass.addField(field);
/*  61:    */     }
/*  62: 99 */     field = new Field();
/*  63:100 */     field.addComment(table);
/*  64:101 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  65:102 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  66:103 */     field.setName("combineTypeOr");
/*  67:104 */     topLevelClass.addField(field);
/*  68:    */     
/*  69:106 */     Method method = new Method();
/*  70:107 */     method.addComment(table);
/*  71:108 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  72:109 */     method.setName("setCombineTypeOr");
/*  73:110 */     method.addParameter(new Parameter(
/*  74:111 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance(), "combineTypeOr"));
/*  75:112 */     method.addBodyLine("this.combineTypeOr = combineTypeOr;");
/*  76:113 */     topLevelClass.addMethod(method);
/*  77:    */     
/*  78:115 */     method = new Method();
/*  79:116 */     method.addComment(table);
/*  80:117 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  81:118 */     method.setReturnType(
/*  82:119 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  83:120 */     method.setName("isCombineTypeOr");
/*  84:121 */     method.addBodyLine("return combineTypeOr;");
/*  85:122 */     topLevelClass.addMethod(method);
/*  86:    */     
/*  87:124 */     iter = introspectedTable.getNonBLOBColumns();
/*  88:125 */     while (iter.hasNext())
/*  89:    */     {
/*  90:126 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  91:    */       
/*  92:128 */       String fieldName = cd.getJavaProperty() + "_Indicator";
/*  93:    */       
/*  94:130 */       field = new Field();
/*  95:131 */       field.addComment(table);
/*  96:132 */       field.setVisibility(JavaVisibility.PRIVATE);
/*  97:133 */       field.setType(FullyQualifiedJavaType.getIntInstance());
/*  98:134 */       field.setName(fieldName);
/*  99:135 */       topLevelClass.addField(field);
/* 100:    */       
/* 101:137 */       method = new Method();
/* 102:138 */       method.addComment(table);
/* 103:139 */       method.setVisibility(JavaVisibility.PUBLIC);
/* 104:140 */       method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 105:141 */       method.setName(JavaBeansUtil.getGetterMethodName(fieldName));
/* 106:142 */       sb.setLength(0);
/* 107:143 */       sb.append("return ");
/* 108:144 */       sb.append(fieldName);
/* 109:145 */       sb.append(';');
/* 110:146 */       method.addBodyLine(sb.toString());
/* 111:147 */       topLevelClass.addMethod(method);
/* 112:    */       
/* 113:149 */       method = new Method();
/* 114:150 */       method.addComment(table);
/* 115:151 */       method.setVisibility(JavaVisibility.PUBLIC);
/* 116:152 */       method.setName(JavaBeansUtil.getSetterMethodName(fieldName));
/* 117:153 */       method.addParameter(new Parameter(
/* 118:154 */         FullyQualifiedJavaType.getIntInstance(), fieldName));
/* 119:155 */       sb.setLength(0);
/* 120:156 */       sb.append("this.");
/* 121:157 */       sb.append(fieldName);
/* 122:158 */       sb.append(" = ");
/* 123:159 */       sb.append(fieldName);
/* 124:160 */       sb.append(';');
/* 125:161 */       method.addBodyLine(sb.toString());
/* 126:162 */       topLevelClass.addMethod(method);
/* 127:    */     }
/* 128:165 */     return topLevelClass;
/* 129:    */   }
/* 130:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.model.JavaModelGeneratorLegacyImpl
 * JD-Core Version:    0.7.0.1
 */