/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ public class SpringAbatorJava2DAOGenerator
/*  4:   */   extends BaseDAOGenerator
/*  5:   */ {
/*  6:   */   public SpringAbatorJava2DAOGenerator()
/*  7:   */   {
/*  8:24 */     super(new SpringAbatorDAOTemplate(), true);
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringAbatorJava2DAOGenerator
 * JD-Core Version:    0.7.0.1
 */