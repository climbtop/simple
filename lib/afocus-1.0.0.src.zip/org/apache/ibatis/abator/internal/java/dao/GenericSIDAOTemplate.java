/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.Field;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  6:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  7:   */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  8:   */ 
/*  9:   */ public class GenericSIDAOTemplate
/* 10:   */   extends AbstractDAOTemplate
/* 11:   */ {
/* 12:   */   public GenericSIDAOTemplate()
/* 13:   */   {
/* 14:35 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/* 15:36 */       "com.ibatis.sqlmap.client.SqlMapClient");
/* 16:   */     
/* 17:38 */     addImplementationImport(fqjt);
/* 18:   */     
/* 19:40 */     Method method = new Method();
/* 20:41 */     method.setConstructor(true);
/* 21:42 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 22:43 */     method.addBodyLine("super();");
/* 23:44 */     setConstructorTemplate(method);
/* 24:   */     
/* 25:46 */     Field field = new Field();
/* 26:47 */     field.setVisibility(JavaVisibility.PRIVATE);
/* 27:48 */     field.setType(fqjt);
/* 28:49 */     field.setName("sqlMapClient");
/* 29:50 */     addField(field);
/* 30:   */     
/* 31:52 */     method = new Method();
/* 32:53 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 33:54 */     method.setName("setSqlMapClient");
/* 34:55 */     method.addParameter(new Parameter(fqjt, "sqlMapClient"));
/* 35:56 */     method.addBodyLine("this.sqlMapClient = sqlMapClient;");
/* 36:57 */     addMethod(method);
/* 37:   */     
/* 38:59 */     method = new Method();
/* 39:60 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 40:61 */     method.setName("getSqlMapClient");
/* 41:62 */     method.setReturnType(fqjt);
/* 42:63 */     method.addBodyLine("return sqlMapClient;");
/* 43:64 */     addMethod(method);
/* 44:   */     
/* 45:66 */     addCheckedException(new FullyQualifiedJavaType("java.sql.SQLException"));
/* 46:67 */     setDeleteMethodTemplate("sqlMapClient.delete(\"{0}.{1}\", {2});");
/* 47:68 */     setInsertMethodTemplate("sqlMapClient.insert(\"{0}.{1}\", {2});");
/* 48:69 */     setQueryForObjectMethodTemplate("sqlMapClient.queryForObject(\"{0}.{1}\", {2});");
/* 49:70 */     setQueryForListMethodTemplate("sqlMapClient.queryForList(\"{0}.{1}\", {2});");
/* 50:71 */     setUpdateMethodTemplate("sqlMapClient.update(\"{0}.{1}\", {2});");
/* 51:   */   }
/* 52:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.GenericSIDAOTemplate
 * JD-Core Version:    0.7.0.1
 */