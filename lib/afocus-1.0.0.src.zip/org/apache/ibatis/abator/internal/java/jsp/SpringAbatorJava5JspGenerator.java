/*  1:   */ package org.apache.ibatis.abator.internal.java.jsp;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.JspGenerator;
/*  4:   */ 
/*  5:   */ public class SpringAbatorJava5JspGenerator
/*  6:   */   extends BaseJspGenerator
/*  7:   */   implements JspGenerator
/*  8:   */ {
/*  9:   */   public SpringAbatorJava5JspGenerator()
/* 10:   */   {
/* 11:67 */     super(true);
/* 12:   */   }
/* 13:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.jsp.SpringAbatorJava5JspGenerator
 * JD-Core Version:    0.7.0.1
 */