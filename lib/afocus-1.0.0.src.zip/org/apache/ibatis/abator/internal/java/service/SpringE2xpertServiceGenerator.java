/*  1:   */ package org.apache.ibatis.abator.internal.java.service;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  5:   */ 
/*  6:   */ public class SpringE2xpertServiceGenerator
/*  7:   */   extends BaseServiceGenerator
/*  8:   */   implements ServiceGenerator
/*  9:   */ {
/* 10:   */   public SpringE2xpertServiceGenerator()
/* 11:   */   {
/* 12:69 */     super(new SpringE2xpertServiceTemplate(), false);
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/* 16:   */   {
/* 17:73 */     return new FullyQualifiedJavaType("com.e2xpert.framework.util.PageList");
/* 18:   */   }
/* 19:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.service.SpringE2xpertServiceGenerator
 * JD-Core Version:    0.7.0.1
 */