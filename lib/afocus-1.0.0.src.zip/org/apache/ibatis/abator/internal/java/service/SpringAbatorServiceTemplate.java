/*  1:   */ package org.apache.ibatis.abator.internal.java.service;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  4:   */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  6:   */ 
/*  7:   */ public class SpringAbatorServiceTemplate
/*  8:   */   extends AbstractServiceTemplate
/*  9:   */ {
/* 10:   */   public SpringAbatorServiceTemplate()
/* 11:   */   {
/* 12:33 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.framework.base.service.impl.BaseServiceImpl");
/* 13:   */     
/* 14:35 */     Method method = new Method();
/* 15:36 */     method.setConstructor(true);
/* 16:37 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 17:38 */     method.addBodyLine("super();");
/* 18:39 */     setConstructorTemplate(method);
/* 19:   */     
/* 20:41 */     setSuperClass(fqjt);
/* 21:   */     
/* 22:43 */     addImplementationImport(fqjt);
/* 23:   */   }
/* 24:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.service.SpringAbatorServiceTemplate
 * JD-Core Version:    0.7.0.1
 */