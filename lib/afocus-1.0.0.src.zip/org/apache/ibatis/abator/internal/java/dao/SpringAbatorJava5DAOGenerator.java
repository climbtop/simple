/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*  4:   */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  5:   */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  6:   */ 
/*  7:   */ public class SpringAbatorJava5DAOGenerator
/*  8:   */   extends SpringAbatorLegacyDAOGenerator
/*  9:   */ {
/* 10:   */   public SpringAbatorJava5DAOGenerator()
/* 11:   */   {
/* 12:27 */     super(new SpringAbatorDAOTemplate(), true);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public FullyQualifiedJavaType getBaseDAOInterfaceType(FullyQualifiedTable table)
/* 16:   */   {
/* 17:31 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("com.afocus.framework.base.dao.BaseDao");
/* 18:32 */     fqjt.addTypeArgument(this.javaModelGenerator.getBaseRecordType(table));
/* 19:33 */     return fqjt;
/* 20:   */   }
/* 21:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringAbatorJava5DAOGenerator
 * JD-Core Version:    0.7.0.1
 */