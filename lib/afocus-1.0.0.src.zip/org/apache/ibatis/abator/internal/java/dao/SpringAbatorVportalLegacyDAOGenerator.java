/*   1:    */ package org.apache.ibatis.abator.internal.java.dao;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import org.apache.ibatis.abator.api.DAOMethodNameCalculator;
/*   7:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   8:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   9:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*  10:    */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*  11:    */ import org.apache.ibatis.abator.api.dom.java.CompilationUnit;
/*  12:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*  13:    */ import org.apache.ibatis.abator.api.dom.java.JavaVisibility;
/*  14:    */ import org.apache.ibatis.abator.api.dom.java.Method;
/*  15:    */ import org.apache.ibatis.abator.api.dom.java.Parameter;
/*  16:    */ 
/*  17:    */ public class SpringAbatorVportalLegacyDAOGenerator
/*  18:    */   extends BaseLegacyDAOGenerator
/*  19:    */ {
/*  20:    */   public SpringAbatorVportalLegacyDAOGenerator()
/*  21:    */   {
/*  22: 42 */     super(new SpringAbatorDAOTemplate());
/*  23:    */   }
/*  24:    */   
/*  25:    */   protected FullyQualifiedJavaType getSelectByExampleReturnListJavaType()
/*  26:    */   {
/*  27: 46 */     return new FullyQualifiedJavaType("com.afocus.framework.util.PageList");
/*  28:    */   }
/*  29:    */   
/*  30:    */   protected List getExtraImplementationMethods(IntrospectedTable introspectedTable, CompilationUnit compilationUnit)
/*  31:    */   {
/*  32: 51 */     return null;
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected List getSelectByExampleWithoutBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  36:    */   {
/*  37: 57 */     return getSelectByExamplMethods(introspectedTable, interfaceMethod, compilationUnit, 
/*  38: 58 */       this.methodNameCalculator.getSelectByExampleWithoutBLOBsMethodName(introspectedTable), 
/*  39: 59 */       this.sqlMapGenerator.getSelectByExampleStatementId());
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected List getSelectByExampleWithBLOBsMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/*  43:    */   {
/*  44: 65 */     return getSelectByExamplMethods(introspectedTable, interfaceMethod, compilationUnit, 
/*  45: 66 */       this.methodNameCalculator.getSelectByExampleWithBLOBsMethodName(introspectedTable), 
/*  46: 67 */       this.sqlMapGenerator.getSelectByExampleWithBLOBsStatementId());
/*  47:    */   }
/*  48:    */   
/*  49:    */   private List getSelectByExamplMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit, String selectByExampleMethodName, String selectByExampleStatementId)
/*  50:    */   {
/*  51: 74 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/*  52: 75 */       return null;
/*  53:    */     }
/*  54: 78 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  55: 79 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/*  56: 80 */     compilationUnit.addImportedType(type);
/*  57: 81 */     compilationUnit.addImportedType(getSelectByExampleReturnListJavaType());
/*  58:    */     
/*  59: 83 */     Method method = new Method();
/*  60: 84 */     method.addComment(table);
/*  61: 85 */     method.setVisibility(this.exampleMethodVisibility);
/*  62: 86 */     method.setReturnType(getSelectByExampleReturnListJavaType());
/*  63: 87 */     method.setName(selectByExampleMethodName);
/*  64: 88 */     method.addParameter(new Parameter(type, "params, int pageNum, int numPerPage, boolean doCount"));
/*  65:    */     
/*  66: 90 */     Method method2 = new Method();
/*  67: 91 */     method2.addComment(table);
/*  68: 92 */     method2.setVisibility(this.exampleMethodVisibility);
/*  69: 93 */     method2.setReturnType(getSelectByExampleReturnListJavaType());
/*  70: 94 */     method2.setName(selectByExampleMethodName);
/*  71: 95 */     method2.addParameter(new Parameter(type, "params, int pageNum, int numPerPage"));
/*  72:    */     
/*  73: 97 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/*  74: 98 */     while (iter.hasNext())
/*  75:    */     {
/*  76: 99 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/*  77:100 */       method.addException(fqjt);
/*  78:101 */       method2.addException(fqjt);
/*  79:102 */       compilationUnit.addImportedType(fqjt);
/*  80:    */     }
/*  81:105 */     if (!interfaceMethod)
/*  82:    */     {
/*  83:107 */       compilationUnit.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
/*  84:    */       
/*  85:109 */       StringBuffer sb = new StringBuffer();
/*  86:111 */       if (this.suppressTypeWarnings) {
/*  87:112 */         method.addSuppressTypeWarningsAnnotation();
/*  88:    */       }
/*  89:115 */       sb.append("return ");
/*  90:116 */       sb.append(this.daoTemplate.getQueryForListMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/*  91:117 */         selectByExampleStatementId, "params, new Integer(pageNum), new Integer(numPerPage), doCount"));
/*  92:118 */       method.addBodyLine(sb.toString());
/*  93:    */       
/*  94:120 */       sb.setLength(0);
/*  95:121 */       sb.append("return ");
/*  96:122 */       sb.append(selectByExampleMethodName);
/*  97:123 */       sb.append("(params, pageNum, numPerPage, true);");
/*  98:124 */       method2.addBodyLine(sb.toString());
/*  99:    */     }
/* 100:127 */     ArrayList answer = new ArrayList();
/* 101:128 */     answer.add(method);
/* 102:129 */     answer.add(method2);
/* 103:    */     
/* 104:131 */     return answer;
/* 105:    */   }
/* 106:    */   
/* 107:    */   protected List getDeleteByExampleMethods(IntrospectedTable introspectedTable, boolean interfaceMethod, CompilationUnit compilationUnit)
/* 108:    */   {
/* 109:139 */     if ((interfaceMethod) && (this.exampleMethodVisibility != JavaVisibility.PUBLIC)) {
/* 110:140 */       return null;
/* 111:    */     }
/* 112:143 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 113:144 */     FullyQualifiedJavaType type = this.javaModelGenerator.getExampleType(table);
/* 114:145 */     compilationUnit.addImportedType(type);
/* 115:    */     
/* 116:147 */     Method method = new Method();
/* 117:148 */     method.addComment(table);
/* 118:149 */     method.setVisibility(this.exampleMethodVisibility);
/* 119:150 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 120:151 */     method.setName(this.methodNameCalculator.getDeleteByExampleMethodName(introspectedTable));
/* 121:152 */     method.addParameter(new Parameter(type, "params"));
/* 122:    */     
/* 123:154 */     Iterator iter = this.daoTemplate.getCheckedExceptions().iterator();
/* 124:155 */     while (iter.hasNext())
/* 125:    */     {
/* 126:156 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)iter.next();
/* 127:157 */       method.addException(fqjt);
/* 128:158 */       compilationUnit.addImportedType(fqjt);
/* 129:    */     }
/* 130:161 */     if (!interfaceMethod)
/* 131:    */     {
/* 132:163 */       StringBuffer sb = new StringBuffer();
/* 133:    */       
/* 134:    */ 
/* 135:166 */       sb.append("return ");
/* 136:167 */       sb.append(this.daoTemplate.getDeleteMethod(this.sqlMapGenerator.getSqlMapNamespace(table), 
/* 137:168 */         this.sqlMapGenerator.getDeleteByExampleStatementId(), 
/* 138:169 */         "params"));
/* 139:170 */       method.addBodyLine(sb.toString());
/* 140:    */     }
/* 141:175 */     ArrayList answer = new ArrayList();
/* 142:176 */     answer.add(method);
/* 143:    */     
/* 144:178 */     return answer;
/* 145:    */   }
/* 146:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.SpringAbatorVportalLegacyDAOGenerator
 * JD-Core Version:    0.7.0.1
 */