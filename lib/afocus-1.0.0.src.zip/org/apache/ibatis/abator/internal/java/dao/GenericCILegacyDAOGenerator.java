/*  1:   */ package org.apache.ibatis.abator.internal.java.dao;
/*  2:   */ 
/*  3:   */ public class GenericCILegacyDAOGenerator
/*  4:   */   extends BaseLegacyDAOGenerator
/*  5:   */ {
/*  6:   */   public GenericCILegacyDAOGenerator()
/*  7:   */   {
/*  8:31 */     super(new GenericCIDAOTemplate());
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.java.dao.GenericCILegacyDAOGenerator
 * JD-Core Version:    0.7.0.1
 */