/*  1:   */ package org.apache.ibatis.abator.internal;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.AopMethodNameCalculator;
/*  4:   */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  5:   */ 
/*  6:   */ public class DefaultAopMethodNameCalculator
/*  7:   */   implements AopMethodNameCalculator
/*  8:   */ {
/*  9:   */   public String getBeforeMethodName(IntrospectedTable introspectedTable)
/* 10:   */   {
/* 11:37 */     return "before";
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getAfterMethodName(IntrospectedTable introspectedTable)
/* 15:   */   {
/* 16:41 */     return "after";
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getAroundMethodName(IntrospectedTable introspectedTable)
/* 20:   */   {
/* 21:45 */     return "around";
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.DefaultAopMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */