/*   1:    */ package org.apache.ibatis.abator.internal;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.apache.ibatis.abator.api.AopGenerator;
/*   5:    */ import org.apache.ibatis.abator.api.ControllerGenerator;
/*   6:    */ import org.apache.ibatis.abator.api.DAOGenerator;
/*   7:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   8:    */ import org.apache.ibatis.abator.api.JavaTypeResolver;
/*   9:    */ import org.apache.ibatis.abator.api.JspGenerator;
/*  10:    */ import org.apache.ibatis.abator.api.ServiceGenerator;
/*  11:    */ import org.apache.ibatis.abator.api.ShellCallback;
/*  12:    */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*  13:    */ import org.apache.ibatis.abator.config.AbatorContext;
/*  14:    */ import org.apache.ibatis.abator.config.AopGeneratorConfiguration;
/*  15:    */ import org.apache.ibatis.abator.config.ControllerGeneratorConfiguration;
/*  16:    */ import org.apache.ibatis.abator.config.DAOGeneratorConfiguration;
/*  17:    */ import org.apache.ibatis.abator.config.GeneratorSet;
/*  18:    */ import org.apache.ibatis.abator.config.JavaModelGeneratorConfiguration;
/*  19:    */ import org.apache.ibatis.abator.config.JavaTypeResolverConfiguration;
/*  20:    */ import org.apache.ibatis.abator.config.JspGeneratorConfiguration;
/*  21:    */ import org.apache.ibatis.abator.config.ServiceGeneratorConfiguration;
/*  22:    */ import org.apache.ibatis.abator.config.SqlMapGeneratorConfiguration;
/*  23:    */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*  24:    */ 
/*  25:    */ public class AbatorObjectFactory
/*  26:    */ {
/*  27:    */   public static Object createObject(String type)
/*  28:    */   {
/*  29: 55 */     Class clazz = null;
/*  30:    */     try
/*  31:    */     {
/*  32: 58 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*  33: 59 */       clazz = cl.loadClass(type);
/*  34:    */     }
/*  35:    */     catch (Exception localException1) {}
/*  36:    */     try
/*  37:    */     {
/*  38: 67 */       if (clazz == null) {
/*  39: 68 */         clazz = Class.forName(type);
/*  40:    */       }
/*  41: 71 */       answer = clazz.newInstance();
/*  42:    */     }
/*  43:    */     catch (Exception e)
/*  44:    */     {
/*  45:    */       Object answer;
/*  46: 73 */       throw new RuntimeException(
/*  47: 74 */         Messages.getString("RuntimeError.6", type), e);
/*  48:    */     }
/*  49:    */     Object answer;
/*  50: 78 */     return answer;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static JavaTypeResolver createJavaTypeResolver(AbatorContext context, List warnings)
/*  54:    */   {
/*  55: 83 */     JavaTypeResolverConfiguration config = context.getJavaTypeResolverConfiguration();
/*  56:    */     String type;
/*  57:    */     String type;
/*  58: 86 */     if ((config != null) && (config.getConfigurationType() != null)) {
/*  59: 87 */       type = config.getConfigurationType();
/*  60:    */     } else {
/*  61: 89 */       type = context.getGeneratorSet().getJavaTypeResolverType();
/*  62:    */     }
/*  63: 92 */     JavaTypeResolver answer = (JavaTypeResolver)createObject(type);
/*  64: 93 */     answer.setWarnings(warnings);
/*  65: 95 */     if (config != null) {
/*  66: 96 */       answer.addConfigurationProperties(config.getProperties());
/*  67:    */     }
/*  68: 99 */     answer.addContextProperties(context.getProperties());
/*  69:    */     
/*  70:101 */     return answer;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static SqlMapGenerator createSqlMapGenerator(AbatorContext context, JavaModelGenerator javaModelGenerator, List warnings)
/*  74:    */   {
/*  75:107 */     SqlMapGeneratorConfiguration config = context.getSqlMapGeneratorConfiguration();
/*  76:    */     String type;
/*  77:    */     String type;
/*  78:110 */     if (config.getConfigurationType() != null) {
/*  79:111 */       type = config.getConfigurationType();
/*  80:    */     } else {
/*  81:113 */       type = context.getGeneratorSet().getSqlMapGeneratorType();
/*  82:    */     }
/*  83:116 */     SqlMapGenerator answer = (SqlMapGenerator)createObject(type);
/*  84:117 */     answer.setWarnings(warnings);
/*  85:    */     
/*  86:119 */     answer.setJavaModelGenerator(javaModelGenerator);
/*  87:120 */     answer.addConfigurationProperties(config.getProperties());
/*  88:121 */     answer.addContextProperties(context.getProperties());
/*  89:122 */     answer.setTargetPackage(config.getTargetPackage());
/*  90:123 */     answer.setTargetProject(config.getTargetProject());
/*  91:    */     
/*  92:125 */     return answer;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static JavaModelGenerator createJavaModelGenerator(AbatorContext context, List warnings)
/*  96:    */   {
/*  97:131 */     JavaModelGeneratorConfiguration config = context.getJavaModelGeneratorConfiguration();
/*  98:    */     String type;
/*  99:    */     String type;
/* 100:134 */     if (config.getConfigurationType() != null) {
/* 101:135 */       type = config.getConfigurationType();
/* 102:    */     } else {
/* 103:137 */       type = context.getGeneratorSet().getJavaModelGeneratorType();
/* 104:    */     }
/* 105:140 */     JavaModelGenerator answer = (JavaModelGenerator)createObject(type);
/* 106:141 */     answer.setWarnings(warnings);
/* 107:    */     
/* 108:143 */     answer.addConfigurationProperties(config.getProperties());
/* 109:144 */     answer.addContextProperties(context.getProperties());
/* 110:145 */     answer.setTargetPackage(config.getTargetPackage());
/* 111:146 */     answer.setTargetProject(config.getTargetProject());
/* 112:    */     
/* 113:148 */     return answer;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static DAOGenerator createDAOGenerator(AbatorContext context, JavaModelGenerator javaModelGenerator, SqlMapGenerator sqlMapGenerator, List warnings)
/* 117:    */   {
/* 118:154 */     DAOGeneratorConfiguration config = context.getDaoGeneratorConfiguration();
/* 119:156 */     if (config == null) {
/* 120:157 */       return null;
/* 121:    */     }
/* 122:160 */     String type = context.getGeneratorSet().translateDAOGeneratorType(config.getConfigurationType());
/* 123:    */     
/* 124:162 */     DAOGenerator answer = (DAOGenerator)createObject(type);
/* 125:163 */     answer.setWarnings(warnings);
/* 126:    */     
/* 127:165 */     answer.setJavaModelGenerator(javaModelGenerator);
/* 128:166 */     answer.addConfigurationProperties(config.getProperties());
/* 129:167 */     answer.addContextProperties(context.getProperties());
/* 130:168 */     answer.setSqlMapGenerator(sqlMapGenerator);
/* 131:169 */     answer.setTargetPackage(config.getTargetPackage());
/* 132:170 */     answer.setTargetProject(config.getTargetProject());
/* 133:    */     
/* 134:172 */     return answer;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public static AopGenerator createAopGenerator(AbatorContext context, JavaModelGenerator javaModelGenerator, DAOGenerator daoGenerator, List warnings)
/* 138:    */   {
/* 139:178 */     AopGeneratorConfiguration config = context.getAopGeneratorConfiguration();
/* 140:180 */     if (config == null) {
/* 141:181 */       return null;
/* 142:    */     }
/* 143:184 */     String type = context.getGeneratorSet().translateAopGeneratorType(config.getConfigurationType());
/* 144:    */     
/* 145:186 */     AopGenerator answer = (AopGenerator)createObject(type);
/* 146:187 */     answer.setWarnings(warnings);
/* 147:    */     
/* 148:189 */     answer.setJavaModelGenerator(javaModelGenerator);
/* 149:190 */     answer.addConfigurationProperties(config.getProperties());
/* 150:191 */     answer.addContextProperties(context.getProperties());
/* 151:192 */     answer.setDaoGenerator(daoGenerator);
/* 152:193 */     answer.setTargetPackage(config.getTargetPackage());
/* 153:194 */     answer.setTargetProject(config.getTargetProject());
/* 154:    */     
/* 155:196 */     return answer;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public static ServiceGenerator createServiceGenerator(AbatorContext context, JavaModelGenerator javaModelGenerator, DAOGenerator daoGenerator, List warnings)
/* 159:    */   {
/* 160:202 */     ServiceGeneratorConfiguration config = context.getServiceGeneratorConfiguration();
/* 161:204 */     if (config == null) {
/* 162:205 */       return null;
/* 163:    */     }
/* 164:208 */     String type = context.getGeneratorSet().translateServiceGeneratorType(config.getConfigurationType());
/* 165:    */     
/* 166:210 */     ServiceGenerator answer = (ServiceGenerator)createObject(type);
/* 167:211 */     answer.setWarnings(warnings);
/* 168:    */     
/* 169:213 */     answer.setJavaModelGenerator(javaModelGenerator);
/* 170:214 */     answer.addConfigurationProperties(config.getProperties());
/* 171:215 */     answer.addContextProperties(context.getProperties());
/* 172:216 */     answer.setDaoGenerator(daoGenerator);
/* 173:217 */     answer.setTargetPackage(config.getTargetPackage());
/* 174:218 */     answer.setTargetProject(config.getTargetProject());
/* 175:    */     
/* 176:220 */     return answer;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public static ControllerGenerator createControllerGenerator(AbatorContext context, JavaModelGenerator javaModelGenerator, ServiceGenerator serviceGenerator, List warnings)
/* 180:    */   {
/* 181:226 */     ControllerGeneratorConfiguration config = context.getControllerGeneratorConfiguration();
/* 182:228 */     if (config == null) {
/* 183:229 */       return null;
/* 184:    */     }
/* 185:232 */     String type = context.getGeneratorSet().translateControllerGeneratorType(config.getConfigurationType());
/* 186:    */     
/* 187:234 */     ControllerGenerator answer = (ControllerGenerator)createObject(type);
/* 188:235 */     answer.setWarnings(warnings);
/* 189:    */     
/* 190:237 */     answer.setJavaModelGenerator(javaModelGenerator);
/* 191:238 */     answer.addConfigurationProperties(config.getProperties());
/* 192:239 */     answer.addContextProperties(context.getProperties());
/* 193:240 */     answer.setServiceGenerator(serviceGenerator);
/* 194:241 */     answer.setTargetPackage(config.getTargetPackage());
/* 195:242 */     answer.setTargetProject(config.getTargetProject());
/* 196:    */     
/* 197:244 */     return answer;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static JspGenerator createJspGenerator(AbatorContext context, ShellCallback shellCallback, JavaModelGenerator javaModelGenerator, ControllerGenerator controllerGenerator, List warnings)
/* 201:    */   {
/* 202:250 */     JspGeneratorConfiguration config = context.getJspGeneratorConfiguration();
/* 203:252 */     if (config == null) {
/* 204:253 */       return null;
/* 205:    */     }
/* 206:256 */     String type = context.getGeneratorSet().translateJspGeneratorType(config.getConfigurationType());
/* 207:    */     
/* 208:258 */     JspGenerator answer = (JspGenerator)createObject(type);
/* 209:259 */     answer.setWarnings(warnings);
/* 210:    */     
/* 211:261 */     answer.setTargetPackage(config.getTargetPackage());
/* 212:262 */     answer.setTargetProject(config.getTargetProject());
/* 213:263 */     answer.setShellCallback(shellCallback);
/* 214:264 */     answer.setJavaModelGenerator(javaModelGenerator);
/* 215:265 */     answer.addConfigurationProperties(config.getProperties());
/* 216:266 */     answer.addContextProperties(context.getProperties());
/* 217:267 */     answer.setControllerGenerator(controllerGenerator);
/* 218:    */     
/* 219:269 */     return answer;
/* 220:    */   }
/* 221:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.AbatorObjectFactory
 * JD-Core Version:    0.7.0.1
 */