package org.apache.ibatis.abator.internal.sqlmap;

public class XmlConstants
{
  public static final String SQL_MAP_SYSTEM_ID = "http://ibatis.apache.org/dtd/sql-map-2.dtd";
  public static final String SQL_MAP_PUBLIC_ID = "-//ibatis.apache.org//DTD SQL Map 2.0//EN";
  public static final String ABATOR_CONFIG_PUBLIC_ID = "-//Apache Software Foundation//DTD Abator for iBATIS Configuration 1.0//EN";
}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.sqlmap.XmlConstants
 * JD-Core Version:    0.7.0.1
 */