/*   1:    */ package org.apache.ibatis.abator.internal.sqlmap;
/*   2:    */ 
/*   3:    */ import java.text.MessageFormat;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*   9:    */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*  10:    */ 
/*  11:    */ public class ExampleClause
/*  12:    */ {
/*  13:    */   private static final int IS_NULL_CLAUSE_ID = 1;
/*  14:    */   private static final int IS_NOT_NULL_CLAUSE_ID = 2;
/*  15:    */   private static final int EQUALS_CLAUSE_ID = 3;
/*  16:    */   private static final int NOT_EQUALS_CLAUSE_ID = 4;
/*  17:    */   private static final int GREATER_THAN_CLAUSE_ID = 5;
/*  18:    */   private static final int GREATER_THAN_OR_EQUAL_CLAUSE_ID = 6;
/*  19:    */   private static final int LESS_THAN_CLAUSE_ID = 7;
/*  20:    */   private static final int LESS_THAN_OR_EQUAL_CLAUSE_ID = 8;
/*  21:    */   private static final int LIKE_CLAUSE_ID = 9;
/*  22:    */   private static final int IN_CLAUSE_ID = 10;
/*  23:    */   private static final int NOT_IN_CLAUSE_ID = 11;
/*  24:    */   private static final int IN_LIST_CLAUSE_ID = 12;
/*  25:    */   private static final int NOT_IN_LIST_CLAUSE_ID = 13;
/*  26:    */   private static final int BETWEEN_CLAUSE_ID = 14;
/*  27:    */   private static final int OF_ALL_CHILDREN_CLAUSE_ID = 15;
/*  28:    */   private static final int AS_PARENTID_CLAUSE_ID = 16;
/*  29:    */   private static final int AS_CHILDID_CLAUSE_ID = 17;
/*  30:    */   private static final List clauses;
/*  31:    */   private String selectorProperty;
/*  32:    */   private String clause;
/*  33:    */   private boolean propertyInMapRequired;
/*  34:    */   private boolean characterOnly;
/*  35:    */   private String examplePropertyName;
/*  36:    */   private int examplePropertyValue;
/*  37:    */   
/*  38:    */   static
/*  39:    */   {
/*  40: 77 */     List list = new ArrayList();
/*  41:    */     
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:111 */     list.add(new ExampleClause("eq{0}", "{0} = {1}", true, false, "eq", 3));
/*  75:112 */     list.add(new ExampleClause("neq{0}", "{0} <![CDATA[ <> ]]> {1}", false, false, "neq", 4));
/*  76:113 */     list.add(new ExampleClause("in{0}s", "{0} in ( ${1}$ )", false, false, "in", 10));
/*  77:114 */     list.add(new ExampleClause("in{0}List", "{0} in <iterate prepend=\"\" property=\"{1}\" open=\"(\" close=\")\" conjunction=\",\">#{1}[]:{2}#</iterate>", false, false, "inList", 12));
/*  78:115 */     list.add(new ExampleClause("notIn{0}s", "{0} not in ( ${1}$ )", false, false, "notIn", 11));
/*  79:116 */     list.add(new ExampleClause("notIn{0}List", "{0} not in <iterate prepend=\"\" property=\"{1}\" open=\"(\" close=\")\" conjunction=\",\">#{1}[]:{2}#</iterate>", false, false, "notInList", 13));
/*  80:117 */     list.add(new ExampleClause("gt{0}", "{0} <![CDATA[ > ]]> {1}", true, false, "gt", 5));
/*  81:118 */     list.add(new ExampleClause("lt{0}", "{0} <![CDATA[ < ]]> {1}", false, false, "lt", 7));
/*  82:119 */     list.add(new ExampleClause("ge{0}", "{0} <![CDATA[ >= ]]> {1}", false, false, "ge", 6));
/*  83:120 */     list.add(new ExampleClause("le{0}", "{0} <![CDATA[ <= ]]> {1}", false, false, "le", 8));
/*  84:121 */     list.add(new ExampleClause("isNull{0}", "{0} is null", false, false, "isNull", 1));
/*  85:122 */     list.add(new ExampleClause("isNotNull{0}", "{0} is not null", false, false, "isNotNull", 2));
/*  86:123 */     list.add(new ExampleClause("like{0}", "{0} like {1}", true, true, "like", 9));
/*  87:124 */     list.add(new ExampleClause("between{0}", "{0} between {1} and {2}", false, false, "between", 14));
/*  88:125 */     list.add(new ExampleClause("eq{0}OfAllChildren", "start with {2} = {1} connect by {2}=PRIOR {0}", true, false, "ofAllChildren", 15));
/*  89:126 */     list.add(new ExampleClause("eq{0}AsParentId", "start with {0} = {1} connect by {2}=PRIOR {0}", true, false, "asParentId", 16));
/*  90:127 */     list.add(new ExampleClause("eq{0}AsChildId", "start with {0} = {1} connect by {0}=PRIOR {2}", true, false, "asChildId", 17));
/*  91:    */     
/*  92:129 */     clauses = Collections.unmodifiableList(list);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static Iterator getAllExampleClauses()
/*  96:    */   {
/*  97:133 */     return clauses.iterator();
/*  98:    */   }
/*  99:    */   
/* 100:    */   private ExampleClause(String selectorProperty, String clause, boolean propertyInMapRequired, boolean characterOnly, String examplePropertyName, int examplePropertyValue)
/* 101:    */   {
/* 102:143 */     this.selectorProperty = selectorProperty;
/* 103:144 */     this.clause = clause;
/* 104:145 */     this.propertyInMapRequired = propertyInMapRequired;
/* 105:146 */     this.characterOnly = characterOnly;
/* 106:147 */     this.examplePropertyName = examplePropertyName;
/* 107:148 */     this.examplePropertyValue = examplePropertyValue;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getSelectorAndProperty(ColumnDefinition cd)
/* 111:    */   {
/* 112:152 */     Object[] arguments = { "AND", cd.getColumnName() };
/* 113:    */     
/* 114:154 */     return MessageFormat.format(this.selectorProperty, arguments);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public String getSelectorOrProperty(ColumnDefinition cd)
/* 118:    */   {
/* 119:158 */     Object[] arguments = { "OR", cd.getColumnName() };
/* 120:    */     
/* 121:160 */     return MessageFormat.format(this.selectorProperty, arguments);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public String getExampleProperty(ColumnDefinition cd)
/* 125:    */   {
/* 126:164 */     Object[] arguments = { cd.getPrefixJavaProperty(null) };
/* 127:    */     
/* 128:166 */     return MessageFormat.format(this.selectorProperty, arguments);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public String getClause(ColumnDefinition pk, ColumnDefinition cd, int databaseDialect)
/* 132:    */   {
/* 133:172 */     if ((this.examplePropertyValue == 12) || (this.examplePropertyValue == 13))
/* 134:    */     {
/* 135:173 */       Object[] arguments = { cd.getAliasedColumnName(), getExampleProperty(cd), cd.getResolvedJavaType().getJdbcTypeName() };
/* 136:174 */       return MessageFormat.format(this.clause, arguments);
/* 137:    */     }
/* 138:176 */     if (this.examplePropertyValue == 14)
/* 139:    */     {
/* 140:177 */       Object[] arguments = { cd.getAliasedColumnName(), cd.getIbatisFormattedParameterClause(getExampleProperty(cd)), cd.getIbatisFormattedParameterClause(getExampleProperty(cd) + "2") };
/* 141:178 */       return MessageFormat.format(this.clause, arguments);
/* 142:    */     }
/* 143:180 */     if ((this.examplePropertyValue == 10) || (this.examplePropertyValue == 11))
/* 144:    */     {
/* 145:181 */       Object[] arguments = { cd.getAliasedColumnName(), getExampleProperty(cd) };
/* 146:182 */       return MessageFormat.format(this.clause, arguments);
/* 147:    */     }
/* 148:184 */     if ((this.examplePropertyValue == 16) || (this.examplePropertyValue == 17))
/* 149:    */     {
/* 150:185 */       Object[] arguments = { pk.getAliasedColumnName(), pk.getIbatisFormattedExampleParameterClause(getExampleProperty(pk), databaseDialect), cd.getAliasedColumnName() };
/* 151:186 */       return MessageFormat.format(this.clause, arguments);
/* 152:    */     }
/* 153:188 */     if (this.examplePropertyValue == 15)
/* 154:    */     {
/* 155:189 */       Object[] arguments = { pk.getAliasedColumnName(), pk.getIbatisFormattedExampleParameterClause(getExampleProperty(cd), databaseDialect), cd.getAliasedColumnName() };
/* 156:190 */       return MessageFormat.format(this.clause, arguments);
/* 157:    */     }
/* 158:193 */     Object[] arguments = { cd.getAliasedColumnName(), cd.getIbatisFormattedExampleParameterClause(getExampleProperty(cd), databaseDialect) };
/* 159:194 */     return MessageFormat.format(this.clause, arguments);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean isCharacterOnly()
/* 163:    */   {
/* 164:198 */     return this.characterOnly;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public boolean isPropertyInMapRequired()
/* 168:    */   {
/* 169:202 */     return this.propertyInMapRequired;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public String getExamplePropertyName()
/* 173:    */   {
/* 174:206 */     return this.examplePropertyName;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public int getExamplePropertyValue()
/* 178:    */   {
/* 179:210 */     return this.examplePropertyValue;
/* 180:    */   }
/* 181:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.sqlmap.ExampleClause
 * JD-Core Version:    0.7.0.1
 */