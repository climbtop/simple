package org.apache.ibatis.abator.internal.sqlmap;

import org.apache.ibatis.abator.api.SqlMapGenerator;

public class SqlMapGeneratorJava5Impl
  extends SqlMapGeneratorLegacyImpl
  implements SqlMapGenerator
{}


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorJava5Impl
 * JD-Core Version:    0.7.0.1
 */