/*   1:    */ package org.apache.ibatis.abator.internal.sqlmap;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   6:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   7:    */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*   8:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   9:    */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*  10:    */ import org.apache.ibatis.abator.api.dom.xml.TextElement;
/*  11:    */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*  12:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*  13:    */ import org.apache.ibatis.abator.internal.db.DatabaseDialects;
/*  14:    */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*  15:    */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*  16:    */ 
/*  17:    */ public class SqlMapGeneratorLegacyImpl
/*  18:    */   extends SqlMapGeneratorIterateImpl
/*  19:    */   implements SqlMapGenerator
/*  20:    */ {
/*  21:    */   protected XmlElement getDeleteByExample(IntrospectedTable introspectedTable)
/*  22:    */   {
/*  23: 57 */     XmlElement answer = new XmlElement("delete");
/*  24:    */     
/*  25: 59 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  26: 60 */     answer.addAttribute(new Attribute("id", getDeleteByExampleStatementId()));
/*  27: 61 */     answer.addAttribute(new Attribute("parameterClass", "java.util.Map"));
/*  28:    */     
/*  29: 63 */     answer.addComment();
/*  30:    */     
/*  31: 65 */     StringBuffer sb = new StringBuffer();
/*  32: 66 */     sb.append("delete from ");
/*  33: 67 */     sb.append(table.getAliasedFullyQualifiedTableName());
/*  34: 68 */     answer.addElement(new TextElement(sb.toString()));
/*  35:    */     
/*  36: 70 */     XmlElement includeElement = new XmlElement("include");
/*  37: 71 */     sb.setLength(0);
/*  38: 72 */     sb.append(getSqlMapNamespace(table));
/*  39: 73 */     sb.append('.');
/*  40: 74 */     sb.append(getExampleWhereClauseId());
/*  41: 75 */     includeElement.addAttribute(new Attribute("refid", 
/*  42: 76 */       sb.toString()));
/*  43:    */     
/*  44: 78 */     answer.addElement(includeElement);
/*  45:    */     
/*  46: 80 */     return answer;
/*  47:    */   }
/*  48:    */   
/*  49:    */   protected XmlElement getByExampleWhereClauseFragment(IntrospectedTable introspectedTable)
/*  50:    */   {
/*  51: 92 */     XmlElement answer = new XmlElement("sql");
/*  52:    */     
/*  53: 94 */     answer.addAttribute(new Attribute("id", getExampleWhereClauseId()));
/*  54:    */     
/*  55: 96 */     answer.addComment();
/*  56:    */     
/*  57: 98 */     XmlElement dynamicElement = new XmlElement("dynamic");
/*  58: 99 */     dynamicElement.addAttribute(new Attribute("prepend", "where"));
/*  59:100 */     ArrayList<XmlElement> parentIdClausesList = new ArrayList();
/*  60:    */     
/*  61:102 */     String pkColumnName = "";
/*  62:103 */     ColumnDefinition pkColumn = null;
/*  63:104 */     Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  64:105 */     if (iter.hasNext())
/*  65:    */     {
/*  66:106 */       pkColumn = (ColumnDefinition)iter.next();
/*  67:107 */       pkColumnName = pkColumn.getColumnName();
/*  68:    */     }
/*  69:110 */     iter = introspectedTable.getNonBLOBColumns();
/*  70:    */     boolean isPk;
/*  71:    */     Iterator clauseIterator;
/*  72:    */     label659:
/*  73:111 */     for (; iter.hasNext(); clauseIterator.hasNext())
/*  74:    */     {
/*  75:112 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  76:113 */       if ((cd.isBLOBColumn()) || 
/*  77:114 */         (!cd.isQueryable())) {
/*  78:    */         break label659;
/*  79:    */       }
/*  80:116 */       isPk = (pkColumnName.equalsIgnoreCase(cd.getColumnName())) || (cd.isIdentity());
/*  81:    */       
/*  82:118 */       boolean isDate = (cd.isJDBCDateColumn()) || (cd.isJDBCTimeColumn()) || 
/*  83:119 */         (cd.getResolvedJavaType().getFullyQualifiedJavaType().getBaseShortName().equalsIgnoreCase("Date"));
/*  84:    */       
/*  85:121 */       boolean isParentIdColumn = (cd.getJavaProperty().toLowerCase().indexOf("parentid") > -1) && (pkColumn != null) && 
/*  86:122 */         (getDatabaseDialect() == DatabaseDialects.ORACLE.intValue());
/*  87:    */       
/*  88:124 */       clauseIterator = ExampleClause.getAllExampleClauses();
/*  89:125 */       continue;
/*  90:126 */       ExampleClause ec = (ExampleClause)clauseIterator.next();
/*  91:128 */       if (((!ec.isCharacterOnly()) || (cd.isJdbcCharacterColumn())) && (
/*  92:129 */         (ec.isPropertyInMapRequired()) || (isPk) || (isParentIdColumn)))
/*  93:    */       {
/*  94:131 */         boolean isAsParentChildIdClause = "ofAllChildren,asParentId,asChildId".indexOf(ec.getExamplePropertyName()) >= 0;
/*  95:132 */         boolean isInEq = "eq,inList,in".indexOf(ec.getExamplePropertyName()) >= 0;
/*  96:135 */         if (((!isAsParentChildIdClause) || (isParentIdColumn)) && (
/*  97:136 */           (!isParentIdColumn) || (isInEq) || (isAsParentChildIdClause)))
/*  98:    */         {
/*  99:139 */           boolean isInGtEq = "eq,gt,inList,in".indexOf(ec.getExamplePropertyName()) >= 0;
/* 100:140 */           if ((!isPk) || (isInGtEq)) {
/* 101:142 */             if ((!cd.isJdbcCharacterColumn()) || ("gt".indexOf(ec.getExamplePropertyName()) < 0)) {
/* 102:144 */               if (("eq,inList,in,notIn,notInList".indexOf(ec.getExamplePropertyName()) < 0) || (!isDate))
/* 103:    */               {
/* 104:148 */                 XmlElement isPropAvail = new XmlElement("isPropertyAvailable");
/* 105:149 */                 if ((isParentIdColumn) && (isAsParentChildIdClause))
/* 106:    */                 {
/* 107:150 */                   isPropAvail.addAttribute(new Attribute("prepend", ""));
/* 108:151 */                   if ("ofAllChildren".indexOf(ec.getExamplePropertyName()) >= 0) {
/* 109:152 */                     isPropAvail.addAttribute(new Attribute("property", ec.getExampleProperty(cd)));
/* 110:    */                   } else {
/* 111:155 */                     isPropAvail.addAttribute(new Attribute("property", ec.getExampleProperty(pkColumn)));
/* 112:    */                   }
/* 113:156 */                   parentIdClausesList.add(isPropAvail);
/* 114:    */                 }
/* 115:    */                 else
/* 116:    */                 {
/* 117:159 */                   isPropAvail.addAttribute(new Attribute("prepend", "and"));
/* 118:160 */                   isPropAvail.addAttribute(new Attribute("property", ec.getExampleProperty(cd)));
/* 119:161 */                   dynamicElement.addElement(isPropAvail);
/* 120:    */                 }
/* 121:163 */                 isPropAvail.addElement(new TextElement(ec.getClause(pkColumn, cd, getDatabaseDialect())));
/* 122:    */               }
/* 123:    */             }
/* 124:    */           }
/* 125:    */         }
/* 126:    */       }
/* 127:    */     }
/* 128:176 */     if (parentIdClausesList.size() > 0) {
/* 129:177 */       for (XmlElement isPropAvail : parentIdClausesList) {
/* 130:178 */         dynamicElement.addElement(isPropAvail);
/* 131:    */       }
/* 132:    */     }
/* 133:182 */     answer.addElement(dynamicElement);
/* 134:    */     
/* 135:184 */     return answer;
/* 136:    */   }
/* 137:    */   
/* 138:    */   protected XmlElement getSelectByExample(IntrospectedTable introspectedTable)
/* 139:    */   {
/* 140:196 */     XmlElement answer = new XmlElement("select");
/* 141:    */     
/* 142:198 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 143:199 */     answer.addAttribute(new Attribute("id", getSelectByExampleStatementId()));
/* 144:200 */     answer.addAttribute(new Attribute("resultMap", 
/* 145:201 */       getResultMapName(table)));
/* 146:202 */     answer.addAttribute(new Attribute("parameterClass", "java.util.Map"));
/* 147:    */     
/* 148:204 */     answer.addComment();
/* 149:    */     
/* 150:206 */     StringBuffer sb = new StringBuffer();
/* 151:207 */     if (getPaginationClauseStartId().length() > 0)
/* 152:    */     {
/* 153:208 */       answer.addElement(new TextElement("select "));
/* 154:209 */       XmlElement paginationElement = new XmlElement("include");
/* 155:210 */       paginationElement.addAttribute(new Attribute("refid", 
/* 156:211 */         getPaginationClauseStartId()));
/* 157:212 */       answer.addElement(paginationElement);
/* 158:    */     }
/* 159:    */     else
/* 160:    */     {
/* 161:215 */       sb.append("select ");
/* 162:    */     }
/* 163:218 */     boolean comma = false;
/* 164:219 */     if (StringUtility.stringHasValue(introspectedTable.getSelectByExampleQueryId()))
/* 165:    */     {
/* 166:220 */       sb.append('\'');
/* 167:221 */       sb.append(introspectedTable.getSelectByExampleQueryId());
/* 168:222 */       sb.append("' as QUERYID");
/* 169:223 */       comma = true;
/* 170:    */     }
/* 171:226 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/* 172:227 */     while (iter.hasNext())
/* 173:    */     {
/* 174:228 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 175:230 */       if (comma) {
/* 176:231 */         sb.append(", ");
/* 177:    */       } else {
/* 178:233 */         comma = true;
/* 179:    */       }
/* 180:236 */       sb.append(cd.getSelectListPhrase());
/* 181:    */     }
/* 182:238 */     answer.addElement(new TextElement(sb.toString()));
/* 183:    */     
/* 184:240 */     sb.setLength(0);
/* 185:241 */     sb.append("from ");
/* 186:242 */     sb.append(table.getAliasedFullyQualifiedTableName());
/* 187:243 */     answer.addElement(new TextElement(sb.toString()));
/* 188:    */     
/* 189:245 */     XmlElement isParameterPresenteElement = 
/* 190:246 */       new XmlElement("isParameterPresent");
/* 191:247 */     answer.addElement(isParameterPresenteElement);
/* 192:    */     
/* 193:249 */     XmlElement includeElement = new XmlElement("include");
/* 194:250 */     includeElement.addAttribute(new Attribute("refid", 
/* 195:251 */       getSqlMapNamespace(table) + 
/* 196:252 */       "." + getExampleWhereClauseId()));
/* 197:253 */     isParameterPresenteElement.addElement(includeElement);
/* 198:    */     
/* 199:255 */     XmlElement isPropAvail = new XmlElement("isPropertyAvailable");
/* 200:256 */     isPropAvail.addAttribute(new Attribute("property", "orderByClause"));
/* 201:257 */     isPropAvail.addElement(new TextElement("order by $orderByClause$"));
/* 202:258 */     isParameterPresenteElement.addElement(isPropAvail);
/* 203:    */     
/* 204:260 */     XmlElement paginationElement = new XmlElement("include");
/* 205:261 */     paginationElement.addAttribute(new Attribute("refid", 
/* 206:262 */       getPaginationClauseEndId()));
/* 207:263 */     isParameterPresenteElement.addElement(paginationElement);
/* 208:    */     
/* 209:265 */     return answer;
/* 210:    */   }
/* 211:    */   
/* 212:    */   protected XmlElement getSelectByExampleWithBLOBs(IntrospectedTable introspectedTable)
/* 213:    */   {
/* 214:277 */     XmlElement answer = new XmlElement("select");
/* 215:    */     
/* 216:279 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 217:280 */     answer.addAttribute(new Attribute("id", getSelectByExampleWithBLOBsStatementId()));
/* 218:281 */     answer.addAttribute(new Attribute("resultMap", 
/* 219:282 */       getResultMapName(table) + "WithBLOBs"));
/* 220:283 */     answer.addAttribute(new Attribute("parameterClass", "java.util.Map"));
/* 221:    */     
/* 222:285 */     answer.addComment();
/* 223:    */     
/* 224:287 */     StringBuffer sb = new StringBuffer();
/* 225:288 */     if (getPaginationClauseStartId().length() > 0)
/* 226:    */     {
/* 227:289 */       answer.addElement(new TextElement("select "));
/* 228:290 */       XmlElement paginationElement = new XmlElement("include");
/* 229:291 */       paginationElement.addAttribute(new Attribute("refid", 
/* 230:292 */         getPaginationClauseStartId()));
/* 231:293 */       answer.addElement(paginationElement);
/* 232:    */     }
/* 233:    */     else
/* 234:    */     {
/* 235:296 */       sb.append("select ");
/* 236:    */     }
/* 237:299 */     boolean comma = false;
/* 238:300 */     if (StringUtility.stringHasValue(introspectedTable.getSelectByExampleQueryId()))
/* 239:    */     {
/* 240:301 */       sb.append('\'');
/* 241:302 */       sb.append(introspectedTable.getSelectByExampleQueryId());
/* 242:303 */       sb.append("' as QUERYID");
/* 243:304 */       comma = true;
/* 244:    */     }
/* 245:307 */     Iterator iter = introspectedTable.getAllColumns();
/* 246:308 */     while (iter.hasNext())
/* 247:    */     {
/* 248:309 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 249:311 */       if (comma) {
/* 250:312 */         sb.append(", ");
/* 251:    */       } else {
/* 252:314 */         comma = true;
/* 253:    */       }
/* 254:317 */       sb.append(cd.getSelectListPhrase());
/* 255:    */     }
/* 256:319 */     answer.addElement(new TextElement(sb.toString()));
/* 257:    */     
/* 258:321 */     sb.setLength(0);
/* 259:322 */     sb.append("from ");
/* 260:323 */     sb.append(table.getAliasedFullyQualifiedTableName());
/* 261:324 */     answer.addElement(new TextElement(sb.toString()));
/* 262:    */     
/* 263:326 */     XmlElement isParameterPresenteElement = 
/* 264:327 */       new XmlElement("isParameterPresent");
/* 265:328 */     answer.addElement(isParameterPresenteElement);
/* 266:    */     
/* 267:330 */     XmlElement includeElement = new XmlElement("include");
/* 268:331 */     includeElement.addAttribute(new Attribute("refid", 
/* 269:332 */       getSqlMapNamespace(table) + 
/* 270:333 */       "." + getExampleWhereClauseId()));
/* 271:334 */     isParameterPresenteElement.addElement(includeElement);
/* 272:    */     
/* 273:336 */     XmlElement isPropAvail = new XmlElement("isPropertyAvailable");
/* 274:337 */     isPropAvail.addAttribute(new Attribute("property", "orderByClause"));
/* 275:338 */     isPropAvail.addElement(new TextElement("order by $orderByClause$"));
/* 276:339 */     isParameterPresenteElement.addElement(isPropAvail);
/* 277:    */     
/* 278:341 */     XmlElement paginationElement = new XmlElement("include");
/* 279:342 */     paginationElement.addAttribute(new Attribute("refid", 
/* 280:343 */       getPaginationClauseEndId()));
/* 281:344 */     isParameterPresenteElement.addElement(paginationElement);
/* 282:    */     
/* 283:346 */     return answer;
/* 284:    */   }
/* 285:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorLegacyImpl
 * JD-Core Version:    0.7.0.1
 */