/*    1:     */ package org.apache.ibatis.abator.internal.sqlmap;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.HashMap;
/*    5:     */ import java.util.Iterator;
/*    6:     */ import java.util.List;
/*    7:     */ import java.util.Map;
/*    8:     */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*    9:     */ import org.apache.ibatis.abator.api.GeneratedXmlFile;
/*   10:     */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   11:     */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   12:     */ import org.apache.ibatis.abator.api.ProgressCallback;
/*   13:     */ import org.apache.ibatis.abator.api.SqlMapGenerator;
/*   14:     */ import org.apache.ibatis.abator.api.dom.OutputUtilities;
/*   15:     */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   16:     */ import org.apache.ibatis.abator.api.dom.xml.Attribute;
/*   17:     */ import org.apache.ibatis.abator.api.dom.xml.Document;
/*   18:     */ import org.apache.ibatis.abator.api.dom.xml.TextElement;
/*   19:     */ import org.apache.ibatis.abator.api.dom.xml.XmlElement;
/*   20:     */ import org.apache.ibatis.abator.config.GeneratedKey;
/*   21:     */ import org.apache.ibatis.abator.config.TableConfiguration;
/*   22:     */ import org.apache.ibatis.abator.internal.db.ColumnDefinition;
/*   23:     */ import org.apache.ibatis.abator.internal.db.DatabaseDialects;
/*   24:     */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   25:     */ import org.apache.ibatis.abator.internal.types.ResolvedJavaType;
/*   26:     */ import org.apache.ibatis.abator.internal.util.StringUtility;
/*   27:     */ import org.apache.ibatis.abator.internal.util.messages.Messages;
/*   28:     */ 
/*   29:     */ public class SqlMapGeneratorIterateImpl
/*   30:     */   implements SqlMapGenerator
/*   31:     */ {
/*   32:     */   protected List warnings;
/*   33:     */   protected Map properties;
/*   34:     */   protected String targetPackage;
/*   35:     */   protected String targetProject;
/*   36:     */   protected JavaModelGenerator javaModelGenerator;
/*   37:     */   private Map tableStringMaps;
/*   38:  79 */   private int databaseDialect = 0;
/*   39:     */   
/*   40:     */   public SqlMapGeneratorIterateImpl()
/*   41:     */   {
/*   42:  86 */     this.tableStringMaps = new HashMap();
/*   43:  87 */     this.properties = new HashMap();
/*   44:     */   }
/*   45:     */   
/*   46:     */   public int getDatabaseDialect()
/*   47:     */   {
/*   48:  91 */     return this.databaseDialect;
/*   49:     */   }
/*   50:     */   
/*   51:     */   private Map getTableStringMap(FullyQualifiedTable table)
/*   52:     */   {
/*   53:  95 */     Map map = (Map)this.tableStringMaps.get(table);
/*   54:  96 */     if (map == null)
/*   55:     */     {
/*   56:  97 */       map = new HashMap();
/*   57:  98 */       this.tableStringMaps.put(table, map);
/*   58:     */     }
/*   59: 101 */     return map;
/*   60:     */   }
/*   61:     */   
/*   62:     */   public void addConfigurationProperties(Map properties)
/*   63:     */   {
/*   64: 105 */     this.properties.putAll(properties);
/*   65: 106 */     initDatabaseDialect();
/*   66:     */   }
/*   67:     */   
/*   68:     */   public void addContextProperties(Map properties)
/*   69:     */   {
/*   70: 110 */     this.properties.putAll(properties);
/*   71: 111 */     initDatabaseDialect();
/*   72:     */   }
/*   73:     */   
/*   74:     */   private void initDatabaseDialect()
/*   75:     */   {
/*   76: 115 */     String vendor = (String)this.properties.get("databaseVendor");
/*   77: 116 */     if ("mysql".equalsIgnoreCase(vendor)) {
/*   78: 117 */       this.databaseDialect = DatabaseDialects.MYSQL.intValue();
/*   79: 119 */     } else if ("oracle".equalsIgnoreCase(vendor)) {
/*   80: 120 */       this.databaseDialect = DatabaseDialects.ORACLE.intValue();
/*   81: 122 */     } else if ("DB2".equalsIgnoreCase(vendor)) {
/*   82: 123 */       this.databaseDialect = DatabaseDialects.DB2.intValue();
/*   83: 125 */     } else if ("SQLSERVER".equalsIgnoreCase(vendor)) {
/*   84: 126 */       this.databaseDialect = DatabaseDialects.SQLSERVER.intValue();
/*   85: 128 */     } else if ("CLOUDSCAPE".equalsIgnoreCase(vendor)) {
/*   86: 129 */       this.databaseDialect = DatabaseDialects.CLOUDSCAPE.intValue();
/*   87: 131 */     } else if ("DERBY".equalsIgnoreCase(vendor)) {
/*   88: 132 */       this.databaseDialect = DatabaseDialects.DERBY.intValue();
/*   89: 134 */     } else if ("HSQLDB".equalsIgnoreCase(vendor)) {
/*   90: 135 */       this.databaseDialect = DatabaseDialects.HSQLDB.intValue();
/*   91:     */     }
/*   92:     */   }
/*   93:     */   
/*   94:     */   public void setTargetPackage(String targetPackage)
/*   95:     */   {
/*   96: 144 */     this.targetPackage = targetPackage;
/*   97:     */   }
/*   98:     */   
/*   99:     */   public void setJavaModelGenerator(JavaModelGenerator javaModelGenerator)
/*  100:     */   {
/*  101: 153 */     this.javaModelGenerator = javaModelGenerator;
/*  102:     */   }
/*  103:     */   
/*  104:     */   public List getGeneratedXMLFiles(IntrospectedTable introspectedTable, ProgressCallback callback)
/*  105:     */   {
/*  106: 162 */     ArrayList list = new ArrayList();
/*  107:     */     
/*  108: 164 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  109: 165 */     callback.startSubTask(Messages.getString(
/*  110: 166 */       "Progress.12", 
/*  111: 167 */       table.getFullyQualifiedTableName()));
/*  112: 168 */     list.add(getSqlMap(introspectedTable));
/*  113:     */     
/*  114: 170 */     return list;
/*  115:     */   }
/*  116:     */   
/*  117:     */   protected GeneratedXmlFile getSqlMap(IntrospectedTable introspectedTable)
/*  118:     */   {
/*  119: 181 */     Document document = new Document("-//ibatis.apache.org//DTD SQL Map 2.0//EN", 
/*  120: 182 */       "http://ibatis.apache.org/dtd/sql-map-2.dtd");
/*  121: 183 */     document.setRootElement(getSqlMapElement(introspectedTable));
/*  122:     */     
/*  123: 185 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  124: 186 */     GeneratedXmlFile answer = new GeneratedXmlFile(document, 
/*  125: 187 */       getSqlMapFileName(table), getSqlMapPackage(table), 
/*  126: 188 */       this.targetProject);
/*  127:     */     
/*  128: 190 */     return answer;
/*  129:     */   }
/*  130:     */   
/*  131:     */   public XmlElement getAbatorTableConfigure(IntrospectedTable introspectedTable, TableConfiguration tc)
/*  132:     */   {
/*  133: 194 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  134: 195 */     XmlElement answer = new XmlElement("table");
/*  135: 196 */     if (StringUtility.stringHasValue(table.getCatalog())) {
/*  136: 197 */       answer.addAttribute(new Attribute("catalog", table.getCatalog()));
/*  137:     */     }
/*  138: 198 */     if (StringUtility.stringHasValue(table.getSchema())) {
/*  139: 199 */       answer.addAttribute(new Attribute("schema", table.getSchema()));
/*  140:     */     }
/*  141: 200 */     answer.addAttribute(new Attribute("tableName", table.getTableName()));
/*  142: 201 */     if (StringUtility.stringHasValue(table.getAlias())) {
/*  143: 202 */       answer.addAttribute(new Attribute("alias", table.getAlias()));
/*  144:     */     }
/*  145: 203 */     answer.addAttribute(new Attribute("domainObjectName", table.getDomainObjectName()));
/*  146: 204 */     answer.addAttribute(new Attribute("label", table.getLabel()));
/*  147: 206 */     if (tc.getGeneratedKey() != null) {
/*  148: 207 */       answer.addElement(tc.getGeneratedKey().toXml());
/*  149:     */     }
/*  150: 209 */     tc.addIgnoredColumns2TableConfigureXml(answer);
/*  151:     */     
/*  152: 211 */     Iterator iter = introspectedTable.getAllColumns();
/*  153: 212 */     while (iter.hasNext())
/*  154:     */     {
/*  155: 213 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  156:     */       
/*  157: 215 */       XmlElement element = new XmlElement("columnOverride");
/*  158: 216 */       element.addAttribute(new Attribute("column", cd.getColumnName()));
/*  159: 217 */       element.addAttribute(new Attribute("property", cd.getJavaProperty()));
/*  160: 218 */       element.addAttribute(new Attribute("javaType", cd.getResolvedJavaType().getFullyQualifiedJavaType().getFullyQualifiedName()));
/*  161:     */       
/*  162: 220 */       element.addAttribute(new Attribute("listable", Boolean.toString(cd.isListable())));
/*  163: 221 */       element.addAttribute(new Attribute("queryable", Boolean.toString(cd.isQueryable())));
/*  164: 222 */       element.addAttribute(new Attribute("mainFk", Boolean.toString(cd.isMainFk())));
/*  165: 223 */       element.addAttribute(new Attribute("label", cd.getLabel()));
/*  166: 224 */       element.addAttribute(new Attribute("htmlEditor", cd.getHtmlEditor()));
/*  167: 225 */       element.addAttribute(new Attribute("validator", cd.getValidator()));
/*  168: 226 */       if (StringUtility.stringHasValue(cd.getDefaultValue())) {
/*  169: 227 */         element.addAttribute(new Attribute("optionValue", cd.getOptionValue()));
/*  170:     */       } else {
/*  171: 229 */         element.addAttribute(new Attribute("optionValue", ""));
/*  172:     */       }
/*  173: 230 */       if (StringUtility.stringHasValue(cd.getDefaultValue())) {
/*  174: 231 */         element.addAttribute(new Attribute("defaultValue", cd.getDefaultValue()));
/*  175:     */       } else {
/*  176: 233 */         element.addAttribute(new Attribute("defaultValue", ""));
/*  177:     */       }
/*  178: 234 */       if (StringUtility.stringHasValue(cd.getTypeHandler())) {
/*  179: 235 */         element.addAttribute(new Attribute("typeHandler", cd.getTypeHandler()));
/*  180:     */       }
/*  181: 236 */       if (StringUtility.stringHasValue(cd.getMemo())) {
/*  182: 237 */         element.addAttribute(new Attribute("memo", cd.getMemo().trim().replace('\n', ' ').replace('\r', ' ').replace('"', '\'')));
/*  183:     */       } else {
/*  184: 239 */         element.addAttribute(new Attribute("memo", ""));
/*  185:     */       }
/*  186: 240 */       answer.addElement(element);
/*  187:     */     }
/*  188: 242 */     return answer;
/*  189:     */   }
/*  190:     */   
/*  191:     */   protected XmlElement getSqlMapElement(IntrospectedTable introspectedTable)
/*  192:     */   {
/*  193: 253 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  194: 254 */     XmlElement answer = new XmlElement("sqlMap");
/*  195: 255 */     answer.addAttribute(new Attribute("namespace", 
/*  196: 256 */       getSqlMapNamespace(table)));
/*  197: 259 */     if (introspectedTable.getRules().generateBaseResultMap())
/*  198:     */     {
/*  199: 260 */       XmlElement element = getBaseResultMapElement(introspectedTable);
/*  200: 261 */       if (element != null) {
/*  201: 262 */         answer.addElement(element);
/*  202:     */       }
/*  203:     */     }
/*  204: 266 */     if (introspectedTable.getRules().generateResultMapWithBLOBs())
/*  205:     */     {
/*  206: 267 */       XmlElement element = getResultMapWithBLOBsElement(introspectedTable);
/*  207: 268 */       if (element != null) {
/*  208: 269 */         answer.addElement(element);
/*  209:     */       }
/*  210:     */     }
/*  211: 273 */     if (introspectedTable.hasParentIdColumn())
/*  212:     */     {
/*  213: 274 */       XmlElement element = getResultMapWithParentElement(introspectedTable);
/*  214: 275 */       if (element != null) {
/*  215: 276 */         answer.addElement(element);
/*  216:     */       }
/*  217:     */     }
/*  218: 280 */     if (introspectedTable.getRules().generateSQLExampleWhereClause())
/*  219:     */     {
/*  220: 281 */       XmlElement element = getByExampleWhereClauseFragment(introspectedTable);
/*  221: 282 */       if (element != null) {
/*  222: 283 */         answer.addElement(element);
/*  223:     */       }
/*  224:     */     }
/*  225: 287 */     if (introspectedTable.getRules().generateSelectByPrimaryKey())
/*  226:     */     {
/*  227: 288 */       XmlElement element = getSelectByPrimaryKey(introspectedTable);
/*  228: 289 */       if (element != null) {
/*  229: 290 */         answer.addElement(element);
/*  230:     */       }
/*  231:     */     }
/*  232: 294 */     if (introspectedTable.getRules().generateSelectByExampleWithoutBLOBs())
/*  233:     */     {
/*  234: 295 */       XmlElement element = getSelectByExample(introspectedTable);
/*  235: 296 */       if (element != null) {
/*  236: 297 */         answer.addElement(element);
/*  237:     */       }
/*  238:     */     }
/*  239: 301 */     if (introspectedTable.getRules().generateSelectByExampleWithBLOBs())
/*  240:     */     {
/*  241: 302 */       XmlElement element = getSelectByExampleWithBLOBs(introspectedTable);
/*  242: 303 */       if (element != null) {
/*  243: 304 */         answer.addElement(element);
/*  244:     */       }
/*  245:     */     }
/*  246: 308 */     if ((introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) || 
/*  247: 309 */       (introspectedTable.getRules().generateSelectByExampleWithBLOBs()))
/*  248:     */     {
/*  249: 310 */       XmlElement element = getSelectCountByExample(introspectedTable);
/*  250: 311 */       if (element != null) {
/*  251: 312 */         answer.addElement(element);
/*  252:     */       }
/*  253:     */     }
/*  254: 316 */     if (introspectedTable.getRules().generateDeleteByPrimaryKey())
/*  255:     */     {
/*  256: 317 */       XmlElement element = getDeleteByPrimaryKey(introspectedTable);
/*  257: 318 */       if (element != null) {
/*  258: 319 */         answer.addElement(element);
/*  259:     */       }
/*  260:     */     }
/*  261: 323 */     if (introspectedTable.getRules().generateDeleteByExample())
/*  262:     */     {
/*  263: 324 */       XmlElement element = getDeleteByExample(introspectedTable);
/*  264: 325 */       if (element != null) {
/*  265: 326 */         answer.addElement(element);
/*  266:     */       }
/*  267:     */     }
/*  268: 330 */     if (introspectedTable.getRules().generateInsert())
/*  269:     */     {
/*  270: 331 */       XmlElement element = getInsertElement(introspectedTable);
/*  271: 332 */       if (element != null) {
/*  272: 333 */         answer.addElement(element);
/*  273:     */       }
/*  274:     */     }
/*  275: 337 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs())
/*  276:     */     {
/*  277: 338 */       XmlElement element = getUpdateByPrimaryKeyWithBLOBs(introspectedTable);
/*  278: 339 */       if (element != null) {
/*  279: 340 */         answer.addElement(element);
/*  280:     */       }
/*  281:     */     }
/*  282: 344 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs())
/*  283:     */     {
/*  284: 345 */       XmlElement element = getUpdateByPrimaryKeyWithoutBLOBs(introspectedTable);
/*  285: 346 */       if (element != null) {
/*  286: 347 */         answer.addElement(element);
/*  287:     */       }
/*  288:     */     }
/*  289: 351 */     if (introspectedTable.getRules().generateUpdateByPrimaryKeySelective())
/*  290:     */     {
/*  291: 352 */       XmlElement element = getUpdateByPrimaryKeySelective(introspectedTable);
/*  292: 353 */       if (element != null) {
/*  293: 354 */         answer.addElement(element);
/*  294:     */       }
/*  295:     */     }
/*  296: 358 */     return answer;
/*  297:     */   }
/*  298:     */   
/*  299:     */   protected XmlElement getBaseResultMapElement(IntrospectedTable introspectedTable)
/*  300:     */   {
/*  301: 369 */     XmlElement answer = new XmlElement("resultMap");
/*  302: 370 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  303: 371 */     answer.addAttribute(new Attribute("id", 
/*  304: 372 */       getResultMapName(table)));
/*  305:     */     FullyQualifiedJavaType returnType;
/*  306:     */     FullyQualifiedJavaType returnType;
/*  307: 375 */     if (introspectedTable.getRules().generateBaseRecordClass()) {
/*  308: 376 */       returnType = this.javaModelGenerator.getBaseRecordType(table);
/*  309:     */     } else {
/*  310: 378 */       returnType = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/*  311:     */     }
/*  312: 381 */     answer.addAttribute(new Attribute("class", 
/*  313: 382 */       returnType.getFullyQualifiedName()));
/*  314:     */     
/*  315: 384 */     answer.addComment();
/*  316:     */     
/*  317: 386 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/*  318: 387 */     while (iter.hasNext())
/*  319:     */     {
/*  320: 388 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  321:     */       
/*  322: 390 */       XmlElement resultElement = new XmlElement("result");
/*  323:     */       
/*  324: 392 */       resultElement.addAttribute(new Attribute(
/*  325: 393 */         "column", cd.getRenamedColumnName()));
/*  326: 394 */       resultElement.addAttribute(new Attribute(
/*  327: 395 */         "property", cd.getJavaProperty()));
/*  328: 396 */       resultElement.addAttribute(new Attribute("jdbcType", 
/*  329: 397 */         cd.getResolvedJavaType().getJdbcTypeName()));
/*  330: 399 */       if (StringUtility.stringHasValue(cd.getTypeHandler())) {
/*  331: 400 */         resultElement.addAttribute(new Attribute(
/*  332: 401 */           "typeHandler", cd.getTypeHandler()));
/*  333:     */       }
/*  334: 404 */       answer.addElement(resultElement);
/*  335:     */     }
/*  336: 407 */     return answer;
/*  337:     */   }
/*  338:     */   
/*  339:     */   protected XmlElement getResultMapWithBLOBsElement(IntrospectedTable introspectedTable)
/*  340:     */   {
/*  341: 420 */     XmlElement answer = new XmlElement("resultMap");
/*  342: 421 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  343:     */     
/*  344: 423 */     StringBuffer sb = new StringBuffer();
/*  345: 424 */     sb.append(getResultMapName(table));
/*  346: 425 */     sb.append("WithBLOBs");
/*  347:     */     
/*  348: 427 */     answer.addAttribute(new Attribute("id", sb.toString()));
/*  349:     */     FullyQualifiedJavaType returnType;
/*  350:     */     FullyQualifiedJavaType returnType;
/*  351: 430 */     if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  352: 431 */       returnType = this.javaModelGenerator.getRecordWithBLOBsType(table);
/*  353:     */     } else {
/*  354: 435 */       returnType = this.javaModelGenerator.getBaseRecordType(table);
/*  355:     */     }
/*  356: 438 */     answer.addAttribute(new Attribute("class", 
/*  357: 439 */       returnType.getFullyQualifiedName()));
/*  358:     */     
/*  359: 441 */     sb.setLength(0);
/*  360: 442 */     sb.append(getSqlMapNamespace(table));
/*  361: 443 */     sb.append('.');
/*  362: 444 */     sb.append(getResultMapName(table));
/*  363: 445 */     answer.addAttribute(new Attribute("extends", sb.toString()));
/*  364:     */     
/*  365: 447 */     answer.addComment();
/*  366:     */     
/*  367: 449 */     Iterator iter = introspectedTable.getBLOBColumns();
/*  368: 450 */     while (iter.hasNext())
/*  369:     */     {
/*  370: 451 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  371:     */       
/*  372: 453 */       XmlElement resultElement = new XmlElement("result");
/*  373:     */       
/*  374: 455 */       resultElement.addAttribute(new Attribute(
/*  375: 456 */         "column", cd.getRenamedColumnName()));
/*  376: 457 */       resultElement.addAttribute(new Attribute(
/*  377: 458 */         "property", cd.getJavaProperty()));
/*  378: 459 */       resultElement.addAttribute(new Attribute(
/*  379: 460 */         "jdbcType", cd.getResolvedJavaType().getJdbcTypeName()));
/*  380: 462 */       if (StringUtility.stringHasValue(cd.getTypeHandler())) {
/*  381: 463 */         resultElement.addAttribute(new Attribute(
/*  382: 464 */           "typeHandler", cd.getTypeHandler()));
/*  383:     */       }
/*  384: 467 */       answer.addElement(resultElement);
/*  385:     */     }
/*  386: 470 */     return answer;
/*  387:     */   }
/*  388:     */   
/*  389:     */   protected XmlElement getResultMapWithParentElement(IntrospectedTable introspectedTable)
/*  390:     */   {
/*  391: 475 */     XmlElement answer = new XmlElement("resultMap");
/*  392: 476 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  393:     */     
/*  394: 478 */     StringBuffer sb = new StringBuffer();
/*  395: 479 */     sb.append(getResultMapName(table));
/*  396: 480 */     sb.append("WithParent");
/*  397:     */     
/*  398: 482 */     answer.addAttribute(new Attribute("id", sb.toString()));
/*  399:     */     
/*  400:     */ 
/*  401: 485 */     FullyQualifiedJavaType returnType = this.javaModelGenerator.getBaseRecordType(table);
/*  402:     */     
/*  403: 487 */     answer.addAttribute(new Attribute("class", returnType.getFullyQualifiedName()));
/*  404:     */     
/*  405: 489 */     sb.setLength(0);
/*  406: 490 */     sb.append(getSqlMapNamespace(table));
/*  407: 491 */     sb.append('.');
/*  408: 492 */     sb.append(getResultMapName(table));
/*  409: 493 */     answer.addAttribute(new Attribute("extends", sb.toString()));
/*  410:     */     
/*  411: 495 */     answer.addComment();
/*  412: 496 */     String parentObjName = "parent" + table.getDomainObjectName() + ".";
/*  413:     */     
/*  414: 498 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/*  415: 499 */     while (iter.hasNext())
/*  416:     */     {
/*  417: 500 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  418: 501 */       String p = cd.getJavaProperty().toLowerCase();
/*  419: 502 */       if (((p.indexOf("name") >= 0) || (p.indexOf("code") >= 0) || (p.indexOf("account") >= 0) || 
/*  420: 503 */         (p.indexOf("url") >= 0)) && (p.indexOf("parentid") <= -1))
/*  421:     */       {
/*  422: 507 */         XmlElement resultElement = new XmlElement("result");
/*  423:     */         
/*  424: 509 */         resultElement.addAttribute(new Attribute(
/*  425: 510 */           "column", "PARENT_" + cd.getRenamedColumnName()));
/*  426: 511 */         resultElement.addAttribute(new Attribute(
/*  427: 512 */           "property", parentObjName + cd.getJavaProperty()));
/*  428: 513 */         resultElement.addAttribute(new Attribute(
/*  429: 514 */           "jdbcType", cd.getResolvedJavaType().getJdbcTypeName()));
/*  430: 516 */         if (StringUtility.stringHasValue(cd.getTypeHandler())) {
/*  431: 517 */           resultElement.addAttribute(new Attribute(
/*  432: 518 */             "typeHandler", cd.getTypeHandler()));
/*  433:     */         }
/*  434: 521 */         answer.addElement(resultElement);
/*  435:     */       }
/*  436:     */     }
/*  437: 524 */     return answer;
/*  438:     */   }
/*  439:     */   
/*  440:     */   protected XmlElement getInsertElement(IntrospectedTable introspectedTable)
/*  441:     */   {
/*  442: 535 */     XmlElement answer = new XmlElement("insert");
/*  443:     */     
/*  444: 537 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  445: 538 */     answer.addAttribute(new Attribute("id", getInsertStatementId()));
/*  446:     */     
/*  447: 540 */     FullyQualifiedJavaType parameterType = 
/*  448: 541 */       introspectedTable.getRules().calculateAllFieldsClass(this.javaModelGenerator, introspectedTable);
/*  449:     */     
/*  450: 543 */     answer.addAttribute(new Attribute("parameterClass", 
/*  451: 544 */       parameterType.getFullyQualifiedName()));
/*  452:     */     
/*  453: 546 */     answer.addComment();
/*  454:     */     
/*  455: 548 */     GeneratedKey gk = introspectedTable.getGeneratedKey();
/*  456: 550 */     if ((gk != null) && ((!gk.isIdentity()) || (!gk.isPost())))
/*  457:     */     {
/*  458: 551 */       ColumnDefinition cd = introspectedTable.getColumn(gk.getColumn());
/*  459: 554 */       if (cd != null) {
/*  460: 556 */         answer.addElement(getSelectKey(cd, gk));
/*  461:     */       }
/*  462:     */     }
/*  463: 560 */     StringBuffer insertClause = new StringBuffer();
/*  464: 561 */     StringBuffer valuesClause = new StringBuffer();
/*  465: 562 */     StringBuffer insertIdClause = new StringBuffer();
/*  466:     */     
/*  467: 564 */     insertClause.append("insert into ");
/*  468: 565 */     insertClause.append(table.getFullyQualifiedTableName());
/*  469: 566 */     insertClause.append(" (");
/*  470:     */     
/*  471: 568 */     valuesClause.append("values (");
/*  472:     */     
/*  473: 570 */     ColumnDefinition identityColumn = null;
/*  474: 571 */     boolean comma = false;
/*  475: 572 */     Iterator iter = introspectedTable.getAllColumns();
/*  476: 573 */     int index = 0;
/*  477: 574 */     while (iter.hasNext())
/*  478:     */     {
/*  479: 575 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  480: 577 */       if (cd.isIdentity())
/*  481:     */       {
/*  482: 578 */         identityColumn = cd;
/*  483:     */       }
/*  484:     */       else
/*  485:     */       {
/*  486: 583 */         if (comma)
/*  487:     */         {
/*  488: 584 */           insertClause.append(", ");
/*  489: 585 */           valuesClause.append(", ");
/*  490:     */         }
/*  491:     */         else
/*  492:     */         {
/*  493: 587 */           comma = true;
/*  494:     */         }
/*  495: 591 */         if ((index == 0) && (cd.getColumnName().equals("id"))) {
/*  496: 592 */           insertIdClause.append("<selectKey   resultClass=\"int\"   keyProperty=\"id\" >SELECT LAST_INSERT_ID() as id  </selectKey>");
/*  497:     */         }
/*  498: 595 */         insertClause.append(cd.getColumnName());
/*  499: 596 */         valuesClause.append(cd.getIbatisFormattedParameterClause());
/*  500: 597 */         index++;
/*  501:     */       }
/*  502:     */     }
/*  503: 599 */     insertClause.append(')');
/*  504: 600 */     valuesClause.append(')');
/*  505:     */     
/*  506:     */ 
/*  507: 603 */     answer.addElement(new TextElement(insertClause.toString()));
/*  508: 604 */     answer.addElement(new TextElement(valuesClause.toString()));
/*  509: 605 */     answer.addElement(new TextElement(insertIdClause.toString()));
/*  510: 607 */     if ((gk != null) && (identityColumn != null)) {
/*  511: 608 */       answer.addElement(getSelectKey(identityColumn, gk));
/*  512:     */     }
/*  513: 611 */     return answer;
/*  514:     */   }
/*  515:     */   
/*  516:     */   protected XmlElement getUpdateByPrimaryKeyWithBLOBs(IntrospectedTable introspectedTable)
/*  517:     */   {
/*  518: 623 */     XmlElement answer = new XmlElement("update");
/*  519: 624 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  520:     */     
/*  521: 626 */     answer.addAttribute(new Attribute(
/*  522: 627 */       "id", getUpdateByPrimaryKeyWithBLOBsStatementId()));
/*  523:     */     FullyQualifiedJavaType parameterType;
/*  524:     */     FullyQualifiedJavaType parameterType;
/*  525: 631 */     if (introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  526: 632 */       parameterType = this.javaModelGenerator.getRecordWithBLOBsType(table);
/*  527:     */     } else {
/*  528: 634 */       parameterType = this.javaModelGenerator.getBaseRecordType(table);
/*  529:     */     }
/*  530: 637 */     answer.addAttribute(new Attribute("parameterClass", 
/*  531: 638 */       parameterType.getFullyQualifiedName()));
/*  532:     */     
/*  533: 640 */     answer.addComment();
/*  534:     */     
/*  535: 642 */     StringBuffer sb = new StringBuffer();
/*  536:     */     
/*  537: 644 */     sb.append("update ");
/*  538: 645 */     sb.append(table.getFullyQualifiedTableName());
/*  539: 646 */     answer.addElement(new TextElement(sb.toString()));
/*  540:     */     
/*  541:     */ 
/*  542: 649 */     sb.setLength(0);
/*  543: 650 */     sb.append("set ");
/*  544:     */     
/*  545: 652 */     Iterator iter = introspectedTable.getNonPrimaryKeyColumns();
/*  546: 653 */     while (iter.hasNext())
/*  547:     */     {
/*  548: 654 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  549:     */       
/*  550: 656 */       sb.append(cd.getColumnName());
/*  551: 657 */       sb.append(" = ");
/*  552: 658 */       sb.append(cd.getIbatisFormattedParameterClause());
/*  553: 660 */       if (iter.hasNext()) {
/*  554: 661 */         sb.append(',');
/*  555:     */       }
/*  556: 664 */       answer.addElement(new TextElement(sb.toString()));
/*  557: 667 */       if (iter.hasNext())
/*  558:     */       {
/*  559: 668 */         sb.setLength(0);
/*  560: 669 */         OutputUtilities.xmlIndent(sb, 1);
/*  561:     */       }
/*  562:     */     }
/*  563: 673 */     boolean and = false;
/*  564: 674 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  565: 675 */     while (iter.hasNext())
/*  566:     */     {
/*  567: 676 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  568:     */       
/*  569: 678 */       sb.setLength(0);
/*  570: 679 */       if (and)
/*  571:     */       {
/*  572: 680 */         sb.append("  and ");
/*  573:     */       }
/*  574:     */       else
/*  575:     */       {
/*  576: 682 */         sb.append("where ");
/*  577: 683 */         and = true;
/*  578:     */       }
/*  579: 686 */       sb.append(cd.getColumnName());
/*  580: 687 */       sb.append(" = #");
/*  581: 688 */       sb.append(cd.getJavaProperty());
/*  582: 689 */       sb.append('#');
/*  583: 690 */       answer.addElement(new TextElement(sb.toString()));
/*  584:     */     }
/*  585: 693 */     return answer;
/*  586:     */   }
/*  587:     */   
/*  588:     */   protected XmlElement getUpdateByPrimaryKeyWithoutBLOBs(IntrospectedTable introspectedTable)
/*  589:     */   {
/*  590: 705 */     XmlElement answer = new XmlElement("update");
/*  591: 706 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  592:     */     
/*  593: 708 */     answer.addAttribute(new Attribute(
/*  594: 709 */       "id", getUpdateByPrimaryKeyStatementId()));
/*  595: 710 */     answer.addAttribute(new Attribute("parameterClass", 
/*  596: 711 */       this.javaModelGenerator.getBaseRecordType(table).getFullyQualifiedName()));
/*  597:     */     
/*  598: 713 */     answer.addComment();
/*  599:     */     
/*  600: 715 */     StringBuffer sb = new StringBuffer();
/*  601: 716 */     sb.append("update ");
/*  602: 717 */     sb.append(table.getFullyQualifiedTableName());
/*  603: 718 */     answer.addElement(new TextElement(sb.toString()));
/*  604:     */     
/*  605:     */ 
/*  606: 721 */     sb.setLength(0);
/*  607: 722 */     sb.append("set ");
/*  608:     */     
/*  609: 724 */     Iterator iter = introspectedTable.getBaseColumns();
/*  610: 725 */     while (iter.hasNext())
/*  611:     */     {
/*  612: 726 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  613:     */       
/*  614: 728 */       sb.append(cd.getColumnName());
/*  615: 729 */       sb.append(" = ");
/*  616: 730 */       sb.append(cd.getIbatisFormattedParameterClause());
/*  617: 732 */       if (iter.hasNext()) {
/*  618: 733 */         sb.append(',');
/*  619:     */       }
/*  620: 736 */       answer.addElement(new TextElement(sb.toString()));
/*  621: 739 */       if (iter.hasNext())
/*  622:     */       {
/*  623: 740 */         sb.setLength(0);
/*  624: 741 */         OutputUtilities.xmlIndent(sb, 1);
/*  625:     */       }
/*  626:     */     }
/*  627: 745 */     boolean and = false;
/*  628: 746 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  629: 747 */     while (iter.hasNext())
/*  630:     */     {
/*  631: 748 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  632:     */       
/*  633: 750 */       sb.setLength(0);
/*  634: 751 */       if (and)
/*  635:     */       {
/*  636: 752 */         sb.append("  and ");
/*  637:     */       }
/*  638:     */       else
/*  639:     */       {
/*  640: 754 */         sb.append("where ");
/*  641: 755 */         and = true;
/*  642:     */       }
/*  643: 758 */       sb.append(cd.getColumnName());
/*  644: 759 */       sb.append(" = ");
/*  645: 760 */       sb.append(cd.getIbatisFormattedParameterClause());
/*  646: 761 */       answer.addElement(new TextElement(sb.toString()));
/*  647:     */     }
/*  648: 764 */     return answer;
/*  649:     */   }
/*  650:     */   
/*  651:     */   protected XmlElement getDeleteByPrimaryKey(IntrospectedTable introspectedTable)
/*  652:     */   {
/*  653: 776 */     XmlElement answer = new XmlElement("delete");
/*  654: 777 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  655:     */     
/*  656: 779 */     answer.addAttribute(new Attribute(
/*  657: 780 */       "id", getDeleteByPrimaryKeyStatementId()));
/*  658:     */     FullyQualifiedJavaType parameterClass;
/*  659:     */     FullyQualifiedJavaType parameterClass;
/*  660: 782 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/*  661:     */     {
/*  662: 783 */       parameterClass = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/*  663:     */     }
/*  664:     */     else
/*  665:     */     {
/*  666: 786 */       Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  667:     */       FullyQualifiedJavaType parameterClass;
/*  668: 787 */       if (iter.hasNext())
/*  669:     */       {
/*  670: 788 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  671: 789 */         parameterClass = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*  672:     */       }
/*  673:     */       else
/*  674:     */       {
/*  675: 794 */         parameterClass = this.javaModelGenerator.getBaseRecordType(table);
/*  676:     */       }
/*  677:     */     }
/*  678: 797 */     answer.addAttribute(new Attribute("parameterClass", 
/*  679: 798 */       parameterClass.getFullyQualifiedName()));
/*  680:     */     
/*  681: 800 */     answer.addComment();
/*  682:     */     
/*  683: 802 */     StringBuffer sb = new StringBuffer();
/*  684: 803 */     sb.append("delete from ");
/*  685: 804 */     sb.append(table.getFullyQualifiedTableName());
/*  686: 805 */     answer.addElement(new TextElement(sb.toString()));
/*  687:     */     
/*  688: 807 */     boolean and = false;
/*  689: 808 */     Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  690: 809 */     while (iter.hasNext())
/*  691:     */     {
/*  692: 810 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  693:     */       
/*  694: 812 */       sb.setLength(0);
/*  695: 813 */       if (and)
/*  696:     */       {
/*  697: 814 */         sb.append("  and ");
/*  698:     */       }
/*  699:     */       else
/*  700:     */       {
/*  701: 816 */         sb.append(" where ");
/*  702: 817 */         and = true;
/*  703:     */       }
/*  704: 820 */       sb.append(cd.getColumnName());
/*  705: 821 */       sb.append(" = ");
/*  706: 822 */       if (introspectedTable.getRules().getPrimaryKeyColumnSize() == 1) {
/*  707: 823 */         sb.append("#value#");
/*  708:     */       } else {
/*  709: 826 */         sb.append(cd.getIbatisFormattedParameterClause());
/*  710:     */       }
/*  711: 827 */       answer.addElement(new TextElement(sb.toString()));
/*  712:     */     }
/*  713: 830 */     return answer;
/*  714:     */   }
/*  715:     */   
/*  716:     */   protected XmlElement getDeleteByExample(IntrospectedTable introspectedTable)
/*  717:     */   {
/*  718: 842 */     XmlElement answer = new XmlElement("delete");
/*  719:     */     
/*  720: 844 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  721: 845 */     FullyQualifiedJavaType fqjt = this.javaModelGenerator.getExampleType(table);
/*  722:     */     
/*  723: 847 */     answer
/*  724: 848 */       .addAttribute(new Attribute(
/*  725: 849 */       "id", getDeleteByExampleStatementId()));
/*  726: 850 */     answer.addAttribute(new Attribute(
/*  727: 851 */       "parameterClass", fqjt.getFullyQualifiedName()));
/*  728:     */     
/*  729: 853 */     answer.addComment();
/*  730:     */     
/*  731: 855 */     StringBuffer sb = new StringBuffer();
/*  732: 856 */     sb.append("delete from ");
/*  733: 857 */     sb.append(table.getAliasedFullyQualifiedTableName());
/*  734: 858 */     answer.addElement(new TextElement(sb.toString()));
/*  735:     */     
/*  736: 860 */     XmlElement includeElement = new XmlElement("include");
/*  737: 861 */     sb.setLength(0);
/*  738: 862 */     sb.append(getSqlMapNamespace(table));
/*  739: 863 */     sb.append('.');
/*  740: 864 */     sb.append(getExampleWhereClauseId());
/*  741: 865 */     includeElement.addAttribute(new Attribute("refid", 
/*  742: 866 */       sb.toString()));
/*  743:     */     
/*  744: 868 */     answer.addElement(includeElement);
/*  745:     */     
/*  746: 870 */     return answer;
/*  747:     */   }
/*  748:     */   
/*  749:     */   protected XmlElement getSelectByPrimaryKey(IntrospectedTable introspectedTable)
/*  750:     */   {
/*  751: 883 */     XmlElement answer = new XmlElement("select");
/*  752: 884 */     FullyQualifiedTable table = introspectedTable.getTable();
/*  753:     */     
/*  754: 886 */     answer.addAttribute(new Attribute(
/*  755: 887 */       "id", getSelectByPrimaryKeyStatementId()));
/*  756: 888 */     if (introspectedTable.getRules().generateResultMapWithBLOBs()) {
/*  757: 889 */       answer.addAttribute(new Attribute("resultMap", 
/*  758: 890 */         getResultMapName(table) + "WithBLOBs"));
/*  759:     */     } else {
/*  760: 892 */       answer.addAttribute(new Attribute("resultMap", 
/*  761: 893 */         getResultMapName(table)));
/*  762:     */     }
/*  763:     */     FullyQualifiedJavaType parameterType;
/*  764:     */     FullyQualifiedJavaType parameterType;
/*  765: 897 */     if (introspectedTable.getRules().generatePrimaryKeyClass())
/*  766:     */     {
/*  767: 898 */       parameterType = this.javaModelGenerator.getPrimaryKeyType(introspectedTable);
/*  768:     */     }
/*  769:     */     else
/*  770:     */     {
/*  771: 901 */       Iterator iter = introspectedTable.getPrimaryKeyColumns();
/*  772:     */       FullyQualifiedJavaType parameterType;
/*  773: 902 */       if (iter.hasNext())
/*  774:     */       {
/*  775: 903 */         ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  776: 904 */         parameterType = cd.getResolvedJavaType().getFullyQualifiedJavaType();
/*  777:     */       }
/*  778:     */       else
/*  779:     */       {
/*  780: 909 */         parameterType = this.javaModelGenerator.getBaseRecordType(table);
/*  781:     */       }
/*  782:     */     }
/*  783: 913 */     answer.addAttribute(new Attribute("parameterClass", 
/*  784: 914 */       parameterType.getFullyQualifiedName()));
/*  785:     */     
/*  786: 916 */     answer.addComment();
/*  787:     */     
/*  788: 918 */     StringBuffer sb = new StringBuffer();
/*  789: 919 */     sb.append("select ");
/*  790:     */     
/*  791: 921 */     boolean comma = false;
/*  792: 922 */     if (StringUtility.stringHasValue(introspectedTable.getSelectByPrimaryKeyQueryId()))
/*  793:     */     {
/*  794: 923 */       sb.append('\'');
/*  795: 924 */       sb.append(introspectedTable.getSelectByPrimaryKeyQueryId());
/*  796: 925 */       sb.append("' as QUERYID");
/*  797: 926 */       comma = true;
/*  798:     */     }
/*  799: 929 */     Iterator iter = introspectedTable.getAllColumns();
/*  800: 930 */     while (iter.hasNext())
/*  801:     */     {
/*  802: 931 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  803: 932 */       if (comma) {
/*  804: 933 */         sb.append(", ");
/*  805:     */       } else {
/*  806: 935 */         comma = true;
/*  807:     */       }
/*  808: 938 */       sb.append(cd.getSelectListPhrase());
/*  809:     */     }
/*  810: 941 */     answer.addElement(new TextElement(sb.toString()));
/*  811:     */     
/*  812: 943 */     sb.setLength(0);
/*  813: 944 */     sb.append("from ");
/*  814: 945 */     sb.append(table.getAliasedFullyQualifiedTableName());
/*  815: 946 */     answer.addElement(new TextElement(sb.toString()));
/*  816:     */     
/*  817: 948 */     boolean and = false;
/*  818: 949 */     iter = introspectedTable.getPrimaryKeyColumns();
/*  819: 950 */     while (iter.hasNext())
/*  820:     */     {
/*  821: 951 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/*  822:     */       
/*  823: 953 */       sb.setLength(0);
/*  824: 954 */       if (and)
/*  825:     */       {
/*  826: 955 */         sb.append("  and ");
/*  827:     */       }
/*  828:     */       else
/*  829:     */       {
/*  830: 957 */         sb.append("where ");
/*  831: 958 */         and = true;
/*  832:     */       }
/*  833: 961 */       sb.append(cd.getAliasedColumnName());
/*  834: 962 */       sb.append(" = ");
/*  835: 963 */       if (introspectedTable.getRules().getPrimaryKeyColumnSize() == 1) {
/*  836: 964 */         sb.append("#value#");
/*  837:     */       } else {
/*  838: 967 */         sb.append(cd.getIbatisFormattedParameterClause());
/*  839:     */       }
/*  840: 968 */       answer.addElement(new TextElement(sb.toString()));
/*  841:     */     }
/*  842: 971 */     return answer;
/*  843:     */   }
/*  844:     */   
/*  845:     */   protected XmlElement getSelectKey(ColumnDefinition columnDefinition, GeneratedKey generatedKey)
/*  846:     */   {
/*  847: 986 */     String identityColumnType = columnDefinition.getResolvedJavaType()
/*  848: 987 */       .getFullyQualifiedJavaType().getFullyQualifiedName();
/*  849:     */     
/*  850: 989 */     XmlElement answer = new XmlElement("selectKey");
/*  851: 990 */     answer.addAttribute(new Attribute("resultClass", identityColumnType));
/*  852: 991 */     answer.addAttribute(new Attribute(
/*  853: 992 */       "keyProperty", columnDefinition.getJavaProperty()));
/*  854: 993 */     answer.addElement(new TextElement(generatedKey.getSqlStatement()));
/*  855:     */     
/*  856: 995 */     return answer;
/*  857:     */   }
/*  858:     */   
/*  859:     */   public String getSqlMapNamespace(FullyQualifiedTable table)
/*  860:     */   {
/*  861:1004 */     String key = "getSqlMapNamespace";
/*  862:     */     
/*  863:     */ 
/*  864:1007 */     Map map = getTableStringMap(table);
/*  865:1008 */     String s = (String)map.get(key);
/*  866:1009 */     if (s == null)
/*  867:     */     {
/*  868:1010 */       s = table.getFullyQualifiedTableNameWithUnderscores();
/*  869:1011 */       map.put(key, s);
/*  870:     */     }
/*  871:1014 */     return s;
/*  872:     */   }
/*  873:     */   
/*  874:     */   protected String getResultMapName(FullyQualifiedTable table)
/*  875:     */   {
/*  876:1028 */     String key = "getResultMapName";
/*  877:     */     
/*  878:     */ 
/*  879:1031 */     Map map = getTableStringMap(table);
/*  880:1032 */     String s = (String)map.get(key);
/*  881:1033 */     if (s == null)
/*  882:     */     {
/*  883:1034 */       StringBuffer sb = new StringBuffer();
/*  884:     */       
/*  885:     */ 
/*  886:1037 */       sb.append(table.getDomainObjectName());
/*  887:1038 */       sb.append("Result");
/*  888:     */       
/*  889:1040 */       s = sb.toString();
/*  890:1041 */       map.put(key, s);
/*  891:     */     }
/*  892:1044 */     return s;
/*  893:     */   }
/*  894:     */   
/*  895:     */   protected String getSqlMapFileName(FullyQualifiedTable table)
/*  896:     */   {
/*  897:1057 */     String key = "getSqlMapFileName";
/*  898:     */     
/*  899:     */ 
/*  900:1060 */     Map map = getTableStringMap(table);
/*  901:1061 */     String s = (String)map.get(key);
/*  902:1062 */     if (s == null)
/*  903:     */     {
/*  904:1063 */       StringBuffer sb = new StringBuffer();
/*  905:1064 */       sb.append(table.getFullyQualifiedTableNameWithUnderscores());
/*  906:     */       
/*  907:1066 */       sb.append("_SqlMap.xml");
/*  908:     */       
/*  909:1068 */       s = sb.toString();
/*  910:1069 */       map.put(key, s);
/*  911:     */     }
/*  912:1072 */     return s;
/*  913:     */   }
/*  914:     */   
/*  915:     */   public String getDeleteByPrimaryKeyStatementId()
/*  916:     */   {
/*  917:1081 */     return "deleteById";
/*  918:     */   }
/*  919:     */   
/*  920:     */   public String getDeleteByExampleStatementId()
/*  921:     */   {
/*  922:1090 */     return "deleteByMap";
/*  923:     */   }
/*  924:     */   
/*  925:     */   public String getInsertStatementId()
/*  926:     */   {
/*  927:1099 */     return "insert";
/*  928:     */   }
/*  929:     */   
/*  930:     */   public String getSelectByPrimaryKeyStatementId()
/*  931:     */   {
/*  932:1108 */     return "selectById";
/*  933:     */   }
/*  934:     */   
/*  935:     */   public String getSelectCountByExampleStatementId()
/*  936:     */   {
/*  937:1117 */     return "selectByMap_count";
/*  938:     */   }
/*  939:     */   
/*  940:     */   public String getSelectByExampleStatementId()
/*  941:     */   {
/*  942:1126 */     return "selectByMap";
/*  943:     */   }
/*  944:     */   
/*  945:     */   public String getSelectByExampleWithBLOBsStatementId()
/*  946:     */   {
/*  947:1135 */     return "selectByMapWithBLOBs";
/*  948:     */   }
/*  949:     */   
/*  950:     */   public String getUpdateByPrimaryKeyWithBLOBsStatementId()
/*  951:     */   {
/*  952:1144 */     return "updateByIdWithBLOBs";
/*  953:     */   }
/*  954:     */   
/*  955:     */   public String getUpdateByPrimaryKeyStatementId()
/*  956:     */   {
/*  957:1153 */     return "updateById";
/*  958:     */   }
/*  959:     */   
/*  960:     */   public String getUpdateByPrimaryKeySelectiveStatementId()
/*  961:     */   {
/*  962:1157 */     return "updateByMap";
/*  963:     */   }
/*  964:     */   
/*  965:     */   protected String getSqlMapPackage(FullyQualifiedTable table)
/*  966:     */   {
/*  967:1168 */     String key = "getSqlMapPackage";
/*  968:     */     
/*  969:     */ 
/*  970:1171 */     Map map = getTableStringMap(table);
/*  971:1172 */     String s = (String)map.get(key);
/*  972:1173 */     if (s == null)
/*  973:     */     {
/*  974:1174 */       if ("true".equals(this.properties.get("enableSubPackages")))
/*  975:     */       {
/*  976:1175 */         StringBuffer sb = new StringBuffer(this.targetPackage);
/*  977:1177 */         if (StringUtility.stringHasValue(table.getCatalog()))
/*  978:     */         {
/*  979:1178 */           sb.append('.');
/*  980:1179 */           sb.append(table.getCatalog().toLowerCase());
/*  981:     */         }
/*  982:1182 */         if (StringUtility.stringHasValue(table.getSchema()))
/*  983:     */         {
/*  984:1183 */           sb.append('.');
/*  985:1184 */           sb.append(table.getSchema().toLowerCase());
/*  986:     */         }
/*  987:1187 */         s = sb.toString();
/*  988:     */       }
/*  989:     */       else
/*  990:     */       {
/*  991:1189 */         s = this.targetPackage;
/*  992:     */       }
/*  993:1192 */       map.put(key, s);
/*  994:     */     }
/*  995:1195 */     return s;
/*  996:     */   }
/*  997:     */   
/*  998:     */   protected String getPaginationClauseStartId()
/*  999:     */   {
/* 1000:1204 */     if (this.databaseDialect == DatabaseDialects.MYSQL.intValue()) {
/* 1001:1205 */       return "";
/* 1002:     */     }
/* 1003:1207 */     return "BASE_DAO.pagination_Start";
/* 1004:     */   }
/* 1005:     */   
/* 1006:     */   protected String getPaginationClauseEndId()
/* 1007:     */   {
/* 1008:1211 */     return "BASE_DAO.pagination_End";
/* 1009:     */   }
/* 1010:     */   
/* 1011:     */   protected String getExampleWhereClauseId()
/* 1012:     */   {
/* 1013:1220 */     return "ByMap_Where_Clause";
/* 1014:     */   }
/* 1015:     */   
/* 1016:     */   protected XmlElement getByExampleWhereClauseFragment(IntrospectedTable introspectedTable)
/* 1017:     */   {
/* 1018:1232 */     XmlElement answer = new XmlElement("sql");
/* 1019:     */     
/* 1020:1234 */     answer.addAttribute(new Attribute("id", getExampleWhereClauseId()));
/* 1021:     */     
/* 1022:1236 */     answer.addComment();
/* 1023:     */     
/* 1024:1238 */     XmlElement outerIterateElement = new XmlElement("iterate");
/* 1025:1239 */     outerIterateElement.addAttribute(new Attribute(
/* 1026:1240 */       "property", "oredCriteria"));
/* 1027:1241 */     outerIterateElement.addAttribute(new Attribute("conjunction", "or"));
/* 1028:1242 */     outerIterateElement.addAttribute(new Attribute("prepend", "where"));
/* 1029:1243 */     outerIterateElement.addAttribute(new Attribute("removeFirstPrepend", "iterate"));
/* 1030:1244 */     answer.addElement(outerIterateElement);
/* 1031:     */     
/* 1032:1246 */     outerIterateElement.addElement(new TextElement("("));
/* 1033:     */     
/* 1034:1248 */     XmlElement innerIterateElement = new XmlElement("iterate");
/* 1035:1249 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1036:1250 */     innerIterateElement.addAttribute(new Attribute(
/* 1037:1251 */       "property", "oredCriteria[].criteriaWithoutValue"));
/* 1038:1252 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1039:1253 */     innerIterateElement.addElement(new TextElement(
/* 1040:1254 */       "$oredCriteria[].criteriaWithoutValue[]$"));
/* 1041:1255 */     outerIterateElement.addElement(innerIterateElement);
/* 1042:     */     
/* 1043:1257 */     innerIterateElement = new XmlElement("iterate");
/* 1044:1258 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1045:1259 */     innerIterateElement.addAttribute(new Attribute(
/* 1046:1260 */       "property", "oredCriteria[].criteriaWithSingleValue"));
/* 1047:1261 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1048:1262 */     innerIterateElement
/* 1049:1263 */       .addElement(new TextElement(
/* 1050:1264 */       "$oredCriteria[].criteriaWithSingleValue[].condition$ #oredCriteria[].criteriaWithSingleValue[].value#"));
/* 1051:1265 */     outerIterateElement.addElement(innerIterateElement);
/* 1052:     */     
/* 1053:1267 */     innerIterateElement = new XmlElement("iterate");
/* 1054:1268 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1055:1269 */     innerIterateElement.addAttribute(new Attribute(
/* 1056:1270 */       "property", "oredCriteria[].criteriaWithListValue"));
/* 1057:1271 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1058:1272 */     innerIterateElement.addElement(new TextElement(
/* 1059:1273 */       "$oredCriteria[].criteriaWithListValue[].condition$"));
/* 1060:1274 */     XmlElement innerInnerIterateElement = new XmlElement("iterate");
/* 1061:1275 */     innerInnerIterateElement.addAttribute(new Attribute("property", 
/* 1062:1276 */       "oredCriteria[].criteriaWithListValue[].values"));
/* 1063:1277 */     innerInnerIterateElement.addAttribute(new Attribute("open", "("));
/* 1064:1278 */     innerInnerIterateElement.addAttribute(new Attribute("close", ")"));
/* 1065:1279 */     innerInnerIterateElement
/* 1066:1280 */       .addAttribute(new Attribute("conjunction", ","));
/* 1067:1281 */     innerInnerIterateElement.addElement(new TextElement(
/* 1068:1282 */       "#oredCriteria[].criteriaWithListValue[].values[]#"));
/* 1069:1283 */     innerIterateElement.addElement(innerInnerIterateElement);
/* 1070:1284 */     outerIterateElement.addElement(innerIterateElement);
/* 1071:     */     
/* 1072:1286 */     innerIterateElement = new XmlElement("iterate");
/* 1073:1287 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1074:1288 */     innerIterateElement.addAttribute(new Attribute(
/* 1075:1289 */       "property", "oredCriteria[].criteriaWithBetweenValue"));
/* 1076:1290 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1077:1291 */     innerIterateElement.addElement(new TextElement(
/* 1078:1292 */       "$oredCriteria[].criteriaWithBetweenValue[].condition$"));
/* 1079:1293 */     innerIterateElement
/* 1080:1294 */       .addElement(new TextElement(
/* 1081:1295 */       "#oredCriteria[].criteriaWithBetweenValue[].values[0]# and"));
/* 1082:1296 */     innerIterateElement.addElement(new TextElement(
/* 1083:1297 */       "#oredCriteria[].criteriaWithBetweenValue[].values[1]#"));
/* 1084:1298 */     outerIterateElement.addElement(innerIterateElement);
/* 1085:     */     
/* 1086:     */ 
/* 1087:     */ 
/* 1088:1302 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/* 1089:1303 */     while (iter.hasNext())
/* 1090:     */     {
/* 1091:1304 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1092:1306 */       if (StringUtility.stringHasValue(cd.getTypeHandler()))
/* 1093:     */       {
/* 1094:1309 */         StringBuffer sb1 = new StringBuffer();
/* 1095:1310 */         StringBuffer sb2 = new StringBuffer();
/* 1096:1311 */         innerIterateElement = new XmlElement("iterate");
/* 1097:1312 */         innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1098:     */         
/* 1099:1314 */         sb1.append("oredCriteria[].");
/* 1100:1315 */         sb1.append(cd.getJavaProperty());
/* 1101:1316 */         sb1.append("CriteriaWithSingleValue");
/* 1102:     */         
/* 1103:1318 */         innerIterateElement.addAttribute(new Attribute(
/* 1104:1319 */           "property", sb1.toString()));
/* 1105:1320 */         innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1106:     */         
/* 1107:1322 */         sb2.append(sb1);
/* 1108:     */         
/* 1109:1324 */         sb1.insert(0, '$');
/* 1110:1325 */         sb1.append("[].condition$ ");
/* 1111:     */         
/* 1112:1327 */         sb2.insert(0, '#');
/* 1113:1328 */         sb2.append("[].value,handler=");
/* 1114:1329 */         sb2.append(cd.getTypeHandler());
/* 1115:1330 */         sb2.append('#');
/* 1116:     */         
/* 1117:1332 */         sb1.append(sb2);
/* 1118:     */         
/* 1119:1334 */         innerIterateElement.addElement(new TextElement(sb1.toString()));
/* 1120:1335 */         outerIterateElement.addElement(innerIterateElement);
/* 1121:     */         
/* 1122:1337 */         sb1.setLength(0);
/* 1123:1338 */         sb2.setLength(0);
/* 1124:1339 */         sb1.append("oredCriteria[].");
/* 1125:1340 */         sb1.append(cd.getJavaProperty());
/* 1126:1341 */         sb1.append("CriteriaWithListValue");
/* 1127:     */         
/* 1128:1343 */         innerIterateElement = new XmlElement("iterate");
/* 1129:1344 */         innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1130:1345 */         innerIterateElement.addAttribute(new Attribute(
/* 1131:1346 */           "property", sb1.toString()));
/* 1132:1347 */         innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1133:     */         
/* 1134:1349 */         sb2.append('$');
/* 1135:1350 */         sb2.append(sb1);
/* 1136:1351 */         sb2.append("[].condition$");
/* 1137:     */         
/* 1138:1353 */         innerIterateElement.addElement(new TextElement(sb2.toString()));
/* 1139:     */         
/* 1140:1355 */         sb2.setLength(0);
/* 1141:1356 */         sb2.append(sb1);
/* 1142:1357 */         sb2.append("[].values");
/* 1143:     */         
/* 1144:1359 */         innerInnerIterateElement = new XmlElement("iterate");
/* 1145:1360 */         innerInnerIterateElement.addAttribute(new Attribute("property", 
/* 1146:1361 */           sb2.toString()));
/* 1147:1362 */         innerInnerIterateElement.addAttribute(new Attribute("open", "("));
/* 1148:1363 */         innerInnerIterateElement.addAttribute(new Attribute("close", ")"));
/* 1149:1364 */         innerInnerIterateElement
/* 1150:1365 */           .addAttribute(new Attribute("conjunction", ","));
/* 1151:     */         
/* 1152:1367 */         sb2.setLength(0);
/* 1153:1368 */         sb2.append('#');
/* 1154:1369 */         sb2.append(sb1);
/* 1155:1370 */         sb2.append("[].values[],handler=");
/* 1156:1371 */         sb2.append(cd.getTypeHandler());
/* 1157:1372 */         sb2.append('#');
/* 1158:     */         
/* 1159:1374 */         innerInnerIterateElement.addElement(new TextElement(sb2.toString()));
/* 1160:1375 */         innerIterateElement.addElement(innerInnerIterateElement);
/* 1161:1376 */         outerIterateElement.addElement(innerIterateElement);
/* 1162:     */         
/* 1163:1378 */         sb1.setLength(0);
/* 1164:1379 */         sb2.setLength(0);
/* 1165:1380 */         sb1.append("oredCriteria[].");
/* 1166:1381 */         sb1.append(cd.getJavaProperty());
/* 1167:1382 */         sb1.append("CriteriaWithBetweenValue");
/* 1168:     */         
/* 1169:1384 */         innerIterateElement = new XmlElement("iterate");
/* 1170:1385 */         innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 1171:1386 */         innerIterateElement.addAttribute(new Attribute(
/* 1172:1387 */           "property", sb1.toString()));
/* 1173:1388 */         innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 1174:     */         
/* 1175:1390 */         sb2.append('$');
/* 1176:1391 */         sb2.append(sb1);
/* 1177:1392 */         sb2.append("[].condition$");
/* 1178:     */         
/* 1179:1394 */         innerIterateElement.addElement(new TextElement(sb2.toString()));
/* 1180:     */         
/* 1181:1396 */         sb2.setLength(0);
/* 1182:1397 */         sb2.append(sb1);
/* 1183:     */         
/* 1184:1399 */         sb1.insert(0, '#');
/* 1185:1400 */         sb1.append("[].values[0],handler=");
/* 1186:1401 */         sb1.append(cd.getTypeHandler());
/* 1187:1402 */         sb1.append("# and");
/* 1188:     */         
/* 1189:1404 */         sb2.insert(0, '#');
/* 1190:1405 */         sb2.append("[].values[1],handler=");
/* 1191:1406 */         sb2.append(cd.getTypeHandler());
/* 1192:1407 */         sb2.append('#');
/* 1193:     */         
/* 1194:1409 */         innerIterateElement.addElement(new TextElement(sb1.toString()));
/* 1195:1410 */         innerIterateElement.addElement(new TextElement(sb2.toString()));
/* 1196:1411 */         outerIterateElement.addElement(innerIterateElement);
/* 1197:     */       }
/* 1198:     */     }
/* 1199:1415 */     outerIterateElement.addElement(new TextElement(")"));
/* 1200:     */     
/* 1201:1417 */     return answer;
/* 1202:     */   }
/* 1203:     */   
/* 1204:     */   protected XmlElement getSelectCountByExample(IntrospectedTable introspectedTable)
/* 1205:     */   {
/* 1206:1421 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1207:1422 */     FullyQualifiedJavaType fqjt = this.javaModelGenerator.getExampleType(table);
/* 1208:     */     
/* 1209:1424 */     XmlElement answer = new XmlElement("select");
/* 1210:     */     
/* 1211:1426 */     answer.addAttribute(new Attribute("id", getSelectCountByExampleStatementId()));
/* 1212:1427 */     answer.addAttribute(new Attribute("resultClass", "int"));
/* 1213:1428 */     answer.addAttribute(new Attribute("parameterClass", fqjt.getFullyQualifiedName()));
/* 1214:     */     
/* 1215:1430 */     answer.addComment();
/* 1216:     */     
/* 1217:1432 */     StringBuffer sb = new StringBuffer();
/* 1218:1433 */     sb.append("select count(1) from ");
/* 1219:1434 */     sb.append(table.getAliasedFullyQualifiedTableName());
/* 1220:1435 */     answer.addElement(new TextElement(sb.toString()));
/* 1221:     */     
/* 1222:1437 */     XmlElement isParameterPresenteElement = 
/* 1223:1438 */       new XmlElement("isParameterPresent");
/* 1224:1439 */     answer.addElement(isParameterPresenteElement);
/* 1225:     */     
/* 1226:1441 */     XmlElement includeElement = new XmlElement("include");
/* 1227:1442 */     includeElement.addAttribute(new Attribute("refid", 
/* 1228:1443 */       getSqlMapNamespace(table) + "." + getExampleWhereClauseId()));
/* 1229:1444 */     isParameterPresenteElement.addElement(includeElement);
/* 1230:     */     
/* 1231:1446 */     return answer;
/* 1232:     */   }
/* 1233:     */   
/* 1234:     */   protected XmlElement getSelectByExample(IntrospectedTable introspectedTable)
/* 1235:     */   {
/* 1236:1458 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1237:1459 */     FullyQualifiedJavaType fqjt = this.javaModelGenerator.getExampleType(table);
/* 1238:     */     
/* 1239:1461 */     XmlElement answer = new XmlElement("select");
/* 1240:     */     
/* 1241:1463 */     answer
/* 1242:1464 */       .addAttribute(new Attribute(
/* 1243:1465 */       "id", getSelectByExampleStatementId()));
/* 1244:1466 */     answer
/* 1245:1467 */       .addAttribute(new Attribute(
/* 1246:1468 */       "resultMap", getResultMapName(table)));
/* 1247:1469 */     answer.addAttribute(new Attribute(
/* 1248:1470 */       "parameterClass", fqjt.getFullyQualifiedName()));
/* 1249:     */     
/* 1250:1472 */     answer.addComment();
/* 1251:     */     
/* 1252:1474 */     StringBuffer sb = new StringBuffer();
/* 1253:1475 */     if (getPaginationClauseStartId().length() > 0)
/* 1254:     */     {
/* 1255:1476 */       answer.addElement(new TextElement("select "));
/* 1256:1477 */       XmlElement paginationElement = new XmlElement("include");
/* 1257:1478 */       paginationElement.addAttribute(new Attribute("refid", 
/* 1258:1479 */         getPaginationClauseStartId()));
/* 1259:1480 */       answer.addElement(paginationElement);
/* 1260:     */     }
/* 1261:     */     else
/* 1262:     */     {
/* 1263:1483 */       sb.append("select ");
/* 1264:     */     }
/* 1265:1486 */     boolean comma = false;
/* 1266:1487 */     if (StringUtility.stringHasValue(introspectedTable.getSelectByExampleQueryId()))
/* 1267:     */     {
/* 1268:1488 */       sb.append('\'');
/* 1269:1489 */       sb.append(introspectedTable.getSelectByExampleQueryId());
/* 1270:1490 */       sb.append("' as QUERYID");
/* 1271:1491 */       comma = true;
/* 1272:     */     }
/* 1273:1494 */     Iterator iter = introspectedTable.getNonBLOBColumns();
/* 1274:1495 */     while (iter.hasNext())
/* 1275:     */     {
/* 1276:1496 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1277:1498 */       if (comma) {
/* 1278:1499 */         sb.append(", ");
/* 1279:     */       } else {
/* 1280:1501 */         comma = true;
/* 1281:     */       }
/* 1282:1504 */       sb.append(cd.getSelectListPhrase());
/* 1283:     */     }
/* 1284:1506 */     answer.addElement(new TextElement(sb.toString()));
/* 1285:     */     
/* 1286:1508 */     sb.setLength(0);
/* 1287:1509 */     sb.append("from ");
/* 1288:1510 */     sb.append(table.getAliasedFullyQualifiedTableName());
/* 1289:1511 */     answer.addElement(new TextElement(sb.toString()));
/* 1290:     */     
/* 1291:1513 */     XmlElement isParameterPresenteElement = 
/* 1292:1514 */       new XmlElement("isParameterPresent");
/* 1293:1515 */     answer.addElement(isParameterPresenteElement);
/* 1294:     */     
/* 1295:1517 */     XmlElement includeElement = new XmlElement("include");
/* 1296:1518 */     includeElement.addAttribute(new Attribute("refid", 
/* 1297:1519 */       getSqlMapNamespace(table) + "." + getExampleWhereClauseId()));
/* 1298:1520 */     isParameterPresenteElement.addElement(includeElement);
/* 1299:     */     
/* 1300:1522 */     XmlElement isNotNullElement = new XmlElement("isNotNull");
/* 1301:1523 */     isNotNullElement
/* 1302:1524 */       .addAttribute(new Attribute("property", "orderByClause"));
/* 1303:1525 */     isNotNullElement
/* 1304:1526 */       .addElement(new TextElement("order by $orderByClause$"));
/* 1305:1527 */     isParameterPresenteElement.addElement(isNotNullElement);
/* 1306:     */     
/* 1307:1529 */     XmlElement paginationElement = new XmlElement("include");
/* 1308:1530 */     paginationElement.addAttribute(new Attribute("refid", 
/* 1309:1531 */       getPaginationClauseEndId()));
/* 1310:1532 */     isParameterPresenteElement.addElement(paginationElement);
/* 1311:     */     
/* 1312:1534 */     return answer;
/* 1313:     */   }
/* 1314:     */   
/* 1315:     */   protected XmlElement getSelectByExampleWithBLOBs(IntrospectedTable introspectedTable)
/* 1316:     */   {
/* 1317:1546 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1318:1547 */     FullyQualifiedJavaType fqjt = this.javaModelGenerator.getExampleType(table);
/* 1319:     */     
/* 1320:1549 */     XmlElement answer = new XmlElement("select");
/* 1321:1550 */     answer.addAttribute(new Attribute(
/* 1322:1551 */       "id", getSelectByExampleWithBLOBsStatementId()));
/* 1323:1552 */     answer.addAttribute(new Attribute(
/* 1324:1553 */       "resultMap", getResultMapName(table) + "WithBLOBs"));
/* 1325:1554 */     answer.addAttribute(new Attribute(
/* 1326:1555 */       "parameterClass", fqjt.getFullyQualifiedName()));
/* 1327:     */     
/* 1328:1557 */     answer.addComment();
/* 1329:     */     
/* 1330:1559 */     StringBuffer sb = new StringBuffer();
/* 1331:1560 */     if (getPaginationClauseStartId().length() > 0)
/* 1332:     */     {
/* 1333:1561 */       answer.addElement(new TextElement("select "));
/* 1334:1562 */       XmlElement paginationElement = new XmlElement("include");
/* 1335:1563 */       paginationElement.addAttribute(new Attribute("refid", 
/* 1336:1564 */         getPaginationClauseStartId()));
/* 1337:1565 */       answer.addElement(paginationElement);
/* 1338:     */     }
/* 1339:     */     else
/* 1340:     */     {
/* 1341:1568 */       sb.append("select ");
/* 1342:     */     }
/* 1343:1571 */     boolean comma = false;
/* 1344:1573 */     if (StringUtility.stringHasValue(introspectedTable.getSelectByExampleQueryId()))
/* 1345:     */     {
/* 1346:1574 */       sb.append('\'');
/* 1347:1575 */       sb.append(introspectedTable.getSelectByExampleQueryId());
/* 1348:1576 */       sb.append("' as QUERYID");
/* 1349:1577 */       comma = true;
/* 1350:     */     }
/* 1351:1580 */     Iterator iter = introspectedTable.getAllColumns();
/* 1352:1581 */     while (iter.hasNext())
/* 1353:     */     {
/* 1354:1582 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1355:1584 */       if (comma) {
/* 1356:1585 */         sb.append(", ");
/* 1357:     */       } else {
/* 1358:1587 */         comma = true;
/* 1359:     */       }
/* 1360:1590 */       sb.append(cd.getSelectListPhrase());
/* 1361:     */     }
/* 1362:1592 */     answer.addElement(new TextElement(sb.toString()));
/* 1363:     */     
/* 1364:1594 */     sb.setLength(0);
/* 1365:1595 */     sb.append("from ");
/* 1366:1596 */     sb.append(table.getAliasedFullyQualifiedTableName());
/* 1367:1597 */     answer.addElement(new TextElement(sb.toString()));
/* 1368:     */     
/* 1369:1599 */     XmlElement isParameterPresenteElement = 
/* 1370:1600 */       new XmlElement("isParameterPresent");
/* 1371:1601 */     answer.addElement(isParameterPresenteElement);
/* 1372:     */     
/* 1373:1603 */     XmlElement includeElement = new XmlElement("include");
/* 1374:1604 */     includeElement.addAttribute(new Attribute("refid", 
/* 1375:1605 */       getSqlMapNamespace(table) + "." + getExampleWhereClauseId()));
/* 1376:1606 */     isParameterPresenteElement.addElement(includeElement);
/* 1377:     */     
/* 1378:1608 */     XmlElement isNotNullElement = new XmlElement("isNotNull");
/* 1379:1609 */     isNotNullElement
/* 1380:1610 */       .addAttribute(new Attribute("property", "orderByClause"));
/* 1381:1611 */     isNotNullElement
/* 1382:1612 */       .addElement(new TextElement("order by $orderByClause$"));
/* 1383:1613 */     isParameterPresenteElement.addElement(isNotNullElement);
/* 1384:     */     
/* 1385:1615 */     XmlElement paginationElement = new XmlElement("include");
/* 1386:1616 */     paginationElement.addAttribute(new Attribute("refid", 
/* 1387:1617 */       getPaginationClauseEndId()));
/* 1388:1618 */     isParameterPresenteElement.addElement(paginationElement);
/* 1389:     */     
/* 1390:1620 */     return answer;
/* 1391:     */   }
/* 1392:     */   
/* 1393:     */   public void setTargetProject(String targetProject)
/* 1394:     */   {
/* 1395:1629 */     this.targetProject = targetProject;
/* 1396:     */   }
/* 1397:     */   
/* 1398:     */   public void setWarnings(List warnings)
/* 1399:     */   {
/* 1400:1638 */     this.warnings = warnings;
/* 1401:     */   }
/* 1402:     */   
/* 1403:     */   protected XmlElement getUpdateByPrimaryKeySelective(IntrospectedTable introspectedTable)
/* 1404:     */   {
/* 1405:1651 */     XmlElement answer = new XmlElement("update");
/* 1406:1652 */     FullyQualifiedTable table = introspectedTable.getTable();
/* 1407:     */     
/* 1408:1654 */     answer.addAttribute(new Attribute(
/* 1409:1655 */       "id", getUpdateByPrimaryKeySelectiveStatementId()));
/* 1410:     */     
/* 1411:     */ 
/* 1412:     */ 
/* 1413:     */ 
/* 1414:     */ 
/* 1415:     */ 
/* 1416:     */ 
/* 1417:     */ 
/* 1418:     */ 
/* 1419:     */ 
/* 1420:1666 */     answer.addAttribute(new Attribute("parameterClass", "java.util.Map"));
/* 1421:     */     
/* 1422:1668 */     answer.addComment();
/* 1423:     */     
/* 1424:1670 */     StringBuffer sb = new StringBuffer();
/* 1425:     */     
/* 1426:1672 */     sb.append("update ");
/* 1427:1673 */     sb.append(table.getFullyQualifiedTableName());
/* 1428:1674 */     answer.addElement(new TextElement(sb.toString()));
/* 1429:     */     
/* 1430:1676 */     XmlElement dynamicElement = new XmlElement("dynamic");
/* 1431:1677 */     dynamicElement.addAttribute(new Attribute("prepend", "set"));
/* 1432:1678 */     answer.addElement(dynamicElement);
/* 1433:     */     
/* 1434:1680 */     Iterator iter = introspectedTable.getNonPrimaryKeyColumns();
/* 1435:1681 */     while (iter.hasNext())
/* 1436:     */     {
/* 1437:1682 */       ColumnDefinition cd = (ColumnDefinition)iter.next();
/* 1438:     */       
/* 1439:     */ 
/* 1440:1685 */       XmlElement isNotNullElement = new XmlElement("isPropertyAvailable");
/* 1441:1686 */       isNotNullElement.addAttribute(new Attribute("prepend", ","));
/* 1442:1687 */       isNotNullElement.addAttribute(new Attribute("property", cd.getJavaProperty()));
/* 1443:1688 */       dynamicElement.addElement(isNotNullElement);
/* 1444:     */       
/* 1445:1690 */       sb.setLength(0);
/* 1446:1691 */       sb.append(cd.getColumnName());
/* 1447:1692 */       sb.append(" = ");
/* 1448:1693 */       sb.append(cd.getIbatisFormattedParameterClause());
/* 1449:     */       
/* 1450:1695 */       isNotNullElement.addElement(new TextElement(sb.toString()));
/* 1451:     */     }
/* 1452:1718 */     XmlElement isParameterPresenteElement = 
/* 1453:1719 */       new XmlElement("isParameterPresent");
/* 1454:1720 */     answer.addElement(isParameterPresenteElement);
/* 1455:     */     
/* 1456:1722 */     XmlElement includeElement = new XmlElement("include");
/* 1457:1723 */     includeElement.addAttribute(new Attribute("refid", 
/* 1458:1724 */       getSqlMapNamespace(table) + "." + getExampleWhereClauseId()));
/* 1459:1725 */     isParameterPresenteElement.addElement(includeElement);
/* 1460:     */     
/* 1461:     */ 
/* 1462:1728 */     return answer;
/* 1463:     */   }
/* 1464:     */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.sqlmap.SqlMapGeneratorIterateImpl
 * JD-Core Version:    0.7.0.1
 */