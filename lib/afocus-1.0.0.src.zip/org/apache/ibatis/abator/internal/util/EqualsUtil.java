/*  1:   */ package org.apache.ibatis.abator.internal.util;
/*  2:   */ 
/*  3:   */ public final class EqualsUtil
/*  4:   */ {
/*  5:   */   public static boolean areEqual(boolean aThis, boolean aThat)
/*  6:   */   {
/*  7:33 */     return aThis == aThat;
/*  8:   */   }
/*  9:   */   
/* 10:   */   public static boolean areEqual(char aThis, char aThat)
/* 11:   */   {
/* 12:37 */     return aThis == aThat;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public static boolean areEqual(long aThis, long aThat)
/* 16:   */   {
/* 17:45 */     return aThis == aThat;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static boolean areEqual(float aThis, float aThat)
/* 21:   */   {
/* 22:49 */     return Float.floatToIntBits(aThis) == Float.floatToIntBits(aThat);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static boolean areEqual(double aThis, double aThat)
/* 26:   */   {
/* 27:53 */     return Double.doubleToLongBits(aThis) == Double.doubleToLongBits(aThat);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static boolean areEqual(Object aThis, Object aThat)
/* 31:   */   {
/* 32:63 */     return aThis == null ? false : aThat == null ? true : aThis.equals(aThat);
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.util.EqualsUtil
 * JD-Core Version:    0.7.0.1
 */