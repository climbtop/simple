/*   1:    */ package org.apache.ibatis.abator.internal.util;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Array;
/*   4:    */ 
/*   5:    */ public final class HashCodeUtil
/*   6:    */ {
/*   7:    */   public static final int SEED = 23;
/*   8:    */   private static final int fODD_PRIME_NUMBER = 37;
/*   9:    */   
/*  10:    */   public static int hash(int aSeed, boolean aBoolean)
/*  11:    */   {
/*  12: 38 */     return firstTerm(aSeed) + (aBoolean ? 1 : 0);
/*  13:    */   }
/*  14:    */   
/*  15:    */   public static int hash(int aSeed, char aChar)
/*  16:    */   {
/*  17: 45 */     return firstTerm(aSeed) + aChar;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static int hash(int aSeed, int aInt)
/*  21:    */   {
/*  22: 56 */     return firstTerm(aSeed) + aInt;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static int hash(int aSeed, long aLong)
/*  26:    */   {
/*  27: 63 */     return firstTerm(aSeed) + (int)(aLong ^ aLong >>> 32);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static int hash(int aSeed, float aFloat)
/*  31:    */   {
/*  32: 70 */     return hash(aSeed, Float.floatToIntBits(aFloat));
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static int hash(int aSeed, double aDouble)
/*  36:    */   {
/*  37: 77 */     return hash(aSeed, Double.doubleToLongBits(aDouble));
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static int hash(int aSeed, Object aObject)
/*  41:    */   {
/*  42: 88 */     int result = aSeed;
/*  43: 89 */     if (aObject == null)
/*  44:    */     {
/*  45: 90 */       result = hash(result, 0);
/*  46:    */     }
/*  47: 91 */     else if (!isArray(aObject))
/*  48:    */     {
/*  49: 92 */       result = hash(result, aObject.hashCode());
/*  50:    */     }
/*  51:    */     else
/*  52:    */     {
/*  53: 94 */       int length = Array.getLength(aObject);
/*  54: 95 */       for (int idx = 0; idx < length; idx++)
/*  55:    */       {
/*  56: 96 */         Object item = Array.get(aObject, idx);
/*  57:    */         
/*  58: 98 */         result = hash(result, item);
/*  59:    */       }
/*  60:    */     }
/*  61:101 */     return result;
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static int firstTerm(int aSeed)
/*  65:    */   {
/*  66:108 */     return 37 * aSeed;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static boolean isArray(Object aObject)
/*  70:    */   {
/*  71:112 */     return aObject.getClass().isArray();
/*  72:    */   }
/*  73:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.util.HashCodeUtil
 * JD-Core Version:    0.7.0.1
 */