/*   1:    */ package org.apache.ibatis.abator.internal.util;
/*   2:    */ 
/*   3:    */ public class JavaBeansUtil
/*   4:    */ {
/*   5:    */   public static String getPrefixProperty(String prefix, String property)
/*   6:    */   {
/*   7: 31 */     StringBuffer sb = new StringBuffer();
/*   8:    */     
/*   9: 33 */     sb.append(property);
/*  10: 34 */     if (Character.isLowerCase(sb.charAt(0))) {
/*  11: 35 */       sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  12:    */     }
/*  13: 38 */     sb.insert(0, prefix);
/*  14:    */     
/*  15: 40 */     return sb.toString();
/*  16:    */   }
/*  17:    */   
/*  18:    */   public static String getGetterMethodName(String property)
/*  19:    */   {
/*  20: 44 */     return getPrefixProperty("get", property);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static String getSetterMethodName(String property)
/*  24:    */   {
/*  25: 48 */     return getPrefixProperty("set", property);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static String getCamelCaseString(String inputString, boolean firstCharacterUppercase)
/*  29:    */   {
/*  30: 53 */     StringBuffer sb = new StringBuffer();
/*  31:    */     
/*  32: 55 */     boolean nextUpperCase = false;
/*  33: 56 */     for (int i = 0; i < inputString.length(); i++)
/*  34:    */     {
/*  35: 57 */       char c = inputString.charAt(i);
/*  36: 59 */       switch (c)
/*  37:    */       {
/*  38:    */       case '-': 
/*  39:    */       case '_': 
/*  40: 62 */         if (sb.length() > 0) {
/*  41: 63 */           nextUpperCase = true;
/*  42:    */         }
/*  43: 65 */         break;
/*  44:    */       default: 
/*  45: 68 */         if (nextUpperCase)
/*  46:    */         {
/*  47: 69 */           sb.append(Character.toUpperCase(c));
/*  48: 70 */           nextUpperCase = false;
/*  49:    */         }
/*  50:    */         else
/*  51:    */         {
/*  52: 72 */           sb.append(Character.toLowerCase(c));
/*  53:    */         }
/*  54:    */         break;
/*  55:    */       }
/*  56:    */     }
/*  57: 78 */     if (firstCharacterUppercase) {
/*  58: 79 */       sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  59:    */     }
/*  60: 82 */     return sb.toString();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static String getValidPropertyName(String inputString)
/*  64:    */   {
/*  65: 98 */     if (inputString.length() < 2) {
/*  66: 99 */       return inputString.toLowerCase();
/*  67:    */     }
/*  68:102 */     if ((Character.isUpperCase(inputString.charAt(0))) && 
/*  69:103 */       (Character.isLowerCase(inputString.charAt(1))))
/*  70:    */     {
/*  71:104 */       StringBuffer sb = new StringBuffer(inputString);
/*  72:105 */       sb.setCharAt(0, Character.toLowerCase(sb.charAt(0)));
/*  73:106 */       return sb.toString();
/*  74:    */     }
/*  75:108 */     return inputString;
/*  76:    */   }
/*  77:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.util.JavaBeansUtil
 * JD-Core Version:    0.7.0.1
 */