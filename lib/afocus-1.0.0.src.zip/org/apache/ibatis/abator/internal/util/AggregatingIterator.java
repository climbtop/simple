/*  1:   */ package org.apache.ibatis.abator.internal.util;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.NoSuchElementException;
/*  5:   */ 
/*  6:   */ public class AggregatingIterator
/*  7:   */   implements Iterator
/*  8:   */ {
/*  9:   */   private Iterator iterator1;
/* 10:   */   private Iterator iterator2;
/* 11:   */   private Iterator iterator3;
/* 12:   */   
/* 13:   */   public AggregatingIterator(Iterator iterator1, Iterator iterator2, Iterator iterator3)
/* 14:   */   {
/* 15:40 */     this.iterator1 = (iterator1 == null ? new NullIterator() : iterator1);
/* 16:41 */     this.iterator2 = (iterator2 == null ? new NullIterator() : iterator2);
/* 17:42 */     this.iterator3 = (iterator3 == null ? new NullIterator() : iterator3);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public AggregatingIterator(Iterator iterator1, Iterator iterator2)
/* 21:   */   {
/* 22:46 */     this(iterator1, iterator2, null);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void remove()
/* 26:   */   {
/* 27:53 */     throw new UnsupportedOperationException();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean hasNext()
/* 31:   */   {
/* 32:60 */     return (this.iterator1.hasNext()) || 
/* 33:61 */       (this.iterator2.hasNext()) || 
/* 34:62 */       (this.iterator3.hasNext());
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Object next()
/* 38:   */   {
/* 39:69 */     if (this.iterator1.hasNext()) {
/* 40:70 */       return this.iterator1.next();
/* 41:   */     }
/* 42:71 */     if (this.iterator2.hasNext()) {
/* 43:72 */       return this.iterator2.next();
/* 44:   */     }
/* 45:73 */     if (this.iterator3.hasNext()) {
/* 46:74 */       return this.iterator3.next();
/* 47:   */     }
/* 48:76 */     throw new NoSuchElementException();
/* 49:   */   }
/* 50:   */   
/* 51:   */   public static class NullIterator
/* 52:   */     implements Iterator
/* 53:   */   {
/* 54:   */     public boolean hasNext()
/* 55:   */     {
/* 56:82 */       return false;
/* 57:   */     }
/* 58:   */     
/* 59:   */     public Object next()
/* 60:   */     {
/* 61:86 */       throw new NoSuchElementException();
/* 62:   */     }
/* 63:   */     
/* 64:   */     public void remove()
/* 65:   */     {
/* 66:90 */       throw new UnsupportedOperationException();
/* 67:   */     }
/* 68:   */   }
/* 69:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.util.AggregatingIterator
 * JD-Core Version:    0.7.0.1
 */