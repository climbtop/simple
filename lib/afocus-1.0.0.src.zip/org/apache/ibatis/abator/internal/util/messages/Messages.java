/*  1:   */ package org.apache.ibatis.abator.internal.util.messages;
/*  2:   */ 
/*  3:   */ import java.text.MessageFormat;
/*  4:   */ import java.util.MissingResourceException;
/*  5:   */ import java.util.ResourceBundle;
/*  6:   */ 
/*  7:   */ public class Messages
/*  8:   */ {
/*  9:   */   private static final String BUNDLE_NAME = "org.apache.ibatis.abator.internal.util.messages.messages";
/* 10:29 */   private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("org.apache.ibatis.abator.internal.util.messages.messages");
/* 11:   */   
/* 12:   */   public static String getString(String key)
/* 13:   */   {
/* 14:   */     try
/* 15:   */     {
/* 16:36 */       return RESOURCE_BUNDLE.getString(key);
/* 17:   */     }
/* 18:   */     catch (MissingResourceException e) {}
/* 19:38 */     return '!' + key + '!';
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static String getString(String key, String parm1)
/* 23:   */   {
/* 24:   */     try
/* 25:   */     {
/* 26:44 */       return MessageFormat.format(RESOURCE_BUNDLE.getString(key), new String[] { parm1 });
/* 27:   */     }
/* 28:   */     catch (MissingResourceException e) {}
/* 29:46 */     return '!' + key + '!';
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static String getString(String key, String parm1, String parm2)
/* 33:   */   {
/* 34:   */     try
/* 35:   */     {
/* 36:52 */       return MessageFormat.format(RESOURCE_BUNDLE.getString(key), new String[] { parm1, parm2 });
/* 37:   */     }
/* 38:   */     catch (MissingResourceException e) {}
/* 39:54 */     return '!' + key + '!';
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static String getString(String key, String parm1, String parm2, String parm3)
/* 43:   */   {
/* 44:   */     try
/* 45:   */     {
/* 46:60 */       return MessageFormat.format(RESOURCE_BUNDLE.getString(key), new String[] { parm1, parm2, parm3 });
/* 47:   */     }
/* 48:   */     catch (MissingResourceException e) {}
/* 49:62 */     return '!' + key + '!';
/* 50:   */   }
/* 51:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.util.messages.Messages
 * JD-Core Version:    0.7.0.1
 */