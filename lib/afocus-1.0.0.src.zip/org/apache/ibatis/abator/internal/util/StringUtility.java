/*   1:    */ package org.apache.ibatis.abator.internal.util;
/*   2:    */ 
/*   3:    */ import java.util.Random;
/*   4:    */ 
/*   5:    */ public class StringUtility
/*   6:    */ {
/*   7: 26 */   private static Random rnd = new Random();
/*   8:    */   
/*   9:    */   public static boolean stringHasValue(String s)
/*  10:    */   {
/*  11: 36 */     return (s != null) && (s.length() > 0);
/*  12:    */   }
/*  13:    */   
/*  14:    */   public static String charsetConvert(String str, String srcCharset, String dstCharset)
/*  15:    */   {
/*  16: 40 */     if (!stringHasValue(str)) {
/*  17: 41 */       return "";
/*  18:    */     }
/*  19:    */     try
/*  20:    */     {
/*  21: 43 */       return new String(str.getBytes(srcCharset), dstCharset);
/*  22:    */     }
/*  23:    */     catch (Exception localException) {}
/*  24: 47 */     return "";
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static String gbk2iso(String str)
/*  28:    */   {
/*  29: 51 */     return charsetConvert(str, "GBK", "ISO-8859-1");
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static String utf82iso(String str)
/*  33:    */   {
/*  34: 55 */     return charsetConvert(str, "UTF-8", "ISO-8859-1");
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static String utf82gbk(String str)
/*  38:    */   {
/*  39: 59 */     return charsetConvert(str, "UTF-8", "GBK");
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static String iso2gbk(String str)
/*  43:    */   {
/*  44: 63 */     return charsetConvert(str, "ISO-8859-1", "GBK");
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static String iso2utf8(String str)
/*  48:    */   {
/*  49: 67 */     return charsetConvert(str, "ISO-8859-1", "UTF-8");
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static String getRandomLongString()
/*  53:    */   {
/*  54: 71 */     return String.valueOf(rnd.nextLong()) + "L";
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static String composeFullyQualifiedTableName(String catalog, String schema, String tableName)
/*  58:    */   {
/*  59: 82 */     StringBuffer sb = new StringBuffer();
/*  60: 84 */     if (stringHasValue(catalog))
/*  61:    */     {
/*  62: 85 */       sb.append(catalog);
/*  63: 86 */       sb.append('.');
/*  64:    */     }
/*  65: 89 */     if (stringHasValue(schema))
/*  66:    */     {
/*  67: 90 */       sb.append(schema);
/*  68: 91 */       sb.append('.');
/*  69:    */     }
/*  70: 93 */     else if (sb.length() > 0)
/*  71:    */     {
/*  72: 94 */       sb.append('.');
/*  73:    */     }
/*  74: 98 */     sb.append(tableName);
/*  75:    */     
/*  76:100 */     return sb.toString();
/*  77:    */   }
/*  78:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.util.StringUtility
 * JD-Core Version:    0.7.0.1
 */