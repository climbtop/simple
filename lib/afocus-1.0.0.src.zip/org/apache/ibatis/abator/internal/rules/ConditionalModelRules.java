/*  1:   */ package org.apache.ibatis.abator.internal.rules;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import org.apache.ibatis.abator.config.TableConfiguration;
/*  5:   */ import org.apache.ibatis.abator.internal.db.ColumnDefinitions;
/*  6:   */ 
/*  7:   */ public class ConditionalModelRules
/*  8:   */   extends AbatorRules
/*  9:   */ {
/* 10:   */   public ConditionalModelRules(TableConfiguration tableConfiguration, ColumnDefinitions columnDefinitions)
/* 11:   */   {
/* 12:38 */     super(tableConfiguration, columnDefinitions);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public boolean generatePrimaryKeyClass()
/* 16:   */   {
/* 17:48 */     return this.columnDefinitions.getPrimaryKeyColumns().size() > 1;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean generateBaseRecordClass()
/* 21:   */   {
/* 22:61 */     return (this.columnDefinitions.getBaseColumns().size() > 0) || 
/* 23:62 */       (this.columnDefinitions.getPrimaryKeyColumns().size() == 1) || (
/* 24:63 */       (this.columnDefinitions.getBLOBColumns().size() > 0) && 
/* 25:64 */       (!generateRecordWithBLOBsClass()));
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean generateRecordWithBLOBsClass()
/* 29:   */   {
/* 30:76 */     int otherColumnCount = this.columnDefinitions.getPrimaryKeyColumns().size() + 
/* 31:77 */       this.columnDefinitions.getBaseColumns().size();
/* 32:   */     
/* 33:79 */     return (otherColumnCount > 1) && (
/* 34:80 */       this.columnDefinitions.getBLOBColumns().size() > 1);
/* 35:   */   }
/* 36:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.rules.ConditionalModelRules
 * JD-Core Version:    0.7.0.1
 */