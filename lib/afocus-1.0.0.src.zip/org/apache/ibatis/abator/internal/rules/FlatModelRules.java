/*  1:   */ package org.apache.ibatis.abator.internal.rules;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.config.TableConfiguration;
/*  4:   */ import org.apache.ibatis.abator.internal.db.ColumnDefinitions;
/*  5:   */ 
/*  6:   */ public class FlatModelRules
/*  7:   */   extends AbatorRules
/*  8:   */ {
/*  9:   */   public FlatModelRules(TableConfiguration tableConfiguration, ColumnDefinitions columnDefinitions)
/* 10:   */   {
/* 11:36 */     super(tableConfiguration, columnDefinitions);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public boolean generatePrimaryKeyClass()
/* 15:   */   {
/* 16:45 */     return false;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public boolean generateBaseRecordClass()
/* 20:   */   {
/* 21:54 */     return true;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean generateRecordWithBLOBsClass()
/* 25:   */   {
/* 26:63 */     return false;
/* 27:   */   }
/* 28:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.rules.FlatModelRules
 * JD-Core Version:    0.7.0.1
 */