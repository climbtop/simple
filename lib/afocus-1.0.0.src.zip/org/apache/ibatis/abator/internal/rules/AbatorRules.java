/*   1:    */ package org.apache.ibatis.abator.internal.rules;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   5:    */ import org.apache.ibatis.abator.api.JavaModelGenerator;
/*   6:    */ import org.apache.ibatis.abator.api.dom.java.FullyQualifiedJavaType;
/*   7:    */ import org.apache.ibatis.abator.config.TableConfiguration;
/*   8:    */ import org.apache.ibatis.abator.internal.db.ColumnDefinitions;
/*   9:    */ 
/*  10:    */ public abstract class AbatorRules
/*  11:    */ {
/*  12:    */   protected TableConfiguration tableConfiguration;
/*  13:    */   protected ColumnDefinitions columnDefinitions;
/*  14:    */   
/*  15:    */   public AbatorRules(TableConfiguration tableConfiguration, ColumnDefinitions columnDefinitions)
/*  16:    */   {
/*  17: 45 */     this.tableConfiguration = tableConfiguration;
/*  18: 46 */     this.columnDefinitions = columnDefinitions;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public int getPrimaryKeyColumnSize()
/*  22:    */   {
/*  23: 50 */     return this.columnDefinitions.getPrimaryKeyColumns().size();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public boolean generateInsert()
/*  27:    */   {
/*  28: 61 */     return this.tableConfiguration.isInsertStatementEnabled();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public FullyQualifiedJavaType calculateAllFieldsClass(JavaModelGenerator javaModelGenerator, IntrospectedTable introspectedTable)
/*  32:    */   {
/*  33:    */     FullyQualifiedJavaType answer;
/*  34:    */     FullyQualifiedJavaType answer;
/*  35: 79 */     if (generateRecordWithBLOBsClass())
/*  36:    */     {
/*  37: 80 */       answer = javaModelGenerator.getRecordWithBLOBsType(introspectedTable.getTable());
/*  38:    */     }
/*  39:    */     else
/*  40:    */     {
/*  41:    */       FullyQualifiedJavaType answer;
/*  42: 81 */       if (generateBaseRecordClass()) {
/*  43: 82 */         answer = javaModelGenerator.getBaseRecordType(introspectedTable.getTable());
/*  44:    */       } else {
/*  45: 84 */         answer = javaModelGenerator.getPrimaryKeyType(introspectedTable);
/*  46:    */       }
/*  47:    */     }
/*  48: 87 */     return answer;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean generateUpdateByPrimaryKeyWithoutBLOBs()
/*  52:    */   {
/*  53: 99 */     boolean rc = (this.tableConfiguration.isUpdateByPrimaryKeyStatementEnabled()) && 
/*  54:100 */       (this.columnDefinitions.hasPrimaryKeyColumns()) && 
/*  55:101 */       (this.columnDefinitions.hasBaseColumns());
/*  56:    */     
/*  57:103 */     return rc;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean generateUpdateByPrimaryKeyWithBLOBs()
/*  61:    */   {
/*  62:115 */     boolean rc = (this.tableConfiguration.isUpdateByPrimaryKeyStatementEnabled()) && 
/*  63:116 */       (this.columnDefinitions.hasPrimaryKeyColumns()) && 
/*  64:117 */       (this.columnDefinitions.hasBLOBColumns());
/*  65:    */     
/*  66:119 */     return rc;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public boolean generateUpdateByPrimaryKeySelective()
/*  70:    */   {
/*  71:131 */     boolean rc = (this.tableConfiguration.isUpdateByPrimaryKeyStatementEnabled()) && 
/*  72:132 */       (this.columnDefinitions.hasPrimaryKeyColumns()) && (
/*  73:133 */       (this.columnDefinitions.hasBLOBColumns()) || 
/*  74:134 */       (this.columnDefinitions.hasBaseColumns()));
/*  75:    */     
/*  76:136 */     return rc;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean generateDeleteByPrimaryKey()
/*  80:    */   {
/*  81:148 */     boolean rc = (this.tableConfiguration.isDeleteByPrimaryKeyStatementEnabled()) && 
/*  82:149 */       (this.columnDefinitions.hasPrimaryKeyColumns());
/*  83:    */     
/*  84:151 */     return rc;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean generateDeleteByExample()
/*  88:    */   {
/*  89:162 */     boolean rc = this.tableConfiguration.isDeleteByExampleStatementEnabled();
/*  90:    */     
/*  91:164 */     return rc;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean generateBaseResultMap()
/*  95:    */   {
/*  96:174 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/*  97:175 */       (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled());
/*  98:    */     
/*  99:177 */     return rc;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean generateResultMapWithBLOBs()
/* 103:    */   {
/* 104:188 */     boolean rc = ((this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 105:189 */       (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled())) && 
/* 106:190 */       (this.columnDefinitions.hasBLOBColumns());
/* 107:    */     
/* 108:192 */     return rc;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean generateSQLExampleWhereClause()
/* 112:    */   {
/* 113:203 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 114:204 */       (this.tableConfiguration.isDeleteByExampleStatementEnabled());
/* 115:    */     
/* 116:206 */     return rc;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean generateSelectByPrimaryKey()
/* 120:    */   {
/* 121:218 */     boolean rc = (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled()) && 
/* 122:219 */       (this.columnDefinitions.hasPrimaryKeyColumns()) && (
/* 123:220 */       (this.columnDefinitions.hasBaseColumns()) || 
/* 124:221 */       (this.columnDefinitions.hasBLOBColumns()));
/* 125:    */     
/* 126:223 */     return rc;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public boolean generateSelectByExampleWithoutBLOBs()
/* 130:    */   {
/* 131:234 */     return this.tableConfiguration.isSelectByExampleStatementEnabled();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean generateSelectByExampleWithBLOBs()
/* 135:    */   {
/* 136:246 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) && 
/* 137:247 */       (this.columnDefinitions.hasBLOBColumns());
/* 138:    */     
/* 139:249 */     return rc;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean generateExampleClass()
/* 143:    */   {
/* 144:260 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 145:261 */       (this.tableConfiguration.isDeleteByExampleStatementEnabled());
/* 146:    */     
/* 147:263 */     return rc;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public abstract boolean generatePrimaryKeyClass();
/* 151:    */   
/* 152:    */   public abstract boolean generateBaseRecordClass();
/* 153:    */   
/* 154:    */   public abstract boolean generateRecordWithBLOBsClass();
/* 155:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.rules.AbatorRules
 * JD-Core Version:    0.7.0.1
 */