/*  1:   */ package org.apache.ibatis.abator.internal;
/*  2:   */ 
/*  3:   */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*  4:   */ import org.apache.ibatis.abator.api.ServiceMethodNameCalculator;
/*  5:   */ 
/*  6:   */ public class SpringAbatorJava5ServiceMethodNameCalculator
/*  7:   */   implements ServiceMethodNameCalculator
/*  8:   */ {
/*  9:   */   public String getInsertMethodName(IntrospectedTable introspectedTable)
/* 10:   */   {
/* 11:36 */     return "insert";
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getUpdateByPrimaryKeyWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/* 15:   */   {
/* 16:48 */     return "update";
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getUpdateByPrimaryKeyWithBLOBsMethodName(IntrospectedTable introspectedTable)
/* 20:   */   {
/* 21:60 */     return "update";
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getDeleteByExampleMethodName(IntrospectedTable introspectedTable)
/* 25:   */   {
/* 26:64 */     return "delete";
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getDeleteByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/* 30:   */   {
/* 31:68 */     return "delete";
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getSelectCountByExampleMethodName(IntrospectedTable introspectedTable)
/* 35:   */   {
/* 36:72 */     return "getCount";
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String getSelectByExampleWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/* 40:   */   {
/* 41:81 */     return "getList";
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getSelectByExampleWithBLOBsMethodName(IntrospectedTable introspectedTable)
/* 45:   */   {
/* 46:90 */     return "getList";
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String getSelectByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/* 50:   */   {
/* 51:94 */     return "getById";
/* 52:   */   }
/* 53:   */   
/* 54:   */   public String getUpdateByPrimaryKeySelectiveMethodName(IntrospectedTable introspectedTable)
/* 55:   */   {
/* 56:98 */     return "update";
/* 57:   */   }
/* 58:   */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.SpringAbatorJava5ServiceMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */