/*   1:    */ package org.apache.ibatis.abator.internal;
/*   2:    */ 
/*   3:    */ import org.apache.ibatis.abator.api.FullyQualifiedTable;
/*   4:    */ import org.apache.ibatis.abator.api.IntrospectedTable;
/*   5:    */ import org.apache.ibatis.abator.api.ServiceMethodNameCalculator;
/*   6:    */ import org.apache.ibatis.abator.internal.rules.AbatorRules;
/*   7:    */ 
/*   8:    */ public class DefaultServiceMethodNameCalculator
/*   9:    */   implements ServiceMethodNameCalculator
/*  10:    */ {
/*  11:    */   public String getInsertMethodName(IntrospectedTable introspectedTable)
/*  12:    */   {
/*  13: 37 */     return "insert";
/*  14:    */   }
/*  15:    */   
/*  16:    */   public String getUpdateByPrimaryKeyWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/*  17:    */   {
/*  18: 49 */     AbatorRules rules = introspectedTable.getRules();
/*  19: 51 */     if (!rules.generateUpdateByPrimaryKeyWithBLOBs()) {
/*  20: 52 */       return "update";
/*  21:    */     }
/*  22: 53 */     if (rules.generateRecordWithBLOBsClass()) {
/*  23: 54 */       return "update";
/*  24:    */     }
/*  25: 56 */     return "updateByIdWithoutBLOBs";
/*  26:    */   }
/*  27:    */   
/*  28:    */   public String getUpdateByPrimaryKeyWithBLOBsMethodName(IntrospectedTable introspectedTable)
/*  29:    */   {
/*  30: 69 */     AbatorRules rules = introspectedTable.getRules();
/*  31: 71 */     if (!rules.generateUpdateByPrimaryKeyWithoutBLOBs()) {
/*  32: 72 */       return "update";
/*  33:    */     }
/*  34: 73 */     if (rules.generateRecordWithBLOBsClass()) {
/*  35: 74 */       return "update";
/*  36:    */     }
/*  37: 76 */     return "updateByIdWithBLOBs";
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String getDeleteByExampleMethodName(IntrospectedTable introspectedTable)
/*  41:    */   {
/*  42: 81 */     return "delete";
/*  43:    */   }
/*  44:    */   
/*  45:    */   public String getDeleteByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/*  46:    */   {
/*  47: 85 */     return "delete";
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getSelectCountByExampleMethodName(IntrospectedTable introspectedTable)
/*  51:    */   {
/*  52: 89 */     return "getCount";
/*  53:    */   }
/*  54:    */   
/*  55:    */   public String getSelectByExampleWithoutBLOBsMethodName(IntrospectedTable introspectedTable)
/*  56:    */   {
/*  57: 98 */     return "get" + introspectedTable.getTable().getDomainObjectName() + "List";
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getSelectByExampleWithBLOBsMethodName(IntrospectedTable introspectedTable)
/*  61:    */   {
/*  62:107 */     return "get" + introspectedTable.getTable().getDomainObjectName() + "List";
/*  63:    */   }
/*  64:    */   
/*  65:    */   public String getSelectByPrimaryKeyMethodName(IntrospectedTable introspectedTable)
/*  66:    */   {
/*  67:111 */     return "get" + introspectedTable.getTable().getDomainObjectName();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String getUpdateByPrimaryKeySelectiveMethodName(IntrospectedTable introspectedTable)
/*  71:    */   {
/*  72:115 */     return "update";
/*  73:    */   }
/*  74:    */ }


/* Location:           D:\项目\反编译\afocus-1.0.0.jar
 * Qualified Name:     org.apache.ibatis.abator.internal.DefaultServiceMethodNameCalculator
 * JD-Core Version:    0.7.0.1
 */