/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderCancelStatusEnum
/*  4:   */ {
/*  5: 5 */   UN_APPLY(0, "未申请"),  CANCEL_APPLY(1, "申请中"),  CANCEL_REFUND(2, "退款中"),  CANCEL_FAILURE(3, "取消失败"),  CANCEL_GOODS_RETURN(4, "退货中"),  CANCEL_SUCCESS(5, "取消成功");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private OrderCancelStatusEnum(int id, String name)
/* 11:   */   {
/* 12:15 */     this.id = id;
/* 13:16 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:19 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:22 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:25 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:28 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static String getNameById(int id)
/* 37:   */   {
/* 38:32 */     for (OrderCancelStatusEnum inst : ) {
/* 39:33 */       if (id == inst.id) {
/* 40:34 */         return inst.getName();
/* 41:   */       }
/* 42:   */     }
/* 43:36 */     throw new IllegalArgumentException("不支持的常量：" + id);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static int getIdByName(String name)
/* 47:   */   {
/* 48:40 */     for (OrderCancelStatusEnum inst : ) {
/* 49:41 */       if (name == inst.name) {
/* 50:42 */         return inst.getId();
/* 51:   */       }
/* 52:   */     }
/* 53:44 */     throw new IllegalArgumentException("不支持的常量：" + name);
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderCancelStatusEnum
 * JD-Core Version:    0.7.0.1
 */