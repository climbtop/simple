/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum OrderProduceSourceEnum
/*  7:   */ {
/*  8: 7 */   EHY("ehy", "官网"),  CDEHY("cdehy", "成都易好药"),  DDW("ddw", "当当网"),  JD("jd", "京东SOPL"),  LYSOP("lysop", "浏友"),  LYSOP2("lysop2", "浏友2店"),  MSJK("msjk", "民生健康"),  SOP("sop", "京东SOP"),  TBHYS("tbhys", "天猫"),  WX("wx", "微信"),  CN21("cn21", "21世纪"),  PHP_MALL("php_mall", "PHP官网"),  MOBILE("mobile", "移动官网"),  WXSHOP("wxshop", "微信小店"),  JDSG("JDSG", "京东闪购"),  MEHY("MEHY", "官网手机站"),  CFY("CFY", "处方药"),  DXD("DXD", "代下单"),  YHD("yhd", "一号店");
/*  9:   */   
/* 10:   */   private String code;
/* 11:   */   private String name;
/* 12:   */   
/* 13:   */   private OrderProduceSourceEnum(String code, String name)
/* 14:   */   {
/* 15:30 */     this.code = code;
/* 16:31 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getCode()
/* 20:   */   {
/* 21:35 */     return this.code;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setCode(String code)
/* 25:   */   {
/* 26:38 */     this.code = code;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:41 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:44 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static Map<String, String> getMap()
/* 40:   */   {
/* 41:48 */     Map<String, String> map = new HashMap();
/* 42:49 */     for (OrderProduceSourceEnum inst : values()) {
/* 43:50 */       map.put(inst.code, inst.name);
/* 44:   */     }
/* 45:52 */     return map;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static String getSoruceName(String produceSoruce)
/* 49:   */   {
/* 50:55 */     for (OrderProduceSourceEnum inst : ) {
/* 51:56 */       if (produceSoruce.equals(inst.code)) {
/* 52:57 */         return inst.name;
/* 53:   */       }
/* 54:   */     }
/* 55:60 */     return produceSoruce;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public static boolean isHave(String flag)
/* 59:   */   {
/* 60:64 */     for (OrderProduceSourceEnum areaEnum : ) {
/* 61:65 */       if ((flag != null) && (flag.equalsIgnoreCase(areaEnum.getCode()))) {
/* 62:66 */         return true;
/* 63:   */       }
/* 64:   */     }
/* 65:69 */     return false;
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderProduceSourceEnum
 * JD-Core Version:    0.7.0.1
 */