/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum IntegralExchangeColumnEnum
/*  7:   */ {
/*  8:13 */   VIP(1, "vip栏目"),  GOODS(2, "兑换商品栏目");
/*  9:   */   
/* 10:   */   int id;
/* 11:   */   String name;
/* 12:   */   
/* 13:   */   private IntegralExchangeColumnEnum(int id, String name)
/* 14:   */   {
/* 15:20 */     this.id = id;
/* 16:21 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getId()
/* 20:   */   {
/* 21:24 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setId(int id)
/* 25:   */   {
/* 26:27 */     this.id = id;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:30 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:33 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static Map<Integer, String> list()
/* 40:   */   {
/* 41:41 */     Map<Integer, String> map = new HashMap();
/* 42:42 */     IntegralExchangeColumnEnum[] typeEnums = values();
/* 43:44 */     for (IntegralExchangeColumnEnum object : typeEnums) {
/* 44:45 */       map.put(Integer.valueOf(object.getId()), object.getName());
/* 45:   */     }
/* 46:48 */     return map;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.IntegralExchangeColumnEnum
 * JD-Core Version:    0.7.0.1
 */