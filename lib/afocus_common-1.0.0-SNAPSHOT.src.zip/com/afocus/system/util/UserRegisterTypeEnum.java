/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum UserRegisterTypeEnum
/*  4:   */ {
/*  5:13 */   REGISTER_BIND_OLD(0, "直接绑定旧账号"),  REGISTER_BIND_NEW(1, "注册新账号（需要用户自己填写的账号密码）"),  REGISTER_BIND_OPENPLATFOMR(2, "注册新账号（需要开放平台昵称作为账号和用户填写的密码）");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private UserRegisterTypeEnum(int id, String name)
/* 11:   */   {
/* 12:23 */     this.id = id;
/* 13:24 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:28 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:32 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:36 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:40 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:44 */     for (UserRegisterTypeEnum userEnum : ) {
/* 39:45 */       if (id == userEnum.getId()) {
/* 40:46 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:49 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserRegisterTypeEnum
 * JD-Core Version:    0.7.0.1
 */