/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum ItemListParamPrefixEnum
/*  4:   */ {
/*  5:12 */   category("c", "一级分类"),  categories("s", "多选分类"),  brand("b", "品牌"),  place("p", "产地"),  dosage("g", "剂型"),  drugType("d", "药品类型"),  level("l", "星级"),  order("o", "排序"),  pageNo("n", "页码");
/*  6:   */   
/*  7:   */   String prefix;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private ItemListParamPrefixEnum(String prefix, String name)
/* 11:   */   {
/* 12:26 */     this.prefix = prefix;
/* 13:27 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getPrefix()
/* 17:   */   {
/* 18:34 */     return this.prefix;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setPrefix(String prefix)
/* 22:   */   {
/* 23:42 */     this.prefix = prefix;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:49 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:57 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.ItemListParamPrefixEnum
 * JD-Core Version:    0.7.0.1
 */