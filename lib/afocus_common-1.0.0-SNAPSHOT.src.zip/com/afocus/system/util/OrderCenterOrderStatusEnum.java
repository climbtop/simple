/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderCenterOrderStatusEnum
/*  4:   */ {
/*  5:14 */   WAIT_SELLER_STOCK_OUT("WAIT_SELLER_STOCK_OUT", OrderStatusEnum.STATUS_WAIT_SEND.getId()),  TRADE_CANCELED("TRADE_CANCELED", OrderStatusEnum.STATUS_CANCEL_WAIT.getId()),  TRADE_FINISH("TRADE_FINISH", OrderStatusEnum.STATUS_FINISHED.getId()),  TRADE_REFUND("TRADE_REFUND", OrderStatusEnum.STATUS_CANCEL_REFUND.getId());
/*  6:   */   
/*  7:   */   String statusStr;
/*  8:   */   int status;
/*  9:   */   
/* 10:   */   private OrderCenterOrderStatusEnum(String statusStr, int status)
/* 11:   */   {
/* 12:22 */     this.status = status;
/* 13:23 */     this.statusStr = statusStr;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getStatusStr()
/* 17:   */   {
/* 18:27 */     return this.statusStr;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setStatusStr(String statusStr)
/* 22:   */   {
/* 23:31 */     this.statusStr = statusStr;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int getStatus()
/* 27:   */   {
/* 28:35 */     return this.status;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setStatus(int status)
/* 32:   */   {
/* 33:39 */     this.status = status;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(String statusStr)
/* 37:   */   {
/* 38:44 */     for (OrderCenterOrderStatusEnum e : ) {
/* 39:45 */       if (statusStr.equals(e.getStatusStr())) {
/* 40:46 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:49 */     return false;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static int statusValueOf(String valueStr)
/* 47:   */   {
/* 48:53 */     for (OrderCenterOrderStatusEnum inst : ) {
/* 49:54 */       if (valueStr.equals(inst.statusStr)) {
/* 50:55 */         return inst.getStatus();
/* 51:   */       }
/* 52:   */     }
/* 53:57 */     throw new IllegalArgumentException("不支持的常量：" + valueStr);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static String getStatusStr(int status)
/* 57:   */   {
/* 58:61 */     for (OrderCenterOrderStatusEnum inst : ) {
/* 59:62 */       if (status == inst.status) {
/* 60:63 */         return inst.getStatusStr();
/* 61:   */       }
/* 62:   */     }
/* 63:65 */     return status + "";
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderCenterOrderStatusEnum
 * JD-Core Version:    0.7.0.1
 */