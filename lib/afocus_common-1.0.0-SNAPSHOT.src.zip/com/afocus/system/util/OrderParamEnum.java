package com.afocus.system.util;

public enum OrderParamEnum
{
  orderSn,  operateUserName,  operateUserIp,  paymentKey,  specialRequireMoney,  weixinPaidMoney,  paidTime,  payStatus;
  
  private OrderParamEnum() {}
}


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderParamEnum
 * JD-Core Version:    0.7.0.1
 */