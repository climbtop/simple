/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum TaskActionListEmum
/*  4:   */ {
/*  5: 4 */   REGISTER("100001", "注册"),  BIND_EMAIL("100002", "绑定邮箱"),  BIND_PHONE("100003", "绑定手机"),  LOGIN("100004", "登录"),  BIND_ADDRESS("100005", "绑定收货地址"),  EVALUATE("100006", "评价"),  PAY_ONLINE("100007", "在线支付"),  CHECK_POINT_TASK("100008", "查看常规任务"),  MEASUREMENT_TASK("100009", "测量");
/*  6:   */   
/*  7:   */   String id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private TaskActionListEmum(String id, String name)
/* 11:   */   {
/* 12:17 */     this.id = id;
/* 13:18 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getId()
/* 17:   */   {
/* 18:22 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(String id)
/* 22:   */   {
/* 23:26 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:30 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:34 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.TaskActionListEmum
 * JD-Core Version:    0.7.0.1
 */