/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum TJBRecommonedTypeEnum
/*  4:   */ {
/*  5:12 */   UNIT_HOME(1, "/unit/home"),  UNIT_ITEM(2, "/unit/item"),  UNIT_KEYWORDS(3, "/unit/by_keywords"),  ALSO_VIEWED(4, "AlsoViewed"),  BY_BROWSING_HISTORY(5, "ByBrowsingHistory"),  ALSO_BOUGHT(5, "AlsoBought"),  BOUGHT_TOGETHER(6, "AlsoViewed"),  ULTIMATELY_BOUGHT(6, "UltimatelyBought"),  BY_PURCHASING_HISTORY(7, "ByPurchasingHistory"),  BY_SHOPPING_CART(8, "ByShoppingCart"),  BY_HOT_INDEX(9, "ByHotIndex"),  CUSTOM_LIST(10, "CustomList");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private TJBRecommonedTypeEnum(int id, String name)
/* 11:   */   {
/* 12:31 */     this.id = id;
/* 13:32 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:36 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:40 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:44 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:48 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.TJBRecommonedTypeEnum
 * JD-Core Version:    0.7.0.1
 */