/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum UserAccountInfoStatusEnum
/*  4:   */ {
/*  5:15 */   AVAILABILITY_NO(0, "无效"),  AVAILABILITY_YES(1, "有效"),  STATUS_NORMAL(1, "正常"),  STATUS_SUSPENDED(2, "冻结状态"),  VIP_NO(0, "不是vip"),  VIP_YES(1, "是vip");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private UserAccountInfoStatusEnum(int id, String name)
/* 11:   */   {
/* 12:28 */     this.id = id;
/* 13:29 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:33 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:37 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:41 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:45 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:49 */     for (UserAccountInfoStatusEnum userEnum : ) {
/* 39:50 */       if (id == userEnum.getId()) {
/* 40:51 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:54 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserAccountInfoStatusEnum
 * JD-Core Version:    0.7.0.1
 */