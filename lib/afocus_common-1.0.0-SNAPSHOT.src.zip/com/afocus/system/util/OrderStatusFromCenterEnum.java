/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderStatusFromCenterEnum
/*  4:   */ {
/*  5: 7 */   STATUS_WAIT_SEND("s00", 20),  STATUS_SENDED_SUCCESS("s01", 30),  STATUS_SENDED_TUISONG("s02", 30),  STATUS_FINISHED("s03", 40),  STATUS_CANCEL("s04", 50),  STATUS_RETURN("s05", 51),  STATUS_LOCK("s06", 52);
/*  6:   */   
/*  7:   */   private int mallStatus;
/*  8:   */   private String orderCenterStatus;
/*  9:   */   
/* 10:   */   public int getMallStatus()
/* 11:   */   {
/* 12:36 */     return this.mallStatus;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setMallStatus(int mallStatus)
/* 16:   */   {
/* 17:39 */     this.mallStatus = mallStatus;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getOrderCenterStatus()
/* 21:   */   {
/* 22:42 */     return this.orderCenterStatus;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setOrderCenterStatus(String orderCenterStatus)
/* 26:   */   {
/* 27:45 */     this.orderCenterStatus = orderCenterStatus;
/* 28:   */   }
/* 29:   */   
/* 30:   */   private OrderStatusFromCenterEnum(String orderCenterStatus, int mallStatus)
/* 31:   */   {
/* 32:49 */     this.mallStatus = mallStatus;
/* 33:50 */     this.orderCenterStatus = orderCenterStatus;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(String statusStr)
/* 37:   */   {
/* 38:54 */     for (OrderStatusFromCenterEnum e : ) {
/* 39:55 */       if (statusStr.equals(e.getOrderCenterStatus())) {
/* 40:56 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:59 */     return false;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static int getMallStatus(String orderCenterStatus)
/* 47:   */   {
/* 48:63 */     for (OrderStatusFromCenterEnum inst : ) {
/* 49:64 */       if (orderCenterStatus.equals(inst.orderCenterStatus)) {
/* 50:65 */         return inst.getMallStatus();
/* 51:   */       }
/* 52:   */     }
/* 53:67 */     throw new IllegalArgumentException("不支持的常量：" + orderCenterStatus);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static String getOrderCenterStatus(int mallStatus)
/* 57:   */   {
/* 58:71 */     for (OrderStatusFromCenterEnum inst : ) {
/* 59:72 */       if (mallStatus == inst.mallStatus) {
/* 60:73 */         return inst.getOrderCenterStatus();
/* 61:   */       }
/* 62:   */     }
/* 63:75 */     throw new IllegalArgumentException("不支持的常量：" + mallStatus);
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderStatusFromCenterEnum
 * JD-Core Version:    0.7.0.1
 */