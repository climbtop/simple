/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderLogOperateTypeEnum
/*  4:   */ {
/*  5:14 */   CREATE(1, "用户创建订单"),  PAYED(2, "付款"),  SEND(3, "发货"),  CANCEL(4, "交易取消"),  FINISHED(5, "完成"),  APPLY_RETURN(6, "申请退货"),  RETURN_FINISHED(7, "退货完成"),  LOCKED(8, "锁定"),  ADMIN_EDIT_ORDER(9, "后台修改订单"),  ADMIN_CREATE_ORDER(10, "后台人员创建订单");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private OrderLogOperateTypeEnum(int id, String name)
/* 11:   */   {
/* 12:28 */     this.id = id;
/* 13:29 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:33 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:37 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:41 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:45 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderLogOperateTypeEnum
 * JD-Core Version:    0.7.0.1
 */