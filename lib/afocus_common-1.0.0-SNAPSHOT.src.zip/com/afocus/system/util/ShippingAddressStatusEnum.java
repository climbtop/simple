/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum ShippingAddressStatusEnum
/*  4:   */ {
/*  5:12 */   STATUS_NOT_DELETE(1, "未删除"),  STATUS_DELETE(0, "已删除"),  STATUS_DEFAULT(1, "默认"),  STATUS_NOT_DEFAULT(0, "非默认"),  STATUS_PRIVACY_RECEIPT(1, "隐私"),  STATUS_NOT_PRIVACY_RECEIPT(1, "非隐私"),  STATUS_TEMP_ADDR(1, "临时地址"),  STATUS_NOT_TEMP_ADDR(1, "非临时地址");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private ShippingAddressStatusEnum(int id, String name)
/* 11:   */   {
/* 12:33 */     this.id = id;
/* 13:34 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:38 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:41 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:44 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:47 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.ShippingAddressStatusEnum
 * JD-Core Version:    0.7.0.1
 */