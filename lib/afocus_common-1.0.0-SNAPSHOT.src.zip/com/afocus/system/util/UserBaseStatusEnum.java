/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum UserBaseStatusEnum
/*  4:   */ {
/*  5:15 */   USER_STATUS_DELETED(0, "无效"),  USER_STATUS_NOT_DELETE(1, "有效");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private UserBaseStatusEnum(int id, String name)
/* 11:   */   {
/* 12:23 */     this.id = id;
/* 13:24 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:28 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:32 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:36 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:40 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:44 */     for (UserBaseStatusEnum userEnum : ) {
/* 39:45 */       if (id == userEnum.getId()) {
/* 40:46 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:49 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserBaseStatusEnum
 * JD-Core Version:    0.7.0.1
 */