/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderAdminTypeEnum
/*  4:   */ {
/*  5: 6 */   NORMAL(0, "普通类型", OrderCenterOrderFlagEnum.HYSGW),  ORDER_PROXY(1, "代下单", OrderCenterOrderFlagEnum.DXD),  DRUGSPRESCRIPTION(2, "处方药", OrderCenterOrderFlagEnum.CFY),  HUI_SHI(3, "惠氏订单", OrderCenterOrderFlagEnum.HYDD),  JIN_XI_LI_AN(4, "金斯利安", OrderCenterOrderFlagEnum.JSLA);
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   OrderCenterOrderFlagEnum orderCenterOrderFlagEnum;
/* 10:   */   
/* 11:   */   private OrderAdminTypeEnum(int id, String name, OrderCenterOrderFlagEnum orderCenterOrderFlagEnum)
/* 12:   */   {
/* 13:16 */     this.id = id;
/* 14:17 */     this.name = name;
/* 15:18 */     this.orderCenterOrderFlagEnum = orderCenterOrderFlagEnum;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static OrderAdminTypeEnum getOrderAdminTypeEnum(int id)
/* 19:   */   {
/* 20:22 */     for (OrderAdminTypeEnum orderAdminTypeEnum : ) {
/* 21:23 */       if (orderAdminTypeEnum.getId() == id) {
/* 22:24 */         return orderAdminTypeEnum;
/* 23:   */       }
/* 24:   */     }
/* 25:27 */     return null;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public int getId()
/* 29:   */   {
/* 30:31 */     return this.id;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getName()
/* 34:   */   {
/* 35:34 */     return this.name;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public OrderCenterOrderFlagEnum getOrderCenterOrderFlagEnum()
/* 39:   */   {
/* 40:37 */     return this.orderCenterOrderFlagEnum;
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderAdminTypeEnum
 * JD-Core Version:    0.7.0.1
 */