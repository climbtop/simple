/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum TJBTermFieldsEnum
/*  4:   */ {
/*  5:14 */   TAGS("tags"),  SKU("sku");
/*  6:   */   
/*  7:   */   private String value;
/*  8:   */   
/*  9:   */   private TJBTermFieldsEnum(String value)
/* 10:   */   {
/* 11:22 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getValue()
/* 15:   */   {
/* 16:26 */     return this.value;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.TJBTermFieldsEnum
 * JD-Core Version:    0.7.0.1
 */