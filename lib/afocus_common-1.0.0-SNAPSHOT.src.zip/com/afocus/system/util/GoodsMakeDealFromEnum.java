/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsMakeDealFromEnum
/*  4:   */ {
/*  5:14 */   SITE(0, "站内"),  TUI_JIAN_BAO(1, "推荐宝");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private GoodsMakeDealFromEnum(int id, String name)
/* 11:   */   {
/* 12:21 */     this.id = id;
/* 13:22 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:26 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:30 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsMakeDealFromEnum
 * JD-Core Version:    0.7.0.1
 */