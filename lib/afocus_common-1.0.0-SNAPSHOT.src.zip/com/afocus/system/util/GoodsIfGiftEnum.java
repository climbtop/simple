/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsIfGiftEnum
/*  4:   */ {
/*  5:13 */   NO(0, "不是赠品"),  YES(1, "是赠品");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private GoodsIfGiftEnum(int id, String name)
/* 11:   */   {
/* 12:20 */     this.id = id;
/* 13:21 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:25 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:29 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsIfGiftEnum
 * JD-Core Version:    0.7.0.1
 */