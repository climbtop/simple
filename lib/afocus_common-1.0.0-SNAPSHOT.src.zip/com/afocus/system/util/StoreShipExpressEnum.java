/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum StoreShipExpressEnum
/*  4:   */ {
/*  5:10 */   PTKD("PTKD", "普通快递");
/*  6:   */   
/*  7:   */   String code;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private StoreShipExpressEnum(String code, String name)
/* 11:   */   {
/* 12:16 */     this.code = code;
/* 13:17 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getCode()
/* 17:   */   {
/* 18:21 */     return this.code;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:25 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.StoreShipExpressEnum
 * JD-Core Version:    0.7.0.1
 */