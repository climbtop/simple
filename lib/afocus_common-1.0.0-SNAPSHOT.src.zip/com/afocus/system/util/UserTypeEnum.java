/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum UserTypeEnum
/*  7:   */ {
/*  8:14 */   ALL(0, 0, "全网用户"),  GENERAL(10000, 1, "普通用户"),  VIP1(20001, 1, "VIP1"),  VIP2(20002, 1, "VIP2"),  VIP3(20003, 2, "VIP3"),  VIP4(20004, 2, "VIP4"),  VIP5(20005, 2, "VIP5"),  VIP6(20006, 2, "VIP6"),  PHARMACIST(30001, 10, "执业药师"),  SENIORPHARMACIST(30002, 20, "高级执业药师"),  BLACKLIST(90000, 0, "黑名单");
/*  9:   */   
/* 10:   */   String name;
/* 11:   */   int weight;
/* 12:   */   int type;
/* 13:   */   
/* 14:   */   private UserTypeEnum(int type, int weight, String name)
/* 15:   */   {
/* 16:33 */     this.name = name;
/* 17:34 */     this.weight = weight;
/* 18:35 */     this.type = type;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:39 */     return this.name;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setName(String name)
/* 27:   */   {
/* 28:43 */     this.name = name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int getWeight()
/* 32:   */   {
/* 33:47 */     return this.weight;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void setWeight(int weight)
/* 37:   */   {
/* 38:51 */     this.weight = weight;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public int getType()
/* 42:   */   {
/* 43:55 */     return this.type;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setType(int type)
/* 47:   */   {
/* 48:59 */     this.type = type;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public String toString()
/* 52:   */   {
/* 53:65 */     return this.name;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static UserTypeEnum getByType(int type)
/* 57:   */   {
/* 58:74 */     UserTypeEnum[] typeEnums = values();
/* 59:75 */     for (int i = 0; i < typeEnums.length; i++) {
/* 60:76 */       if (typeEnums[i].getType() == type) {
/* 61:77 */         return typeEnums[i];
/* 62:   */       }
/* 63:   */     }
/* 64:80 */     return null;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public static Map<Integer, String> listAllTypes()
/* 68:   */   {
/* 69:88 */     Map<Integer, String> typesMap = new HashMap();
/* 70:89 */     UserTypeEnum[] typeEnums = values();
/* 71:91 */     for (UserTypeEnum utype : typeEnums) {
/* 72:92 */       typesMap.put(Integer.valueOf(utype.getType()), utype.getName());
/* 73:   */     }
/* 74:95 */     return typesMap;
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserTypeEnum
 * JD-Core Version:    0.7.0.1
 */