/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum SmsPartnerEnum
/*  4:   */ {
/*  5: 5 */   QUAN_LI_TONG("QxtFirewall", "全力通"),  BAI_FEN("baifen", "百分信息");
/*  6:   */   
/*  7:   */   String code;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private SmsPartnerEnum(String code, String name)
/* 11:   */   {
/* 12:12 */     this.code = code;
/* 13:13 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getCode()
/* 17:   */   {
/* 18:17 */     return this.code;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setCode(String code)
/* 22:   */   {
/* 23:22 */     this.code = code;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:27 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:31 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.SmsPartnerEnum
 * JD-Core Version:    0.7.0.1
 */