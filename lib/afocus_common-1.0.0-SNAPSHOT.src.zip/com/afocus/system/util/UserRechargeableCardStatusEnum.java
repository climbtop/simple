/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum UserRechargeableCardStatusEnum
/*  7:   */ {
/*  8: 8 */   UNUSED(0, "未激活"),  USE(1, "正常使用中"),  FREEZING(2, "过期冻结"),  RUN_OUT(3, "已使用完");
/*  9:   */   
/* 10:   */   int id;
/* 11:   */   String name;
/* 12:   */   
/* 13:   */   private UserRechargeableCardStatusEnum(int id, String name)
/* 14:   */   {
/* 15:17 */     this.id = id;
/* 16:18 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getId()
/* 20:   */   {
/* 21:21 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setId(int id)
/* 25:   */   {
/* 26:24 */     this.id = id;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:27 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:30 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static Map<Integer, String> list()
/* 40:   */   {
/* 41:38 */     Map<Integer, String> map = new HashMap();
/* 42:39 */     UserRechargeableCardStatusEnum[] typeEnums = values();
/* 43:41 */     for (UserRechargeableCardStatusEnum object : typeEnums) {
/* 44:42 */       map.put(Integer.valueOf(object.getId()), object.getName());
/* 45:   */     }
/* 46:45 */     return map;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserRechargeableCardStatusEnum
 * JD-Core Version:    0.7.0.1
 */