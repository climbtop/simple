/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum ExpandCodeEnum
/*  7:   */ {
/*  8:13 */   ALL("u_0", "所有渠道"),  MALL("u_mall", "官网渠道"),  CAIBEI("u_caibei", "彩贝渠道"),  LANHAI("u_lanhai", "蓝海渠道"),  TCL("u_tcl", "TCL渠道"),  TAIKANG("u_taikang", "泰康渠道"),  WEIXIN_MALL("u_weixin_mall", "微信商城渠道"),  CHUNYU("u_chunyu", "春雨渠道"),  PINGAN("u_pingan", "平安渠道");
/*  9:   */   
/* 10:   */   String id;
/* 11:   */   String name;
/* 12:   */   
/* 13:   */   private ExpandCodeEnum(String id, String name)
/* 14:   */   {
/* 15:27 */     this.id = id;
/* 16:28 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getId()
/* 20:   */   {
/* 21:32 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setId(String id)
/* 25:   */   {
/* 26:36 */     this.id = id;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:40 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:44 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static boolean isHave(String id)
/* 40:   */   {
/* 41:48 */     for (ExpandCodeEnum areaEnum : ) {
/* 42:49 */       if (id == areaEnum.getId()) {
/* 43:50 */         return true;
/* 44:   */       }
/* 45:   */     }
/* 46:53 */     return false;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public static Map<String, String> list()
/* 50:   */   {
/* 51:61 */     Map<String, String> map = new HashMap();
/* 52:62 */     ExpandCodeEnum[] typeEnums = values();
/* 53:64 */     for (ExpandCodeEnum object : typeEnums) {
/* 54:65 */       map.put(object.getId(), object.getName());
/* 55:   */     }
/* 56:68 */     return map;
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.ExpandCodeEnum
 * JD-Core Version:    0.7.0.1
 */