/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum MailingEnum
/*  4:   */ {
/*  5:11 */   EMAIL("email"),  ACCOUNT("account"),  TONAME("toname"),  FROMNAME("fromname"),  CONTENT("content"),  EVENT_IMG_1("event_img1"),  EVENT_IMG_2("event_img2"),  EVENT_URL_1("event_url1"),  EVENT_URL_2("event_url2"),  EVENT_ALT_1("event_alt1"),  EVENT_ALT_2("event_alt2"),  RESET_PSW_URL("reset_psw_url"),  ACTIVE_URL("active_url");
/*  6:   */   
/*  7:   */   String paramName;
/*  8:   */   
/*  9:   */   private MailingEnum(String name)
/* 10:   */   {
/* 11:29 */     this.paramName = name;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getParamName()
/* 15:   */   {
/* 16:33 */     return this.paramName;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setParamName(String paramName)
/* 20:   */   {
/* 21:37 */     this.paramName = paramName;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString()
/* 25:   */   {
/* 26:42 */     return this.paramName;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.MailingEnum
 * JD-Core Version:    0.7.0.1
 */