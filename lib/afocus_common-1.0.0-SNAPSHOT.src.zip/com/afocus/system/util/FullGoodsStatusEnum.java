/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum FullGoodsStatusEnum
/*  4:   */ {
/*  5: 6 */   GOODS_NOTSELECTED(0, "unselected"),  GOODS_SELECTED(1, "selected"),  GOODS_NOT_MEET(0, "unmeet"),  GOODS_MEET(1, "meet"),  GOODS_HAVE_GIFT(1, "haveGift"),  GOODS_NOT_HAVE_GIFT(0, "notHaveGift"),  GOODS_HAVE_EXCHANGE(1, "haveExchange"),  GOODS_NOT_HAVE_EXCHANGE(0, "notHaveExchange"),  GOODS_GROUP_EFFECT(1, "effecctGroup"),  GOODS_GROUP_DEFAULT(2, "defaultGroup"),  GOODS_HAVE_PROMOTION(1, ""),  GOODS_NOT_HAVE_PROMOTION(2, ""),  GOODS_WITHOUT_PROMOTION(0, ""),  GOODS_DEFAULT_PROMOTION(-1, ""),  GOODS_NOT_SECKILL(0, "非秒杀商品"),  GOODS_IS_SECKILL(1, "秒杀商品");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private FullGoodsStatusEnum(int id, String name)
/* 11:   */   {
/* 12:41 */     this.id = id;
/* 13:42 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:46 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:50 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:54 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:58 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.FullGoodsStatusEnum
 * JD-Core Version:    0.7.0.1
 */