/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public class OrderCancelReasonMap
/*  7:   */ {
/*  8: 7 */   private static Map<Integer, String> cancelReasonMap = new HashMap();
/*  9:   */   
/* 10:   */   static
/* 11:   */   {
/* 12:10 */     cancelReasonMap.put(Integer.valueOf(1), "现在不想购买");
/* 13:11 */     cancelReasonMap.put(Integer.valueOf(2), "商品价格较贵");
/* 14:12 */     cancelReasonMap.put(Integer.valueOf(3), "价格波动");
/* 15:13 */     cancelReasonMap.put(Integer.valueOf(4), "商品缺货");
/* 16:14 */     cancelReasonMap.put(Integer.valueOf(5), "重复下单添加或删除商品");
/* 17:15 */     cancelReasonMap.put(Integer.valueOf(6), "收货人信息有误");
/* 18:16 */     cancelReasonMap.put(Integer.valueOf(7), "发票信息有误/发票未开");
/* 19:17 */     cancelReasonMap.put(Integer.valueOf(8), "送货时间过长");
/* 20:18 */     cancelReasonMap.put(Integer.valueOf(9), "其他原因");
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static String getValue(int id)
/* 24:   */   {
/* 25:22 */     return (String)cancelReasonMap.get(Integer.valueOf(id));
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static Map<Integer, String> getMap()
/* 29:   */   {
/* 30:25 */     return cancelReasonMap;
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderCancelReasonMap
 * JD-Core Version:    0.7.0.1
 */