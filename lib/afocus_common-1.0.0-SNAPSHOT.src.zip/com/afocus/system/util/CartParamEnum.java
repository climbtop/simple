package com.afocus.system.util;

public enum CartParamEnum
{
  mid,  gid,  pid,  quantity,  cartKey,  loginUserId,  verify,  appId,  itemId,  productIds,  userLoginName,  userAddressId,  paymentMethodId,  userIp,  invoiceType,  platform,  partnersUserId,  cartFromChannel,  orderCpsFlag,  invoiceTitle,  mealDirectIds,  extraKey,  identityTypeKey,  requireNote,  prescriptionInfo;
  
  private CartParamEnum() {}
}


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.CartParamEnum
 * JD-Core Version:    0.7.0.1
 */