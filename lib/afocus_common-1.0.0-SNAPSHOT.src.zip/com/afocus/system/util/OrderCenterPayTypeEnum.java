/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderCenterPayTypeEnum
/*  4:   */ {
/*  5: 9 */   ON_LINE(1, 1),  UNDER_LINE(4, 0);
/*  6:   */   
/*  7:   */   int mallPayType;
/*  8:   */   int orderCenterPayType;
/*  9:   */   
/* 10:   */   private OrderCenterPayTypeEnum(int orderCenterPayType, int mallPayType)
/* 11:   */   {
/* 12:16 */     this.mallPayType = mallPayType;
/* 13:17 */     this.orderCenterPayType = orderCenterPayType;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getMallPayType()
/* 17:   */   {
/* 18:23 */     return this.mallPayType;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setMallPayType(int mallPayType)
/* 22:   */   {
/* 23:29 */     this.mallPayType = mallPayType;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int getOrderCenterPayType()
/* 27:   */   {
/* 28:35 */     return this.orderCenterPayType;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setOrderCenterPayType(int orderCenterPayType)
/* 32:   */   {
/* 33:41 */     this.orderCenterPayType = orderCenterPayType;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(String statusStr)
/* 37:   */   {
/* 38:47 */     for (OrderCenterOrderStatusEnum e : ) {
/* 39:48 */       if (statusStr == e.getStatusStr()) {
/* 40:49 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:52 */     return false;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static int getMallPayType(int orderCenterPayType)
/* 47:   */   {
/* 48:56 */     for (OrderCenterPayTypeEnum inst : ) {
/* 49:57 */       if (orderCenterPayType == inst.orderCenterPayType) {
/* 50:58 */         return inst.getMallPayType();
/* 51:   */       }
/* 52:   */     }
/* 53:60 */     throw new IllegalArgumentException("不支持的常量：" + orderCenterPayType);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static int getOrderPayType(int mallType)
/* 57:   */   {
/* 58:64 */     for (OrderCenterPayTypeEnum inst : ) {
/* 59:65 */       if (mallType == inst.mallPayType) {
/* 60:66 */         return inst.orderCenterPayType;
/* 61:   */       }
/* 62:   */     }
/* 63:68 */     throw new IllegalArgumentException("不支持的常量：" + mallType);
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderCenterPayTypeEnum
 * JD-Core Version:    0.7.0.1
 */