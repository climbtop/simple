/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum UserIntegralRecordEnum
/*  7:   */ {
/*  8: 8 */   ORDER_EXCHANGE(1, "订单兑换"),  ADMIN_DONATE(2, "后台管理员赠送/扣除"),  PROMOTION_DONATION(3, "满额送积分"),  TASKCOMPLETE_DONATE(4, "任务完成送积分"),  EVALUATE_DONATE(5, "评价送积分"),  BACK_DONATE(6, "抵制余额积分回滚"),  ORDER_BACK_DONATE(7, "订单兑换积分回滚"),  RECHARGE_MONEY(8, "充值送积分");
/*  9:   */   
/* 10:   */   private int id;
/* 11:   */   private String name;
/* 12:   */   
/* 13:   */   private UserIntegralRecordEnum(int id, String name)
/* 14:   */   {
/* 15:22 */     this.id = id;
/* 16:23 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getId()
/* 20:   */   {
/* 21:27 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getName()
/* 25:   */   {
/* 26:31 */     return this.name;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setName(String name)
/* 30:   */   {
/* 31:35 */     this.name = name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static Map<Integer, String> list()
/* 35:   */   {
/* 36:42 */     Map<Integer, String> map = new HashMap();
/* 37:43 */     UserIntegralRecordEnum[] typeEnums = values();
/* 38:45 */     for (UserIntegralRecordEnum object : typeEnums) {
/* 39:46 */       map.put(Integer.valueOf(object.getId()), object.getName());
/* 40:   */     }
/* 41:49 */     return map;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserIntegralRecordEnum
 * JD-Core Version:    0.7.0.1
 */