/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsIfMixEnum
/*  4:   */ {
/*  5: 5 */   yes(1),  no(0);
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   
/*  9:   */   private GoodsIfMixEnum(int id)
/* 10:   */   {
/* 11:11 */     this.id = id;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public int getId()
/* 15:   */   {
/* 16:15 */     return this.id;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsIfMixEnum
 * JD-Core Version:    0.7.0.1
 */