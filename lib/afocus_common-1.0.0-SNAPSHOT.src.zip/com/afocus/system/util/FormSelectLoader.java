/*   1:    */ package com.afocus.system.util;
/*   2:    */ 
/*   3:    */ import java.util.SortedMap;
/*   4:    */ import java.util.TreeMap;
/*   5:    */ 
/*   6:    */ public class FormSelectLoader
/*   7:    */ {
/*   8: 10 */   private static final SortedMap<Integer, String> applicablePlatformMap = new TreeMap();
/*   9: 13 */   private static final SortedMap<Integer, String> orderStatusMap = new TreeMap();
/*  10: 16 */   private static final SortedMap<Integer, String> orderDelStatusMap = new TreeMap();
/*  11: 19 */   private static final SortedMap<Integer, String> userTypeMap = new TreeMap();
/*  12: 22 */   private static final SortedMap<Integer, String> modifyWayMap = new TreeMap();
/*  13: 25 */   private static final SortedMap<Integer, String> auditGoodsMap = new TreeMap();
/*  14: 28 */   private static final SortedMap<Integer, String> sexMap = new TreeMap();
/*  15: 31 */   private static final SortedMap<Integer, String> payStatusformMap = new TreeMap();
/*  16: 34 */   private static final SortedMap<Integer, String> userIntegralRecordTypeMap = new TreeMap();
/*  17: 37 */   private static final SortedMap<Integer, String> userFeedbackStatusMap = new TreeMap();
/*  18: 40 */   private static final SortedMap<Integer, String> taskActionStatusMap = new TreeMap();
/*  19: 43 */   private static final SortedMap<Integer, String> taskTypeMap = new TreeMap();
/*  20: 46 */   private static final SortedMap<Integer, String> taskCycleMap = new TreeMap();
/*  21: 49 */   private static final SortedMap<Integer, String> taskCompleteStatusMap = new TreeMap();
/*  22: 52 */   private static final SortedMap<Integer, String> integralExchangeConditionTypeMap = new TreeMap();
/*  23: 55 */   private static final SortedMap<Integer, String> userIntegralConsumeMap = new TreeMap();
/*  24: 58 */   private static final SortedMap<Integer, String> integralExchangeTargetMap = new TreeMap();
/*  25: 61 */   private static final SortedMap<Integer, String> integralExchangeTypeMap = new TreeMap();
/*  26: 64 */   private static final SortedMap<Integer, String> integralExchangeColumnMap = new TreeMap();
/*  27: 67 */   private static final SortedMap<String, String> expandCodeEnumTypeMap = new TreeMap();
/*  28: 70 */   private static final SortedMap<Integer, String> userMessageReceiverTypeMap = new TreeMap();
/*  29: 73 */   private static final SortedMap<Integer, String> userMessageSendTypeMap = new TreeMap();
/*  30: 76 */   private static final SortedMap<Integer, String> userMessageContentTypeMap = new TreeMap();
/*  31: 79 */   private static final SortedMap<Integer, String> userInfoCompleteStatusMap = new TreeMap();
/*  32: 82 */   private static final SortedMap<Integer, String> insuranceTypeMap = new TreeMap();
/*  33: 85 */   private static final SortedMap<Integer, String> userRechargeableCardStatusMap = new TreeMap();
/*  34: 88 */   private static final SortedMap<Integer, String> insuranceValidDateUnitMap = new TreeMap();
/*  35: 91 */   private static final SortedMap<Integer, String> insuranceCompanyMap = new TreeMap();
/*  36:    */   
/*  37:    */   public static SortedMap<Integer, String> getUserFeedbackStatusMap()
/*  38:    */   {
/*  39: 94 */     userFeedbackStatusMap.put(Integer.valueOf(UserFeedbackStatusEnum.FINISH.getId()), UserFeedbackStatusEnum.FINISH.getName());
/*  40: 95 */     userFeedbackStatusMap.put(Integer.valueOf(UserFeedbackStatusEnum.FINISH.getId()), UserFeedbackStatusEnum.FINISH.getName());
/*  41: 96 */     userFeedbackStatusMap.put(Integer.valueOf(UserFeedbackStatusEnum.HANDLING.getId()), UserFeedbackStatusEnum.HANDLING.getName());
/*  42:    */     
/*  43: 98 */     return userFeedbackStatusMap;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static SortedMap<Integer, String> getUserIntegralRecordTypeMap()
/*  47:    */   {
/*  48:102 */     userIntegralRecordTypeMap.putAll(UserIntegralRecordEnum.list());
/*  49:103 */     return userIntegralRecordTypeMap;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static SortedMap<Integer, String> getAuditGoodsMap()
/*  53:    */   {
/*  54:107 */     auditGoodsMap.put(Integer.valueOf(GoodsEvaluateEnum.AUDIT_NOT.getId()), GoodsEvaluateEnum.AUDIT_NOT.getName());
/*  55:108 */     auditGoodsMap.put(Integer.valueOf(GoodsEvaluateEnum.AUDITED_PASS.getId()), GoodsEvaluateEnum.AUDITED_PASS.getName());
/*  56:109 */     auditGoodsMap.put(Integer.valueOf(GoodsEvaluateEnum.AUDITED_NOTPASS.getId()), GoodsEvaluateEnum.AUDITED_NOTPASS.getName());
/*  57:110 */     auditGoodsMap.put(Integer.valueOf(GoodsEvaluateEnum.DELETED.getId()), GoodsEvaluateEnum.DELETED.getName());
/*  58:111 */     return auditGoodsMap;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static SortedMap<Integer, String> getApplicablePlatformMap()
/*  62:    */   {
/*  63:115 */     applicablePlatformMap.put(Integer.valueOf(ApplicablePlatformEnum.ALL.getId()), ApplicablePlatformEnum.ALL.getName());
/*  64:116 */     applicablePlatformMap.put(Integer.valueOf(ApplicablePlatformEnum.HTML5.getId()), ApplicablePlatformEnum.HTML5.getName());
/*  65:117 */     applicablePlatformMap.put(Integer.valueOf(ApplicablePlatformEnum.WEB.getId()), ApplicablePlatformEnum.WEB.getName());
/*  66:118 */     applicablePlatformMap.put(Integer.valueOf(ApplicablePlatformEnum.WECHAT.getId()), ApplicablePlatformEnum.WECHAT.getName());
/*  67:119 */     return applicablePlatformMap;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static SortedMap<Integer, String> getOrderStatusMap()
/*  71:    */   {
/*  72:123 */     orderStatusMap.put(Integer.valueOf(OrderStatusEnum.STATUS_NOT_PAY.getId()), OrderStatusEnum.STATUS_NOT_PAY.getName());
/*  73:124 */     orderStatusMap.put(Integer.valueOf(OrderStatusEnum.STATUS_WAIT_CONFIRM.getId()), OrderStatusEnum.STATUS_WAIT_CONFIRM.getName());
/*  74:125 */     orderStatusMap.put(Integer.valueOf(OrderStatusEnum.STATUS_WAIT_SEND.getId()), OrderStatusEnum.STATUS_WAIT_SEND.getName());
/*  75:126 */     orderStatusMap.put(Integer.valueOf(OrderStatusEnum.STATUS_SENDED.getId()), OrderStatusEnum.STATUS_SENDED.getName());
/*  76:127 */     orderStatusMap.put(Integer.valueOf(OrderStatusEnum.STATUS_FINISHED.getId()), OrderStatusEnum.STATUS_FINISHED.getName());
/*  77:128 */     orderStatusMap.put(Integer.valueOf(OrderStatusEnum.STATUS_CANCEL.getId()), OrderStatusEnum.STATUS_CANCEL.getName());
/*  78:129 */     return orderStatusMap;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static SortedMap<Integer, String> getOrderDelStatusMap()
/*  82:    */   {
/*  83:133 */     orderDelStatusMap.put(Integer.valueOf(OrderDelStatusEnum.DEL_STATUS_YES.getId()), OrderDelStatusEnum.DEL_STATUS_YES.getName());
/*  84:134 */     orderDelStatusMap.put(Integer.valueOf(OrderDelStatusEnum.DEL_STATUS_NO.getId()), OrderDelStatusEnum.DEL_STATUS_NO.getName());
/*  85:135 */     return orderDelStatusMap;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static SortedMap<Integer, String> getUserTypeMap()
/*  89:    */   {
/*  90:139 */     userTypeMap.putAll(UserTypeEnum.listAllTypes());
/*  91:140 */     return userTypeMap;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static SortedMap<Integer, String> getModifyWayMap()
/*  95:    */   {
/*  96:144 */     modifyWayMap.putAll(ModifyWayEnum.listAllTypes());
/*  97:145 */     return modifyWayMap;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static SortedMap<Integer, String> getSexMap()
/* 101:    */   {
/* 102:149 */     sexMap.put(Integer.valueOf(SexEnum.MALE.getId()), SexEnum.MALE.getName());
/* 103:150 */     sexMap.put(Integer.valueOf(SexEnum.FEMALE.getId()), SexEnum.FEMALE.getName());
/* 104:151 */     return sexMap;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static SortedMap<Integer, String> getPayStatusformMap()
/* 108:    */   {
/* 109:155 */     payStatusformMap.put(Integer.valueOf(OrderPayStatusEnum.PAY_STATUS_NO.getId()), OrderPayStatusEnum.PAY_STATUS_NO.getName());
/* 110:156 */     payStatusformMap.put(Integer.valueOf(OrderPayStatusEnum.PAY_STATUS_YES.getId()), OrderPayStatusEnum.PAY_STATUS_YES.getName());
/* 111:157 */     payStatusformMap.put(Integer.valueOf(OrderPayStatusEnum.PAY_STATUS_FAIL.getId()), OrderPayStatusEnum.PAY_STATUS_FAIL.getName());
/* 112:158 */     payStatusformMap.put(Integer.valueOf(OrderPayStatusEnum.PAY_STATUS_REFUND.getId()), OrderPayStatusEnum.PAY_STATUS_REFUND.getName());
/* 113:159 */     return payStatusformMap;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static SortedMap<Integer, String> getTaskStatusformMap()
/* 117:    */   {
/* 118:163 */     taskActionStatusMap.put(Integer.valueOf(TaskActionStatusEnum.UNABLE.getId()), TaskActionStatusEnum.UNABLE.getName());
/* 119:164 */     taskActionStatusMap.put(Integer.valueOf(TaskActionStatusEnum.ENABLED.getId()), TaskActionStatusEnum.ENABLED.getName());
/* 120:165 */     return taskActionStatusMap;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static SortedMap<Integer, String> getTaskTypeformMap()
/* 124:    */   {
/* 125:169 */     taskTypeMap.put(Integer.valueOf(TaskTypeEnum.FLOWTASK.getId()), TaskTypeEnum.FLOWTASK.getName());
/* 126:170 */     taskTypeMap.put(Integer.valueOf(TaskTypeEnum.POINTTASK.getId()), TaskTypeEnum.POINTTASK.getName());
/* 127:171 */     return taskTypeMap;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static SortedMap<Integer, String> getTaskCycleformMap()
/* 131:    */   {
/* 132:175 */     taskCycleMap.put(Integer.valueOf(TaskCycleEnum.NOCODITION.getId()), TaskCycleEnum.NOCODITION.getName());
/* 133:176 */     taskCycleMap.put(Integer.valueOf(TaskCycleEnum.ONCE.getId()), TaskCycleEnum.ONCE.getName());
/* 134:177 */     taskCycleMap.put(Integer.valueOf(TaskCycleEnum.EVERYDAY.getId()), TaskCycleEnum.EVERYDAY.getName());
/* 135:178 */     taskCycleMap.put(Integer.valueOf(TaskCycleEnum.WEEKLY.getId()), TaskCycleEnum.WEEKLY.getName());
/* 136:179 */     taskCycleMap.put(Integer.valueOf(TaskCycleEnum.MONTHLY.getId()), TaskCycleEnum.MONTHLY.getName());
/* 137:180 */     return taskCycleMap;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static SortedMap<Integer, String> getIntegralExchangeConditionTypeMap()
/* 141:    */   {
/* 142:184 */     integralExchangeConditionTypeMap.put(Integer.valueOf(IntegralExchangeConditionTypeEnum.MONEY.getId()), IntegralExchangeConditionTypeEnum.MONEY.getName());
/* 143:185 */     integralExchangeConditionTypeMap.put(Integer.valueOf(IntegralExchangeConditionTypeEnum.OFFSET_AMOUNT.getId()), IntegralExchangeConditionTypeEnum.OFFSET_AMOUNT.getName());
/* 144:186 */     return integralExchangeConditionTypeMap;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static SortedMap<Integer, String> getUserIntegralConsumeMap()
/* 148:    */   {
/* 149:190 */     userIntegralConsumeMap.put(Integer.valueOf(UserIntegralConsumeEnum.JOIN_MONEY_TO_GOODS.getId()), UserIntegralConsumeEnum.JOIN_MONEY_TO_GOODS.getName());
/* 150:191 */     userIntegralConsumeMap.put(Integer.valueOf(UserIntegralConsumeEnum.TO_COUPON.getId()), UserIntegralConsumeEnum.TO_COUPON.getName());
/* 151:192 */     userIntegralConsumeMap.put(Integer.valueOf(UserIntegralConsumeEnum.TO_GOODS.getId()), UserIntegralConsumeEnum.TO_GOODS.getName());
/* 152:193 */     userIntegralConsumeMap.put(Integer.valueOf(UserIntegralConsumeEnum.TO_MONEY.getId()), UserIntegralConsumeEnum.TO_MONEY.getName());
/* 153:194 */     userIntegralConsumeMap.put(Integer.valueOf(UserIntegralConsumeEnum.TO_ORDER.getId()), UserIntegralConsumeEnum.TO_ORDER.getName());
/* 154:195 */     return userIntegralConsumeMap;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static SortedMap<Integer, String> getIntegralExchangeTargetMap()
/* 158:    */   {
/* 159:199 */     integralExchangeTargetMap.putAll(IntegralExchangeTargetEnum.listAllTypes());
/* 160:200 */     return integralExchangeTargetMap;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static SortedMap<Integer, String> getIntegralExchangeTypeMap()
/* 164:    */   {
/* 165:204 */     integralExchangeTypeMap.putAll(IntegralExchangeTypeEnum.list());
/* 166:205 */     return integralExchangeTypeMap;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static SortedMap<Integer, String> getTaskCompleteStatusMap()
/* 170:    */   {
/* 171:209 */     taskCompleteStatusMap.put(Integer.valueOf(TaskCompleteStatusEnum.INITIALIZATION.getId()), TaskCompleteStatusEnum.INITIALIZATION.getName());
/* 172:210 */     taskCompleteStatusMap.put(Integer.valueOf(TaskCompleteStatusEnum.PROCESSING.getId()), TaskCompleteStatusEnum.PROCESSING.getName());
/* 173:211 */     taskCompleteStatusMap.put(Integer.valueOf(TaskCompleteStatusEnum.FINISH.getId()), TaskCompleteStatusEnum.FINISH.getName());
/* 174:212 */     taskCompleteStatusMap.put(Integer.valueOf(TaskCompleteStatusEnum.COMPLETED.getId()), TaskCompleteStatusEnum.COMPLETED.getName());
/* 175:213 */     return taskCompleteStatusMap;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static SortedMap<String, String> getExpandCodeEnumMap()
/* 179:    */   {
/* 180:217 */     expandCodeEnumTypeMap.putAll(ExpandCodeEnum.list());
/* 181:218 */     return expandCodeEnumTypeMap;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static SortedMap<Integer, String> getUserMessageReceiverMap()
/* 185:    */   {
/* 186:222 */     userMessageReceiverTypeMap.put(Integer.valueOf(UserMessageTypeEnum.RECEIVER_ALL.getId()), UserMessageTypeEnum.RECEIVER_ALL.getName());
/* 187:223 */     userMessageReceiverTypeMap.put(Integer.valueOf(UserMessageTypeEnum.RECEIVER_LEVEL.getId()), UserMessageTypeEnum.RECEIVER_LEVEL.getName());
/* 188:224 */     userMessageReceiverTypeMap.put(Integer.valueOf(UserMessageTypeEnum.RECEIVER_PERSONAL.getId()), UserMessageTypeEnum.RECEIVER_PERSONAL.getName());
/* 189:225 */     return userMessageReceiverTypeMap;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static SortedMap<Integer, String> getUserMessageSendMap()
/* 193:    */   {
/* 194:229 */     userMessageSendTypeMap.put(Integer.valueOf(UserMessageTypeEnum.SEND_ADMIN.getId()), UserMessageTypeEnum.SEND_ADMIN.getName());
/* 195:230 */     userMessageSendTypeMap.put(Integer.valueOf(UserMessageTypeEnum.SEND_SYSTEM.getId()), UserMessageTypeEnum.SEND_SYSTEM.getName());
/* 196:231 */     userMessageSendTypeMap.put(Integer.valueOf(UserMessageTypeEnum.SEND_THIRD.getId()), UserMessageTypeEnum.SEND_THIRD.getName());
/* 197:232 */     return userMessageSendTypeMap;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static SortedMap<Integer, String> getUserMessageContentMap()
/* 201:    */   {
/* 202:236 */     userMessageContentTypeMap.put(Integer.valueOf(UserMessageTypeEnum.CONTENT_CUSTOM.getId()), UserMessageTypeEnum.CONTENT_CUSTOM.getName());
/* 203:237 */     userMessageContentTypeMap.put(Integer.valueOf(UserMessageTypeEnum.CONTENT_MODEL.getId()), UserMessageTypeEnum.CONTENT_MODEL.getName());
/* 204:238 */     return userMessageContentTypeMap;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public static SortedMap<Integer, String> getIntegralExchangeColumnMap()
/* 208:    */   {
/* 209:242 */     integralExchangeColumnMap.putAll(IntegralExchangeColumnEnum.list());
/* 210:243 */     return integralExchangeColumnMap;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public static SortedMap<Integer, String> getUserRechargeableCardStatusMap()
/* 214:    */   {
/* 215:246 */     userRechargeableCardStatusMap.putAll(UserRechargeableCardStatusEnum.list());
/* 216:247 */     return userRechargeableCardStatusMap;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static SortedMap<Integer, String> getUserInfoCompleteStatusMap()
/* 220:    */   {
/* 221:251 */     userInfoCompleteStatusMap.put(Integer.valueOf(UserInfoCompleteStatusEnum.SEND_MAIL.getId()), UserInfoCompleteStatusEnum.SEND_MAIL.getName());
/* 222:252 */     userInfoCompleteStatusMap.put(Integer.valueOf(UserInfoCompleteStatusEnum.UNFINISH.getId()), UserInfoCompleteStatusEnum.UNFINISH.getName());
/* 223:253 */     userInfoCompleteStatusMap.put(Integer.valueOf(UserInfoCompleteStatusEnum.UNSEND_MAIL.getId()), UserInfoCompleteStatusEnum.UNSEND_MAIL.getName());
/* 224:254 */     return userInfoCompleteStatusMap;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public static SortedMap<Integer, String> getInsuranceTypeMap()
/* 228:    */   {
/* 229:258 */     insuranceTypeMap.putAll(InsuranceTypeEnum.listAllTypes());
/* 230:259 */     return insuranceTypeMap;
/* 231:    */   }
/* 232:    */   
/* 233:    */   public static SortedMap<Integer, String> getInsuranceValidDateUnitMap()
/* 234:    */   {
/* 235:263 */     insuranceValidDateUnitMap.putAll(InsuranceValidDateUnitEnum.listAllTypes());
/* 236:264 */     return insuranceValidDateUnitMap;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static SortedMap<Integer, String> getInsuranceCompanyMap()
/* 240:    */   {
/* 241:268 */     insuranceCompanyMap.putAll(InsuranceCompanyEnum.listAllTypes());
/* 242:269 */     return insuranceCompanyMap;
/* 243:    */   }
/* 244:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.FormSelectLoader
 * JD-Core Version:    0.7.0.1
 */