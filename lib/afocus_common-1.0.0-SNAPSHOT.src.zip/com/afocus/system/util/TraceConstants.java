package com.afocus.system.util;

public class TraceConstants
{
  public static final int TRACE_UC_REG_AUTO = 1;
  public static final int TRACE_UC_REG = 2;
  public static final int TRACE_UC_LOGIN = 3;
  public static final int TRACE_UC_ADD_MEMBER = 4;
  public static final int TRACE_UC_BINDING_EMAIL = 5;
  public static final int TRACE_UC_BINDING_PHONE = 6;
  public static final int TRACE_UC_FIND_PASSWORD = 7;
  public static final int TRACE_UC_UPDATE_PASSWORD = 8;
  public static final int TRACE_UC_CHANNEL_QQ = 1;
  public static final int TRACE_UC_CHANNEL_ZFB = 2;
  public static final int TRACE_UC_CHANNEL_SINA_WB = 3;
  public static final int TRACE_UC_CHANNEL_WECHAT_XYJ = 4;
  public static final int TRACE_UC_CHANNEL_WECHAT_SC = 5;
  public static final int TRACE_UC_CHANNEL_WECHAT_SM = 6;
  public static final int TRACE_UC_CHANNEL_GW = 7;
  public static final int TRACE_UC_CHANNEL_LH = 8;
  public static final int TRACE_UC_CHANNEL_WAP = 9;
  public static final int TRACE_MALL_GEN_ORDER = 1;
  public static final int TRACE_MALL_PAY_ORDER = 2;
  public static final int TRACE_MALL_CANCEL_ORDER = 3;
  public static final int TRACE_MALL_PAY_COD = 1;
  public static final int TRACE_MALL_PAY_KQ = 2;
  public static final int TRACE_MALL_PAY_ZFB = 3;
  public static final int TRACE_MALL_PLATFORM_GW = 1;
  public static final int TRACE_MALL_PLATFORM_WX = 2;
  public static final int TRACE_MALL_PLATFORM_JD = 3;
  public static final int TRACE_MALL_PLATFORM_TM = 4;
}


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.TraceConstants
 * JD-Core Version:    0.7.0.1
 */