/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum PrivateKey
/*  4:   */ {
/*  5:12 */   HAOYAO_PRIVATE_KEY("haoyao.com"),  LANHAI_PRIVATE_KEY("VOjqgrAi0Q6vxwYMHDtX6izGxjaxQfBi");
/*  6:   */   
/*  7:   */   private String value;
/*  8:   */   
/*  9:   */   private PrivateKey(String value)
/* 10:   */   {
/* 11:21 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getValue()
/* 15:   */   {
/* 16:25 */     return this.value;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setValue(String value)
/* 20:   */   {
/* 21:29 */     this.value = value;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.PrivateKey
 * JD-Core Version:    0.7.0.1
 */