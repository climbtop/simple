/*  1:   */ 
/*  2:   */ 
/*  3:   */ ActivitiesTypeEnum
/*  4:   */ 
/*  5: 5 */   CARD1, "卡劵", FULL2, "满额", SECKILL3, "秒杀", REST4, "限购"
/*  6:   */   
/*  7:   */   id
/*  8:   */   name
/*  9:   */   
/* 10:   */   ActivitiesTypeEnum, 
/* 11:   */   
/* 12:13 */     id = 
/* 13:14 */     name = 
/* 14:   */   
/* 15:   */   
/* 16:   */   getId
/* 17:   */   
/* 18:17 */     id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:20 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:23 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:26 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.ActivitiesTypeEnum
 * JD-Core Version:    0.7.0.1
 */