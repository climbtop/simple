/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsFavoriteStatusEnum
/*  4:   */ {
/*  5:14 */   FAVORITE_STATUS_DELETED(0, "已删除"),  FAVORITE_STATUS_NOT_DELETE(1, "未删除"),  FAVORITE_STATUS_NOT_PRIVACY(0, "非隐私设置"),  FAVORITE_STATUS_PRIVACY(1, "隐私设置");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private GoodsFavoriteStatusEnum(int id, String name)
/* 11:   */   {
/* 12:27 */     this.id = id;
/* 13:28 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:32 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:36 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:40 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:44 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:48 */     for (GoodsFavoriteStatusEnum userEnum : ) {
/* 39:49 */       if (id == userEnum.getId()) {
/* 40:50 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:53 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsFavoriteStatusEnum
 * JD-Core Version:    0.7.0.1
 */