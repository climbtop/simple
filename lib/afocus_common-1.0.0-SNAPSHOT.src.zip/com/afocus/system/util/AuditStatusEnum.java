/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum AuditStatusEnum
/*  4:   */ {
/*  5: 5 */   WAITING_AUDIT(0, "待审核"),  AUDIT_PASS(1, "审核通过"),  AUDIT_NOT_PASS(2, "审核不通过");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private AuditStatusEnum(int id, String name)
/* 11:   */   {
/* 12:12 */     this.id = id;
/* 13:13 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:16 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:19 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.AuditStatusEnum
 * JD-Core Version:    0.7.0.1
 */