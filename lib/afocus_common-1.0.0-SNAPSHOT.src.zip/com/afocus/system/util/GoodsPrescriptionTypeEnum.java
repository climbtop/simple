/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsPrescriptionTypeEnum
/*  4:   */ {
/*  5:17 */   OTHERS(0, "其它"),  OTC_A(1, "非处方药(甲类)"),  OTC_B(2, "非处方药(乙类)"),  Drugsprescription(3, "处方药"),  healthFood(4, "非药品"),  Drugsprescription_93(93, "单轨处方药");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private GoodsPrescriptionTypeEnum(int id, String name)
/* 11:   */   {
/* 12:30 */     this.id = id;
/* 13:31 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:35 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:39 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsPrescriptionTypeEnum
 * JD-Core Version:    0.7.0.1
 */