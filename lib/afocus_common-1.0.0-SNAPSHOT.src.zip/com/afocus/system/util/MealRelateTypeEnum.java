/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum MealRelateTypeEnum
/*  4:   */ {
/*  5:11 */   CALN(1, "同宗"),  FATHER_AND_SON(2, "父子");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private MealRelateTypeEnum(int id, String name)
/* 11:   */   {
/* 12:19 */     this.id = id;
/* 13:20 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:24 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:28 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.MealRelateTypeEnum
 * JD-Core Version:    0.7.0.1
 */