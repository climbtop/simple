/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum InsuranceCompanyEnum
/*  7:   */ {
/*  8: 8 */   ZHONGAN_COMP(1, "众安保险");
/*  9:   */   
/* 10:   */   int id;
/* 11:   */   String name;
/* 12:   */   
/* 13:   */   private InsuranceCompanyEnum(int id, String name)
/* 14:   */   {
/* 15:15 */     this.id = id;
/* 16:16 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getId()
/* 20:   */   {
/* 21:20 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setId(int id)
/* 25:   */   {
/* 26:24 */     this.id = id;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:28 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:32 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static Map<Integer, String> listAllTypes()
/* 40:   */   {
/* 41:36 */     Map<Integer, String> typesMap = new HashMap();
/* 42:37 */     InsuranceCompanyEnum[] enums = values();
/* 43:39 */     for (InsuranceCompanyEnum object : enums) {
/* 44:40 */       typesMap.put(Integer.valueOf(object.getId()), object.getName());
/* 45:   */     }
/* 46:43 */     return typesMap;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.InsuranceCompanyEnum
 * JD-Core Version:    0.7.0.1
 */