/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsImportTypeEnum
/*  4:   */ {
/*  5: 5 */   manual(0, "商城人工添加"),  goods_center(1, "商品中心导入"),  batch_import(2, "后台批量导入");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private GoodsImportTypeEnum(int id, String name)
/* 11:   */   {
/* 12:13 */     this.id = id;
/* 13:14 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:18 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:22 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsImportTypeEnum
 * JD-Core Version:    0.7.0.1
 */