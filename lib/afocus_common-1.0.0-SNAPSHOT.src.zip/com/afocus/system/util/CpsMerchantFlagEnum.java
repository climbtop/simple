/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ 
/*  5:   */ public enum CpsMerchantFlagEnum
/*  6:   */ {
/*  7: 5 */   CHANET("chanet", "成果网"),  EMAR("emar", "亿玛"),  DUOMAI("duomai", "多麦"),  BIGOU_51("51bi", "51比购"),  LANHAI("lanhai", "蓝海之略"),  CHUNYU("chunyu", "春雨"),  LINGKETE("lkt", "领克特"),  YWBD("ywbd", "有问必答"),  DIRECT("direct", "直接访问"),  BAIDU("baidu", "百度"),  TCLJKYL("tcljkyl", "TCL健康医疗"),  _39JKYD("39jkyd", "39健康网"),  BAIDUYD("baiduyd", "百度移动"),  TAIKANG("taikang", "泰康保险");
/*  8:   */   
/*  9:   */   String cpsFlag;
/* 10:   */   String name;
/* 11:   */   
/* 12:   */   private CpsMerchantFlagEnum(String cpsFlag, String name)
/* 13:   */   {
/* 14:26 */     this.cpsFlag = cpsFlag;
/* 15:27 */     this.name = name;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public String getCpsFlag()
/* 19:   */   {
/* 20:33 */     return this.cpsFlag;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setCpsFlag(String cpsFlag)
/* 24:   */   {
/* 25:39 */     this.cpsFlag = cpsFlag;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getName()
/* 29:   */   {
/* 30:45 */     return this.name;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void setName(String name)
/* 34:   */   {
/* 35:49 */     this.name = name;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static boolean isHave(String cpsFlag)
/* 39:   */   {
/* 40:52 */     for (CpsMerchantFlagEnum areaEnum : ) {
/* 41:53 */       if ((cpsFlag != null) && (cpsFlag.equalsIgnoreCase(areaEnum.getCpsFlag()))) {
/* 42:54 */         return true;
/* 43:   */       }
/* 44:   */     }
/* 45:57 */     return false;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static void main(String[] args)
/* 49:   */   {
/* 50:61 */     boolean bb = isHave(YWBD.getCpsFlag());
/* 51:62 */     System.out.println("" + bb);
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.CpsMerchantFlagEnum
 * JD-Core Version:    0.7.0.1
 */