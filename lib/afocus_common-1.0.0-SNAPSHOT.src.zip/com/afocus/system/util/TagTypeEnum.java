/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum TagTypeEnum
/*  4:   */ {
/*  5:18 */   USER_TAG(1, "用户标签"),  STANDING(10001, "常备"),  CHRONIC_DISEASE(10002, "常见慢性病"),  ELDERLY(10003, "老年"),  MALE(10004, "男性"),  FEMALE(10005, "女性"),  CHILD(10006, "儿童"),  TEENAGER(10007, "青少年"),  MATERNAL_AND_CHILD(10008, "母婴"),  BODY(10009, "身体情况"),  LIVING_HABIT(10010, "生活习惯"),  TREATMENT_STATUS(10011, "治疗状况"),  BRAND_TAG(2, "品牌标签"),  BRAND(20001, "品牌"),  MANAGER_TAG(3, "后台标签"),  PLACE_OF_PRODUCTION(30001, "产地"),  BACKSTAGE_TOP(30002, "后台一级分类"),  PRESCRIPTION(30003, "处方类型"),  MEDICAL_DEVICES(30004, "医疗器械分类"),  BACKSTAGE(30005, "后台分类"),  CUSTOM_TAG(4, "自定义标签"),  CUSTOM(40001, "自定义");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private TagTypeEnum(int id, String name)
/* 11:   */   {
/* 12:56 */     this.id = id;
/* 13:57 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:61 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:65 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:69 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:73 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static TagTypeEnum getEnumById(int id)
/* 37:   */   {
/* 38:77 */     TagTypeEnum[] typeEnums = values();
/* 39:78 */     for (int i = 0; i < typeEnums.length; i++) {
/* 40:79 */       if (typeEnums[i].getId() == id) {
/* 41:80 */         return typeEnums[i];
/* 42:   */       }
/* 43:   */     }
/* 44:83 */     return null;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.TagTypeEnum
 * JD-Core Version:    0.7.0.1
 */