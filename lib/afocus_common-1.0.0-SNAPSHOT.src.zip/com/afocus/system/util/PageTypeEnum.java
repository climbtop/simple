/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum PageTypeEnum
/*  4:   */ {
/*  5:12 */   PAGE_COMMON(0, "全网"),  PAGE_INDEX(1, "首页"),  PAGE_HEADER(2, "头部"),  PAGE_SEARCH(3, "搜索结果页"),  PAGE_CART(4, "购物车页面"),  PAGE_PROMOTION(5, "促销专区页面"),  PAGE_OVERSEAS(6, "海外购"),  PAGE_CHANNEL_CHINESEWESTERN(7, "中西药品频道"),  PAGE_CHANNEL_MEDICALDEVICES(8, "医疗器械频道"),  PAGE_CHANNEL_HEALTHCARE(9, "养生保健频道"),  PAGE_CHANNEL_HEALTHSUPPLIES(10, "计生用品频道"),  PAGE_CHANNEL_PERSONALCARE(11, "个护美装频道"),  PAGE_OVERSEAS_USA(12, "海外购-美国馆"),  PAGE_OVERSEAS_AUS(13, "海外购-澳洲馆"),  PAGE_OVERSEAS_TAIWAN(14, "海外购-台湾馆"),  PAGE_OVERSEAS_JAPAN(15, "海外购-日本馆");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private PageTypeEnum(int id, String name)
/* 11:   */   {
/* 12:35 */     this.id = id;
/* 13:36 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:40 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:44 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:48 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:52 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.PageTypeEnum
 * JD-Core Version:    0.7.0.1
 */