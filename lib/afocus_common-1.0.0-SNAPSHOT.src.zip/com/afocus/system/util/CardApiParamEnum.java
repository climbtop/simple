/*   1:    */ package com.afocus.system.util;
/*   2:    */ 
/*   3:    */ public enum CardApiParamEnum
/*   4:    */ {
/*   5:  9 */   id("id"),  cardType("cardType"),  logoUrl("logoUrl"),  imgUrl("imgUrl"),  codeType("codeType"),  brandName("brandName"),  title("title"),  subTitle("subTitle"),  color("color"),  notice("notice"),  servicePhone("servicePhone"),  description("description"),  timeType("timeType"),  beginTime("beginTime"),  endTime("endTime"),  fixedTerm("fixedTerm"),  detail("detail"),  maxCount("maxCount"),  times("times"),  status("status"),  leastCost("leastCost"),  reduceValue("reduceValue"),  scope("scope"),  composition("composition"),  createDate("createDate"),  createUserId("createUserId"),  updateDate("updateDate"),  updateUserId("updateUserId"),  getLimit("getLimit"),  customUrlName("customUrlName"),  customUrl("customUrl"),  wxCardId("wxCardId"),  wxStatus("wxStatus"),  supplyBonus("supplyBonus"),  supplyBalance("supplyBalance"),  bonusCleared("bonusCleared"),  bonusRules("bonusRules"),  balanceRules("balanceRules"),  prerogative("prerogative"),  bindOldCardUrl("bindOldCardUrl"),  activateUrl("activateUrl"),  companyId("companyId"),  needPushOnView("needPushOnView"),  useCustomCode("useCustomCode"),  bindOpenid("bindOpenid"),  canShare("canShare"),  canGiveFriend("canGiveFriend"),  source("source"),  customUrlSubTitle("customUrlSubTitle"),  promotionUrlName("promotionUrlName"),  promotionUrl("promotionUrl"),  promotionUrlSubTitle("promotionUrlSubTitle"),  pushTarget("pushTarget"),  bonusUrl("bonusUrl"),  balanceUrl("balanceUrl"),  supplyCustomField("supplyCustomField"),  customFieldNameType("customFieldNameType"),  customFieldUrl("customFieldUrl"),  customCellName("customCellName"),  customCellTips("customCellTips"),  customCellUrl("customCellUrl"),  isGet("isGet"),  cid("cid"),  code("code"),  bindStatus("bindStatus"),  bindUserId("bindUserId"),  bindDate("bindDate"),  cstatus("cstatus"),  cardId("cardId"),  batchId("batchId"),  bid("bid"),  genCount("genCount"),  bindCount("bindCount"),  batchStatus("batchStatus"),  batchDesc("batchDesc"),  ccid("ccid"),  operator("operator"),  userId("userId"),  orderSn("orderSn"),  amount("amount"),  ccstatus("ccstatus"),  cardCodeId("cardCodeId"),  codeCount("codeCount"),  gtBindDate("gtBindDate"),  itBindDate("itBindDate"),  beginDate("beginDate"),  endDate("endDate");
/*   6:    */   
/*   7:    */   private String paramName;
/*   8:    */   
/*   9:    */   private CardApiParamEnum(String paramName)
/*  10:    */   {
/*  11:108 */     this.paramName = paramName;
/*  12:    */   }
/*  13:    */   
/*  14:    */   public String getParamName()
/*  15:    */   {
/*  16:112 */     return this.paramName;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void setParamName(String paramName)
/*  20:    */   {
/*  21:116 */     this.paramName = paramName;
/*  22:    */   }
/*  23:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.CardApiParamEnum
 * JD-Core Version:    0.7.0.1
 */