/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum ApplicablePlatformEnum
/*  4:   */ {
/*  5: 8 */   ALL(0, "全网"),  WEB(1, "官网"),  HTML5(2, "移动官网"),  WECHAT(3, "微信"),  SERVICE(4, "客服代注册"),  AGENCY_TRADE(5, "代下单");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private ApplicablePlatformEnum(int id, String name)
/* 11:   */   {
/* 12:18 */     this.id = id;
/* 13:19 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:23 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:27 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:31 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:35 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:39 */     for (ApplicablePlatformEnum areaEnum : ) {
/* 39:40 */       if (id == areaEnum.getId()) {
/* 40:41 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:44 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.ApplicablePlatformEnum
 * JD-Core Version:    0.7.0.1
 */