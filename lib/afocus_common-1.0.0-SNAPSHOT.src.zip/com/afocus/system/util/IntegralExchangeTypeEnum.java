/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum IntegralExchangeTypeEnum
/*  7:   */ {
/*  8:13 */   TO_COUPON(1, "积分兑换优惠券"),  TO_GOODS(2, "积分兑换商品"),  JOIN_MONEY_TO_GOODS(3, "金额+积分兑换商品"),  TO_CDKEY(4, "积分兑换激活码");
/*  9:   */   
/* 10:   */   int id;
/* 11:   */   String name;
/* 12:   */   
/* 13:   */   private IntegralExchangeTypeEnum(int id, String name)
/* 14:   */   {
/* 15:22 */     this.id = id;
/* 16:23 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getId()
/* 20:   */   {
/* 21:26 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setId(int id)
/* 25:   */   {
/* 26:29 */     this.id = id;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:32 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:35 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static Map<Integer, String> list()
/* 40:   */   {
/* 41:42 */     Map<Integer, String> map = new HashMap();
/* 42:43 */     IntegralExchangeTypeEnum[] typeEnums = values();
/* 43:45 */     for (IntegralExchangeTypeEnum object : typeEnums) {
/* 44:46 */       map.put(Integer.valueOf(object.getId()), object.getName());
/* 45:   */     }
/* 46:49 */     return map;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.IntegralExchangeTypeEnum
 * JD-Core Version:    0.7.0.1
 */