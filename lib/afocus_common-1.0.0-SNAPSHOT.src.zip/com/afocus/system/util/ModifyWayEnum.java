/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum ModifyWayEnum
/*  7:   */ {
/*  8:14 */   COMMON(1, "常规修改"),  EMAIL(2, "邮箱修改"),  PHONE(3, "短信修改");
/*  9:   */   
/* 10:   */   String name;
/* 11:   */   int type;
/* 12:   */   
/* 13:   */   private ModifyWayEnum(int type, String name)
/* 14:   */   {
/* 15:23 */     this.name = name;
/* 16:24 */     this.type = type;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getName()
/* 20:   */   {
/* 21:28 */     return this.name;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setName(String name)
/* 25:   */   {
/* 26:32 */     this.name = name;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public int getType()
/* 30:   */   {
/* 31:36 */     return this.type;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setType(int type)
/* 35:   */   {
/* 36:40 */     this.type = type;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String toString()
/* 40:   */   {
/* 41:45 */     return this.name;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public static ModifyWayEnum getByType(int type)
/* 45:   */   {
/* 46:54 */     ModifyWayEnum[] typeEnums = values();
/* 47:55 */     for (int i = 0; i < typeEnums.length; i++) {
/* 48:56 */       if (typeEnums[i].getType() == type) {
/* 49:57 */         return typeEnums[i];
/* 50:   */       }
/* 51:   */     }
/* 52:60 */     return null;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public static Map<Integer, String> listAllTypes()
/* 56:   */   {
/* 57:68 */     Map<Integer, String> typesMap = new HashMap();
/* 58:69 */     ModifyWayEnum[] typeEnums = values();
/* 59:71 */     for (ModifyWayEnum utype : typeEnums) {
/* 60:72 */       typesMap.put(Integer.valueOf(utype.getType()), utype.getName());
/* 61:   */     }
/* 62:75 */     return typesMap;
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.ModifyWayEnum
 * JD-Core Version:    0.7.0.1
 */