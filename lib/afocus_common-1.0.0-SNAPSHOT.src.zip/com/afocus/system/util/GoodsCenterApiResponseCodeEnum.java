/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum GoodsCenterApiResponseCodeEnum
/*  4:   */ {
/*  5:14 */   CODE_1(1, "请求成功"),  CODE_2(2, "请求失败-参数格式错误"),  CODE_3(3, "请求失败-无数据");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private GoodsCenterApiResponseCodeEnum(int id, String name)
/* 11:   */   {
/* 12:22 */     this.id = id;
/* 13:23 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:27 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:31 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:35 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:39 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsCenterApiResponseCodeEnum
 * JD-Core Version:    0.7.0.1
 */