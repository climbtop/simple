/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum CpsUserIfAdminEnum
/*  4:   */ {
/*  5: 4 */   yes(1, "管理员"),  no(0, "一般用户");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private CpsUserIfAdminEnum(int id, String name)
/* 11:   */   {
/* 12:10 */     this.id = id;
/* 13:11 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:15 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:19 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:23 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:27 */     this.name = name;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.CpsUserIfAdminEnum
 * JD-Core Version:    0.7.0.1
 */