/*   1:    */ package com.afocus.system.util;
/*   2:    */ 
/*   3:    */ public enum CouponTypeEnum
/*   4:    */ {
/*   5: 11 */   COUPON_TYPE_ALL(0, "适用全网"),  COUPON_STATUS_0(0, "未使用"),  COUPON_STATUS_1(1, "已使用"),  COUPON_STATUS_2(2, "已删除"),  COUPON_STATUS_3(3, "已过期"),  IS_SHOW_0(0, "隐藏"),  IS_SHOW_1(1, "显示"),  IS_SHOW_2(2, "特殊"),  BING_STATUS_0(0, "未绑定"),  BING_STATUS_1(1, "已绑定"),  IS_TIMES_0(0, "一次使用"),  IS_TIMES_1(1, "多次使用"),  FULL_ACTIVITY_TYPE_OK(0, "正常"),  FULL_ACTIVITY_TYPE_OUT(1, "过期"),  FULL_ACTIVITY_TYPE_DEL(2, "删除"),  FULL_ACTIVITY_TYPE_MINUS(1, "满额减金额"),  FULL_ACTIVITY_TYPE_POST(3, "满额包邮"),  PROMOTION_TYPE_1(1, "优惠劵"),  PROMOTION_TYPE_2(2, "满额活动"),  SEKILL_STATUS_0(0, "未开始"),  SEKILL_STATUS_1(1, "秒杀中"),  SEKILL_STATUS_2(2, "已结束"),  SEKILL_STATUS_3(3, "已删除"),  COUPON_HIDDEN(0, "不显示"),  COUPON_SHOW(1, "显示"),  GOODS_GROUP_OK(1, "正常"),  GOODS_GROUP_DEL(2, "删除"),  OPER_STATUS_OK(1, "成功"),  OPER_STATUS_ERR(2, "失败"),  USER_OPER_COUPON_1(1, "获取"),  USER_OPER_COUPON_2(2, "使用"),  USER_OPER_COUPON_3(3, "生成"),  USER_OPER_COUPON_4(4, "返还"),  COUPON_LEVEL_0(0, "0"),  COUPON_LEVEL_1(1, "1"),  COUPON_LEVEL_2(2, "2"),  COUPON_LEVEL_3(3, "3"),  COUPON_LEVEL_4(4, "4"),  COUPON_LEVEL_5(5, "5"),  COUPON_LEVEL_6(6, "6"),  COUPON_LEVEL_7(7, "7"),  COUPON_LEVEL_8(8, "8"),  COUPON_LEVEL_9(9, "9");
/*   6:    */   
/*   7:    */   int id;
/*   8:    */   String name;
/*   9:    */   
/*  10:    */   private CouponTypeEnum(int id, String name)
/*  11:    */   {
/*  12: 89 */     this.id = id;
/*  13: 90 */     this.name = name;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public int getId()
/*  17:    */   {
/*  18: 94 */     return this.id;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setId(int id)
/*  22:    */   {
/*  23: 98 */     this.id = id;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public String getName()
/*  27:    */   {
/*  28:102 */     return this.name;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setName(String name)
/*  32:    */   {
/*  33:106 */     this.name = name;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static boolean isHave(int id)
/*  37:    */   {
/*  38:110 */     for (CouponTypeEnum couponTypeEnum : ) {
/*  39:111 */       if (id == couponTypeEnum.getId()) {
/*  40:112 */         return true;
/*  41:    */       }
/*  42:    */     }
/*  43:115 */     return false;
/*  44:    */   }
/*  45:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.CouponTypeEnum
 * JD-Core Version:    0.7.0.1
 */