package com.afocus.system.util;

public class StoreConstants
{
  public static final int STORE_ID_SELF = 100;
  public static final String STORE_NAME_SELF = "好药师官方商城";
}


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.StoreConstants
 * JD-Core Version:    0.7.0.1
 */