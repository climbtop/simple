/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum MemberApiEnum
/*  4:   */ {
/*  5: 7 */   msn("msn"),  wci("wci"),  cc("cc"),  abt("abt"),  aet("aet"),  mnt("mnt"),  ibs("ibs"),  ibe("ibe"),  field("field"),  oId("oId"),  uId("uId"),  addBonus("addBonus"),  recordBonus("recordBonus"),  bonusType("bonusType"),  addBlance("addBlance"),  recordBlance("recordBlance"),  balanceType("balanceType"),  fieldDetail("fieldDetail"),  actType("actType");
/*  6:   */   
/*  7:   */   private String name;
/*  8:   */   
/*  9:   */   private MemberApiEnum(String name)
/* 10:   */   {
/* 11:33 */     this.name = name;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getName()
/* 15:   */   {
/* 16:37 */     return this.name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setName(String name)
/* 20:   */   {
/* 21:41 */     this.name = name;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.MemberApiEnum
 * JD-Core Version:    0.7.0.1
 */