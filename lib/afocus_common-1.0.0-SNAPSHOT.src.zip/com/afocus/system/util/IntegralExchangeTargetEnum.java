/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ public enum IntegralExchangeTargetEnum
/*  7:   */ {
/*  8:13 */   COUPON(1, "优惠券"),  GOODS(2, "商品"),  CDKEY(3, "激活码");
/*  9:   */   
/* 10:   */   int id;
/* 11:   */   String name;
/* 12:   */   
/* 13:   */   private IntegralExchangeTargetEnum(int id, String name)
/* 14:   */   {
/* 15:21 */     this.id = id;
/* 16:22 */     this.name = name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getId()
/* 20:   */   {
/* 21:25 */     return this.id;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setId(int id)
/* 25:   */   {
/* 26:28 */     this.id = id;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName()
/* 30:   */   {
/* 31:31 */     return this.name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setName(String name)
/* 35:   */   {
/* 36:34 */     this.name = name;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static Map<Integer, String> listAllTypes()
/* 40:   */   {
/* 41:38 */     Map<Integer, String> typesMap = new HashMap();
/* 42:39 */     IntegralExchangeTargetEnum[] enums = values();
/* 43:41 */     for (IntegralExchangeTargetEnum object : enums) {
/* 44:42 */       typesMap.put(Integer.valueOf(object.getId()), object.getName());
/* 45:   */     }
/* 46:45 */     return typesMap;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.IntegralExchangeTargetEnum
 * JD-Core Version:    0.7.0.1
 */