/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum SearchApiUrlParamEnum
/*  4:   */ {
/*  5:12 */   keyword("q"),  pageSize("ps"),  pageNo("pn"),  highLight("hl"),  sortFields("sf"),  firstCategory("fct"),  categories("cts"),  level("lvl"),  brands("bds"),  places("plcs"),  dosage("dsg"),  drugType("dt"),  itemId("itd"),  channel("cl"),  price("pc"),  marketPrice("mpc"),  matchField("mf");
/*  6:   */   
/*  7:   */   String paramName;
/*  8:   */   
/*  9:   */   private SearchApiUrlParamEnum(String name)
/* 10:   */   {
/* 11:35 */     this.paramName = name;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getParamName()
/* 15:   */   {
/* 16:39 */     return this.paramName;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setParamName(String paramName)
/* 20:   */   {
/* 21:43 */     this.paramName = paramName;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString()
/* 25:   */   {
/* 26:48 */     return this.paramName;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.SearchApiUrlParamEnum
 * JD-Core Version:    0.7.0.1
 */