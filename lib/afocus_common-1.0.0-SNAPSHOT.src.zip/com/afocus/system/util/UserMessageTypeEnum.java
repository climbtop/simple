/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum UserMessageTypeEnum
/*  4:   */ {
/*  5:13 */   RECEIVER_ALL(1, "全场"),  RECEIVER_PERSONAL(2, "个人"),  RECEIVER_LEVEL(3, "等级"),  SEND_SYSTEM(1, "系统下发"),  SEND_ADMIN(2, "后台下发"),  SEND_THIRD(3, "第三方下发"),  CONTENT_MODEL(1, "模板"),  CONTENT_CUSTOM(2, "自定义");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private UserMessageTypeEnum(int id, String name)
/* 11:   */   {
/* 12:30 */     this.id = id;
/* 13:31 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:35 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:39 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:43 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:47 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:51 */     for (UserMessageTypeEnum userEnum : ) {
/* 39:52 */       if (id == userEnum.getId()) {
/* 40:53 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:56 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserMessageTypeEnum
 * JD-Core Version:    0.7.0.1
 */