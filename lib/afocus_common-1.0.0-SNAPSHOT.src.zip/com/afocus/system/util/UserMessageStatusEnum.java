/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum UserMessageStatusEnum
/*  4:   */ {
/*  5:15 */   DELETE(0, "删除"),  UNREAD(1, "未读"),  READ(2, "已读"),  UNRECIEVE(0, "未发送"),  RECIEVE(1, "已发送"),  UNVERIFY(0, "未验证"),  VERIFY(1, "已验证");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private UserMessageStatusEnum(int id, String name)
/* 11:   */   {
/* 12:30 */     this.id = id;
/* 13:31 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:35 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:39 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:43 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:47 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:51 */     for (UserMessageStatusEnum userEnum : ) {
/* 39:52 */       if (id == userEnum.getId()) {
/* 40:53 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:56 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserMessageStatusEnum
 * JD-Core Version:    0.7.0.1
 */