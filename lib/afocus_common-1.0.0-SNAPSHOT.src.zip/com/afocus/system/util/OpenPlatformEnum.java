/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OpenPlatformEnum
/*  4:   */ {
/*  5: 4 */   WECHAT_MALL(1, "微信商城"),  WECHAT_HDC(2, "微信血压计"),  QQ(3, "QQ"),  SINAWEIBO(4, "新浪微博"),  ALIPAY(5, "支付宝"),  WECHART_QR(6, "微信二维码扫描"),  LANHAI(7, "蓝海"),  CHUNYUYISHENG(8, "春雨医生"),  TAIKANG(9, "泰康"),  TCL(10, "TCL"),  CAIBEI(11, "彩贝"),  PINGAN(12, "平安"),  WECHAT_LENOVO(13, "微信联想");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private OpenPlatformEnum(int id, String name)
/* 11:   */   {
/* 12:22 */     this.id = id;
/* 13:23 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:27 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:31 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:35 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:39 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(int id)
/* 37:   */   {
/* 38:43 */     for (OpenPlatformEnum areaEnum : ) {
/* 39:44 */       if (id == areaEnum.getId()) {
/* 40:45 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:48 */     return false;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OpenPlatformEnum
 * JD-Core Version:    0.7.0.1
 */