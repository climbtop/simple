/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ 
/*  5:   */ public enum PaymentKeyEnum
/*  6:   */ {
/*  7: 8 */   alipayDirect("alipayDirect", "支付宝（即时到账）"),  tenpayDirect("tenpayDirect", "财付富（即时到账）"),  pay99billDirect("pay99billDirect", "快钱（即时到账）"),  taikang_weixinPay("taikang_weixinPay", "泰康微信支付");
/*  8:   */   
/*  9:   */   private String paymentKey;
/* 10:   */   private String paymentName;
/* 11:   */   
/* 12:   */   private PaymentKeyEnum(String paymentKey, String paymentName)
/* 13:   */   {
/* 14:24 */     this.paymentKey = paymentKey;
/* 15:25 */     this.paymentName = paymentName;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static boolean isHave(String paymentKey)
/* 19:   */   {
/* 20:29 */     if (paymentKey != null) {
/* 21:30 */       for (PaymentKeyEnum value : values()) {
/* 22:31 */         if (paymentKey.equals(value.getPaymentKey())) {
/* 23:32 */           return true;
/* 24:   */         }
/* 25:   */       }
/* 26:   */     }
/* 27:36 */     return false;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static String getNameByKey(String paymentKey)
/* 31:   */   {
/* 32:39 */     if (!isNullOrBlank(paymentKey)) {
/* 33:40 */       for (PaymentKeyEnum value : values()) {
/* 34:41 */         if (paymentKey.equals(value.getPaymentKey())) {
/* 35:42 */           return value.getPaymentName();
/* 36:   */         }
/* 37:   */       }
/* 38:   */     }
/* 39:46 */     return null;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static boolean isNullOrBlank(String str)
/* 43:   */   {
/* 44:50 */     if (str == null) {
/* 45:51 */       return true;
/* 46:   */     }
/* 47:53 */     str = str.trim();
/* 48:54 */     if (!str.equals("")) {
/* 49:55 */       return false;
/* 50:   */     }
/* 51:57 */     return true;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static void main(String[] args)
/* 55:   */   {
/* 56:62 */     String ifExist = getNameByKey("pay99billDirect");
/* 57:63 */     System.out.println("ifExist:" + ifExist);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String getPaymentKey()
/* 61:   */   {
/* 62:67 */     return this.paymentKey;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public void setPaymentKey(String paymentKey)
/* 66:   */   {
/* 67:71 */     this.paymentKey = paymentKey;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public String getPaymentName()
/* 71:   */   {
/* 72:75 */     return this.paymentName;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public void setPaymentName(String paymentName)
/* 76:   */   {
/* 77:79 */     this.paymentName = paymentName;
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.PaymentKeyEnum
 * JD-Core Version:    0.7.0.1
 */