/*   1:    */ package com.afocus.system.util;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public enum GoodsEvaluateEnum
/*   7:    */ {
/*   8: 13 */   PRAISE(1, "赞"),  TRAMPLE(0, "踩"),  CONTENT_TYPE_ASK(1, "商品咨询"),  CONTENT_TYPE_EVALUATE(2, "商品评价"),  CONTENT_TYPE_ARTIFICIAL(3, "人工导入"),  AUDIT_NOT(0, "未审核"),  AUDITED_PASS(1, "审核通过"),  AUDITED_NOTPASS(2, "审核不通过"),  DELETED(3, "删除"),  SORT_CREATE_TIME(1, "按时间排序"),  SORT_PRAISE(2, "踩/赞排序"),  SORT_PHARMACIST(3, "用户身份排序"),  SORT_COMBINATION(4, "组合排序"),  SORT_RECOMMEND(5, "推荐组合排序"),  IS_PHARMACIST_EVALUATE_NO(0, "不是药师评价"),  IS_PHARMACIST_EVALUATE_YES(1, "是药师评价"),  HOT_EVALUATE_NO(0, "不是最热评价"),  HOT_EVALUATE_YES(1, "是最热评价");
/*   9:    */   
/*  10:    */   private int id;
/*  11:    */   private String name;
/*  12:    */   
/*  13:    */   private GoodsEvaluateEnum(int id, String name)
/*  14:    */   {
/*  15: 41 */     this.id = id;
/*  16: 42 */     this.name = name;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public int getId()
/*  20:    */   {
/*  21: 46 */     return this.id;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void setId(int id)
/*  25:    */   {
/*  26: 50 */     this.id = id;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public String getName()
/*  30:    */   {
/*  31: 54 */     return this.name;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setName(String name)
/*  35:    */   {
/*  36: 58 */     this.name = name;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static boolean isHave(int id)
/*  40:    */   {
/*  41: 62 */     for (GoodsEvaluateEnum goodsEnum : ) {
/*  42: 63 */       if (id == goodsEnum.getId()) {
/*  43: 64 */         return true;
/*  44:    */       }
/*  45:    */     }
/*  46: 67 */     return false;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static int getStarLevel(int score)
/*  50:    */   {
/*  51: 76 */     int level = 0;
/*  52: 77 */     if ((score >= 0) && (score < 3)) {
/*  53: 78 */       level = 1;
/*  54: 79 */     } else if ((score >= 3) && (score < 5)) {
/*  55: 80 */       level = 2;
/*  56: 81 */     } else if ((score >= 5) && (score < 7)) {
/*  57: 82 */       level = 3;
/*  58: 83 */     } else if ((score >= 7) && (score <= 9)) {
/*  59: 84 */       level = 4;
/*  60: 85 */     } else if (score == 10) {
/*  61: 86 */       level = 5;
/*  62:    */     }
/*  63: 88 */     return level;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static List<Integer> getSortList()
/*  67:    */   {
/*  68: 97 */     List<Integer> list = new ArrayList();
/*  69: 98 */     list.add(Integer.valueOf(SORT_COMBINATION.getId()));
/*  70: 99 */     list.add(Integer.valueOf(SORT_CREATE_TIME.getId()));
/*  71:100 */     list.add(Integer.valueOf(SORT_PHARMACIST.getId()));
/*  72:101 */     list.add(Integer.valueOf(SORT_PRAISE.getId()));
/*  73:102 */     list.add(Integer.valueOf(SORT_RECOMMEND.getId()));
/*  74:103 */     return list;
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsEvaluateEnum
 * JD-Core Version:    0.7.0.1
 */