/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum DataCachePrefixKeyEnum
/*  4:   */ {
/*  5:16 */   ucenter("_ucenter_"),  mall("_mall_"),  order("_order_"),  trace("_trace_"),  admin("_admin_"),  hdc("_hdc_"),  promotion("_promotion_"),  qywechat("qywechat_"),  table("table_"),  constants("constants_");
/*  6:   */   
/*  7:   */   String prefixKeyName;
/*  8:   */   
/*  9:   */   private DataCachePrefixKeyEnum(String prefixKeyName)
/* 10:   */   {
/* 11:40 */     this.prefixKeyName = prefixKeyName;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getPrefixKeyName()
/* 15:   */   {
/* 16:43 */     return this.prefixKeyName;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setPrefixKeyName(String prefixKeyName)
/* 20:   */   {
/* 21:46 */     this.prefixKeyName = prefixKeyName;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString()
/* 25:   */   {
/* 26:51 */     return this.prefixKeyName;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.DataCachePrefixKeyEnum
 * JD-Core Version:    0.7.0.1
 */