/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum KeywordTypeEnum
/*  4:   */ {
/*  5:12 */   HOT("hot", "HOT（热门关键词,提交给推荐宝时使用）"),  MALL("mall", "MALL（商城内部使用）");
/*  6:   */   
/*  7:   */   private String type;
/*  8:   */   private String desc;
/*  9:   */   
/* 10:   */   private KeywordTypeEnum(String type, String desc)
/* 11:   */   {
/* 12:20 */     this.type = type;
/* 13:21 */     this.desc = desc;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getType()
/* 17:   */   {
/* 18:25 */     return this.type;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getDesc()
/* 22:   */   {
/* 23:29 */     return this.desc;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.KeywordTypeEnum
 * JD-Core Version:    0.7.0.1
 */