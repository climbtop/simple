/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderIfPrescEnum
/*  4:   */ {
/*  5: 5 */   no(0, "否"),  yes(1, "是");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private OrderIfPrescEnum(int id, String name)
/* 11:   */   {
/* 12:11 */     this.id = id;
/* 13:12 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:15 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:18 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderIfPrescEnum
 * JD-Core Version:    0.7.0.1
 */