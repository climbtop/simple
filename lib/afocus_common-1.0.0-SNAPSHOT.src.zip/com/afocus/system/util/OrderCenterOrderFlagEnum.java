/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum OrderCenterOrderFlagEnum
/*  4:   */ {
/*  5: 8 */   CDEHY("cdehy", OrderProduceSourceEnum.CDEHY.getCode()),  CN21("cn21", OrderProduceSourceEnum.CN21.getCode()),  DDW("ddw", OrderProduceSourceEnum.DDW.getCode()),  EHY("EHY", OrderProduceSourceEnum.PHP_MALL.getCode()),  JD("JD", OrderProduceSourceEnum.JD.getCode()),  LYSOP("lysop", OrderProduceSourceEnum.LYSOP.getCode()),  LYSOP2("lysop2", OrderProduceSourceEnum.LYSOP2.getCode()),  MSJK("MSJK", OrderProduceSourceEnum.MSJK.getCode()),  SOP("SOP", OrderProduceSourceEnum.SOP.getCode()),  TBHYS("tbhys", OrderProduceSourceEnum.TBHYS.getCode()),  WX("wx", OrderProduceSourceEnum.WX.getCode()),  HYSGW("HYSGW", OrderProduceSourceEnum.EHY.getCode()),  WXSHOP("wxshop", OrderProduceSourceEnum.WXSHOP.getCode()),  JDSG("JDSG", OrderProduceSourceEnum.JDSG.getCode()),  YHD("yhd", OrderProduceSourceEnum.YHD.getCode()),  MEHY("MEHY", OrderProduceSourceEnum.MOBILE.getCode()),  DXD("DXD", "DXD"),  CFY("CFY", "CFY"),  HYDD("HYDD", "HYDD"),  JSLA("JSLA", "JSLA");
/*  6:   */   
/*  7:   */   private String orderFlag;
/*  8:   */   private String produceSource;
/*  9:   */   
/* 10:   */   public String getOrderFlag()
/* 11:   */   {
/* 12:35 */     return this.orderFlag;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setOrderFlag(String orderFlag)
/* 16:   */   {
/* 17:39 */     this.orderFlag = orderFlag;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getProduceSource()
/* 21:   */   {
/* 22:43 */     return this.produceSource;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setProduceSource(String produceSource)
/* 26:   */   {
/* 27:47 */     this.produceSource = produceSource;
/* 28:   */   }
/* 29:   */   
/* 30:   */   private OrderCenterOrderFlagEnum(String orderFlag, String produceSource)
/* 31:   */   {
/* 32:51 */     this.produceSource = produceSource;
/* 33:52 */     this.orderFlag = orderFlag;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static boolean isHave(String orderFlag)
/* 37:   */   {
/* 38:56 */     for (OrderCenterOrderFlagEnum e : ) {
/* 39:57 */       if (orderFlag.equals(e.getOrderFlag())) {
/* 40:58 */         return true;
/* 41:   */       }
/* 42:   */     }
/* 43:61 */     return false;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static String getOrderFlag(String produceSource)
/* 47:   */   {
/* 48:66 */     for (OrderCenterOrderFlagEnum inst : ) {
/* 49:67 */       if (produceSource.equals(inst.produceSource)) {
/* 50:68 */         return inst.getOrderFlag();
/* 51:   */       }
/* 52:   */     }
/* 53:70 */     return produceSource;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static String getProduceSource(String orderFlag)
/* 57:   */   {
/* 58:74 */     for (OrderCenterOrderFlagEnum inst : ) {
/* 59:75 */       if (orderFlag.equals(inst.orderFlag)) {
/* 60:76 */         return inst.getProduceSource();
/* 61:   */       }
/* 62:   */     }
/* 63:78 */     return orderFlag;
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.OrderCenterOrderFlagEnum
 * JD-Core Version:    0.7.0.1
 */