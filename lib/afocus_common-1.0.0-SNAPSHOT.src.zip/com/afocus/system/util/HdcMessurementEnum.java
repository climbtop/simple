/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum HdcMessurementEnum
/*  4:   */ {
/*  5: 4 */   ORDER_BY_DATE(0, "test_time"),  ORDER_BY_NAME(1, "name");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private HdcMessurementEnum(int id, String name)
/* 11:   */   {
/* 12:12 */     this.id = id;
/* 13:13 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:17 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setId(int id)
/* 22:   */   {
/* 23:20 */     this.id = id;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName()
/* 27:   */   {
/* 28:23 */     return this.name;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setName(String name)
/* 32:   */   {
/* 33:26 */     this.name = name;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static HdcMessurementEnum getById(int id)
/* 37:   */   {
/* 38:30 */     HdcMessurementEnum[] enums = values();
/* 39:31 */     for (HdcMessurementEnum enm : enums) {
/* 40:32 */       if (enm.getId() == id) {
/* 41:33 */         return enm;
/* 42:   */       }
/* 43:   */     }
/* 44:36 */     return null;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.HdcMessurementEnum
 * JD-Core Version:    0.7.0.1
 */