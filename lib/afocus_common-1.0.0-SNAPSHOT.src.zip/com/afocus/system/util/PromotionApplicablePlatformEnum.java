/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum PromotionApplicablePlatformEnum
/*  4:   */ {
/*  5:10 */   NEW_MALL(3, "官网"),  MOBILE(4, "移动官网");
/*  6:   */   
/*  7:   */   int id;
/*  8:   */   String name;
/*  9:   */   
/* 10:   */   private PromotionApplicablePlatformEnum(int id, String name)
/* 11:   */   {
/* 12:16 */     this.id = id;
/* 13:17 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:21 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:25 */     return this.name;
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.PromotionApplicablePlatformEnum
 * JD-Core Version:    0.7.0.1
 */