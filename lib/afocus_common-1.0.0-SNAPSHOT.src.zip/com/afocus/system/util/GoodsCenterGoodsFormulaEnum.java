/*   1:    */ package com.afocus.system.util;
/*   2:    */ 
/*   3:    */ public enum GoodsCenterGoodsFormulaEnum
/*   4:    */ {
/*   5: 12 */   FORMULA_01(1, "片剂"),  FORMULA_02(2, "缓释片"),  FORMULA_03(3, "控释片"),  FORMULA_04(4, "肠溶片"),  FORMULA_05(5, "薄膜衣片"),  FORMULA_06(6, "分散片"),  FORMULA_07(7, "咀嚼片"),  FORMULA_08(8, "泡腾片"),  FORMULA_09(9, "软胶囊"),  FORMULA_10(10, "胶囊"),  FORMULA_11(11, "散剂"),  FORMULA_12(12, "胶剂"),  FORMULA_13(13, "丸剂"),  FORMULA_14(14, "水丸"),  FORMULA_15(15, "糊丸"),  FORMULA_16(16, "滴丸"),  FORMULA_17(17, "胶丸"),  FORMULA_18(18, "微丸"),  FORMULA_19(19, "大蜜丸"),  FORMULA_20(20, "小蜜丸"),  FORMULA_21(21, "水蜜丸"),  FORMULA_22(22, "浓缩丸"),  FORMULA_23(23, "颗粒剂"),  FORMULA_24(24, "煎膏剂"),  FORMULA_25(25, "口服溶液剂"),  FORMULA_26(26, "口服乳剂"),  FORMULA_27(27, "糖浆剂"),  FORMULA_28(28, "混悬剂"),  FORMULA_29(29, "合剂"),  FORMULA_30(30, "酒剂"),  FORMULA_31(31, "酊剂"),  FORMULA_32(32, "滴剂"),  FORMULA_33(33, "露剂"),  FORMULA_34(34, "锭剂"),  FORMULA_35(35, "茶剂"),  FORMULA_36(36, "膜剂"),  FORMULA_37(37, "滴鼻剂"),  FORMULA_38(38, "滴耳剂"),  FORMULA_39(39, "滴眼液"),  FORMULA_40(40, "眼膏剂"),  FORMULA_41(41, "软膏剂"),  FORMULA_42(42, "乳膏剂"),  FORMULA_43(43, "贴膏剂"),  FORMULA_44(44, "乳胶剂"),  FORMULA_45(45, "凝胶剂"),  FORMULA_46(46, "搽剂"),  FORMULA_47(47, "洗剂"),  FORMULA_48(48, "栓剂"),  FORMULA_49(49, "吸入剂"),  FORMULA_50(50, "喷雾剂"),  FORMULA_51(51, "气雾剂"),  FORMULA_52(52, "溶液剂"),  FORMULA_53(53, "灌肠剂"),  FORMULA_54(54, "熏剂"),  FORMULA_55(55, "药用辅料"),  FORMULA_56(56, "原料药"),  FORMULA_57(57, "其他");
/*   6:    */   
/*   7:    */   int id;
/*   8:    */   String name;
/*   9:    */   
/*  10:    */   private GoodsCenterGoodsFormulaEnum(int id, String name)
/*  11:    */   {
/*  12: 75 */     this.id = id;
/*  13: 76 */     this.name = name;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public int getId()
/*  17:    */   {
/*  18: 80 */     return this.id;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setId(int id)
/*  22:    */   {
/*  23: 84 */     this.id = id;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public String getName()
/*  27:    */   {
/*  28: 88 */     return this.name;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setName(String name)
/*  32:    */   {
/*  33: 92 */     this.name = name;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static String getNameById(int id)
/*  37:    */   {
/*  38: 96 */     for (GoodsCenterGoodsFormulaEnum enu : ) {
/*  39: 97 */       if (id == enu.getId()) {
/*  40: 98 */         return enu.getName();
/*  41:    */       }
/*  42:    */     }
/*  43:101 */     return null;
/*  44:    */   }
/*  45:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.GoodsCenterGoodsFormulaEnum
 * JD-Core Version:    0.7.0.1
 */