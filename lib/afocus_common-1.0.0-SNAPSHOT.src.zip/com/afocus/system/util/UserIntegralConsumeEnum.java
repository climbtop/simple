/*  1:   */ package com.afocus.system.util;
/*  2:   */ 
/*  3:   */ public enum UserIntegralConsumeEnum
/*  4:   */ {
/*  5: 9 */   TO_COUPON(1, "积分兑换优惠券"),  TO_GOODS(2, "积分兑换商品"),  JOIN_MONEY_TO_GOODS(3, "金额+积分兑换商品"),  TO_MONEY(4, "积分兑换金额"),  TO_ORDER(5, "抵消订单金额"),  TO_CDKEY(6, "积分兑换保险激活码");
/*  6:   */   
/*  7:   */   private int id;
/*  8:   */   private String name;
/*  9:   */   
/* 10:   */   private UserIntegralConsumeEnum(int id, String name)
/* 11:   */   {
/* 12:21 */     this.id = id;
/* 13:22 */     this.name = name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getId()
/* 17:   */   {
/* 18:26 */     return this.id;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getName()
/* 22:   */   {
/* 23:30 */     return this.name;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setName(String name)
/* 27:   */   {
/* 28:34 */     this.name = name;
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.util.UserIntegralConsumeEnum
 * JD-Core Version:    0.7.0.1
 */