/*  1:   */ package com.afocus.system.web.exception;
/*  2:   */ 
/*  3:   */ public class AppBaseException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 3728403084326926290L;
/*  7:   */   
/*  8:   */   public AppBaseException() {}
/*  9:   */   
/* 10:   */   public AppBaseException(String message)
/* 11:   */   {
/* 12:23 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public AppBaseException(String message, Throwable cause)
/* 16:   */   {
/* 17:32 */     super(message, cause);
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.exception.AppBaseException
 * JD-Core Version:    0.7.0.1
 */