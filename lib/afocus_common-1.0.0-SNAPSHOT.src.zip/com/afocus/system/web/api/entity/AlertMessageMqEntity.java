/*  1:   */ package com.afocus.system.web.api.entity;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class AlertMessageMqEntity
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = -8101208428250838857L;
/*  9:   */   private int sender;
/* 10:   */   private int receiver;
/* 11:   */   private String content;
/* 12:   */   
/* 13:   */   public int getSender()
/* 14:   */   {
/* 15:15 */     return this.sender;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setSender(int sender)
/* 19:   */   {
/* 20:19 */     this.sender = sender;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public int getReceiver()
/* 24:   */   {
/* 25:27 */     return this.receiver;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setReceiver(int receiver)
/* 29:   */   {
/* 30:31 */     this.receiver = receiver;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getContent()
/* 34:   */   {
/* 35:35 */     return this.content;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setContent(String content)
/* 39:   */   {
/* 40:39 */     this.content = content;
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.api.entity.AlertMessageMqEntity
 * JD-Core Version:    0.7.0.1
 */