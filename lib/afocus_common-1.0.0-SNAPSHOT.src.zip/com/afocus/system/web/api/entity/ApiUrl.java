/*  1:   */ package com.afocus.system.web.api.entity;
/*  2:   */ 
/*  3:   */ public class ApiUrl
/*  4:   */ {
/*  5:   */   private String url;
/*  6:   */   private String[] keyvals;
/*  7:   */   
/*  8:   */   public ApiUrl(String url, String[] keyvals)
/*  9:   */   {
/* 10:13 */     this.url = url;
/* 11:14 */     this.keyvals = keyvals;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getUrl()
/* 15:   */   {
/* 16:18 */     return this.url;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setUrl(String url)
/* 20:   */   {
/* 21:22 */     this.url = url;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String[] getKeyvals()
/* 25:   */   {
/* 26:26 */     return this.keyvals;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setKeyvals(String[] keyvals)
/* 30:   */   {
/* 31:30 */     this.keyvals = keyvals;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.api.entity.ApiUrl
 * JD-Core Version:    0.7.0.1
 */