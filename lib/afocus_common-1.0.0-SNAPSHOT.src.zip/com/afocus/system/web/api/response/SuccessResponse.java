/*  1:   */ package com.afocus.system.web.api.response;
/*  2:   */ 
/*  3:   */ public class SuccessResponse
/*  4:   */   extends Response
/*  5:   */ {
/*  6:12 */   private Object data = null;
/*  7:   */   
/*  8:   */   public SuccessResponse()
/*  9:   */   {
/* 10:15 */     this.code = Response.ApiResultEnum.SUCCESS.getId();
/* 11:   */   }
/* 12:   */   
/* 13:   */   public SuccessResponse(String tip)
/* 14:   */   {
/* 15:18 */     this.code = Response.ApiResultEnum.SUCCESS.getId();
/* 16:19 */     this.tip = tip;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String toString()
/* 20:   */   {
/* 21:27 */     StringBuilder builder = new StringBuilder();
/* 22:28 */     builder.append("{");
/* 23:29 */     builder.append("\"tip\":\"").append(this.tip).append("\",");
/* 24:30 */     builder.append("\"code\":").append(this.code);
/* 25:31 */     builder.append("}");
/* 26:32 */     return builder.toString();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setCode(int code)
/* 30:   */   {
/* 31:41 */     this.code = code;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Object getData()
/* 35:   */   {
/* 36:44 */     return this.data;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setData(Object data)
/* 40:   */   {
/* 41:47 */     this.data = data;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.api.response.SuccessResponse
 * JD-Core Version:    0.7.0.1
 */