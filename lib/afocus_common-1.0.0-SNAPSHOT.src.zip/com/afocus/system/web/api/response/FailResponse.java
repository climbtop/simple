/*  1:   */ package com.afocus.system.web.api.response;
/*  2:   */ 
/*  3:   */ public class FailResponse
/*  4:   */   extends Response
/*  5:   */ {
/*  6:   */   public FailResponse()
/*  7:   */   {
/*  8:13 */     this.code = Response.ApiResultEnum.FAIL.getId();
/*  9:   */   }
/* 10:   */   
/* 11:   */   public FailResponse(String tip)
/* 12:   */   {
/* 13:16 */     this.code = Response.ApiResultEnum.FAIL.getId();
/* 14:17 */     this.tip = tip;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String toString()
/* 18:   */   {
/* 19:25 */     StringBuilder builder = new StringBuilder();
/* 20:26 */     builder.append("{");
/* 21:27 */     builder.append("\"tip\":\"").append(this.tip).append("\",");
/* 22:28 */     builder.append("\"code\":").append(this.code);
/* 23:29 */     builder.append("}");
/* 24:30 */     return builder.toString();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setCode(int code)
/* 28:   */   {
/* 29:39 */     this.code = code;
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.api.response.FailResponse
 * JD-Core Version:    0.7.0.1
 */