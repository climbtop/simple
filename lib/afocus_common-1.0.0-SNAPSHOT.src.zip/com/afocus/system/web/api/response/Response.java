/*   1:    */ package com.afocus.system.web.api.response;
/*   2:    */ 
/*   3:    */ import com.alibaba.fastjson.JSON;
/*   4:    */ import java.io.Serializable;
/*   5:    */ 
/*   6:    */ public abstract class Response
/*   7:    */   implements Serializable
/*   8:    */ {
/*   9:    */   private static final long serialVersionUID = 2320169320776510183L;
/*  10:    */   protected String tip;
/*  11:    */   protected int code;
/*  12:    */   
/*  13:    */   public Response()
/*  14:    */   {
/*  15: 17 */     this.tip = ApiResultEnum.SUCCESS.getName();
/*  16:    */     
/*  17: 19 */     this.code = ApiResultEnum.SUCCESS.getId();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public String getTip()
/*  21:    */   {
/*  22: 25 */     return this.tip;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void setTip(String tip)
/*  26:    */   {
/*  27: 33 */     this.tip = tip;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public int getCode()
/*  31:    */   {
/*  32: 40 */     return this.code;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setCode(int code)
/*  36:    */   {
/*  37: 48 */     this.code = code;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static enum ResultParamEnum
/*  41:    */   {
/*  42: 52 */     code("code"),  tip("tip");
/*  43:    */     
/*  44:    */     private String paramName;
/*  45:    */     
/*  46:    */     private ResultParamEnum(String name)
/*  47:    */     {
/*  48: 58 */       this.paramName = name;
/*  49:    */     }
/*  50:    */     
/*  51:    */     public String getParamName()
/*  52:    */     {
/*  53: 62 */       return this.paramName;
/*  54:    */     }
/*  55:    */     
/*  56:    */     public void setParamName(String paramName)
/*  57:    */     {
/*  58: 66 */       this.paramName = paramName;
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static enum ApiResultEnum
/*  63:    */   {
/*  64: 71 */     SUCCESS(1, "请求成功"),  FAIL(0, "请求失败"),  RESULT_EMPTY(2, "查询结果为空"),  IP_ILLEGAL(204, "ip验证不通过"),  DATA_EMPTY(203, "没有对应的数据"),  UUID_ERROR(205, "uuid或者token错误");
/*  65:    */     
/*  66:    */     private int id;
/*  67:    */     private String name;
/*  68:    */     
/*  69:    */     private ApiResultEnum(int id, String name)
/*  70:    */     {
/*  71: 81 */       this.id = id;
/*  72: 82 */       this.name = name;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public int getId()
/*  76:    */     {
/*  77: 86 */       return this.id;
/*  78:    */     }
/*  79:    */     
/*  80:    */     public void setId(int id)
/*  81:    */     {
/*  82: 90 */       this.id = id;
/*  83:    */     }
/*  84:    */     
/*  85:    */     public String getName()
/*  86:    */     {
/*  87: 94 */       return this.name;
/*  88:    */     }
/*  89:    */     
/*  90:    */     public void setName(String name)
/*  91:    */     {
/*  92: 98 */       this.name = name;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public static String valueOf(int value)
/*  96:    */     {
/*  97:101 */       for (ApiResultEnum inst : ) {
/*  98:102 */         if (value == inst.id) {
/*  99:103 */           return inst.getName();
/* 100:    */         }
/* 101:    */       }
/* 102:105 */       throw new IllegalArgumentException("不支持的常量：" + value);
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   public String toString()
/* 107:    */   {
/* 108:112 */     return JSON.toJSONString(this);
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.api.response.Response
 * JD-Core Version:    0.7.0.1
 */