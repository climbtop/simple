/*  1:   */ package com.afocus.system.web.api.request;
/*  2:   */ 
/*  3:   */ import com.afocus.system.util.ApiUrlParamEnum;
/*  4:   */ import com.afocus.system.web.exception.RequestIllegalException;
/*  5:   */ import com.alibaba.fastjson.JSON;
/*  6:   */ import java.io.Serializable;
/*  7:   */ import javax.servlet.http.HttpServletRequest;
/*  8:   */ 
/*  9:   */ public abstract class Request
/* 10:   */   implements Serializable
/* 11:   */ {
/* 12:   */   private static final long serialVersionUID = -8504019808196767010L;
/* 13:22 */   protected String token = "";
/* 14:24 */   protected String uuid = "";
/* 15:   */   
/* 16:   */   public abstract void parse(HttpServletRequest paramHttpServletRequest);
/* 17:   */   
/* 18:   */   protected void parseFixedParams(HttpServletRequest request)
/* 19:   */   {
/* 20:37 */     this.token = request.getParameter(ApiUrlParamEnum.token.getParamName());
/* 21:38 */     this.uuid = request.getParameter(ApiUrlParamEnum.uuId.getParamName());
/* 22:39 */     if (("".equals(this.token)) || (this.token.trim().length() < 1)) {
/* 23:40 */       throw new RequestIllegalException("exception token:" + this.token);
/* 24:   */     }
/* 25:42 */     setToken(this.token);
/* 26:43 */     if (("".equals(this.uuid)) || (this.uuid.trim().length() < 1)) {
/* 27:44 */       throw new RequestIllegalException("exception uuid:" + this.uuid);
/* 28:   */     }
/* 29:46 */     setUuid(this.uuid);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getToken()
/* 33:   */   {
/* 34:53 */     return this.token;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setToken(String token)
/* 38:   */   {
/* 39:60 */     this.token = token;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getUuid()
/* 43:   */   {
/* 44:67 */     return this.uuid;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setUuid(String uuid)
/* 48:   */   {
/* 49:74 */     this.uuid = uuid;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String toString()
/* 53:   */   {
/* 54:80 */     return JSON.toJSONString(this);
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\XYSM\Desktop\afocus_common-1.0.0-SNAPSHOT.jar
 * Qualified Name:     com.afocus.system.web.api.request.Request
 * JD-Core Version:    0.7.0.1
 */